"""Reaction-path algorithms shared by the Qemica engine and user input scripts.

These are the SAME functions the sidecar's IRC and NEB actions run — extracted here so
the Method screen's generated input scripts can import them genuinely (`from quchemy.paths
import irc_steepest_descent, neb_relax`) and a hand-edited script executes the identical
algorithm the recipe would.

Both take an `energy_grad` callable seam so any engine can drive them:

    energy_grad(coords) -> (energy_hartree, grad_hartree_per_bohr, converged)

where `coords` is an (natoms, 3) array in Å and the gradient is (natoms, 3) in
Hartree/Bohr (PySCF's native gradient unit). Warnings and per-iteration progress are
surfaced through optional callbacks so library users and the sidecar share one code path.
"""
from __future__ import annotations

from typing import Any, Callable, Optional

BOHR_TO_ANG: float = 0.529177210903

EnergyGrad = Callable[[Any], tuple[float, Any, bool]]

## Gradient norm (Hartree/Å) below which an IRC direction is treated as having reached a
## basin. Anything else means the walk stopped because it ran out of steps.
_BASIN_GRAD_TOL: float = 1e-4
## Energy rise (Hartree) tolerated before a steepest-descent step is rejected as an
## overshoot — ~0.006 kcal/mol, i.e. numerical noise only.
_UPHILL_TOL_HA: float = 1e-5
## Floor on the backtracked step (Å): below this, accept the point and move on rather than
## grinding the step to zero against a pathological surface.
_MIN_STEP_ANG: float = 0.005
## Largest per-image NEB force (Hartree/Å) below which the band counts as relaxed.
_NEB_FORCE_TOL: float = 5e-3
## Relative worsening of the band's max force that counts as an overshoot rather than noise.
_NEB_WORSE_TOL: float = 1e-3
## Floor on the adaptive NEB learning rate — below this, the surface is the problem, not the step.
_NEB_MIN_STEP: float = 1e-3


def irc_steepest_descent(
    energy_grad: EnergyGrad,
    coords0,
    mode,
    *,
    nsteps: int = 12,
    step_ang: float = 0.10,
    kick_ang: float = 0.15,
    on_warn: Optional[Callable[[str], None]] = None,
) -> list[tuple[float, float]]:
    """A steepest-descent reaction path from a transition state, in both directions along
    the imaginary normal mode `mode` (an (natoms, 3) Cartesian displacement). Returns
    (coordinate, energy) points along a signed arc-length coordinate (Å), TS at 0, sorted.

    This is the minimum-energy-path *approximation* (damped Cartesian steepest descent),
    not an exact mass-weighted Gonzalez–Schlegel IRC — enough to confirm a TS rolls down
    to two distinct basins and to draw the profile.
    """
    import numpy as np

    warn = on_warn if on_warn is not None else (lambda _m: None)
    base = np.asarray(coords0, dtype=float)
    unit = np.asarray(mode, dtype=float)
    norm = np.linalg.norm(unit)
    if norm > 0:
        unit = unit / norm

    points: list[tuple[float, float, Any]] = []
    e0, _g0, conv0 = energy_grad(base)
    if not conv0:
        warn("SCF not converged at IRC point s=0.00 Å")
    points.append((0.0, float(e0), base.copy()))
    # Per-direction outcome, for the caller to record and warn on: a path that merely ran
    # out of steps is NOT a path that reached a product basin, and the two used to be
    # indistinguishable in the result.
    reached_basin = {1.0: False, -1.0: False}
    final_gradient = {1.0: float("nan"), -1.0: float("nan")}

    for direction in (1.0, -1.0):
        x = base + direction * kick_ang * unit  # step off the saddle along the imag mode
        s = direction * kick_ang
        step = float(step_ang)
        # Last ACCEPTED point in this direction; a rejected uphill step retries from it.
        x_acc = None
        g_acc = None
        gn_acc = 0.0
        s_acc = 0.0
        e_acc = float(e0)
        for _ in range(nsteps):
            e, g, conv = energy_grad(x)
            if not conv:
                warn("SCF not converged at IRC point s=%.2f Å" % s)
            g_ang = np.asarray(g, dtype=float) / BOHR_TO_ANG  # Hartree/Å
            gn = float(np.linalg.norm(g_ang))
            final_gradient[direction] = gn

            # A steepest-descent path from a saddle DESCENDS monotonically, by
            # construction. A fixed-length step in a curving valley overshoots the floor
            # and climbs the far wall, putting spurious humps of a few kcal/mol into the
            # profile — which a reader takes for shoulders or hidden intermediates.
            # Reject the climb rather than recording it: halve the step and retry from the
            # last accepted point. Standard backtracking; it costs only the rejected
            # energy evaluations, and the returned path is monotonic by construction.
            if x_acc is not None and float(e) > e_acc + _UPHILL_TOL_HA:
                if step > _MIN_STEP_ANG:
                    step *= 0.5
                    x = x_acc - step * g_acc / gn_acc
                    s = s_acc + direction * step
                    continue
                # Backtracked to the floor step and STILL cannot descend: this is the
                # bottom of the valley, not a failure. Stop here rather than recording a
                # climb — the last accepted point is the basin.
                reached_basin[direction] = True
                final_gradient[direction] = gn_acc
                break

            points.append((s, float(e), np.asarray(x, dtype=float).copy()))
            if gn < _BASIN_GRAD_TOL:
                reached_basin[direction] = True
                break
            x_acc = np.asarray(x, dtype=float).copy()
            g_acc, gn_acc, s_acc, e_acc = g_ang, gn, s, float(e)
            x = x - step * g_ang / gn
            s += direction * step

    points.sort(key=lambda p: p[0])
    return points, reached_basin, final_gradient


def neb_tangent(r_prev, r_cur, r_next, e_prev, e_cur, e_next):
    """Improved upwind tangent at an interior NEB image (Henkelman & Jónsson 2000).
    Coords are (natoms, 3) arrays; returns a unit tangent of the same shape."""
    import numpy as np

    tau_plus = r_next - r_cur
    tau_minus = r_cur - r_prev
    if e_next > e_cur > e_prev:
        tau = tau_plus
    elif e_next < e_cur < e_prev:
        tau = tau_minus
    else:
        d1 = abs(e_next - e_cur)
        d2 = abs(e_prev - e_cur)
        dmax, dmin = max(d1, d2), min(d1, d2)
        if e_next > e_prev:
            tau = tau_plus * dmax + tau_minus * dmin
        else:
            tau = tau_plus * dmin + tau_minus * dmax
    norm = np.linalg.norm(tau)
    return tau / norm if norm > 1e-12 else tau


def _neb_forces(band, energies, grads, n_images, spring_k, climbing, climb_active):
    """Per-image NEB force: perpendicular true force + parallel spring, with the highest
    image inverting its parallel component when the climbing phase is active.

    Split out of the relaxation loop so the band's force can be measured BEFORE deciding
    whether the previous step overshot — the accept/revert test needs the same quantity the
    convergence test uses, and the raw gradient is not it.
    """
    import numpy as np

    i_max = int(np.argmax(energies))
    forces = [np.zeros_like(np.asarray(band[0], dtype=float))] * n_images
    out = list(forces)
    for i in range(1, n_images - 1):
        tau = neb_tangent(band[i - 1], band[i], band[i + 1],
                          energies[i - 1], energies[i], energies[i + 1])
        f_true = -grads[i]
        f_par = float(np.sum(f_true * tau))
        if climbing and i == i_max and climb_active:
            out[i] = f_true - 2.0 * f_par * tau
        else:
            f_perp = f_true - f_par * tau
            d_next = np.linalg.norm(band[i + 1] - band[i])
            d_prev = np.linalg.norm(band[i] - band[i - 1])
            out[i] = f_perp + spring_k * (d_next - d_prev) * tau
    return out


def neb_relax(
    energy_grad: EnergyGrad,
    reactant,
    product,
    *,
    n_images: int = 7,
    max_iter: int = 10,
    spring_k: float = 0.5,
    step: float = 0.5,
    max_move: float = 0.2,
    climbing: bool = True,
    e_react: Optional[float] = None,
    e_prod: Optional[float] = None,
    on_warn: Optional[Callable[[str], None]] = None,
    on_iter: Optional[Callable[[int, float], None]] = None,
):
    """Improved-tangent nudged elastic band (Henkelman 2000) between `reactant` and
    `product` ((natoms, 3) Å arrays, same atom order): each interior image feels the
    PERPENDICULAR true force plus a PARALLEL spring force, so it slides onto the
    minimum-energy path without sliding down it. With `climbing` the highest image
    inverts its parallel force to climb onto the saddle (a transition-state estimate,
    active after max_iter // 3 iterations). Returns (band, energies) with the endpoint
    energies included; a real but lightweight chain-of-states path — Cartesian (not
    mass-weighted) steepest-descent image moves.

    `e_react` / `e_prod` skip re-evaluating an endpoint whose energy the caller already
    paid for; `on_iter(iteration, e_max)` reports per-iteration progress.
    """
    import numpy as np

    warn = on_warn if on_warn is not None else (lambda _m: None)
    r0 = np.asarray(reactant, dtype=float)
    rp = np.asarray(product, dtype=float)
    n_images = int(max(3, n_images))
    climb_after = max(1, int(max_iter) // 3)

    if e_react is None:
        e_react, _g, conv = energy_grad(r0)
        if not conv:
            warn("NEB: the reactant-geometry SCF did not converge — the band end is unreliable")
    if e_prod is None:
        e_prod, _g, conv = energy_grad(rp)
        if not conv:
            warn("NEB: the product-geometry SCF did not converge — the band end is unreliable")

    band = [(1.0 - t) * r0 + t * rp for t in np.linspace(0.0, 1.0, n_images)]
    energies = [float(e_react)] + [0.0] * (n_images - 2) + [float(e_prod)]

    converged = False
    max_force = float("inf")
    # Adaptive learning rate. This is plain steepest descent, so a step that is too large
    # for the local curvature makes the band oscillate across the valley instead of settling
    # — measured on a curved-valley potential at the shipped default (0.5), the largest
    # image force stalls at ~1.4 Hartree/Å through 1200 iterations and never converges,
    # while the same band relaxes cleanly at 0.1. Rather than asking the user to guess a
    # rate, detect the overshoot and back off: when an iteration leaves the band WORSE than
    # the last one, restore the previous band and halve the step. Sustained improvement
    # grows it back, so a well-conditioned band is not left crawling.
    step0 = float(step)
    prev_band = None
    prev_energies = None
    prev_grads = None
    prev_forces = None
    prev_force = float("inf")
    good_streak = 0
    reuse = False          # forces already in hand for the current band (after a revert)
    it = 0
    iters_used = 0
    while it < int(max_iter):
        if not reuse:
            max_force = 0.0
            grads = [None] * n_images
            for i in range(1, n_images - 1):
                e_i, g_i, conv_i = energy_grad(band[i])
                energies[i] = float(e_i)
                grads[i] = np.asarray(g_i, dtype=float) / BOHR_TO_ANG  # Hartree/Å
                if not conv_i:
                    warn("NEB: SCF not converged at image %d (iter %d)" % (i, it + 1))
            # The band's own force measure — the PROJECTED NEB force (perpendicular true
            # force + spring, or the inverted parallel force on the climbing image), not
            # the raw gradient: along the path the parallel component is large by
            # construction and says nothing about whether the band has settled.
            forces = _neb_forces(band, energies, grads, n_images, spring_k,
                                 climbing, iters_used >= climb_after)
            max_force = max(float(np.max(np.abs(f))) for f in forces[1:-1])
            it += 1
            iters_used = it
            # Report progress per BAND EVALUATION, not per accepted move: a band that is
            # already relaxed performs no move at all, and a caller driving a progress bar
            # still needs to know the band was looked at.
            if on_iter is not None:
                on_iter(iters_used, float(np.max(energies)))
        reuse = False

        # Did the last move make things worse? Then it overshot: undo it, shrink the step,
        # and retry from the restored band with the forces we already paid for.
        if (prev_band is not None and max_force > prev_force * (1.0 + _NEB_WORSE_TOL)
                and step > _NEB_MIN_STEP):
            band = [b.copy() for b in prev_band]
            energies = list(prev_energies)
            grads = list(prev_grads)
            forces = list(prev_forces)
            max_force = prev_force
            step = max(step * 0.5, _NEB_MIN_STEP)
            good_streak = 0
            reuse = True
        else:
            if prev_band is not None and max_force < prev_force:
                good_streak += 1
                # Three clean iterations in a row: the step is too timid for this surface.
                if good_streak >= 3 and step < step0:
                    step = min(step * 1.5, step0)
                    good_streak = 0
            prev_band = [b.copy() for b in band]
            prev_energies = list(energies)
            prev_grads = list(grads)
            prev_forces = list(forces)
            prev_force = max_force

        if max_force < _NEB_FORCE_TOL:
            converged = True
            break

        new_band = [band[0]] + [None] * (n_images - 2) + [band[-1]]
        for i in range(1, n_images - 1):
            move = np.clip(step * forces[i], -max_move, max_move)
            new_band[i] = band[i] + move
        band = new_band
        # A band that has stopped moving IS converged, and the loop used to have no way to
        # know or say so: it ran a fixed counter and returned, so a NEB result carried the
        # reactant SCF's convergence flag while its path could be arbitrarily far from a
        # minimum-energy path. Exit early when the largest image force falls below
        # tolerance, and report which happened.

    # Final energies on the relaxed interior images (the moves above shifted them).
    for i in range(1, n_images - 1):
        e_i, _g, _conv = energy_grad(band[i])
        energies[i] = float(e_i)
    energies[0] = float(e_react)
    energies[-1] = float(e_prod)
    return band, energies, converged, max_force
