"""Qubit-wise commuting Pauli term grouping for measurement optimization."""

from __future__ import annotations

from openfermion import QubitOperator


def qubitwise_commute(term_a: tuple, term_b: tuple) -> bool:
    """Check if two Pauli terms are qubit-wise commuting (QWC).

    Two Pauli terms QWC if, on every qubit, they either share the same
    Pauli operator or at least one acts as identity.

    Parameters
    ----------
    term_a, term_b : tuple of (int, str)
        Pauli terms as tuples of (qubit_index, pauli_label).

    Returns
    -------
    bool
        True if the terms qubit-wise commute.
    """
    paulis_a = dict(term_a)
    paulis_b = dict(term_b)

    for qubit in set(paulis_a) & set(paulis_b):
        if paulis_a[qubit] != paulis_b[qubit]:
            return False
    return True


def group_commuting_terms(qubit_op: QubitOperator) -> list[QubitOperator]:
    """Group Pauli terms into qubit-wise commuting (QWC) groups.

    Uses a greedy sorted-insertion algorithm: sort terms by Pauli weight
    (number of non-identity qubits) descending, then insert each into
    the first compatible group.

    Parameters
    ----------
    qubit_op : QubitOperator
        The qubit operator to group.

    Returns
    -------
    list[QubitOperator]
        List of QubitOperators, each containing QWC terms.
    """
    # Separate identity and non-identity terms
    terms = []
    identity_coeff = 0.0

    for term, coeff in qubit_op.terms.items():
        if not term:
            identity_coeff = coeff
        else:
            terms.append((term, coeff))

    # Sort by Pauli weight descending (heavier terms first → better packing)
    terms.sort(key=lambda x: len(x[0]), reverse=True)

    groups: list[list[tuple]] = []
    group_terms_cache: list[list[tuple]] = []  # track terms per group for QWC check

    for term, coeff in terms:
        placed = False
        for g_idx, group in enumerate(groups):
            # Check QWC with all terms in the group
            if all(qubitwise_commute(term, existing_term) for existing_term, _ in group):
                group.append((term, coeff))
                placed = True
                break

        if not placed:
            groups.append([(term, coeff)])

    # Convert groups to QubitOperators
    result = []

    # Identity as its own group if present
    if abs(identity_coeff) > 1e-15:
        result.append(QubitOperator((), identity_coeff))

    for group in groups:
        op = QubitOperator()
        for term, coeff in group:
            op += QubitOperator(term, coeff)
        result.append(op)

    return result
