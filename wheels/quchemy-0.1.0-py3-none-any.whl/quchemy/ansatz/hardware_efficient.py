"""Hardware-efficient ansatz (HEA) generation."""

from __future__ import annotations

from ..circuit.circuit import ParameterizedCircuit
from ..circuit.gates import RY, RZ, CNOT


def make_hardware_efficient_ansatz(
    num_qubits: int,
    reps: int = 3,
    entanglement: str = "linear",
    rotation_gates: tuple[str, ...] = ("RY", "RZ"),
) -> ParameterizedCircuit:
    """Build a hardware-efficient ansatz circuit.

    Structure per layer:
    - Rotation block: specified rotation gates on each qubit
    - Entangling block: CNOT pattern between qubits

    Final rotation layer after all entangling layers.

    Parameters
    ----------
    num_qubits : int
        Number of qubits.
    reps : int
        Number of entangling layers.
    entanglement : str
        'linear' (nearest-neighbor), 'full' (all pairs), or 'circular' (linear + wrap).
    rotation_gates : tuple[str, ...]
        Rotation gate types per qubit per layer (default: RY, RZ).

    Returns
    -------
    ParameterizedCircuit
        The hardware-efficient ansatz.
    """
    circuit = ParameterizedCircuit(num_qubits)
    gate_factories = {"RY": RY, "RZ": RZ}

    for layer in range(reps + 1):
        # Rotation block
        for q in range(num_qubits):
            for gate_name in rotation_gates:
                factory = gate_factories[gate_name]
                p_idx = circuit.allocate_parameter()
                circuit.append(factory(q, param_index=p_idx))

        # Entangling block (skip after last rotation layer)
        if layer < reps:
            if entanglement == "linear":
                for q in range(num_qubits - 1):
                    circuit.append(CNOT(q, q + 1))
            elif entanglement == "circular":
                for q in range(num_qubits - 1):
                    circuit.append(CNOT(q, q + 1))
                if num_qubits > 2:
                    circuit.append(CNOT(num_qubits - 1, 0))
            elif entanglement == "full":
                for q0 in range(num_qubits):
                    for q1 in range(q0 + 1, num_qubits):
                        circuit.append(CNOT(q0, q1))
            else:
                raise ValueError(
                    f"Unknown entanglement: {entanglement}. "
                    "Use 'linear', 'full', or 'circular'."
                )

    return circuit
