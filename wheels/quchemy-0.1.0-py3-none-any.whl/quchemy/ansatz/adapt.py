"""ADAPT-VQE: Iterative ansatz construction with operator pool."""

from __future__ import annotations

from typing import Optional, Callable

import numpy as np
from openfermion import (
    QubitOperator,
    FermionOperator,
    jordan_wigner,
    bravyi_kitaev,
    hermitian_conjugated,
)

from ..circuit.circuit import ParameterizedCircuit
from ..circuit.gates import Gate, H, X, RX, RZ, CNOT
from ..solver.expectation import statevector_simulate, compute_expectation


class AdaptVQE:
    """ADAPT-VQE: build the ansatz iteratively from an operator pool.

    At each iteration, compute the gradient of the energy with respect to
    each pool operator, select the one with the largest gradient, append
    it to the circuit, and re-optimize all parameters.

    Parameters
    ----------
    qubit_hamiltonian : QubitOperator
        The qubit Hamiltonian to minimize.
    operator_pool : list[QubitOperator]
        Pool of anti-Hermitian qubit operators to select from.
    num_qubits : int
        Number of qubits.
    initial_state : ParameterizedCircuit, optional
        Initial state preparation (e.g., HF reference).
    optimizer : str
        SciPy optimizer name for parameter optimization.
    max_iterations : int
        Maximum ADAPT iterations.
    gradient_threshold : float
        Stop when max gradient falls below this.
    max_vqe_iterations : int
        Max iterations for each VQE sub-optimization.
    callback : callable, optional
        Called with (iteration, energy, max_gradient) each step.
    """

    def __init__(
        self,
        qubit_hamiltonian: QubitOperator,
        operator_pool: list[QubitOperator],
        num_qubits: int,
        initial_state: Optional[ParameterizedCircuit] = None,
        optimizer: str = "COBYLA",
        max_iterations: int = 50,
        gradient_threshold: float = 1e-5,
        max_vqe_iterations: int = 200,
        callback: Optional[Callable] = None,
    ):
        self.hamiltonian = qubit_hamiltonian
        self.pool = operator_pool
        self.num_qubits = num_qubits
        self.initial_state = initial_state
        self.optimizer = optimizer
        self.max_iterations = max_iterations
        self.gradient_threshold = gradient_threshold
        self.max_vqe_iterations = max_vqe_iterations
        self.callback = callback

    def run(self) -> dict:
        """Run ADAPT-VQE.

        Returns
        -------
        dict with keys:
            energy : float
            parameters : ndarray
            circuit : ParameterizedCircuit
            iterations : int
            operator_indices : list[int]
            converged : bool
            history : list[float]
        """
        from ..solver.vqe import VQE

        # Start with initial state circuit (or empty)
        if self.initial_state is not None:
            base_circuit = ParameterizedCircuit(self.num_qubits)
            base_circuit.compose(self.initial_state)
        else:
            base_circuit = ParameterizedCircuit(self.num_qubits)

        parameters = np.array([], dtype=float)
        operator_indices = []
        history = []

        for iteration in range(self.max_iterations):
            # Simulate current state
            if len(parameters) > 0:
                state = statevector_simulate(base_circuit, parameters)
            else:
                state = statevector_simulate(base_circuit, np.array([0.0]))
                if base_circuit.num_parameters == 0:
                    state = statevector_simulate(base_circuit, np.array([]))

            # Compute gradients: grad_k = 2 * Re(<psi|[H, A_k]|psi>)
            gradients = []
            for pool_op in self.pool:
                commutator = self.hamiltonian * pool_op - pool_op * self.hamiltonian
                grad = 2.0 * abs(compute_expectation(commutator, state))
                gradients.append(grad)

            max_grad = max(gradients) if gradients else 0.0
            best_idx = int(np.argmax(gradients))

            if self.callback:
                current_energy = compute_expectation(self.hamiltonian, state)
                self.callback(iteration, current_energy, max_grad)

            # Check convergence
            if max_grad < self.gradient_threshold:
                energy = compute_expectation(self.hamiltonian, state)
                history.append(energy)
                return {
                    "energy": energy,
                    "parameters": parameters,
                    "circuit": base_circuit,
                    "iterations": iteration,
                    "operator_indices": operator_indices,
                    "converged": True,
                    "history": history,
                }

            # Append the selected operator as a Pauli exponential
            operator_indices.append(best_idx)
            selected_op = self.pool[best_idx]
            _append_operator_to_circuit(base_circuit, selected_op)

            # Re-optimize all parameters
            new_params = np.zeros(base_circuit.num_parameters)
            if len(parameters) > 0:
                new_params[: len(parameters)] = parameters

            vqe = VQE(
                ansatz=base_circuit,
                qubit_hamiltonian=self.hamiltonian,
                optimizer=self.optimizer,
                max_iterations=self.max_vqe_iterations,
                initial_parameters=new_params,
            )
            result = vqe.run()
            parameters = result.optimal_parameters
            history.append(result.energy)

        # Did not converge
        state = statevector_simulate(base_circuit, parameters)
        energy = compute_expectation(self.hamiltonian, state)
        return {
            "energy": energy,
            "parameters": parameters,
            "circuit": base_circuit,
            "iterations": self.max_iterations,
            "operator_indices": operator_indices,
            "converged": False,
            "history": history,
        }


def build_uccsd_pool(
    num_spatial_orbitals: int,
    num_electrons: int,
    mapping: str = "jordan_wigner",
) -> list[QubitOperator]:
    """Build a pool of individual single and double excitation operators.

    Parameters
    ----------
    num_spatial_orbitals : int
        Number of spatial orbitals.
    num_electrons : int
        Number of electrons.
    mapping : str
        Qubit mapping.

    Returns
    -------
    list[QubitOperator]
        Pool of anti-Hermitian qubit operators.
    """
    n_occ = num_electrons // 2
    n_spatial = num_spatial_orbitals
    pool = []

    map_fn = jordan_wigner if mapping == "jordan_wigner" else bravyi_kitaev

    # Interleaved spin-orbital ordering (2p = pα, 2p+1 = pβ) — this MUST match the
    # Hamiltonian (get_molecular_hamiltonian), the HF reference (get_hf_state) and the
    # UCCSD ansatz (OpenFermion's interleaved convention). Block ordering here would
    # silently target the wrong qubits against an interleaved Hamiltonian, so ADAPT's
    # gradients vanish and it never builds a useful ansatz.
    def sa(p: int) -> int:  # alpha spin-orbital for spatial orbital p
        return 2 * p

    def sb(p: int) -> int:  # beta spin-orbital for spatial orbital p
        return 2 * p + 1

    # Single excitations (spin-conserving)
    for i in range(n_occ):
        for a in range(n_occ, n_spatial):
            # Alpha excitation
            op = FermionOperator(f"{sa(a)}^ {sa(i)}") - FermionOperator(f"{sa(i)}^ {sa(a)}")
            pool.append(map_fn(op))
            # Beta excitation
            op = FermionOperator(f"{sb(a)}^ {sb(i)}") - FermionOperator(f"{sb(i)}^ {sb(a)}")
            pool.append(map_fn(op))

    # Double excitations (spin-conserving)
    for i in range(n_occ):
        for j in range(i, n_occ):
            for a in range(n_occ, n_spatial):
                for b in range(a, n_spatial):
                    # Alpha-alpha
                    op = (
                        FermionOperator(f"{sa(a)}^ {sa(b)}^ {sa(j)} {sa(i)}")
                        - FermionOperator(f"{sa(i)}^ {sa(j)}^ {sa(b)} {sa(a)}")
                    )
                    pool.append(map_fn(op))
                    # Beta-beta
                    op = (
                        FermionOperator(f"{sb(a)}^ {sb(b)}^ {sb(j)} {sb(i)}")
                        - FermionOperator(f"{sb(i)}^ {sb(j)}^ {sb(b)} {sb(a)}")
                    )
                    pool.append(map_fn(op))
                    # Alpha-beta
                    op = (
                        FermionOperator(f"{sa(a)}^ {sb(b)}^ {sb(j)} {sa(i)}")
                        - FermionOperator(f"{sa(i)}^ {sb(j)}^ {sb(b)} {sa(a)}")
                    )
                    pool.append(map_fn(op))

    return pool


def build_generalized_pool(
    num_qubits: int,
    mapping: str = "jordan_wigner",
) -> list[QubitOperator]:
    """Build the FULL generalized one- and two-body anti-Hermitian operator pool.

    Unlike `build_uccsd_pool` (occupied->virtual excitations only), this spans every spin-orbital
    index combination, so it is the complete generator set of the Anti-Hermitian Contracted
    Schrodinger Equation. The Contracted Quantum Eigensolver needs this full pool to reach FCI;
    the UCCSD subset has ACSE stationary points well above the ground state. Size is O(num_qubits^4)
    (~hundreds of operators for 8 qubits, ~thousands for 12), so it is meant for small systems.

    Parameters
    ----------
    num_qubits : int
        Number of spin-orbitals / qubits.
    mapping : str
        'jordan_wigner' or 'bravyi_kitaev' (must match the Hamiltonian's mapping).

    Returns
    -------
    list[QubitOperator]
        Non-empty anti-Hermitian qubit operators (duplicates / null images dropped).
    """
    map_fn = jordan_wigner if mapping == "jordan_wigner" else bravyi_kitaev
    pool: list[QubitOperator] = []

    # Generalized singles: a_p^ a_q - h.c. for p > q.
    for p in range(num_qubits):
        for q in range(p):
            qop = map_fn(FermionOperator(f"{p}^ {q}") - FermionOperator(f"{q}^ {p}"))
            if qop.terms:
                pool.append(qop)

    # Generalized doubles: a_p^ a_q^ a_r a_s - h.c. over unordered creation/annihilation pairs,
    # keeping one of each Hermitian-conjugate pair (pair index strictly decreasing).
    pairs = [(p, q) for p in range(num_qubits) for q in range(p)]
    for i, (p, q) in enumerate(pairs):
        for (r, s) in pairs[:i]:
            op = (
                FermionOperator(f"{p}^ {q}^ {r} {s}")
                - FermionOperator(f"{s}^ {r}^ {q} {p}")
            )
            qop = map_fn(op)
            if qop.terms:
                pool.append(qop)

    return pool


def _append_operator_to_circuit(
    circuit: ParameterizedCircuit,
    qubit_op: QubitOperator,
) -> None:
    """Append exp(theta * A) to the circuit for an anti-Hermitian operator A."""
    param_idx = circuit.allocate_parameter()

    for term, coeff in qubit_op.terms.items():
        if not term:
            continue

        qubits = []
        paulis = []
        for qubit, pauli in sorted(term):
            qubits.append(qubit)
            paulis.append(pauli)

        # Basis rotation
        for q, p in zip(qubits, paulis):
            if p == "X":
                circuit.append(H(q))
            elif p == "Y":
                circuit.append(RX(q, angle=np.pi / 2))

        # CNOT staircase
        for i in range(len(qubits) - 1):
            circuit.append(CNOT(qubits[i], qubits[i + 1]))

        # Parameterized RZ with coefficient scaling
        rz_coeff = -2.0 * coeff.imag if abs(coeff.imag) > 1e-12 else -2.0 * coeff.real
        circuit.append(
            Gate("RZ", (qubits[-1],), parameter=None, param_index=param_idx,
                 param_coeff=rz_coeff)
        )

        # Reverse CNOT
        for i in range(len(qubits) - 2, -1, -1):
            circuit.append(CNOT(qubits[i], qubits[i + 1]))

        # Undo basis rotation
        for q, p in zip(qubits, paulis):
            if p == "X":
                circuit.append(H(q))
            elif p == "Y":
                circuit.append(RX(q, angle=-np.pi / 2))
