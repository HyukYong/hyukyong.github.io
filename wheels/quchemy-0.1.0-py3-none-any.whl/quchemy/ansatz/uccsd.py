"""UCCSD (Unitary Coupled Cluster Singles and Doubles) ansatz generation."""

from __future__ import annotations

from typing import Optional

import numpy as np
from openfermion import (
    QubitOperator,
    jordan_wigner,
    bravyi_kitaev,
    uccsd_singlet_generator,
    uccsd_singlet_get_packed_amplitudes,
)

from ..circuit.circuit import ParameterizedCircuit
from ..circuit.gates import Gate, H, X, RX, RZ, CNOT


def get_uccsd_num_parameters(
    n_spatial_orbitals: int,
    n_electrons: int,
    include_singles: bool = True,
) -> int:
    """Compute the number of UCCSD singlet parameters.

    Uses OpenFermion's convention: the packed_amplitudes vector length
    for uccsd_singlet_generator.
    """
    n_qubits = 2 * n_spatial_orbitals
    # OpenFermion packs singles and doubles amplitudes
    # Use a probe to get the exact count
    try:
        zero_amps = uccsd_singlet_get_packed_amplitudes(
            np.zeros((n_qubits, n_qubits)),
            np.zeros((n_qubits, n_qubits, n_qubits, n_qubits)),
            n_qubits,
            n_electrons,
        )
        n_total = len(zero_amps)
    except (ValueError, TypeError, IndexError):
        # OpenFermion's packer rejected the probe shape — fall back to a manual count.
        # Narrowed from bare Exception so an unexpected error (e.g. a bad import) surfaces
        # instead of silently yielding a possibly-wrong count and a malformed ansatz.
        n_occ = n_electrons // 2
        n_virt = n_spatial_orbitals - n_occ
        n_singles = n_occ * n_virt
        n_doubles = n_occ * n_virt * (n_occ * n_virt + 1) // 2
        n_total = n_singles + n_doubles

    if not include_singles:
        n_occ = n_electrons // 2
        n_virt = n_spatial_orbitals - n_occ
        n_total -= n_occ * n_virt

    return n_total


def make_uccsd_ansatz(
    num_spatial_orbitals: int,
    num_electrons: int | tuple[int, int],
    mapping: str = "jordan_wigner",
    include_singles: bool = True,
    initial_state: bool = True,
) -> ParameterizedCircuit:
    """Build a UCCSD ansatz circuit.

    Uses OpenFermion's uccsd_singlet_generator for the fermionic cluster operator,
    then Trotterizes each Pauli exponential into a gate sequence.

    Parameters
    ----------
    num_spatial_orbitals : int
        Number of spatial orbitals.
    num_electrons : int or (int, int)
        Total electrons or (alpha, beta).
    mapping : str
        'jordan_wigner' or 'bravyi_kitaev'.
    include_singles : bool
        Whether to include single excitations.
    initial_state : bool
        If True, prepend HF reference state (X gates on occupied orbitals).

    Returns
    -------
    ParameterizedCircuit
        The UCCSD ansatz circuit.
    """
    if isinstance(num_electrons, (tuple, list)):
        n_alpha, n_beta = num_electrons
        n_elec = n_alpha + n_beta
    else:
        n_elec = num_electrons
        n_alpha = n_elec // 2
        n_beta = n_elec - n_alpha

    n_qubits = 2 * num_spatial_orbitals

    # Determine number of parameters by probing OpenFermion
    zero_amps = np.zeros(_get_packed_size(n_qubits, n_elec))
    n_params = len(zero_amps)

    # For each UCCSD parameter, isolate the Pauli terms it generates.
    # Set amplitude i to 1.0, all others to 0, and collect the resulting
    # qubit operator terms. This gives us the exact parameter→term mapping.
    param_qubit_ops = []
    for i in range(n_params):
        amps = np.zeros(n_params)
        amps[i] = 1.0
        fermion_op = uccsd_singlet_generator(amps, n_qubits, n_elec, anti_hermitian=True)
        if mapping == "jordan_wigner":
            qop = jordan_wigner(fermion_op)
        else:
            qop = bravyi_kitaev(fermion_op)
        param_qubit_ops.append(qop)

    # Build the circuit
    circuit = ParameterizedCircuit(n_qubits)

    # Prepend HF initial state
    if initial_state:
        _prepend_hf_state(circuit, n_alpha, n_beta, num_spatial_orbitals, mapping)

    # For each UCCSD parameter, implement all its Pauli exponentials
    for param_idx, qop in enumerate(param_qubit_ops):
        p_idx = circuit.allocate_parameter()
        for term, coeff in qop.terms.items():
            if not term:
                continue
            if abs(coeff) < 1e-12:
                continue
            _add_pauli_exponential(circuit, term, coeff, p_idx)

    return circuit


def make_hf_state_circuit(
    num_electrons: int | tuple[int, int],
    num_qubits: int,
    mapping: str = "jordan_wigner",
) -> ParameterizedCircuit:
    """Build a Hartree-Fock reference-state circuit (X gates on occupied qubits).

    Used as the ADAPT-VQE initial state. The occupation pattern matches
    ``get_hf_state`` for the chosen mapping (interleaved spin order 2i=iα, 2i+1=iβ
    for Jordan-Wigner; cumulative-XOR for Bravyi-Kitaev).

    Parameters
    ----------
    num_electrons : int or (int, int)
        Total electrons or (alpha, beta).
    num_qubits : int
        Number of qubits (2 * num_spatial_orbitals).
    mapping : str
        'jordan_wigner' or 'bravyi_kitaev'.

    Returns
    -------
    ParameterizedCircuit
        A parameter-free circuit preparing the HF reference state.
    """
    if isinstance(num_electrons, (tuple, list)):
        n_alpha, n_beta = int(num_electrons[0]), int(num_electrons[1])
    else:
        n_elec = int(num_electrons)
        n_alpha = n_elec // 2
        n_beta = n_elec - n_alpha

    circuit = ParameterizedCircuit(num_qubits)
    _prepend_hf_state(circuit, n_alpha, n_beta, num_qubits // 2, mapping)
    return circuit


def _get_packed_size(n_qubits: int, n_electrons: int) -> int:
    """Get the packed amplitudes vector size for uccsd_singlet_generator."""
    # Try with increasing sizes until it works
    n_spatial = n_qubits // 2
    n_occ = n_electrons // 2
    n_virt = n_spatial - n_occ

    # OpenFermion singlet UCCSD packing: singles + doubles
    n_singles = n_occ * n_virt
    # Doubles: unique (i,j,a,b) with spatial symmetry
    n_doubles = n_singles * (n_singles + 1) // 2
    size = n_singles + n_doubles

    # Verify by trying
    try:
        uccsd_singlet_generator(np.zeros(size), n_qubits, n_electrons)
        return size
    except (ValueError, TypeError):
        # Binary search for the correct packed size (narrowed from bare Exception so an
        # unexpected error surfaces instead of masquerading as a sizing problem).
        for s in range(1, n_qubits**4 + 1):
            try:
                uccsd_singlet_generator(np.zeros(s), n_qubits, n_electrons)
                return s
            except (ValueError, TypeError):
                continue
        raise RuntimeError("Could not determine packed amplitudes size")


def _prepend_hf_state(
    circuit: ParameterizedCircuit,
    n_alpha: int,
    n_beta: int,
    n_spatial: int,
    mapping: str,
) -> None:
    """Add X gates to set up the Hartree-Fock reference state."""
    if mapping == "jordan_wigner":
        # OpenFermion interleaved ordering: 2i = iα, 2i+1 = iβ
        for i in range(n_alpha):
            circuit.append(X(2 * i))
        for i in range(n_beta):
            circuit.append(X(2 * i + 1))
    elif mapping == "bravyi_kitaev":
        from ..integral.pyscf_bridge import get_hf_state
        hf = get_hf_state((n_alpha, n_beta), 2 * n_spatial, mapping)
        for i, bit in enumerate(hf):
            if bit:
                circuit.append(X(i))


def _add_pauli_exponential(
    circuit: ParameterizedCircuit,
    pauli_term: tuple,
    coefficient: complex,
    param_index: int,
) -> None:
    """Add gates for exp(coeff * theta * P) to the circuit.

    Implements the standard staircase decomposition:
    1. Basis rotation (H for X, RX(pi/2) for Y)
    2. CNOT cascade to compute parity
    3. RZ(theta) parameterized rotation (coefficient is absorbed)
    4. Reverse CNOT cascade
    5. Undo basis rotation
    """
    if not pauli_term:
        return

    qubits = []
    paulis = []
    for qubit, pauli in sorted(pauli_term):
        qubits.append(qubit)
        paulis.append(pauli)

    # Step 1: Basis rotation
    for q, p in zip(qubits, paulis):
        if p == "X":
            circuit.append(H(q))
        elif p == "Y":
            circuit.append(RX(q, angle=np.pi / 2))

    # Step 2: CNOT staircase
    for i in range(len(qubits) - 1):
        circuit.append(CNOT(qubits[i], qubits[i + 1]))

    # Step 3: Parameterized RZ
    # RZ(φ) implements exp(-i*φ/2 * Z), so the staircase implements exp(-i*φ/2 * P).
    # We want exp(coeff * θ * P). For anti-Hermitian ops, coeff is purely imaginary:
    #   coeff = i*r → exp(i*r*θ * P) → need -φ/2 = r*θ → φ = -2*r*θ
    # So param_coeff = -2 * coeff.imag
    rz_coeff = -2.0 * coefficient.imag if abs(coefficient.imag) > 1e-12 else -2.0 * coefficient.real
    circuit.append(
        Gate("RZ", (qubits[-1],), parameter=None, param_index=param_index,
             param_coeff=rz_coeff)
    )

    # Step 4: Reverse CNOT staircase
    for i in range(len(qubits) - 2, -1, -1):
        circuit.append(CNOT(qubits[i], qubits[i + 1]))

    # Step 5: Undo basis rotation
    for q, p in zip(qubits, paulis):
        if p == "X":
            circuit.append(H(q))
        elif p == "Y":
            circuit.append(RX(q, angle=-np.pi / 2))
