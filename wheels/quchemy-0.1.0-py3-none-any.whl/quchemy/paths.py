"""Reaction-path algorithms shared by the Qemica engine and user input scripts.

These are the SAME functions the sidecar's IRC and NEB actions run — extracted here so
the Method screen's generated input scripts can import them genuinely (`from quchemy.paths
import irc_steepest_descent, neb_relax`) and a hand-edited script executes the identical
algorithm the recipe would.

Both take an `energy_grad` callable seam so any engine can drive them:

    energy_grad(coords) -> (energy_hartree, grad_hartree_per_bohr, converged)

where `coords` is an (natoms, 3) array in Å and the gradient is (natoms, 3) in
Hartree/Bohr (PySCF's native gradient unit). Warnings and per-iteration progress are
surfaced through optional callbacks so library users and the sidecar share one code path.
"""
from __future__ import annotations

from typing import Any, Callable, Optional

BOHR_TO_ANG: float = 0.529177210903

EnergyGrad = Callable[[Any], tuple[float, Any, bool]]


def irc_steepest_descent(
    energy_grad: EnergyGrad,
    coords0,
    mode,
    *,
    nsteps: int = 12,
    step_ang: float = 0.10,
    kick_ang: float = 0.15,
    on_warn: Optional[Callable[[str], None]] = None,
) -> list[tuple[float, float]]:
    """A steepest-descent reaction path from a transition state, in both directions along
    the imaginary normal mode `mode` (an (natoms, 3) Cartesian displacement). Returns
    (coordinate, energy) points along a signed arc-length coordinate (Å), TS at 0, sorted.

    This is the minimum-energy-path *approximation* (damped Cartesian steepest descent),
    not an exact mass-weighted Gonzalez–Schlegel IRC — enough to confirm a TS rolls down
    to two distinct basins and to draw the profile.
    """
    import numpy as np

    warn = on_warn if on_warn is not None else (lambda _m: None)
    base = np.asarray(coords0, dtype=float)
    unit = np.asarray(mode, dtype=float)
    norm = np.linalg.norm(unit)
    if norm > 0:
        unit = unit / norm

    points: list[tuple[float, float]] = []
    e0, _g0, conv0 = energy_grad(base)
    if not conv0:
        warn("SCF not converged at IRC point s=0.00 Å")
    points.append((0.0, float(e0)))
    for direction in (1.0, -1.0):
        x = base + direction * kick_ang * unit  # step off the saddle along the imag mode
        s = direction * kick_ang
        for _ in range(nsteps):
            e, g, conv = energy_grad(x)
            if not conv:
                warn("SCF not converged at IRC point s=%.2f Å" % s)
            points.append((s, float(e)))
            g_ang = np.asarray(g, dtype=float) / BOHR_TO_ANG  # Hartree/Å
            gn = np.linalg.norm(g_ang)
            if gn < 1e-4:
                break  # reached a basin
            x = x - step_ang * g_ang / gn  # fixed-length steepest-descent step
            s += direction * step_ang
    points.sort(key=lambda p: p[0])
    return points


def neb_tangent(r_prev, r_cur, r_next, e_prev, e_cur, e_next):
    """Improved upwind tangent at an interior NEB image (Henkelman & Jónsson 2000).
    Coords are (natoms, 3) arrays; returns a unit tangent of the same shape."""
    import numpy as np

    tau_plus = r_next - r_cur
    tau_minus = r_cur - r_prev
    if e_next > e_cur > e_prev:
        tau = tau_plus
    elif e_next < e_cur < e_prev:
        tau = tau_minus
    else:
        d1 = abs(e_next - e_cur)
        d2 = abs(e_prev - e_cur)
        dmax, dmin = max(d1, d2), min(d1, d2)
        if e_next > e_prev:
            tau = tau_plus * dmax + tau_minus * dmin
        else:
            tau = tau_plus * dmin + tau_minus * dmax
    norm = np.linalg.norm(tau)
    return tau / norm if norm > 1e-12 else tau


def neb_relax(
    energy_grad: EnergyGrad,
    reactant,
    product,
    *,
    n_images: int = 7,
    max_iter: int = 10,
    spring_k: float = 0.5,
    step: float = 0.5,
    max_move: float = 0.2,
    climbing: bool = True,
    e_react: Optional[float] = None,
    e_prod: Optional[float] = None,
    on_warn: Optional[Callable[[str], None]] = None,
    on_iter: Optional[Callable[[int, float], None]] = None,
):
    """Improved-tangent nudged elastic band (Henkelman 2000) between `reactant` and
    `product` ((natoms, 3) Å arrays, same atom order): each interior image feels the
    PERPENDICULAR true force plus a PARALLEL spring force, so it slides onto the
    minimum-energy path without sliding down it. With `climbing` the highest image
    inverts its parallel force to climb onto the saddle (a transition-state estimate,
    active after max_iter // 3 iterations). Returns (band, energies) with the endpoint
    energies included; a real but lightweight chain-of-states path — Cartesian (not
    mass-weighted) steepest-descent image moves.

    `e_react` / `e_prod` skip re-evaluating an endpoint whose energy the caller already
    paid for; `on_iter(iteration, e_max)` reports per-iteration progress.
    """
    import numpy as np

    warn = on_warn if on_warn is not None else (lambda _m: None)
    r0 = np.asarray(reactant, dtype=float)
    rp = np.asarray(product, dtype=float)
    n_images = int(max(3, n_images))
    climb_after = max(1, int(max_iter) // 3)

    if e_react is None:
        e_react, _g, conv = energy_grad(r0)
        if not conv:
            warn("NEB: the reactant-geometry SCF did not converge — the band end is unreliable")
    if e_prod is None:
        e_prod, _g, conv = energy_grad(rp)
        if not conv:
            warn("NEB: the product-geometry SCF did not converge — the band end is unreliable")

    band = [(1.0 - t) * r0 + t * rp for t in np.linspace(0.0, 1.0, n_images)]
    energies = [float(e_react)] + [0.0] * (n_images - 2) + [float(e_prod)]

    for it in range(int(max_iter)):
        grads = [None] * n_images
        for i in range(1, n_images - 1):
            e_i, g_i, conv_i = energy_grad(band[i])
            energies[i] = float(e_i)
            grads[i] = np.asarray(g_i, dtype=float) / BOHR_TO_ANG  # Hartree/Å
            if not conv_i:
                warn("NEB: SCF not converged at image %d (iter %d)" % (i, it + 1))
        i_max = int(np.argmax(energies))
        new_band = [band[0]] + [None] * (n_images - 2) + [band[-1]]
        for i in range(1, n_images - 1):
            tau = neb_tangent(band[i - 1], band[i], band[i + 1],
                              energies[i - 1], energies[i], energies[i + 1])
            f_true = -grads[i]
            f_par = float(np.sum(f_true * tau))
            if climbing and i == i_max and it >= climb_after:
                force = f_true - 2.0 * f_par * tau
            else:
                f_perp = f_true - f_par * tau
                d_next = np.linalg.norm(band[i + 1] - band[i])
                d_prev = np.linalg.norm(band[i] - band[i - 1])
                f_spring = spring_k * (d_next - d_prev) * tau
                force = f_perp + f_spring
            move = np.clip(step * force, -max_move, max_move)
            new_band[i] = band[i] + move
        band = new_band
        if on_iter is not None:
            on_iter(it + 1, float(np.max(energies)))

    # Final energies on the relaxed interior images (the moves above shifted them).
    for i in range(1, n_images - 1):
        e_i, _g, _conv = energy_grad(band[i])
        energies[i] = float(e_i)
    energies[0] = float(e_react)
    energies[-1] = float(e_prod)
    return band, energies
