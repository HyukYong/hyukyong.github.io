"""Quantum gate definitions with matrix representations."""

from __future__ import annotations

from dataclasses import dataclass
from typing import Optional

import numpy as np


@dataclass(frozen=True)
class Gate:
    """A quantum gate applied to specific qubits.

    Parameters
    ----------
    name : str
        Gate name (H, X, Y, Z, S, T, RX, RY, RZ, CNOT, CZ, SWAP).
    qubits : tuple[int, ...]
        Target qubit indices.
    parameter : float or None
        Concrete rotation angle (None if parameterized).
    param_index : int or None
        Index into ParameterizedCircuit's parameter vector.
    """

    name: str
    qubits: tuple[int, ...]
    parameter: Optional[float] = None
    param_index: Optional[int] = None
    param_coeff: float = 1.0  # Multiplier: actual angle = param_coeff * param_value

    @property
    def num_qubits(self) -> int:
        return len(self.qubits)

    @property
    def is_parameterized(self) -> bool:
        return self.param_index is not None and self.parameter is None

    def matrix(self, param_value: Optional[float] = None) -> np.ndarray:
        """Return the unitary matrix for this gate.

        For parameterized gates, pass the angle via param_value.
        """
        if self.parameter is not None:
            theta = self.parameter
        elif param_value is not None:
            theta = self.param_coeff * param_value
        else:
            theta = param_value
        name = self.name

        if name == "H":
            return np.array([[1, 1], [1, -1]], dtype=complex) / np.sqrt(2)
        elif name == "X":
            return np.array([[0, 1], [1, 0]], dtype=complex)
        elif name == "Y":
            return np.array([[0, -1j], [1j, 0]], dtype=complex)
        elif name == "Z":
            return np.array([[1, 0], [0, -1]], dtype=complex)
        elif name == "S":
            return np.array([[1, 0], [0, 1j]], dtype=complex)
        elif name == "T":
            return np.array([[1, 0], [0, np.exp(1j * np.pi / 4)]], dtype=complex)
        elif name == "RX":
            c, s = np.cos(theta / 2), np.sin(theta / 2)
            return np.array([[c, -1j * s], [-1j * s, c]], dtype=complex)
        elif name == "RY":
            c, s = np.cos(theta / 2), np.sin(theta / 2)
            return np.array([[c, -s], [s, c]], dtype=complex)
        elif name == "RZ":
            return np.array(
                [[np.exp(-1j * theta / 2), 0], [0, np.exp(1j * theta / 2)]],
                dtype=complex,
            )
        elif name == "CNOT":
            return np.array(
                [[1, 0, 0, 0], [0, 1, 0, 0], [0, 0, 0, 1], [0, 0, 1, 0]],
                dtype=complex,
            )
        elif name == "CZ":
            return np.array(
                [[1, 0, 0, 0], [0, 1, 0, 0], [0, 0, 1, 0], [0, 0, 0, -1]],
                dtype=complex,
            )
        elif name == "SWAP":
            return np.array(
                [[1, 0, 0, 0], [0, 0, 1, 0], [0, 1, 0, 0], [0, 0, 0, 1]],
                dtype=complex,
            )
        else:
            raise ValueError(f"Unknown gate: {name}")


# --- Factory functions ---

def H(q: int) -> Gate:
    return Gate("H", (q,))

def X(q: int) -> Gate:
    return Gate("X", (q,))

def Y(q: int) -> Gate:
    return Gate("Y", (q,))

def Z(q: int) -> Gate:
    return Gate("Z", (q,))

def S(q: int) -> Gate:
    return Gate("S", (q,))

def T(q: int) -> Gate:
    return Gate("T", (q,))

def RX(q: int, angle: Optional[float] = None, param_index: Optional[int] = None) -> Gate:
    return Gate("RX", (q,), parameter=angle, param_index=param_index)

def RY(q: int, angle: Optional[float] = None, param_index: Optional[int] = None) -> Gate:
    return Gate("RY", (q,), parameter=angle, param_index=param_index)

def RZ(q: int, angle: Optional[float] = None, param_index: Optional[int] = None) -> Gate:
    return Gate("RZ", (q,), parameter=angle, param_index=param_index)

def CNOT(control: int, target: int) -> Gate:
    return Gate("CNOT", (control, target))

def CZ(q0: int, q1: int) -> Gate:
    return Gate("CZ", (q0, q1))

def SWAP(q0: int, q1: int) -> Gate:
    return Gate("SWAP", (q0, q1))
