"""Parameterized quantum circuit representation."""

from __future__ import annotations

from copy import deepcopy
from typing import Optional

import numpy as np

from .gates import Gate


class ParameterizedCircuit:
    """A quantum circuit with symbolic parameters.

    Parameters
    ----------
    num_qubits : int
        Number of qubits in the circuit.
    """

    def __init__(self, num_qubits: int):
        self.num_qubits = num_qubits
        self._gates: list[Gate] = []
        self._num_parameters: int = 0

    @property
    def gates(self) -> list[Gate]:
        return self._gates

    @property
    def num_parameters(self) -> int:
        return self._num_parameters

    def allocate_parameter(self) -> int:
        """Allocate a new parameter slot and return its index."""
        idx = self._num_parameters
        self._num_parameters += 1
        return idx

    def append(self, gate: Gate) -> None:
        """Append a gate to the circuit."""
        for q in gate.qubits:
            if q < 0 or q >= self.num_qubits:
                raise ValueError(
                    f"Qubit {q} out of range for {self.num_qubits}-qubit circuit"
                )
        if gate.param_index is not None and gate.param_index >= self._num_parameters:
            self._num_parameters = gate.param_index + 1
        self._gates.append(gate)

    def bind_parameters(self, values: np.ndarray) -> "ParameterizedCircuit":
        """Return a new circuit with all parameters resolved to concrete values."""
        if len(values) < self._num_parameters:
            raise ValueError(
                f"Expected {self._num_parameters} parameters, got {len(values)}"
            )
        bound = ParameterizedCircuit(self.num_qubits)
        for gate in self._gates:
            if gate.param_index is not None and gate.parameter is None:
                new_gate = Gate(
                    gate.name,
                    gate.qubits,
                    parameter=float(gate.param_coeff * values[gate.param_index]),
                    param_index=None,
                )
            else:
                new_gate = gate
            bound._gates.append(new_gate)
        bound._num_parameters = 0
        return bound

    def depth(self) -> int:
        """Compute circuit depth (max number of gate layers on any qubit)."""
        layers = [0] * self.num_qubits
        for gate in self._gates:
            max_layer = max(layers[q] for q in gate.qubits)
            for q in gate.qubits:
                layers[q] = max_layer + 1
        return max(layers) if layers else 0

    def compose(self, other: "ParameterizedCircuit", qubit_offset: int = 0) -> None:
        """Append another circuit's gates, remapping qubits and parameter indices."""
        if qubit_offset + other.num_qubits > self.num_qubits:
            raise ValueError(
                f"Cannot compose: {other.num_qubits} qubits at offset {qubit_offset} "
                f"exceeds {self.num_qubits}-qubit circuit"
            )
        param_offset = self._num_parameters
        for gate in other._gates:
            new_qubits = tuple(q + qubit_offset for q in gate.qubits)
            new_param_index = (
                gate.param_index + param_offset
                if gate.param_index is not None
                else None
            )
            new_gate = Gate(
                gate.name,
                new_qubits,
                parameter=gate.parameter,
                param_index=new_param_index,
                param_coeff=gate.param_coeff,
            )
            self._gates.append(new_gate)
        self._num_parameters += other._num_parameters

    def __len__(self) -> int:
        return len(self._gates)

    def __repr__(self) -> str:
        return (
            f"ParameterizedCircuit(qubits={self.num_qubits}, "
            f"gates={len(self._gates)}, params={self._num_parameters})"
        )
