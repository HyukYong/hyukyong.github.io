"""Exact synthesis of an arbitrary unitary into universal gates (Quantum Shannon Decomposition).

QAAE's spectral filter and the open-system Sz.-Nagy dilations are NON-unitary maps realized on
hardware by a UNITARY dilation; to run them as a real gate circuit that unitary must be compiled into
the universal set {RY, RZ, CNOT}.  This module does that exactly (no Trotter error) via the recursive
Quantum Shannon Decomposition (Shende, Bullock & Markov 2006):

  U (n qubits)  =  (A0 ⊕ A1) · (multiplexed-Ry on the top qubit) · (B0 ⊕ B1),

where each block-diagonal multiplexor diag(P, Q) is demultiplexed with one eigendecomposition into a
multiplexed-Rz plus two (n-1)-qubit unitaries, recursing to the 1-qubit ZYZ base case.  The
uniformly-controlled rotations use the Möttönen CNOT-cascade.  Gate count is O(4^n) — deep, the
fault-tolerant regime — so callers gate it to small registers; correctness is what matters here
(verified by reconstruction in the tests).  Convention matches the simulator: qubit 0 is the MSB.
"""

from __future__ import annotations

import numpy as np
from scipy.linalg import cossin, schur

from .gates import Gate, RY, RZ, CNOT


def _zyz(u: np.ndarray) -> tuple[float, float, float, float]:
    """ZYZ Euler angles (alpha global phase, beta, gamma, delta) with U = e^{iα} Rz(β) Ry(γ) Rz(δ)."""
    u = np.asarray(u, dtype=complex)
    det = u[0, 0] * u[1, 1] - u[0, 1] * u[1, 0]
    alpha = 0.5 * np.angle(det)
    su = u * np.exp(-1j * alpha)                       # special-unitary part (det = 1)
    gamma = 2.0 * np.arctan2(abs(su[1, 0]), abs(su[0, 0]))
    beta_plus_delta = 2.0 * np.angle(su[1, 1])
    beta_minus_delta = 2.0 * np.angle(su[1, 0])
    beta = (beta_plus_delta + beta_minus_delta) / 2.0
    delta = (beta_plus_delta - beta_minus_delta) / 2.0
    return float(alpha), float(beta), float(gamma), float(delta)


def _gray(i: int) -> int:
    return i ^ (i >> 1)


def _ucr_gates(angles: np.ndarray, target: int, controls: list[int], axis: str) -> list:
    """Uniformly-controlled R_axis(angles[k]) on `target`, controlled by `controls` (Möttönen).

    angles has length 2^len(controls), indexed by the control basis state (controls[0] = MSB). The
    circuit is 2^m rotations interleaved with CNOTs whose controls follow the Gray code; before
    rotation i the cumulative CNOT-mask equals gray(i), so the per-step rotation angle is
    theta_i = (1/2^m) sum_k (-1)^{popcount(gray(i) & k)} angles_k (the sign matrix's own transpose)."""
    m = len(controls)
    n = 1 << m
    if m == 0:
        a = float(angles[0])
        return [RY(target, angle=a)] if axis == "y" else [RZ(target, angle=a)]
    # CNOT control bit-position per step (LSB = 0), from the cyclic Gray code.
    pos_seq = [(_gray(k) ^ _gray((k + 1) % n)).bit_length() - 1 for k in range(n)]
    # theta = S^T angles / n, with S_{k,i} = (-1)^{popcount(gray(i) & k)} (S S^T = n I).
    alpha = np.asarray(angles, dtype=float)
    theta = np.empty(n)
    for i in range(n):
        gi = _gray(i)
        theta[i] = sum((-1.0) ** bin(gi & k).count("1") * alpha[k] for k in range(n)) / n
    gates = []
    for i in range(n):
        gates.append(RY(target, angle=theta[i]) if axis == "y" else RZ(target, angle=theta[i]))
        control = controls[m - 1 - pos_seq[i]]         # controls[0] is the most significant
        gates.append(CNOT(control, target))
    return gates


def _demultiplex(p: np.ndarray, q: np.ndarray):
    """diag(P, Q) = (I⊗V) · diag(D, D†) · (I⊗W). Returns (V, rz_angles, W).

    rz_angles[k] are the per-lower-state Rz angles realizing diag(D, D†) as a multiplexed-Rz on the
    top qubit (D = exp(-i z/2) on the diagonal, so the multiplexor applies Rz(z))."""
    x = p @ q.conj().T
    # x is unitary; a Schur decomposition x = V T V† gives a UNITARY V even when the eigenvalues are
    # degenerate (np.linalg.eig can return non-orthonormal eigenvectors there — wrong for dilations
    # whose defect operators carry repeated eigenvalues). T is diagonal for unitary x.
    T, V = schur(x, output="complex")                 # x = V T V†, V unitary
    evals = np.diag(T)
    d = np.sqrt(evals.astype(complex))                 # D (branch); D^2 = evals
    W = (1.0 / d)[:, None] * (V.conj().T @ p)          # W = D^-1 V† P
    # diag(D, D†) on the top qubit = multiplexed Rz(z) with D = e^{-i z/2}  ->  z = -2 arg(d).
    rz_angles = -2.0 * np.angle(d)
    return V, rz_angles, W


def synthesize_unitary(U: np.ndarray, qubits: list[int]) -> list:
    """Exact gate list realizing the unitary `U` on `qubits` (qubits[0] = MSB), in {RY, RZ, CNOT}.

    Global phase is dropped (unobservable). For 1 qubit this is the ZYZ decomposition; for n>1 the
    Quantum Shannon Decomposition recursion."""
    U = np.asarray(U, dtype=complex)
    n = len(qubits)
    if n == 1:
        _alpha, beta, gamma, delta = _zyz(U)
        return [RZ(qubits[0], angle=delta), RY(qubits[0], angle=gamma), RZ(qubits[0], angle=beta)]

    half = 1 << (n - 1)
    # Cosine-sine decomposition splitting on the top qubit: U = (u0⊕u1) CS (v0h⊕v1h).
    (u0, u1), theta, (v0h, v1h) = cossin(U, p=half, q=half, separate=True)
    lower = qubits[1:]
    top = qubits[0]
    gates: list = []

    # Right multiplexor diag(v0h, v1h): demultiplex then recurse on the two (n-1)-qubit blocks.
    Vr, rz_r, Wr = _demultiplex(v0h, v1h)
    gates += synthesize_unitary(Wr, lower)
    gates += _ucr_gates(rz_r, top, lower, "z")
    gates += synthesize_unitary(Vr, lower)

    # Middle CS block = multiplexed Ry(2*theta) on the top qubit, controlled by the lower qubits.
    gates += _ucr_gates(2.0 * np.asarray(theta, dtype=float), top, lower, "y")

    # Left multiplexor diag(u0, u1).
    Vl, rz_l, Wl = _demultiplex(u0, u1)
    gates += synthesize_unitary(Wl, lower)
    gates += _ucr_gates(rz_l, top, lower, "z")
    gates += synthesize_unitary(Vl, lower)
    return gates
