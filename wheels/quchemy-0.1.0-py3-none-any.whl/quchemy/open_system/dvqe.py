"""Dissipative VQE — variational search for the steady state of an open system.

The Lindblad steady state rho_ss satisfies L_super vec(rho_ss) = 0.  Rather than diagonalize the
(d^2 x d^2) Liouvillian (lindblad.steady_state), dissipative VQE parameterizes a *physical* mixed
state rho(theta) = U(theta) diag(p(theta)) U(theta)^dag — always Hermitian, PSD, unit-trace by
construction — and minimizes the steady-state residual ||L_super vec(rho(theta))||_F.  At the
optimum the residual -> 0 and rho(theta) -> rho_ss.

This mirrors how a dissipative VQE runs on hardware (a purified/ancilla-doubled register carries the
mixed state, the cost is estimated from measurements), but here the optimization is classical and
exact for small systems.  Reproducible: pass `seed`.  Cross-checks against lindblad.steady_state.
"""

from __future__ import annotations

from dataclasses import dataclass, field

import numpy as np
from scipy.linalg import expm
from scipy.optimize import minimize

from .lindblad import liouvillian, populations as _pops, purity as _purity


@dataclass
class DVQEResult:
    rho: np.ndarray                       # the optimized steady-state density matrix (d x d)
    residual: float                       # ||L vec(rho)||_F at the optimum (-> 0 is converged)
    populations: list[float] = field(default_factory=list)
    purity: float = 0.0
    iterations: int = 0
    converged: bool = False


def _antihermitian(params: np.ndarray, d: int) -> np.ndarray:
    """Anti-Hermitian generator from d^2 real params: d imaginary diagonals + d(d-1) off-diagonals."""
    A = np.zeros((d, d), dtype=complex)
    k = 0
    for i in range(d):                    # imaginary diagonal
        A[i, i] = 1j * params[k]
        k += 1
    for i in range(d):                    # off-diagonal hermitian-antisymmetric pairs
        for j in range(i + 1, d):
            re, im = params[k], params[k + 1]
            k += 2
            A[i, j] = re + 1j * im
            A[j, i] = -re + 1j * im
    return A


def _density(params: np.ndarray, d: int) -> np.ndarray:
    n_u = d * d
    U = expm(_antihermitian(params[:n_u], d))
    logits = params[n_u:n_u + d]
    p = np.exp(logits - np.max(logits))
    p = p / np.sum(p)                     # softmax populations
    return (U * p) @ U.conj().T


def dissipative_vqe(
    hamiltonian: np.ndarray,
    jumps: list[np.ndarray],
    seed: int = 42,
    maxiter: int = 500,
    restarts: int = 3,
    tol: float = 1e-8,
) -> DVQEResult:
    """Variationally find the Lindblad steady state of (`hamiltonian`, `jumps`).

    Minimizes ||L vec(rho(theta))||_F over a unitary-conjugated mixed-state ansatz, with `restarts`
    random initializations (best kept).  Returns the optimized density matrix, residual, and
    observables.
    """
    H = np.asarray(hamiltonian, dtype=complex)
    d = H.shape[0]
    L = liouvillian(H, jumps)
    n_params = d * d + d
    rng = np.random.default_rng(seed)

    def cost(theta: np.ndarray) -> float:
        rho = _density(theta, d)
        return float(np.linalg.norm(L @ rho.reshape(-1, order="F")))

    best = None
    total_iter = 0
    for r in range(max(1, restarts)):
        x0 = rng.normal(scale=0.5, size=n_params) if r else np.zeros(n_params)
        res = minimize(cost, x0, method="L-BFGS-B", options={"maxiter": maxiter, "ftol": 1e-12})
        total_iter += int(res.nit)
        if best is None or res.fun < best.fun:
            best = res

    rho = _density(best.x, d)
    rho = 0.5 * (rho + rho.conj().T)
    return DVQEResult(
        rho=rho,
        residual=float(best.fun),
        populations=_pops(rho),
        purity=_purity(rho),
        iterations=total_iter,
        converged=bool(best.fun < tol),
    )
