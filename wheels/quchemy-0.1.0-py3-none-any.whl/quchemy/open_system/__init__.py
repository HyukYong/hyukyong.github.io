"""Open quantum systems — dissipative dynamics, channels, dilation, dissipative VQE.

Tier-4 of the quantum-algorithms roadmap (§6).  Everything here works on the system density matrix
rho (not a pure statevector): the Lindblad master equation for exact dissipative dynamics, the
Sz.-Nagy dilation that runs a non-unitary step on a unitary device, the Kraus operator-sum channel
form (and its extraction from the Lindblad propagator via Choi), and a variational steady-state
solver (dissipative VQE).  Rodeo / spectral-filter / single-ancilla-Lindbladian (fault-tolerant) are
intentionally out of scope.
"""

from .lindblad import (
    liouvillian,
    propagate,
    steady_state,
    populations,
    purity,
    coherence,
    amplitude_damping_jump,
    dephasing_jump,
)
from .dilation import (
    sz_nagy_dilation,
    apply_nonunitary,
    spectral_norm,
    is_unitary,
)
from .kraus import (
    apply_kraus,
    is_cptp,
    superop_to_choi,
    kraus_from_choi,
    superop_to_kraus,
    amplitude_damping_kraus,
    phase_damping_kraus,
    depolarizing_kraus,
)
from .dvqe import dissipative_vqe, DVQEResult
from .stinespring import stinespring_unitary, channel_to_gates, apply_channel_gates

__all__ = [
    "liouvillian",
    "propagate",
    "steady_state",
    "populations",
    "purity",
    "coherence",
    "amplitude_damping_jump",
    "dephasing_jump",
    "sz_nagy_dilation",
    "apply_nonunitary",
    "spectral_norm",
    "is_unitary",
    "apply_kraus",
    "is_cptp",
    "superop_to_choi",
    "kraus_from_choi",
    "superop_to_kraus",
    "amplitude_damping_kraus",
    "phase_damping_kraus",
    "depolarizing_kraus",
    "dissipative_vqe",
    "DVQEResult",
    "stinespring_unitary",
    "channel_to_gates",
    "apply_channel_gates",
]
