"""Stinespring dilation of an open-system (Kraus) channel into a REAL gate circuit.

A CPTP channel rho -> sum_m K_m rho K_m^dag is not unitary, so on hardware it is run by Stinespring
dilation: introduce an ancilla register (n_anc = ceil(log2(#Kraus)) qubits) initialized to |0>, apply
a JOINT unitary U on system+ancilla, and discard (trace out) the ancilla:

    U (|psi> (x) |0>_anc) = sum_m (K_m|psi>) (x) |m>_anc,   rho_out = Tr_anc[ U (rho (x) |0><0|) U^dag ].

The isometry's first 2^n_sys columns are fixed by the Kraus operators (W[m*d+i, j] = (K_m)[i,j], which
is an isometry because sum_m K_m^dag K_m = I); the remaining columns are any orthonormal completion.
That unitary is then compiled to universal {RY,RZ,CNOT} gates EXACTLY by the Quantum Shannon
Decomposition (circuit.synthesis) — so the open-system step runs as a genuine hardware circuit.

Cost: the dilation is (n_sys + n_anc) qubits and synthesis is O(4^n), so this is only practical for a
few system qubits (the fault-tolerant regime); callers gate it. Convention: ancilla = the MOST
significant qubits (0..n_anc-1), system = the least significant — matching the simulator's qubit-0-MSB
ordering and circuit.synthesis.
"""

from __future__ import annotations

import math

import numpy as np

from ..circuit.synthesis import synthesize_unitary


def stinespring_unitary(kraus: list[np.ndarray], n_anc: int | None = None) -> np.ndarray:
    """The Stinespring dilation unitary U on system (x) ancilla for a Kraus channel.

    U (|psi>|0>_anc) = sum_m (K_m|psi>)|m>_anc. Ancilla is the MOST significant register. `n_anc`
    defaults to ceil(log2(#Kraus)); the channel must be CPTP (sum K_m^dag K_m = I)."""
    kraus = [np.asarray(K, dtype=complex) for K in kraus]
    d = kraus[0].shape[0]
    if n_anc is None:
        n_anc = max(1, math.ceil(math.log2(len(kraus)))) if len(kraus) > 1 else 1
    A = 1 << n_anc
    if len(kraus) > A:
        raise ValueError(f"{len(kraus)} Kraus operators need more than {n_anc} ancilla qubits")
    big = A * d

    # The fixed columns W (big x d): output (anc=m, sys=i) amplitude = (K_m)[i, j] for input sys=j.
    W = np.zeros((big, d), dtype=complex)
    for m, K in enumerate(kraus):
        W[m * d:(m + 1) * d, :] = K
    # W must be an isometry (W^dag W = sum_m K_m^dag K_m = I); guard the channel is trace-preserving.
    if not np.allclose(W.conj().T @ W, np.eye(d), atol=1e-6):
        raise ValueError("Kraus set is not trace-preserving (sum K^dag K != I) — cannot dilate")

    # Complete W's column space to a full unitary by Gram-Schmidt against the standard basis.
    U = np.zeros((big, big), dtype=complex)
    U[:, :d] = W
    basis = [W[:, j] for j in range(d)]
    col = d
    idx = 0
    while col < big and idx < big:
        v = np.zeros(big, dtype=complex)
        v[idx] = 1.0
        idx += 1
        for b in basis:
            v -= np.vdot(b, v) * b
        nrm = np.linalg.norm(v)
        if nrm > 1e-9:
            v /= nrm
            basis.append(v)
            U[:, col] = v
            col += 1
    return U


def channel_to_gates(kraus: list[np.ndarray], n_sys: int, n_anc: int | None = None) -> list:
    """Universal-gate list realizing the Stinespring dilation of `kraus` on n_sys + n_anc qubits."""
    U = stinespring_unitary(kraus, n_anc)
    n_total = int(round(math.log2(U.shape[0])))
    return synthesize_unitary(U, list(range(n_total)))


def apply_channel_gates(
    psi: np.ndarray, kraus: list[np.ndarray], n_sys: int, n_anc: int | None = None
) -> np.ndarray:
    """Run the channel on a PURE system input |psi> via the dilation GATE CIRCUIT; return the output
    density matrix rho_out = sum_m K_m |psi><psi| K_m^dag (ancilla traced out)."""
    from ..solver.expectation import apply_gates_to_state

    psi = np.asarray(psi, dtype=complex).reshape(-1)
    d = psi.size
    if n_anc is None:
        n_anc = max(1, math.ceil(math.log2(len(kraus)))) if len(kraus) > 1 else 1
    A = 1 << n_anc
    gates = channel_to_gates(kraus, n_sys, n_anc)
    state = np.zeros(A * d, dtype=complex)
    state[:d] = psi                                       # |0>_anc (x) |psi>  (ancilla = MSB)
    apply_gates_to_state(gates, state, n_sys + n_anc)
    # Partial trace over the ancilla (MSB): rho[i, i'] = sum_m state[m*d+i] conj(state[m*d+i']).
    blocks = state.reshape(A, d)                          # rows = ancilla outcome m
    return np.einsum("mi,mj->ij", blocks, blocks.conj())
