"""Sz.-Nagy unitary dilation — run a non-unitary operator on a quantum computer.

A quantum computer applies only unitaries, but open-system steps (a single Kraus operator, a
non-unitary imaginary-time / contraction map M with ||M|| <= 1) are not unitary.  Sz.-Nagy's
dilation theorem embeds any contraction M (d x d) in a unitary U (2d x 2d) on one extra ancilla,

    U = [[ M,            D_{Mdag} ],
         [ D_M,         -Mdag     ]],   D_M = sqrt(I - Mdag M),  D_{Mdag} = sqrt(I - M Mdag),

so that applying U to |0>_anc (x) |psi>, then post-selecting the ancilla on |0>, yields M|psi>
(unnormalized — the success probability is ||M|psi||^2).  This is the EASY primitive the Kraus /
Lindblad channel simulation builds on: one ancilla per Kraus operator block-encodes the channel.
"""

from __future__ import annotations

import numpy as np
from scipy.linalg import sqrtm


def _psd_sqrt(A: np.ndarray) -> np.ndarray:
    """Hermitian PSD square root (clips tiny negative eigenvalues from rounding)."""
    A = 0.5 * (A + A.conj().T)
    w, V = np.linalg.eigh(A)
    w = np.clip(w.real, 0.0, None)
    return (V * np.sqrt(w)) @ V.conj().T


def spectral_norm(M: np.ndarray) -> float:
    """Largest singular value ||M||_2 — must be <= 1 for M to be dilatable as a contraction."""
    return float(np.linalg.svd(np.asarray(M, dtype=complex), compute_uv=False)[0])


def sz_nagy_dilation(M: np.ndarray, atol: float = 1e-8) -> np.ndarray:
    """The (2d x 2d) Sz.-Nagy unitary dilation U of a contraction M (||M||_2 <= 1).

    Raises ValueError if M is not a contraction beyond `atol`.  U is unitary and its top-left d x d
    block equals M, i.e. (<0|_anc (x) I) U (|0>_anc (x) I) = M.
    """
    M = np.asarray(M, dtype=complex)
    d = M.shape[0]
    sn = spectral_norm(M)
    if sn > 1.0 + atol:
        raise ValueError(f"M is not a contraction (||M||_2 = {sn:.6g} > 1); rescale before dilation")
    I = np.eye(d, dtype=complex)
    D_M = _psd_sqrt(I - M.conj().T @ M)
    D_Mdag = _psd_sqrt(I - M @ M.conj().T)
    U = np.block([[M, D_Mdag], [D_M, -M.conj().T]])
    return U


def apply_nonunitary(M: np.ndarray, state: np.ndarray) -> np.ndarray:
    """Apply contraction M to `state` via its dilation: returns M|state> (unnormalized).

    Builds U, acts on |0>_anc (x) |state>, post-selects ancilla |0>.  The returned vector's norm^2
    is the post-selection success probability.
    """
    M = np.asarray(M, dtype=complex)
    d = M.shape[0]
    psi = np.asarray(state, dtype=complex).reshape(-1)
    U = sz_nagy_dilation(M)
    big = np.zeros(2 * d, dtype=complex)
    big[:d] = psi                       # ancilla |0> (x) |state>
    out = U @ big
    return out[:d]                      # post-select ancilla |0>


def is_unitary(U: np.ndarray, atol: float = 1e-8) -> bool:
    U = np.asarray(U, dtype=complex)
    return bool(np.allclose(U.conj().T @ U, np.eye(U.shape[0]), atol=atol))
