"""Lindblad master-equation simulation of open-system (dissipative) dynamics.

A system coupled to an environment evolves its density matrix rho by the Lindblad equation

    drho/dt = -i [H, rho] + sum_k ( L_k rho L_k^dag - 1/2 {L_k^dag L_k, rho} ),

with H the system Hamiltonian and {L_k} the jump (collapse) operators that model dissipation
(amplitude damping, dephasing, …).  Vectorizing rho (column-stacking) turns this into a linear ODE
drho_vec/dt = L_super rho_vec, so the exact propagator is expm(L_super t): one matrix exponential
gives the whole trajectory, the steady state is the kernel of L_super, and observables (populations,
coherences, purity) read off the propagated density matrix.

This is the classical reference the quantum open-system algorithms (dilation / Kraus, dissipative
VQE) reproduce on hardware; here it is exact for small systems.  Column-stacking vectorization
(vec = reshape order='F') is used throughout: vec(A X B) = kron(B^T, A) vec(X).
"""

from __future__ import annotations

import numpy as np
from scipy.linalg import expm


def _vec(rho: np.ndarray) -> np.ndarray:
    return rho.reshape(-1, order="F")


def _unvec(v: np.ndarray, d: int) -> np.ndarray:
    return v.reshape((d, d), order="F")


def liouvillian(hamiltonian: np.ndarray, jumps: list[np.ndarray]) -> np.ndarray:
    """The Lindblad superoperator L_super (d^2 x d^2) for `hamiltonian` and jump operators `jumps`.

    drho_vec/dt = L_super rho_vec.  Hamiltonian part -i(I⊗H - H^T⊗I); each jump contributes the
    dissipator conj(L)⊗L - 1/2 (I⊗L†L + (L†L)^T⊗I).
    """
    H = np.asarray(hamiltonian, dtype=complex)
    d = H.shape[0]
    I = np.eye(d, dtype=complex)
    L = -1j * (np.kron(I, H) - np.kron(H.T, I))
    for Lk in jumps:
        Lk = np.asarray(Lk, dtype=complex)
        LdL = Lk.conj().T @ Lk
        L += np.kron(Lk.conj(), Lk)
        L -= 0.5 * (np.kron(I, LdL) + np.kron(LdL.T, I))
    return L


def propagate(
    rho0: np.ndarray, hamiltonian: np.ndarray, jumps: list[np.ndarray], times: list[float]
) -> list[np.ndarray]:
    """Density matrix rho(t) at each t in `times`, by the exact Lindblad propagator expm(L t).

    Reuses one eigendecomposition-free expm per time step; for a dense scan, pass increasing times.
    """
    L = liouvillian(hamiltonian, jumps)
    d = np.asarray(hamiltonian).shape[0]
    v0 = _vec(np.asarray(rho0, dtype=complex))
    out: list[np.ndarray] = []
    for t in times:
        out.append(_unvec(expm(L * float(t)) @ v0, d))
    return out


def steady_state(hamiltonian: np.ndarray, jumps: list[np.ndarray]) -> np.ndarray:
    """The steady state rho_ss (L_super rho_ss = 0), normalized to unit trace.

    Found as the right null vector of L_super (its eigenvector of smallest |eigenvalue|), reshaped
    and Hermitized/normalized.  When the steady state is not unique this returns one valid member.
    """
    L = liouvillian(hamiltonian, jumps)
    d = np.asarray(hamiltonian).shape[0]
    evals, evecs = np.linalg.eig(L)
    idx = int(np.argmin(np.abs(evals)))
    rho = _unvec(evecs[:, idx], d)
    rho = 0.5 * (rho + rho.conj().T)          # Hermitize
    tr = np.trace(rho)
    if abs(tr) > 1e-12:
        rho = rho / tr
    return rho


# ── observables ───────────────────────────────────────────────────────────────
def populations(rho: np.ndarray) -> list[float]:
    """Diagonal populations (real)."""
    return [float(np.real(rho[i, i])) for i in range(rho.shape[0])]


def purity(rho: np.ndarray) -> float:
    """Tr(rho^2) — 1 for a pure state, 1/d for the maximally mixed state."""
    return float(np.real(np.trace(rho @ rho)))


def coherence(rho: np.ndarray, i: int, j: int) -> float:
    """Magnitude of the (i, j) off-diagonal coherence."""
    return float(np.abs(rho[i, j]))


# ── common single-qubit jump operators (convenience) ───────────────────────────
def amplitude_damping_jump(rate: float) -> np.ndarray:
    """sqrt(rate) * sigma^-  (|1> -> |0> decay)."""
    return np.sqrt(float(rate)) * np.array([[0.0, 1.0], [0.0, 0.0]], dtype=complex)


def dephasing_jump(rate: float) -> np.ndarray:
    """sqrt(rate) * sigma_z  (pure dephasing of the coherence)."""
    return np.sqrt(float(rate)) * np.array([[1.0, 0.0], [0.0, -1.0]], dtype=complex)
