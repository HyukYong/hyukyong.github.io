"""Kraus (operator-sum) representation of quantum channels.

Every completely-positive trace-preserving (CPTP) map — the most general open-system step — can be
written as rho -> sum_k K_k rho K_k^dag with sum_k K_k^dag K_k = I.  This module:

  * applies a Kraus channel to a density matrix,
  * extracts a minimal Kraus set from a superoperator (the Lindblad propagator expm(L t)) via the
    Choi-Jamiolkowski isomorphism + eigendecomposition, and
  * provides the textbook single-qubit channels (amplitude damping, phase damping, depolarizing).

The Choi route is the bridge between the classical Lindblad propagator (lindblad.py) and a
hardware-runnable channel: each Kraus operator block-encodes onto one ancilla via Sz.-Nagy dilation
(dilation.py).  Column-stacking vectorization (vec = reshape order='F') is shared with lindblad.py.
"""

from __future__ import annotations

import numpy as np


def apply_kraus(rho: np.ndarray, kraus: list[np.ndarray]) -> np.ndarray:
    """rho -> sum_k K_k rho K_k^dag."""
    rho = np.asarray(rho, dtype=complex)
    out = np.zeros_like(rho)
    for K in kraus:
        K = np.asarray(K, dtype=complex)
        out += K @ rho @ K.conj().T
    return out


def is_cptp(kraus: list[np.ndarray], atol: float = 1e-7) -> bool:
    """Trace-preserving check sum_k K_k^dag K_k = I (completeness)."""
    if not kraus:
        return False
    d = np.asarray(kraus[0]).shape[0]
    s = np.zeros((d, d), dtype=complex)
    for K in kraus:
        K = np.asarray(K, dtype=complex)
        s += K.conj().T @ K
    return bool(np.allclose(s, np.eye(d), atol=atol))


def superop_to_choi(superop: np.ndarray, d: int) -> np.ndarray:
    """Choi matrix of a (d^2 x d^2) superoperator (column-stacking convention).

    With S acting as vec(rho_out) = S vec(rho_in), the Choi is the reshuffle
    choi[(i d + k), (j d + l)] = S[(k d + i), (l d + j)] — equivalently apply the channel to each
    |i><j| basis unit.  A CPTP channel has a positive-semidefinite Choi.
    """
    S = np.asarray(superop, dtype=complex)
    choi = np.zeros((d * d, d * d), dtype=complex)
    for i in range(d):
        for j in range(d):
            Eij = np.zeros((d, d), dtype=complex)
            Eij[i, j] = 1.0
            out = (S @ Eij.reshape(-1, order="F")).reshape((d, d), order="F")
            choi[i * d:(i + 1) * d, j * d:(j + 1) * d] = out
    return choi


def kraus_from_choi(choi: np.ndarray, d: int, tol: float = 1e-10) -> list[np.ndarray]:
    """Minimal Kraus set from a (PSD) Choi matrix via eigendecomposition.

    Each eigenpair (lam>tol, v) gives a Kraus operator sqrt(lam) * unvec(v); rank-deficient channels
    drop the null eigenvalues, so the count is the channel's Kraus rank.
    """
    choi = 0.5 * (np.asarray(choi, dtype=complex) + np.asarray(choi, dtype=complex).conj().T)
    w, V = np.linalg.eigh(choi)
    kraus: list[np.ndarray] = []
    for lam, vec in zip(w[::-1], V.T[::-1]):           # descending
        if lam.real <= tol:
            continue
        kraus.append(np.sqrt(lam.real) * vec.reshape((d, d), order="F"))
    return kraus


def superop_to_kraus(superop: np.ndarray, d: int, tol: float = 1e-10) -> list[np.ndarray]:
    """Convenience: superoperator -> Choi -> minimal Kraus set."""
    return kraus_from_choi(superop_to_choi(superop, d), d, tol=tol)


# ── textbook single-qubit channels ─────────────────────────────────────────────
def amplitude_damping_kraus(gamma: float) -> list[np.ndarray]:
    """Amplitude damping (T1 relaxation), decay probability `gamma` in [0,1]."""
    g = float(gamma)
    K0 = np.array([[1.0, 0.0], [0.0, np.sqrt(1.0 - g)]], dtype=complex)
    K1 = np.array([[0.0, np.sqrt(g)], [0.0, 0.0]], dtype=complex)
    return [K0, K1]


def phase_damping_kraus(gamma: float) -> list[np.ndarray]:
    """Phase damping (pure dephasing, T2), dephasing probability `gamma` in [0,1]."""
    g = float(gamma)
    K0 = np.array([[1.0, 0.0], [0.0, np.sqrt(1.0 - g)]], dtype=complex)
    K1 = np.array([[0.0, 0.0], [0.0, np.sqrt(g)]], dtype=complex)
    return [K0, K1]


def depolarizing_kraus(p: float) -> list[np.ndarray]:
    """Depolarizing channel with total error probability `p` in [0,1]."""
    p = float(p)
    I = np.eye(2, dtype=complex)
    X = np.array([[0, 1], [1, 0]], dtype=complex)
    Y = np.array([[0, -1j], [1j, 0]], dtype=complex)
    Z = np.array([[1, 0], [0, -1]], dtype=complex)
    return [
        np.sqrt(1.0 - 3.0 * p / 4.0) * I,
        np.sqrt(p / 4.0) * X,
        np.sqrt(p / 4.0) * Y,
        np.sqrt(p / 4.0) * Z,
    ]
