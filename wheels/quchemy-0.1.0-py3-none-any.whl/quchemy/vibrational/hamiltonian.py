"""Molecular vibrational Hamiltonian in a truncated harmonic-oscillator (Fock) product basis.

Each normal mode i with frequency omega_i is a quantum harmonic oscillator truncated to `levels`
Fock states.  The zeroth-order (harmonic) Hamiltonian is

    H0 = sum_i omega_i (n_i + 1/2),     n_i = a_i^dag a_i,

and an optional per-mode quartic anharmonicity lambda_i * (omega_i) * x_i^4 (x_i = (a_i + a_i^dag)
/ sqrt(2)) turns each mode into a Morse-like anharmonic oscillator — the leading correction a quartic
force field adds beyond the harmonic frequencies.  Everything is assembled as a dense matrix in the
product Fock basis (size prod(levels)), the natural object to (a) diagonalize exactly for a
vibrational-CI reference and (b) encode onto qubits (see :mod:`quchemy.vibrational.encoding`).

Frequencies carry whatever energy unit the caller passes (cm^-1, Hartree, …); the returned energies
are in that same unit, so a harmonic mode's levels come out as (n + 1/2) * omega.
"""

from __future__ import annotations

import numpy as np


def ladder_matrices(levels: int) -> tuple[np.ndarray, np.ndarray]:
    """Annihilation / creation operators (a, a_dag) on a `levels`-truncated Fock space.

    a|n> = sqrt(n)|n-1>, a_dag|n> = sqrt(n+1)|n+1>; the truncation drops the coupling out of the
    top level (standard for a finite oscillator basis).
    """
    n = int(levels)
    a = np.zeros((n, n), dtype=float)
    for k in range(1, n):
        a[k - 1, k] = np.sqrt(k)
    return a, a.T.copy()


def number_matrix(levels: int) -> np.ndarray:
    """Number operator n = a_dag a = diag(0, 1, …, levels-1)."""
    return np.diag(np.arange(int(levels), dtype=float))


def position_matrix(levels: int) -> np.ndarray:
    """Dimensionless position x = (a + a_dag) / sqrt(2) on the truncated Fock space."""
    a, adag = ladder_matrices(levels)
    return (a + adag) / np.sqrt(2.0)


def _embed_single_mode(op: np.ndarray, mode: int, levels: list[int]) -> np.ndarray:
    """Tensor a single-mode operator into the full product Fock space (I ⊗ … ⊗ op ⊗ … ⊗ I)."""
    mats = [np.eye(d) for d in levels]
    mats[mode] = op
    full = mats[0]
    for m in mats[1:]:
        full = np.kron(full, m)
    return full


def harmonic_matrix(frequencies: list[float], levels: list[int]) -> np.ndarray:
    """The harmonic vibrational Hamiltonian sum_i omega_i (n_i + 1/2) as a dense product-Fock matrix.

    `frequencies` and `levels` are per-mode (same length).  The ground (zero-point) energy is
    0.5 * sum_i omega_i; mode i's ladder is spaced by omega_i.
    """
    dim = int(np.prod(levels))
    H = np.zeros((dim, dim), dtype=float)
    for i, omega in enumerate(frequencies):
        n_plus_half = number_matrix(levels[i]) + 0.5 * np.eye(levels[i])
        H += float(omega) * _embed_single_mode(n_plus_half, i, levels)
    return H


def add_quartic_anharmonicity(
    H: np.ndarray, frequencies: list[float], levels: list[int], anharmonicity: list[float]
) -> np.ndarray:
    """Add a per-mode quartic term anharmonicity_i * omega_i * x_i^4 to `H` (returns a new matrix).

    A small positive coefficient stiffens the well (compresses the high levels); the term is the
    leading diagonal-in-mode quartic force-field contribution, enough to make a mode anharmonic
    without the full Watson cross-mode coupling.  `anharmonicity` is per-mode (dimensionless).
    """
    out = H.copy()
    for i, lam in enumerate(anharmonicity):
        if lam == 0.0:
            continue
        x = position_matrix(levels[i])
        x4 = x @ x @ x @ x
        out += float(lam) * float(frequencies[i]) * _embed_single_mode(x4, i, levels)
    return out


def build_matrix(
    frequencies: list[float],
    levels: list[int] | int = 4,
    anharmonicity: list[float] | float = 0.0,
) -> np.ndarray:
    """Assemble the vibrational Hamiltonian matrix for `frequencies`.

    `levels` is the Fock truncation per mode (an int broadcasts to every mode); `anharmonicity` is
    the per-mode quartic coefficient (a float broadcasts).  Returns the dense product-Fock matrix.
    """
    n_modes = len(frequencies)
    lv = [int(levels)] * n_modes if isinstance(levels, int) else [int(x) for x in levels]
    an = [float(anharmonicity)] * n_modes if isinstance(anharmonicity, (int, float)) \
        else [float(x) for x in anharmonicity]
    if len(lv) != n_modes or len(an) != n_modes:
        raise ValueError("levels and anharmonicity must match the number of frequencies")
    H = harmonic_matrix(frequencies, lv)
    if any(a != 0.0 for a in an):
        H = add_quartic_anharmonicity(H, frequencies, lv, an)
    return H


def exact_energies(matrix: np.ndarray, k: int | None = None) -> list[float]:
    """Lowest-`k` vibrational eigenvalues of the dense matrix (all, ascending, when k is None).

    This is the vibrational-CI reference in the chosen Fock truncation — exact within that basis.
    """
    evals = np.linalg.eigvalsh(matrix)
    energies = [float(e) for e in evals]
    return energies if k is None else energies[: int(k)]
