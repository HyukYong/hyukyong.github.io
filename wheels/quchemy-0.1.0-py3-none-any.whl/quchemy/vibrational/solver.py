"""High-level vibrational-structure entry points: build the Hamiltonian, solve for vibrational
energies exactly (vibrational CI in the chosen Fock truncation) or variationally (VQE on the
boson-to-qubit-encoded Hamiltonian), and report fundamentals (transition energies from the ground).

Frequencies carry whatever energy unit the caller passes; energies come back in that unit.
"""

from __future__ import annotations

from dataclasses import dataclass, field

import numpy as np

from . import hamiltonian as vham
from . import encoding as venc


@dataclass
class VibrationalResult:
    """Result of a vibrational-structure calculation."""

    zero_point_energy: float
    energies: list[float] = field(default_factory=list)        # absolute levels, ascending
    fundamentals: list[float] = field(default_factory=list)    # transition energies from the ground
    num_qubits: int = 0
    encoding: str = ""
    levels: list[int] = field(default_factory=list)
    method: str = "exact"


def _levels_list(frequencies, levels) -> list[int]:
    n = len(frequencies)
    return [int(levels)] * n if isinstance(levels, int) else [int(x) for x in levels]


def vibrational_energies(
    frequencies: list[float],
    levels: list[int] | int = 4,
    anharmonicity: list[float] | float = 0.0,
    num_levels: int = 6,
) -> VibrationalResult:
    """Exact vibrational levels (vibrational CI) for a set of normal-mode `frequencies`.

    Diagonalizes the dense product-Fock Hamiltonian — exact within the Fock truncation `levels`.
    Returns the lowest `num_levels` absolute energies, the zero-point energy, and the fundamentals
    (energy of each level above the ground). For a single harmonic mode the levels are (n+1/2)*omega.
    """
    H = vham.build_matrix(frequencies, levels, anharmonicity)
    energies = vham.exact_energies(H, num_levels)
    zpe = energies[0] if energies else 0.0
    return VibrationalResult(
        zero_point_energy=zpe,
        energies=energies,
        fundamentals=[e - zpe for e in energies],
        levels=_levels_list(frequencies, levels),
        method="exact",
    )


def vibrational_qubit_hamiltonian(
    frequencies: list[float],
    levels: list[int] | int = 4,
    anharmonicity: list[float] | float = 0.0,
    encoding: str = "binary",
):
    """Build the boson-to-qubit-encoded vibrational Hamiltonian -> (QubitOperator, n_qubits)."""
    H = vham.build_matrix(frequencies, levels, anharmonicity)
    lv = _levels_list(frequencies, levels)
    return venc.to_qubit_hamiltonian(H, lv, encoding)


def vibrational_vqe(
    frequencies: list[float],
    levels: list[int] | int = 4,
    anharmonicity: list[float] | float = 0.0,
    encoding: str = "binary",
    optimizer: str = "COBYLA",
    max_iterations: int = 2000,
    reps: int = 3,
) -> VibrationalResult:
    """Variational vibrational ground state (zero-point energy) via VQE on the encoded Hamiltonian.

    Uses a hardware-efficient ansatz over the encoded qubits (it accepts any QubitOperator).  Binary
    encoding with a power-of-two level count is the intended target — every basis state is then a
    physical Fock state, so the |0...0> reference is the vibrational ground and there is no penalty
    subspace for the optimizer to fall into.
    """
    from ..solver import VQE
    from ..ansatz import make_hardware_efficient_ansatz

    qop, nq = vibrational_qubit_hamiltonian(frequencies, levels, anharmonicity, encoding)
    ansatz = make_hardware_efficient_ansatz(nq, reps=reps)
    res = VQE(ansatz, qop, optimizer=optimizer, max_iterations=max_iterations).run()
    return VibrationalResult(
        zero_point_energy=float(res.energy),
        energies=[float(res.energy)],
        fundamentals=[0.0],
        num_qubits=nq,
        encoding=encoding,
        levels=_levels_list(frequencies, levels),
        method="VQE",
    )
