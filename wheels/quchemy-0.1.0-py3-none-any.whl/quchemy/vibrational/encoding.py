"""Boson-to-qubit encodings for the vibrational Hamiltonian.

Each mode's truncated Fock space (`levels` states) is mapped onto qubits by one of three encodings
from the literature:

  * "binary" — ceil(log2 levels) qubits/mode; Fock |n> -> the binary digits of n. Compact, and with
    levels a power of two there are NO unused qubit states (every basis state is physical), which
    makes it the cleanest VQE target.
  * "gray"   — ceil(log2 levels) qubits/mode; |n> -> the Gray code of n (adjacent levels differ by
    one bit), favorable for ladder-type couplings.
  * "unary"  — levels qubits/mode; |n> -> one-hot (bit n set). Simple operator structure, more qubits.

The dense product-Fock Hamiltonian (from :mod:`quchemy.vibrational.hamiltonian`) is embedded into the
2^n_qubits space according to the encoding, with any unused (non-physical) basis states lifted by a
diagonal penalty so the physical vibrational spectrum stays lowest.  A Pauli decomposition of that
matrix yields an OpenFermion ``QubitOperator`` the existing VQE / signal solvers run on unchanged.

Qubit ordering matches the rest of quchemy: qubit 0 is the most significant bit, modes concatenated
mode-0-first (consistent with the np.kron assembly of the Fock matrix).
"""

from __future__ import annotations

import numpy as np
from openfermion import QubitOperator


ENCODINGS = ("binary", "gray", "unary")


def mode_qubit_count(levels: int, encoding: str) -> int:
    """Qubits needed for one mode's `levels` Fock states under `encoding`."""
    if encoding == "unary":
        return int(levels)
    # binary / gray
    return max(1, int(np.ceil(np.log2(max(int(levels), 1)))))


def qubit_count(levels: list[int], encoding: str) -> int:
    """Total qubits for all modes."""
    return sum(mode_qubit_count(d, encoding) for d in levels)


def _fock_to_bits(n: int, levels: int, encoding: str) -> list[int]:
    """The qubit bit-pattern (MSB-first) for Fock level `n` of a `levels`-state mode."""
    w = mode_qubit_count(levels, encoding)
    if encoding == "unary":
        bits = [0] * w
        if 0 <= n < w:
            bits[n] = 1
        return bits
    code = n
    if encoding == "gray":
        code = n ^ (n >> 1)
    return [(code >> (w - 1 - k)) & 1 for k in range(w)]


def _occ_to_qubit_index(occ: tuple[int, ...], levels: list[int], encoding: str) -> int:
    """Computational-basis index (MSB-first) for a product-Fock state `occ`."""
    bits: list[int] = []
    for i, n in enumerate(occ):
        bits.extend(_fock_to_bits(n, levels[i], encoding))
    idx = 0
    nq = len(bits)
    for pos, b in enumerate(bits):
        if b:
            idx |= 1 << (nq - 1 - pos)
    return idx


def embed_to_qubit_matrix(
    vib_matrix: np.ndarray, levels: list[int], encoding: str, penalty: float | None = None
) -> tuple[np.ndarray, int]:
    """Place the product-Fock `vib_matrix` into the 2^n qubit space per `encoding`.

    Returns (qubit_matrix, n_qubits).  Non-physical qubit basis states (no corresponding Fock state)
    get a diagonal `penalty` so they sit above the physical spectrum; the default penalty is well
    above the Fock matrix's largest diagonal.  With a power-of-two `levels` under binary/gray there
    are no non-physical states and the penalty is unused.
    """
    nq = qubit_count(levels, encoding)
    dim_q = 1 << nq
    Q = np.zeros((dim_q, dim_q), dtype=float)

    # Map every Fock matrix element to its qubit-index pair.
    occs = list(np.ndindex(*levels))
    phys: set[int] = set()
    for r, occ_r in enumerate(occs):
        qr = _occ_to_qubit_index(occ_r, levels, encoding)
        phys.add(qr)
        for c, occ_c in enumerate(occs):
            val = vib_matrix[r, c]
            if val != 0.0:
                Q[qr, _occ_to_qubit_index(occ_c, levels, encoding)] = val

    # Lift the unused basis states out of the low spectrum.
    if penalty is None:
        penalty = float(np.max(np.diag(vib_matrix))) * 10.0 + 1.0
    if len(phys) < dim_q:
        for q in range(dim_q):
            if q not in phys:
                Q[q, q] = penalty
    return Q, nq


# Single-qubit Pauli matrices for the decomposition.
_PAULI = {
    "I": np.array([[1, 0], [0, 1]], dtype=complex),
    "X": np.array([[0, 1], [1, 0]], dtype=complex),
    "Y": np.array([[0, -1j], [1j, 0]], dtype=complex),
    "Z": np.array([[1, 0], [0, -1]], dtype=complex),
}

# Above this qubit count the dense 4^n Pauli decomposition is impractical (and the local simulator
# would not run it anyway) — fail loud rather than hang.
MAX_PAULI_QUBITS = 10


def pauli_decompose(matrix: np.ndarray, num_qubits: int, tol: float = 1e-10) -> QubitOperator:
    """Decompose a 2^n x 2^n Hermitian matrix into an OpenFermion QubitOperator (sum of Paulis).

    coeff(P) = Tr(P @ matrix) / 2^n for each of the 4^n Pauli strings P; terms below `tol` are
    dropped.  Qubit 0 is the most significant tensor factor (quchemy convention).
    """
    if num_qubits > MAX_PAULI_QUBITS:
        raise ValueError(
            "vibrational Pauli decomposition needs %d qubits — over the %d-qubit limit; "
            "use fewer modes, fewer Fock levels, or a binary encoding."
            % (num_qubits, MAX_PAULI_QUBITS)
        )
    n = num_qubits
    dim = 1 << n
    scale = 1.0 / dim
    qop = QubitOperator()
    labels = "IXYZ"
    for idx in range(4 ** n):
        # Decode the Pauli string: qubit 0 is the most significant base-4 digit.
        ops = []
        x = idx
        chosen = []
        for q in range(n):
            p = labels[(x >> (2 * (n - 1 - q))) & 3]
            chosen.append(p)
            if p != "I":
                ops.append("%s%d" % (p, q))
        # Build the Pauli matrix and project.
        P = _PAULI[chosen[0]]
        for p in chosen[1:]:
            P = np.kron(P, _PAULI[p])
        coeff = scale * np.trace(P @ matrix)
        if abs(coeff) > tol:
            term = " ".join(ops)
            qop += QubitOperator(term, complex(coeff))
    return qop


def to_qubit_hamiltonian(
    vib_matrix: np.ndarray, levels: list[int], encoding: str = "binary",
    penalty: float | None = None,
) -> tuple[QubitOperator, int]:
    """Embed + Pauli-decompose the vibrational Hamiltonian into (QubitOperator, n_qubits)."""
    if encoding not in ENCODINGS:
        raise ValueError("unknown encoding %r; use one of %s" % (encoding, ENCODINGS))
    Q, nq = embed_to_qubit_matrix(vib_matrix, levels, encoding, penalty)
    # Symmetrize away float noise so the operator is exactly Hermitian.
    Q = 0.5 * (Q + Q.conj().T)
    return pauli_decompose(Q, nq), nq
