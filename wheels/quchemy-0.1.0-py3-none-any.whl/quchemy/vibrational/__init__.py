"""Molecular vibrational structure on the quantum path (roadmap Tier 3 / §5.1).

Normal-mode frequencies (from the sidecar's freq/Hessian path) -> a truncated harmonic-oscillator
product Hamiltonian (optionally with quartic anharmonicity) -> a boson-to-qubit encoding ->
vibrational levels, either exactly (vibrational CI in the Fock truncation) or variationally (VQE).
"""

from .hamiltonian import (
    build_matrix,
    harmonic_matrix,
    add_quartic_anharmonicity,
    ladder_matrices,
    number_matrix,
    position_matrix,
    exact_energies,
)
from .encoding import (
    to_qubit_hamiltonian,
    embed_to_qubit_matrix,
    pauli_decompose,
    qubit_count,
    mode_qubit_count,
    ENCODINGS,
)
from .solver import (
    VibrationalResult,
    vibrational_energies,
    vibrational_qubit_hamiltonian,
    vibrational_vqe,
)

__all__ = [
    "build_matrix", "harmonic_matrix", "add_quartic_anharmonicity",
    "ladder_matrices", "number_matrix", "position_matrix", "exact_energies",
    "to_qubit_hamiltonian", "embed_to_qubit_matrix", "pauli_decompose",
    "qubit_count", "mode_qubit_count", "ENCODINGS",
    "VibrationalResult", "vibrational_energies", "vibrational_qubit_hamiltonian",
    "vibrational_vqe",
]
