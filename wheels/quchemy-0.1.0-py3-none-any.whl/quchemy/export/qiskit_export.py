"""Export ParameterizedCircuit to Qiskit QuantumCircuit."""

from __future__ import annotations

from typing import Optional

import numpy as np

from ..circuit.circuit import ParameterizedCircuit


def to_qiskit_circuit(
    circuit: ParameterizedCircuit,
    parameters: Optional[np.ndarray] = None,
):
    """Convert a ParameterizedCircuit to a Qiskit QuantumCircuit.

    Qiskit is imported lazily — only needed when this function is called.

    Parameters
    ----------
    circuit : ParameterizedCircuit
        The circuit to convert.
    parameters : ndarray, optional
        If provided, creates a bound circuit with concrete angles.
        If None, creates Qiskit ParameterVector for unbound parameters.

    Returns
    -------
    qiskit.QuantumCircuit
        The equivalent Qiskit circuit.
    """
    from qiskit.circuit import QuantumCircuit, ParameterVector

    qc = QuantumCircuit(circuit.num_qubits)

    # Create parameter vector for unbound params
    qiskit_params = None
    if parameters is None and circuit.num_parameters > 0:
        qiskit_params = ParameterVector("θ", circuit.num_parameters)

    for gate in circuit.gates:
        # Resolve parameter value
        if gate.param_index is not None and gate.parameter is None:
            if parameters is not None:
                angle = float(gate.param_coeff * parameters[gate.param_index])
            elif qiskit_params is not None:
                angle = gate.param_coeff * qiskit_params[gate.param_index]
            else:
                angle = 0.0
        else:
            angle = gate.parameter

        name = gate.name
        qubits = gate.qubits

        if name == "H":
            qc.h(qubits[0])
        elif name == "X":
            qc.x(qubits[0])
        elif name == "Y":
            qc.y(qubits[0])
        elif name == "Z":
            qc.z(qubits[0])
        elif name == "S":
            qc.s(qubits[0])
        elif name == "T":
            qc.t(qubits[0])
        elif name == "RX":
            qc.rx(angle, qubits[0])
        elif name == "RY":
            qc.ry(angle, qubits[0])
        elif name == "RZ":
            qc.rz(angle, qubits[0])
        elif name == "CNOT":
            qc.cx(qubits[0], qubits[1])
        elif name == "CZ":
            qc.cz(qubits[0], qubits[1])
        elif name == "SWAP":
            qc.swap(qubits[0], qubits[1])
        else:
            raise ValueError(f"Cannot export gate: {name}")

    return qc
