"""`matscipy.neighbours.neighbour_list` backed by `ase.neighborlist.neighbor_list`.

MACE calls (mace/data/neighborhood.py):

    neighbour_list(quantities="ijS", pbc=pbc, cell=cell, positions=positions, cutoff=cutoff)

matscipy and ASE share the same neighbour-list contract: the `quantities` string selects
which arrays to return ("i" sender index, "j" receiver index, "S" integer cell-shift vectors,
"d" distances, "D" distance vectors) and both default `self_interaction=False` (the trivial
home-cell self-edge is dropped, periodic-image self-edges kept). ASE takes an `Atoms` object
rather than loose positions/cell/pbc, so this adapter assembles one and forwards the call.
"""

from __future__ import annotations

import numpy as np
from ase import Atoms
from ase.neighborlist import neighbor_list as _ase_neighbor_list


def neighbour_list(
    quantities,
    atoms=None,
    cutoff=None,
    *,
    positions=None,
    cell=None,
    pbc=None,
    numbers=None,
    **kwargs,
):
    """Drop-in for matscipy.neighbours.neighbour_list, via ASE.

    Accepts either an ASE `atoms` object (positional, matscipy's other signature) or the
    loose `positions`/`cell`/`pbc` keywords MACE uses. Returns the requested quantities in
    the order given by `quantities`, exactly like both upstream implementations."""
    if atoms is None:
        if positions is None:
            raise ValueError("matscipy shim: neighbour_list needs `atoms` or `positions`")
        pos = np.asarray(positions, dtype=float)
        if cell is None:
            cell = np.identity(3, dtype=float)
        if pbc is None:
            pbc = (False, False, False)
        # Element identity is irrelevant for a scalar cutoff; use placeholder Z=1.
        nums = numbers if numbers is not None else np.ones(len(pos), dtype=int)
        atoms = Atoms(numbers=nums, positions=pos, cell=np.asarray(cell, dtype=float), pbc=pbc)
    return _ase_neighbor_list(quantities, atoms, cutoff, **kwargs)
