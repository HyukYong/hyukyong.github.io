"""A minimal `matscipy` stand-in for the MACE backend.

MACE (mace-torch) hard-imports `matscipy.neighbours.neighbour_list` for its neighbor-list
construction, but matscipy has no Python-3.14 wheel and fails to compile there. MACE only
needs the neighbour-list call, and ASE provides an equivalent — so the sidecar injects THIS
package's directory onto sys.path (only when the real matscipy is absent) and `import
matscipy.neighbours` resolves here instead, backed by `ase.neighborlist`.

This is the same load-shim pattern the sidecar uses for the dispersion backend. It is NOT a
full matscipy reimplementation — only the one neighbour-list entry point MACE uses.
"""

__all__ = ["neighbours"]
__matscipy_shim__ = True
