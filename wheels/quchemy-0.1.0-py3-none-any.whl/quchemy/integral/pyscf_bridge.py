"""Bridge between PySCF and OpenFermion for molecular Hamiltonian construction."""

from __future__ import annotations

from typing import Optional

import numpy as np
from openfermion import InteractionOperator, QubitOperator, jordan_wigner, bravyi_kitaev


# Core electrons by atomic number (for frozen-core approximation)
_CORE_ELECTRONS = {
    1: 0, 2: 0,                                    # H, He
    3: 2, 4: 2, 5: 2, 6: 2, 7: 2, 8: 2, 9: 2, 10: 2,  # Li-Ne
    11: 10, 12: 10, 13: 10, 14: 10, 15: 10, 16: 10, 17: 10, 18: 10,  # Na-Ar
    19: 18, 20: 18, 21: 18, 22: 18, 23: 18, 24: 18, 25: 18,  # K-Mn
    26: 18, 27: 18, 28: 18, 29: 18, 30: 18,  # Fe-Zn
    31: 28, 32: 28, 33: 28, 34: 28, 35: 28, 36: 28,  # Ga-Kr
}


def _active_space_integrals(
    mol,
    mf,
    frozen_core: bool = False,
    active_electrons: Optional[int] = None,
    active_orbitals: Optional[int] = None,
) -> dict:
    """Shared active-space reduction: spatial-orbital integrals + window metadata.

    The single source of truth for the active-space selection (frozen core + a window
    centered on the Fermi level) and the resulting spatial-orbital one-/two-electron
    integrals. Both [func get_molecular_hamiltonian] (which expands these into the
    OpenFermion interleaved spin tensors for VQE/QPE) and [func get_active_space_integrals]
    (which hands the spatial integrals to SQD) call this, so the two paths reduce the active
    space identically. Returns a dict with:
      h1   : (n_active, n_active) one-body integrals in the active MO basis
      eri  : (n_active,)*4 two-body integrals, PySCF CHEMIST notation (pq|rs)
      ecore: core energy = nuclear repulsion + frozen-orbital contribution (the constant
             term of the active-space Hamiltonian)
      n_alpha, n_beta, n_active, n_all_frozen, active_start, active_end
      mo_energies, mo_occ: per-active-orbital slices (lists)
    """
    from pyscf import ao2mo

    mo_coeff = mf.mo_coeff
    mo_energies = mf.mo_energy
    mo_occ = mf.mo_occ
    n_orbs_total = mo_coeff.shape[1]
    nuc_energy = mol.energy_nuc()

    # Determine frozen core
    n_frozen = 0
    if frozen_core:
        for atm_id in range(mol.natm):
            z = mol.atom_charge(atm_id)
            n_frozen += _CORE_ELECTRONS.get(int(z), 0) // 2

    # Determine active space
    if active_orbitals is not None:
        n_active = active_orbitals
    else:
        n_active = n_orbs_total - n_frozen

    if active_electrons is not None:
        n_active_elec = active_electrons
    else:
        n_active_elec = int(np.sum(mo_occ)) - 2 * n_frozen

    n_alpha = (n_active_elec + mol.spin) // 2
    n_beta = n_active_elec - n_alpha

    # Select active orbital indices centered around the Fermi level
    total_occ = int(np.sum(mo_occ)) // 2  # total occupied spatial orbitals
    if active_orbitals is not None and active_orbitals < (n_orbs_total - n_frozen):
        # Center the active window around HOMO-LUMO
        n_occ_active = n_active_elec // 2
        active_start = total_occ - n_occ_active
        # Ensure we don't go below frozen core
        active_start = max(active_start, n_frozen)
    else:
        active_start = n_frozen

    active_end = active_start + n_active
    if active_end > n_orbs_total:
        active_end = n_orbs_total
        n_active = active_end - active_start

    mo_active = mo_coeff[:, active_start:active_end]

    # All frozen orbitals = core + doubly-occupied below active window
    n_all_frozen = active_start  # everything below the active window

    # One-electron integrals in active MO basis
    hcore = mf.get_hcore()
    h1 = mo_active.T @ hcore @ mo_active

    # Two-electron integrals in active MO basis (chemist notation)
    eri = ao2mo.full(mol, mo_active, compact=False)
    eri = eri.reshape(n_active, n_active, n_active, n_active)

    # Frozen orbital contribution (core + inactive doubly-occupied)
    if n_all_frozen > 0:
        mo_frozen = mo_coeff[:, :n_all_frozen]
        # Frozen Fock contribution
        dm_frozen = 2.0 * mo_frozen @ mo_frozen.T
        vj, vk = mf.get_jk(mol, dm_frozen)
        fock_frozen = hcore + vj - 0.5 * vk
        h1 = mo_active.T @ fock_frozen @ mo_active
        # Frozen energy
        frozen_energy = np.trace(dm_frozen @ (hcore + 0.5 * (vj - 0.5 * vk)))
        nuc_energy += frozen_energy

    ecore = float(nuc_energy.real if np.iscomplex(nuc_energy) else nuc_energy)
    return {
        "h1": h1,
        "eri": np.asarray(eri, dtype=float),
        "ecore": ecore,
        "n_alpha": n_alpha,
        "n_beta": n_beta,
        "n_active": n_active,
        "n_all_frozen": n_all_frozen,
        "active_start": active_start,
        "active_end": active_end,
        "mo_energies": mo_energies[active_start:active_end].tolist(),
        "mo_occ": mo_occ[active_start:active_end].tolist(),
    }


def get_active_space_integrals(
    mol,
    mf,
    frozen_core: bool = False,
    active_electrons: Optional[int] = None,
    active_orbitals: Optional[int] = None,
) -> tuple[np.ndarray, np.ndarray, float, tuple[int, int], int]:
    """Spatial-orbital active-space integrals for SQD (sample-based diagonalization).

    Returns ``(h1, eri, ecore, (n_alpha, n_beta), n_active)`` where ``h1`` is the one-body
    matrix and ``eri`` the two-body tensor in PySCF CHEMIST notation ``(pq|rs)`` — exactly
    the inputs ``qiskit_addon_sqd.fermion.diagonalize_fermionic_hamiltonian`` expects (it
    converts chemist→physicist internally). Uses the same active-space reduction as the
    VQE/QPE qubit Hamiltonian, so an SQD run sees the identical active space.
    """
    parts = _active_space_integrals(
        mol, mf, frozen_core, active_electrons, active_orbitals)
    return (
        parts["h1"], parts["eri"], parts["ecore"],
        (parts["n_alpha"], parts["n_beta"]), parts["n_active"],
    )


def get_molecular_hamiltonian(
    mol,
    mf,
    frozen_core: bool = False,
    active_electrons: Optional[int] = None,
    active_orbitals: Optional[int] = None,
) -> tuple[InteractionOperator, dict]:
    """Extract molecular Hamiltonian from PySCF objects.

    Parameters
    ----------
    mol : pyscf.gto.Mole
        PySCF molecule object.
    mf : pyscf.scf.HF or similar
        Converged mean-field object (RHF, UHF, or RKS).
    frozen_core : bool
        If True, freeze core orbitals based on atomic number.
    active_electrons : int, optional
        Number of active electrons (overrides auto-detection).
    active_orbitals : int, optional
        Number of active spatial orbitals (overrides auto-detection).

    Returns
    -------
    (InteractionOperator, dict)
        The molecular Hamiltonian and an info dict with:
        - num_particles: (alpha, beta) electron counts
        - num_spatial_orbitals: number of spatial orbitals
        - num_qubits: 2 * num_spatial_orbitals
        - nuclear_repulsion: nuclear repulsion energy
        - mo_energies: MO energies array
        - mo_occ: MO occupancies
        - frozen_core_orbitals: number of frozen core orbitals
    """
    parts = _active_space_integrals(
        mol, mf, frozen_core, active_electrons, active_orbitals)
    h1 = parts["h1"]
    eri = parts["eri"]
    nuc_energy = parts["ecore"]
    n_active = parts["n_active"]
    n_alpha = parts["n_alpha"]
    n_beta = parts["n_beta"]
    n_all_frozen = parts["n_all_frozen"]

    # Convert two-electron integrals to OpenFermion convention.
    # PySCF ao2mo gives chemist notation: eri[p,q,r,s] = (pq|rs)
    # OpenFermion convention: h2[p,q,r,s] = (ps|qr)
    # So: h2 = eri.transpose(0, 2, 3, 1)
    h2_of = np.asarray(eri.transpose(0, 2, 3, 1), dtype=float)

    # Expand to spin-orbital basis with interleaved ordering:
    # spin-orbital 2p = spatial p alpha, 2p+1 = spatial p beta
    n_spin = 2 * n_active

    h1_spin = np.zeros((n_spin, n_spin))
    h2_spin = np.zeros((n_spin, n_spin, n_spin, n_spin))

    for p in range(n_active):
        for q in range(n_active):
            # One-body: same-spin only
            h1_spin[2 * p, 2 * q] = h1[p, q]
            h1_spin[2 * p + 1, 2 * q + 1] = h1[p, q]

            for r in range(n_active):
                for s in range(n_active):
                    # Two-body: 4 spin blocks, each divided by 2
                    val = h2_of[p, q, r, s] / 2.0
                    # αβ mixed spin
                    h2_spin[2*p, 2*q+1, 2*r+1, 2*s] = val
                    h2_spin[2*p+1, 2*q, 2*r, 2*s+1] = val
                    # Same spin
                    h2_spin[2*p, 2*q, 2*r, 2*s] = val
                    h2_spin[2*p+1, 2*q+1, 2*r+1, 2*s+1] = val

    hamiltonian = InteractionOperator(
        constant=float(nuc_energy.real if np.iscomplex(nuc_energy) else nuc_energy),
        one_body_tensor=h1_spin,
        two_body_tensor=h2_spin,
    )

    info = {
        "num_particles": (n_alpha, n_beta),
        "num_spatial_orbitals": n_active,
        "num_qubits": 2 * n_active,
        "nuclear_repulsion": float(mol.energy_nuc()),
        "mo_energies": parts["mo_energies"],
        "mo_occ": parts["mo_occ"],
        "frozen_core_orbitals": n_all_frozen,
    }

    return hamiltonian, info


def map_to_qubits(
    hamiltonian: InteractionOperator, mapping: str = "jordan_wigner"
) -> QubitOperator:
    """Convert an InteractionOperator to a QubitOperator.

    Parameters
    ----------
    hamiltonian : InteractionOperator
        Molecular Hamiltonian from get_molecular_hamiltonian.
    mapping : str
        'jordan_wigner' or 'bravyi_kitaev'.

    Returns
    -------
    QubitOperator
        The qubit Hamiltonian.
    """
    if mapping == "jordan_wigner":
        return jordan_wigner(hamiltonian)
    elif mapping == "bravyi_kitaev":
        return bravyi_kitaev(hamiltonian)
    else:
        raise ValueError(f"Unknown mapping: {mapping}. Use 'jordan_wigner' or 'bravyi_kitaev'.")


def get_num_qubits(qubit_op: QubitOperator) -> int:
    """Get the number of qubits required for a QubitOperator."""
    max_qubit = -1
    for term in qubit_op.terms:
        for qubit, _ in term:
            if qubit > max_qubit:
                max_qubit = qubit
    return max_qubit + 1 if max_qubit >= 0 else 0


def get_hf_state(
    num_electrons: int | tuple[int, int],
    num_qubits: int,
    mapping: str = "jordan_wigner",
) -> np.ndarray:
    """Get the Hartree-Fock reference state as a bitstring array.

    Parameters
    ----------
    num_electrons : int or (int, int)
        Total electrons or (alpha, beta) tuple.
    num_qubits : int
        Number of qubits.
    mapping : str
        Qubit mapping used.

    Returns
    -------
    ndarray
        Binary array of length num_qubits (1 = occupied).
    """
    if isinstance(num_electrons, (tuple, list)):
        n_alpha, n_beta = num_electrons
    else:
        n_alpha = num_electrons // 2
        n_beta = num_electrons - n_alpha

    state = np.zeros(num_qubits, dtype=int)

    if mapping == "jordan_wigner":
        # Interleaved spin ordering: 2i = iα, 2i+1 = iβ
        for i in range(n_alpha):
            state[2 * i] = 1
        for i in range(n_beta):
            state[2 * i + 1] = 1
    elif mapping == "bravyi_kitaev":
        # For BK, start from JW occupation then transform
        jw_state = np.zeros(num_qubits, dtype=int)
        for i in range(n_alpha):
            jw_state[2 * i] = 1
        for i in range(n_beta):
            jw_state[2 * i + 1] = 1
        # BK transformation: cumulative XOR
        for i in range(num_qubits):
            parity = 0
            j = i
            while j >= 0:
                if j & (j + 1) == 0:
                    # j is of the form 2^k - 1, sum bits 0..j
                    for k in range(j + 1):
                        parity ^= jw_state[k]
                    break
                # Remove lowest set bit contribution
                parity ^= jw_state[j]
                j = (j & (j + 1)) - 1
            state[i] = parity
    else:
        raise ValueError(f"Unknown mapping: {mapping}")

    return state
