"""Codegen for engines we control (overhaul §3, §11.2 live-preview; development P1.2).

Each generator returns a STANDALONE python script *string* which, when executed,
writes a `JobResult` JSON (overhaul §3 schema) to a given output path — the same
contract the sidecar emits. No `=== MARKER ===` stdout scraping: the generated
script writes structured data directly.

The string also feeds the Method screen's live script preview (Phase 2, §11.2).
"""

from __future__ import annotations

from .pyscf_codegen import generate_pyscf_script
from .qiskit_codegen import generate_qiskit_script

__all__ = ["generate_pyscf_script", "generate_qiskit_script"]
