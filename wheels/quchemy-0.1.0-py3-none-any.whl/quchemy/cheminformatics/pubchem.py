"""PubChem import (PUG REST): compound name / CID -> molecule document.

GaussView/Avogadro-parity "fetch by name" — the user types ``aspirin`` or ``2244``
and gets the PubChem structure as the same molecule document ``parse_structure``
emits (graph + coords_3d + charge + multiplicity + name + warnings), so the
modeler reuses the structure-import handoff unchanged.

Strategy: prefer the PubChem **3D conformer** SDF; when a record has no 3D
conformer (large/flexible molecules, salts), fall back to the 2D record and
embed it locally with RDKit (AddHs + ETKDG + MMFF) — with a warning saying so,
never silently (§15.4). Unknown compounds and network failures raise
``ValueError`` with a human-readable message; the sidecar action maps that to
``{"ok": false, "error": ...}``.

stdlib ``urllib`` only — no new dependency for one GET.
"""

from __future__ import annotations

import re
import urllib.error
import urllib.parse
import urllib.request
from typing import Any, Callable

from .file_io import _molecule_doc

PUG_BASE = "https://pubchem.ncbi.nlm.nih.gov/rest/pug"

#: PubChem asks API clients to identify themselves.
_USER_AGENT = "qemica/1.0 (quantum-chemistry desktop; PubChem import)"

#: The compound CID rides the SDF property block: "> <PUBCHEM_COMPOUND_CID>\n2244".
_CID_TAG = re.compile(r">\s*<PUBCHEM_COMPOUND_CID>\s*\r?\n(\d+)")

#: A GET callable: (url, timeout) -> (status, body). Injectable for tests.
HttpGet = Callable[[str, float], tuple[int, str]]


def http_get(url: str, timeout: float = 20.0) -> tuple[int, str]:
    """GET ``url`` -> ``(status, body)``.

    A 404 is a *semantic* answer from PUG REST (unknown name / no 3D conformer),
    so it returns ``(404, body)`` instead of raising. Any other HTTP error or a
    network failure raises ``ValueError`` with a readable message.
    """
    req = urllib.request.Request(url, headers={"User-Agent": _USER_AGENT})
    try:
        with urllib.request.urlopen(req, timeout=timeout) as resp:
            return int(resp.status), resp.read().decode("utf-8", errors="replace")
    except urllib.error.HTTPError as exc:
        if exc.code == 404:
            try:
                return 404, exc.read().decode("utf-8", errors="replace")
            except Exception:  # noqa: BLE001 — the body is best-effort context
                return 404, ""
        raise ValueError(f"PubChem request failed (HTTP {exc.code})") from exc
    except urllib.error.URLError as exc:
        raise ValueError(
            f"PubChem is unreachable — check the network connection ({exc.reason})"
        ) from exc
    except TimeoutError as exc:
        raise ValueError("PubChem request timed out") from exc


def fetch_pubchem(
    query: str,
    query_type: str = "auto",
    timeout: float = 20.0,
    get: HttpGet = http_get,
) -> dict[str, Any]:
    """Fetch a compound from PubChem into a molecule document.

    ``query`` is a compound name (``aspirin``) or a CID (``2244``);
    ``query_type`` ∈ {"auto", "name", "cid"} — "auto" treats an all-digit query
    as a CID. Returns the ``parse_structure`` document contract plus ``cid``
    and ``source: "pubchem"``. Raises ``ValueError`` for an empty query, an
    unknown compound, an unparseable record, or a network failure.
    """
    q = (query or "").strip()
    if not q:
        raise ValueError("enter a compound name or PubChem CID")
    ns = _namespace(q, query_type)
    quoted = urllib.parse.quote(q, safe="")

    # 3D conformer first; 2D record as the honest fallback.
    warnings: list[str] = []
    status, sdf = get(f"{PUG_BASE}/compound/{ns}/{quoted}/SDF?record_type=3d", timeout)
    used_2d = False
    if status == 404:
        status, sdf = get(
            f"{PUG_BASE}/compound/{ns}/{quoted}/SDF?record_type=2d", timeout
        )
        if status == 404:
            kind = "CID" if ns == "cid" else "compound named"
            raise ValueError(f"PubChem found no {kind} {q!r}")
        used_2d = True

    mol = _mol_from_sdf_text(sdf, q)
    cid = _extract_cid(sdf)

    if used_2d:
        mol, embedded = _embed_2d_record(mol)
        if embedded:
            warnings.append(
                "PubChem has no 3D conformer for this record — geometry embedded "
                "locally with RDKit (ETKDG + MMFF)"
            )
        else:
            warnings.append(
                "PubChem has no 3D conformer and the local RDKit embed failed — "
                "imported flat 2D coordinates; use Optimize to generate a 3D geometry"
            )

    name = q if ns == "name" else _fetch_title(cid, timeout, get)
    doc = _molecule_doc(mol, f"{name}.sdf", ".sdf", warnings)
    doc["name"] = name
    doc["cid"] = cid
    doc["source"] = "pubchem"
    return doc


def _namespace(query: str, query_type: str) -> str:
    """The PUG REST namespace segment for the query: 'cid' or 'name'."""
    qt = (query_type or "auto").strip().lower()
    if qt == "cid":
        if not query.isdigit():
            raise ValueError(f"a PubChem CID is numeric — got {query!r}")
        return "cid"
    if qt == "name":
        return "name"
    if qt != "auto":
        raise ValueError(f"unknown query_type {query_type!r} — use auto | name | cid")
    return "cid" if query.isdigit() else "name"


def _mol_from_sdf_text(sdf: str, query: str) -> Any:
    """First record of an SDF body -> RDKit Mol (explicit Hs kept)."""
    from rdkit import Chem

    block = sdf.split("$$$$")[0]
    mol = Chem.MolFromMolBlock(block, removeHs=False)
    if mol is None:
        raise ValueError(f"RDKit could not parse the PubChem record for {query!r}")
    return mol


def _extract_cid(sdf: str) -> int:
    """The CID from the SDF property block (0 when the tag is absent)."""
    m = _CID_TAG.search(sdf)
    return int(m.group(1)) if m else 0


def _embed_2d_record(mol: Any) -> tuple[Any, bool]:
    """AddHs + ETKDG + MMFF a flat 2D record into 3D. Returns (mol, embedded).

    On embed failure the ORIGINAL flat mol is returned (embedded=False) so the
    import still lands with honest 2D coordinates instead of failing outright.
    """
    from rdkit import Chem
    from rdkit.Chem import AllChem

    mol_h = Chem.AddHs(mol)
    params = AllChem.ETKDGv3()
    params.randomSeed = 0xF00D  # reproducible imports
    try:
        if AllChem.EmbedMolecule(mol_h, params) != 0:
            return mol, False
        AllChem.MMFFOptimizeMolecule(mol_h)
    except Exception:  # noqa: BLE001 — MMFF lacks params for exotic atoms
        return mol, False
    return mol_h, True


def _fetch_title(cid: int, timeout: float, get: HttpGet) -> str:
    """The PubChem Title for a CID — best-effort; falls back to 'CID <n>'."""
    fallback = f"CID {cid}" if cid > 0 else "pubchem import"
    if cid <= 0:
        return fallback
    try:
        status, body = get(
            f"{PUG_BASE}/compound/cid/{cid}/property/Title/TXT", timeout
        )
    except ValueError:
        return fallback  # the structure already landed — a missing title is cosmetic
    if status != 200:
        return fallback
    title = body.strip().splitlines()[0].strip() if body.strip() else ""
    return title or fallback
