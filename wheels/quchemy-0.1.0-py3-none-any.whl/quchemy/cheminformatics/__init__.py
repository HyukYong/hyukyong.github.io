"""Cheminformatics layer (overhaul §12.2): RDKit-backed depict/embed/SMILES ops.

Pure functions over the cross-language MoleculeGraph JSON contract. The GDScript
`CheminformaticsClient` (§12.5) rides the one Python sidecar boundary to reach these.

The graph JSON contract (MoleculeGraph.to_dict()):
    {
      "atoms": [{"element": str, "formal_charge": int, "implicit_h": int,
                 "aromatic": bool, "isotope": int}, ...],
      "bonds": [{"a": int, "b": int, "order": int, "stereo": str}, ...]
    }
  bond order: 1..4 (4 == aromatic); stereo: "none" | "wedge" | "hash".
"""

from __future__ import annotations

from .file_io import (
    count_xyz_frames,
    parse_structure,
    parse_xyz_trajectory,
    write_structure,
)
from .pubchem import fetch_pubchem
from .rdkit_ops import (
    canonical_smiles,
    depict_2d,
    embed_3d,
    generate_conformers,
    graph_to_rdkit,
    parse_smiles,
    rdkit_to_graph,
)

__all__ = [
    "graph_to_rdkit",
    "rdkit_to_graph",
    "canonical_smiles",
    "depict_2d",
    "embed_3d",
    "generate_conformers",
    "fetch_pubchem",
    "parse_smiles",
    "parse_structure",
    "parse_xyz_trajectory",
    "count_xyz_frames",
    "write_structure",
]
