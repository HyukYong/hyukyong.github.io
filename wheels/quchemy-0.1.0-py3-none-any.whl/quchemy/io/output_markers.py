"""Output formatting for Quchemy Analyzer integration.

Prints structured marker blocks that the GDScript Analyzer can parse.
"""

from __future__ import annotations

from typing import Optional


def print_methodology(
    method: str,
    basis: str,
    calc_type: str,
    functional: Optional[str] = None,
) -> None:
    """Print the === METHODOLOGY === block.

    Parameters
    ----------
    method : str
        Calculation method (e.g., 'VQE', 'VQD', 'ADAPT-VQE').
    basis : str
        Basis set name.
    calc_type : str
        Calculation type (e.g., 'energy', 'vqe', 'vqd').
    functional : str, optional
        DFT functional if applicable.
    """
    print("=== METHODOLOGY ===")
    print(f"METHOD: {method}")
    print(f"BASIS: {basis}")
    if functional:
        print(f"FUNCTIONAL: {functional}")
    print(f"CALC_TYPE: {calc_type}")
    print("=== END METHODOLOGY ===")


def print_circuit_info(
    num_particles: int | tuple[int, int],
    num_spatial_orbitals: int,
    num_qubits: int,
    ansatz_depth: int,
    num_parameters: int,
    active_space: Optional[str] = None,
    after_freezing: Optional[str] = None,
) -> None:
    """Print circuit metadata that the Analyzer's _parse_qiskit() expects.

    Parameters
    ----------
    num_particles : int or (int, int)
        Total electrons or (alpha, beta).
    num_spatial_orbitals : int
        Number of spatial orbitals.
    num_qubits : int
        Number of qubits in the circuit.
    ansatz_depth : int
        Circuit depth.
    num_parameters : int
        Number of variational parameters.
    active_space : str, optional
        Active space description.
    after_freezing : str, optional
        Post-freezing orbital/electron description.
    """
    if isinstance(num_particles, (tuple, list)):
        particles_str = f"({num_particles[0]}, {num_particles[1]})"
    else:
        particles_str = str(num_particles)

    print(f"Number of particles: {particles_str}")
    print(f"Number of spatial orbitals: {num_spatial_orbitals}")
    print(f"Number of qubits: {num_qubits}")
    print(f"Ansatz depth: {ansatz_depth}")
    print(f"Number of parameters: {num_parameters}")
    if active_space:
        print(f"Active space: {active_space}")
    if after_freezing:
        print(f"After freezing core: {after_freezing}")


def print_energies(
    ground_energy: float,
    total_energy: Optional[float] = None,
    nuclear_repulsion: Optional[float] = None,
    excited_energies: Optional[list[float]] = None,
) -> None:
    """Print energy results.

    Parameters
    ----------
    ground_energy : float
        Ground state energy in Hartree.
    total_energy : float, optional
        Total energy (if different from ground state).
    nuclear_repulsion : float, optional
        Nuclear repulsion energy.
    excited_energies : list[float], optional
        Excited state energies.
    """
    print(f"Ground state energy: {ground_energy:.10f} Hartree")
    if total_energy is not None:
        print(f"Total energy: {total_energy:.10f} Hartree")
    if nuclear_repulsion is not None:
        print(f"Nuclear repulsion: {nuclear_repulsion:.10f} Hartree")
    if excited_energies:
        for i, e in enumerate(excited_energies):
            print(f"State {i + 1}: {e:.10f} Hartree")


def print_mo_energies(
    mo_energies: list[float],
    mo_occs: list[float],
) -> None:
    """Print the === MO ENERGIES === block.

    Parameters
    ----------
    mo_energies : list[float]
        Molecular orbital energies.
    mo_occs : list[float]
        Orbital occupancies.
    """
    print("=== MO ENERGIES ===")
    n = len(mo_energies)
    # Identify HOMO and LUMO
    homo_idx = -1
    lumo_idx = -1
    for i in range(n):
        if mo_occs[i] > 0.5:
            homo_idx = i
    lumo_idx = homo_idx + 1 if homo_idx + 1 < n else -1

    for i in range(n):
        label = ""
        if i == homo_idx:
            label = " HOMO"
        elif i == lumo_idx:
            label = " LUMO"
        print(f"MO {i + 1}: energy={mo_energies[i]:.10f} occ={mo_occs[i]:.1f}{label}")
    print("=== END MO ENERGIES ===")


def print_mulliken_charges(
    atoms: list[str],
    charges: list[float],
) -> None:
    """Print the === MULLIKEN CHARGES === block.

    Parameters
    ----------
    atoms : list[str]
        Element symbols.
    charges : list[float]
        Mulliken charges per atom.
    """
    print("=== MULLIKEN CHARGES ===")
    for i, (atom, charge) in enumerate(zip(atoms, charges)):
        print(f"ATOM {i + 1}: {atom} charge={charge:.6f}")
    print("=== END MULLIKEN CHARGES ===")
