"""`python -m quchemy.sidecar` — the sidecar entrypoint from an installed wheel.

The full sidecar implementation lives in the top-level `sidecar` module (repo:
`quchemy_engine/sidecar.py`; wheel: shipped via `py-modules`). This shim makes the
module runnable both ways the app spawns it:

- dev repo:        `<venv python> quchemy_engine/sidecar.py <request.json>`
- installed wheel: `<venv python> -m quchemy.sidecar <request.json>`

The `quchemy-sidecar` console script (pyproject) resolves to `main` re-exported here.
"""

from __future__ import annotations

import sys

from sidecar import main

if __name__ == "__main__":
    sys.exit(main())
