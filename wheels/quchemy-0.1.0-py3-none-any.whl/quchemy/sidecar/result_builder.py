"""JobResult builder — the single source of truth for the cross-language result
contract (overhaul §3, §13.5).

The sidecar (and our generated PySCF/Qiskit scripts) emit a `result.json` that
GDScript's `JobResult.from_dict` (src/domain/job/job_result.gd) reads. This module
GUARANTEES the exact key set: start from `blank_result()` (every key present with a
sane default) and fill in what a given calculation computed. Tab-specific arrays
stay empty when not computed.

Schema is versioned (`schema_version`). All numbers are emitted as JSON numbers.
"""

from __future__ import annotations

import hashlib
import importlib
import json
import math
import os
import platform
from typing import Any

SCHEMA_VERSION: int = 1
ENERGY_UNIT_HARTREE: str = "Hartree"

# Every top-level key the GDScript `JobResult` contract requires. Used to assert
# that nothing drifts out of the builder (tests rely on this list).
CONTRACT_KEYS: tuple[str, ...] = (
    "schema_version",
    "success",
    "error",
    # Non-fatal degradation notes ("frequencies unavailable: ...", "SCF not converged
    # at MD step 12"). The job still succeeds — these stop an empty Analyze tab from
    # being a silent mystery.
    "warnings",
    "energy_unit",
    # Overview
    "method",
    "basis",
    "functional",
    "engine",
    "engine_version",
    # Verbose human-readable engine log (pyscf SCF at verbose=5, IBM/qiskit runtime records,
    # any prints) captured during the run for the Analyze "Raw" tab. Diagnostics only — never
    # the result channel (§3). The persistence layer peels this into a separate file-of-record.
    "engine_log",
    "charge",
    "multiplicity",
    "formula",
    "point_group",
    "wall_clock_s",
    "host",
    "total_energy",
    "scf_energy",
    "converged",
    # SCF reference actually run ("RHF","RKS","UHF","UKS","ROHF","ROKS"; "" when no
    # mean-field ran, e.g. external parses). Honest: stamped from the converged mf
    # object, never from the request.
    "reference",
    # Open-shell spin diagnostics — defaults (0.0 / []) for closed-shell results.
    # s_squared is ⟨S²⟩ of the converged wavefunction; s_squared_exact is S(S+1)
    # for the requested multiplicity; spin_populations is the per-atom Mulliken
    # spin density (alpha−beta), same atom order as `charges`.
    "s_squared",
    "s_squared_exact",
    "spin_populations",
    # Geometry
    "final_coords",
    # Element symbols, same order as final_coords. The result carries its OWN atom
    # identity so the Analyze tabs never pair result coordinates with whatever
    # molecule happens to be loaded (imported outputs describe a different system).
    # [] only on older documents — consumers then fall back to the current molecule.
    "atom_symbols",
    "z_matrix",
    # Mayer bond orders (GaussView/Multiwfn parity) — the wavefunction-derived bond
    # order per atom pair, revealing actual bond character (single/double/triple/
    # aromatic/partial) vs the drawn Lewis structure. Each {"a","b","order"} with
    # 0-indexed atoms a < b; only SIGNIFICANT pairs (order ≥ ~0.3). [] when no
    # mean-field ran (external parses) or the analysis was unavailable.
    "bond_orders",
    "opt_steps",
    # Geometry constraints actually FROZEN during a constrained optimization
    # (relaxed-scan / hold-a-key-coordinate). Each {"kind","atoms"} with 0-indexed
    # atoms — distance(2) / angle(3) / dihedral(4). [] for an unconstrained run.
    # Echoed so the user (and Reproduce) sees exactly what was held.
    "constraints",
    # Orbitals
    "orbitals",
    "homo_index",
    "lumo_index",
    "cube_files",
    # Density isosurfaces (GaussView parity): each {"kind","path"} where kind is
    # "total" (electron density, positive-definite) or "spin" (alpha−beta, only
    # written for spin-separated references). [] when cubes were not requested.
    "density_cubes",
    # CASSCF / active-space block — {} for single-reference methods. Carries the
    # active-space definition the run used plus its multireference diagnostics
    # (natural-orbital occupations, leading CI weight). See [func]cas_block[/func].
    "cas",
    # Quantum (VQE / ADAPT-VQE / QPE) circuit + run metrics — {} for classical methods.
    # The ACTUAL counterpart to the Method screen's pre-run estimate: qubits, mapping,
    # algorithm, ansatz, circuit depth, parameters, optimizer iterations, energy history.
    # See [func]quantum_block[/func].
    "quantum",
    # IR / Raman
    "vibrations",
    # Vibrational-structure quantum analysis ({} unless the vibrational_vqe calc ran): the
    # boson-to-qubit vibrational levels for a selected mode subset. See [func]vibrational_block[/func].
    "vibrational",
    # Open-quantum-system dissipative dynamics ({} unless the open_dynamics calc ran): the
    # Lindblad / dissipative-VQE density-matrix evolution and steady state — populations,
    # coherence, purity over time, plus the converged steady state. See [func]open_system_block[/func].
    "open_system",
    # UV-Vis
    "excited_states",
    # Excited-state method actually run ("", "TDA", "TDDFT") and emission (excited-state
    # optimization / fluorescence) block — {} when no excited-state geometry was relaxed.
    "excited_method",
    "emission",
    # Natural transition orbitals (NTOs) — the dominant hole→particle orbital pair for
    # each excited state (GaussView/Multiwfn parity, the proper "what does this
    # excitation look like" picture vs the raw MO→MO weight list). Each
    # {"state":int (1-based, matching the excited_states index), "weight":float
    # (dominant pair weight, 0–1), "hole_path":str, "particle_path":str}. The two
    # paths are .cube files (cubegen.orbital of the dominant occupied/virtual NTO
    # coefficient columns), under the job's out_dir like the orbital cubes. [] unless
    # the opt-in compute_nto ran on a (restricted) TDDFT/TDA job.
    "nto_cubes",
    # NMR
    "nmr_shieldings",
    # MD / trajectory
    "trajectory",
    # Periodic provenance ({} for molecular runs): {"kpts":[n,n,n], "n_kpts",
    # "cell_volume_a3", "lattice":{"a","b","c"}} — filled by the pyscf.pbc branch.
    "periodic",
    # What KIND of trajectory `trajectory` holds ("" none; "md" molecular dynamics;
    # "optimization" a geometry-optimization path imported via cclib). The MD/
    # Trajectory tab reads this to label frames honestly (fs for MD, step index for
    # an optimization) and to hide the temperature chart on optimizations.
    "trajectory_kind",
    # IRC
    "irc_path",
    # PES scan: each {"coordinate","energy"}
    "scan_points",
    # NEB (nudged-elastic-band) reaction path ([] unless the `neb` calc ran): the
    # optimized chain of images from reactant to product, each {"image","coordinate"
    # (cumulative path length Å),"energy" (Ha),"coords"[{x,y,z}]}. The barrier is read
    # off it (max image − endpoints). See [func]neb_point[/func]. The same band is also
    # mirrored into `trajectory` (trajectory_kind "neb") for the 3D scrubber.
    "neb_path",
    # Thermochemistry + stationary-point character (filled by frequency calcs)
    "thermochemistry",
    # Thermochemistry-vs-temperature table: each {"temperature_k","gibbs","enthalpy",
    # "entropy","zpe"} (energies Hartree, entropy Hartree/K) evaluated from the SAME
    # frequencies at a spread of temperatures (the chosen one + standard reference
    # points). Lets the user read how G/H/S change with T. [] when no real frequencies.
    "thermo_scan",
    "n_imaginary",
    "stationary_point",
    # Shared
    "charges",
    # Meta-Löwdin atomic charges alongside the Mulliken `charges` (P-UI-25 A2) —
    # same atom order; [] when the population analysis was unavailable.
    "charges_lowdin",
    # ESP-fitted (Merz–Kollman) atomic charges (GaussView parity) — same atom
    # order; [] when the fit was unavailable.
    "charges_esp",
    # Condensed Fukui reactivity indices (Yang–Mortier, Mulliken-based) — predict
    # WHERE a molecule reacts. Each {"atom","f_plus","f_minus","dual"} (0-indexed,
    # same atom order as `charges`): f_plus is the nucleophilic site (added electron),
    # f_minus the electrophilic site (removed electron), dual = f_plus − f_minus
    # (>0 electrophilic / a nucleophile attacks here; <0 nucleophilic). [] unless the
    # opt-in compute_fukui ran on a closed-shell-singlet neutral. Two extra SCFs (the
    # N±1 ions); failure or wrong scope degrades to [] + a warning, never fatal.
    "fukui",
    # Global conceptual-DFT reactivity descriptors ({} unless the opt-in Fukui run
    # ALSO captured the N±1 ion total energies on a closed-shell-singlet neutral).
    # Vertical ΔSCF finite-difference indices (Parr/Pearson): ionization potential,
    # electron affinity, electronegativity χ, chemical potential μ=−χ, chemical
    # hardness η, global softness S=1/η, electrophilicity index ω=μ²/2η, and the
    # maximal electron flow ΔN_max=−μ/η. See [func]reactivity_block[/func]. eV.
    "reactivity",
    # Localized-bonding (NBO-style) analysis ({} unless the opt-in `nbo` calc ran):
    # the Lewis picture from the wavefunction — intrinsic/Pipek–Mezey localized
    # occupied orbitals classified as core / lone pair / 2-centre bond, each with its
    # atomic composition + occupancy, plus the natural (meta-Löwdin) atomic charges.
    # See [func]bonding_block[/func].
    "bonding",
    # MACE committee uncertainty ({} unless a MACE energy ran with a ≥2-model committee):
    # the epistemic spread of the prediction across the committee — {energy_std_ha,
    # max_force_std_ev_ang, n_models}. A rough (uncalibrated) confidence signal for the ML
    # potential; large spread ⇒ off the training distribution. See [func]mace_uncertainty[/func].
    "mace_uncertainty",
    "dipole",
    # Static dipole polarizability tensor α — 3×3 nested list in atomic units
    # (opt-in via spec.params.compute_polarizability); [] when not computed.
    "polarizability",
    # Provenance
    "rng_seed",
    "geometry_checksum",
    "library_versions",
    "calc_type",
    "solvent",
    # Implicit-solvent model actually applied to the SCF ("", PCM, SMD, COSMO).
    # Stamped only when a reaction field was attached — never lies about gas runs.
    "solvent_model",
    # Dispersion correction actually applied to the SCF ("", "D3", "D3(BJ)", "D4").
    # Same honesty rule as solvent_model: stamped only when really attached.
    "dispersion",
    # The REQUEST's spec.params, copied verbatim ({} when none). Reproduce (§15.7)
    # rebuilds the input JobSpec from the result; without this, every params-driven
    # knob (md_steps, excited_nstates, cas, dispersion, solvent_model, …) silently
    # reverted to defaults on a reproduced run.
    "spec_params",
)

# Packages whose versions we record in every result for provenance (§15.7).
_PROVENANCE_PACKAGES: tuple[str, ...] = (
    "pyscf",
    "openfermion",
    "cclib",
    "numpy",
    "scipy",
)


def blank_result() -> dict[str, Any]:
    """Return a JobResult dict with EVERY contract key present at a default value.

    Callers mutate the returned dict to fill in computed fields. This is the only
    correct way to construct a result — it guarantees no key is ever missing.
    """
    return {
        "schema_version": SCHEMA_VERSION,
        "success": False,
        "error": "",
        "warnings": [],
        "energy_unit": ENERGY_UNIT_HARTREE,
        # Overview
        "method": "",
        "basis": "",
        "functional": "",
        "engine": "",
        "engine_version": "",
        "engine_log": "",
        "charge": 0,
        "multiplicity": 1,
        "formula": "",
        "point_group": "",
        "wall_clock_s": 0.0,
        "host": "",
        "total_energy": 0.0,
        "scf_energy": 0.0,
        "converged": False,
        # SCF reference + open-shell diagnostics (defaults = closed shell / not run)
        "reference": "",
        "s_squared": 0.0,
        "s_squared_exact": 0.0,
        "spin_populations": [],
        # Geometry
        "final_coords": [],
        "atom_symbols": [],
        "z_matrix": [],
        "bond_orders": [],
        "opt_steps": [],
        # Frozen geometry constraints actually applied (relaxed-scan / freeze); [] when
        # the run was unconstrained.
        "constraints": [],
        # Orbitals
        "orbitals": [],
        "homo_index": -1,
        "lumo_index": -1,
        "cube_files": [],
        "density_cubes": [],
        # CASSCF / active-space ({} unless a multireference run filled it)
        "cas": {},
        # Quantum circuit + run metrics ({} unless a VQE/ADAPT/QPE run filled it)
        "quantum": {},
        # IR / Raman
        "vibrations": [],
        "vibrational": {},
        # Open-quantum-system dissipative dynamics ({} unless an open_dynamics calc filled it)
        "open_system": {},
        # UV-Vis
        "excited_states": [],
        "excited_method": "",
        "emission": {},
        # Natural transition orbitals: dominant hole/particle pair per excited state
        # ([] unless the opt-in compute_nto ran on a restricted TDDFT/TDA job).
        "nto_cubes": [],
        # NMR
        "nmr_shieldings": [],
        # MD / trajectory
        "trajectory": [],
        "periodic": {},
        "trajectory_kind": "",
        # IRC
        "irc_path": [],
        # PES scan
        "scan_points": [],
        # NEB reaction path ([] unless the `neb` calc filled it)
        "neb_path": [],
        # Thermochemistry + stationary point
        "thermochemistry": {},
        # Thermochemistry-vs-temperature table ([] unless a frequency calc with real
        # modes filled it).
        "thermo_scan": [],
        "n_imaginary": 0,
        "stationary_point": "",
        # Shared
        "charges": [],
        "charges_lowdin": [],
        "charges_esp": [],
        # Condensed Fukui indices ([] unless the opt-in compute_fukui ran)
        "fukui": [],
        # Global conceptual-DFT reactivity descriptors ({} unless the Fukui run filled it)
        "reactivity": {},
        # Localized-bonding (NBO-style) analysis ({} unless the `nbo` calc filled it)
        "bonding": {},
        # MACE committee uncertainty ({} unless a committee MACE energy filled it)
        "mace_uncertainty": {},
        "dipole": {"x": 0.0, "y": 0.0, "z": 0.0},
        "polarizability": [],
        # Provenance
        "rng_seed": 0,
        "geometry_checksum": "",
        "library_versions": {},
        "calc_type": "",
        "solvent": "",
        "solvent_model": "",
        "dispersion": "",
        "spec_params": {},
    }


def error_result(message: str, *, spec: dict[str, Any] | None = None) -> dict[str, Any]:
    """A blank result flagged failed, with the error message and host/versions filled."""
    result = blank_result()
    result["success"] = False
    result["error"] = str(message)
    result["host"] = host()
    result["library_versions"] = library_versions()
    if spec:
        result["method"] = str(spec.get("method", ""))
        result["basis"] = str(spec.get("basis_set", ""))
        result["functional"] = str(spec.get("functional", ""))
        result["charge"] = int(spec.get("charge", 0))
        result["multiplicity"] = int(spec.get("multiplicity", 1))
        result["rng_seed"] = int(spec.get("rng_seed", 0) or 0)
        # Carry what was asked for, so a failed job is still attributable in the
        # Manager (which calc type / solvent the user requested). For an error
        # result nothing ran, so these are the REQUESTED model/correction/params,
        # mirroring calc_type/solvent above (the success path stamps them only
        # when actually attached).
        result["calc_type"] = str(spec.get("calc_type", ""))
        result["solvent"] = str(spec.get("solvent", ""))
        params = spec.get("params", {})
        params = dict(params) if isinstance(params, dict) else {}
        model = str(params.get("solvent_model", "")).strip()
        result["solvent_model"] = "" if model.lower() in ("", "gas") else model.upper()
        result["dispersion"] = str(params.get("dispersion", "")).strip()
        result["spec_params"] = params
    return result


# ─────────────────────────── field helpers ───────────────────────────


def vec3(x: float, y: float, z: float) -> dict[str, float]:
    """A {"x","y","z"} point with plain-float values (JSON numbers, not strings)."""
    return {"x": float(x), "y": float(y), "z": float(z)}


def coords_from_atoms(atoms: list[dict[str, Any]]) -> list[dict[str, float]]:
    """Convert a molecule's atom list into the `final_coords` array shape."""
    return [vec3(a["x"], a["y"], a["z"]) for a in atoms]


def symbols_from_atoms(atoms: list[dict[str, Any]]) -> list[str]:
    """Element symbols in atom order — the `atom_symbols` array shape (pairs 1:1
    with `final_coords` so consumers can label result geometry without a molecule)."""
    return [str(a.get("element", "")) for a in atoms]


def orbital(
    index: int, energy: float, occupation: float, symmetry: str = "", spin: str = ""
) -> dict[str, Any]:
    """An Orbital entry: {"index","energy","occupation","symmetry","spin"}.

    `spin` is "" for restricted/RO orbitals and "a"/"b" for the alpha/beta channels
    of an unrestricted (UHF/UKS) mean-field. `index` is the MO index WITHIN its spin
    channel (so alpha MO 3 and beta MO 3 share an index but differ in spin)."""
    return {
        "index": int(index),
        "energy": float(energy),
        "occupation": float(occupation),
        "symmetry": str(symmetry),
        "spin": str(spin),
    }


def orbitals_from_mo(
    mo_energies: list[float],
    mo_occ: list[float],
    symmetries: list[str] | None = None,
    spin: str = "",
) -> tuple[list[dict[str, Any]], int, int]:
    """Build the orbital list and (homo_index, lumo_index) from MO energies/occupancies.

    HOMO = highest index with non-zero occupation; LUMO = HOMO + 1 (or -1 if none).
    `spin` tags every entry ("a"/"b" for one unrestricted channel, "" restricted).
    """
    orbs: list[dict[str, Any]] = []
    homo = -1
    for i, (e, occ) in enumerate(zip(mo_energies, mo_occ)):
        sym = symmetries[i] if symmetries and i < len(symmetries) else ""
        orbs.append(orbital(i, e, occ, sym, spin))
        if float(occ) > 1e-9:
            homo = i
    lumo = homo + 1 if (homo >= 0 and homo + 1 < len(orbs)) else -1
    return orbs, homo, lumo


def cas_block(
    *,
    ncas: int,
    nelecas: tuple[int, int],
    ncore: int,
    active_mos: list[int],
    natural_occ: list[float],
    ci_weights: list[float],
    converged: bool,
) -> dict[str, Any]:
    """The CASSCF / active-space block (overhaul §13.5, multireference workflow).

    `ncas`/`nelecas` define the active space the run actually used; `active_mos` are
    the absolute (0-based) MO indices that entered it (what the Analyze picker selected
    via `sort_mo`). `natural_occ` are the active natural-orbital occupations (0–2) — the
    iterate-the-active-space feedback the user reads back. `ci_weights` are the leading
    determinant weights (|c|², descending); `ci_weights[0]` is the reference weight, a
    multireference diagnostic (≈1 → single-reference, ≪1 → strongly correlated)."""
    leading = float(ci_weights[0]) if ci_weights else 0.0
    return {
        "ncas": int(ncas),
        "nelecas": [int(nelecas[0]), int(nelecas[1])],
        "ncore": int(ncore),
        "active_mos": [int(i) for i in active_mos],
        "natural_occ": [float(o) for o in natural_occ],
        "ci_weights": [float(w) for w in ci_weights],
        "reference_weight": leading,
        "converged": bool(converged),
    }


def quantum_block(
    *,
    num_qubits: int,
    mapping: str,
    algorithm: str,
    ansatz: str = "",
    num_parameters: int = 0,
    iterations: int = 0,
    circuit_depth: int = 0,
    num_ancilla: int = 0,
    energy_history: list[float] | None = None,
) -> dict[str, Any]:
    """The quantum circuit + run-metrics block (overhaul §13.5) for a VQE/ADAPT/QPE result.

    The ACTUAL circuit the engine ran, so the Analyze Overview can show it against the Method
    screen's pre-run estimate: `num_qubits` (width), `mapping` (jordan_wigner/bravyi_kitaev),
    `algorithm` (UCCSD-VQE/ADAPT-VQE/QPE), `ansatz`, `num_parameters`, the optimizer
    `iterations`, the gate-layer `circuit_depth`, `num_ancilla` (QPE only), and the optimizer
    `energy_history` (downsampled to ≤512 points so a long COBYLA run can't bloat result.json).
    """
    hist = [float(e) for e in (energy_history or [])]
    if len(hist) > 512:
        stride = (len(hist) + 511) // 512
        # Keep the stride-sampled trace AND the true final value (the converged energy).
        hist = hist[::stride] + [hist[-1]]
    return {
        "num_qubits": int(num_qubits),
        "mapping": str(mapping),
        "algorithm": str(algorithm),
        "ansatz": str(ansatz),
        "num_parameters": int(num_parameters),
        "iterations": int(iterations),
        "circuit_depth": int(circuit_depth),
        "num_ancilla": int(num_ancilla),
        "energy_history": hist,
    }


def vibration_mode(
    wavenumber: float,
    ir_intensity: float = 0.0,
    raman_activity: float = 0.0,
    displacements: list[dict[str, float]] | None = None,
) -> dict[str, Any]:
    """A VibrationMode: {"wavenumber","ir_intensity","raman_activity","displacements"}."""
    return {
        "wavenumber": float(wavenumber),
        "ir_intensity": float(ir_intensity),
        "raman_activity": float(raman_activity),
        "displacements": displacements or [],
    }


def vibrational_block(
    *,
    mode_frequencies: list[float],
    zero_point_energy: float,
    levels: list[float],
    fundamentals: list[float],
    encoding: str,
    fock_levels: int,
    num_qubits: int,
    anharmonicity: float,
    method: str,
) -> dict[str, Any]:
    """The vibrational-structure quantum-analysis block (vibrational_vqe calc).

    `mode_frequencies` are the harmonic wavenumbers (cm^-1) of the SELECTED modes the quantum
    vibrational Hamiltonian was built from; `levels`/`fundamentals` are the resulting vibrational
    energies / transitions (cm^-1); `encoding` (binary|gray|unary), `fock_levels` (per-mode
    truncation d), `num_qubits` and `anharmonicity` are the recipe; `method` is "exact" (vibrational
    CI in the Fock truncation) or "VQE" (variational on the encoded Hamiltonian).
    """
    return {
        "mode_frequencies": [float(f) for f in mode_frequencies],
        "zero_point_energy": float(zero_point_energy),
        "levels": [float(e) for e in levels],
        "fundamentals": [float(e) for e in fundamentals],
        "encoding": str(encoding),
        "fock_levels": int(fock_levels),
        "num_qubits": int(num_qubits),
        "anharmonicity": float(anharmonicity),
        "method": str(method),
    }


def open_system_block(
    *,
    algorithm: str,
    dimension: int,
    num_qubits: int,
    num_ancilla: int,
    times: list[float],
    populations: list[list[float]],
    coherence: list[float],
    purity_trace: list[float],
    steady_state_real: list[list[float]],
    steady_state_imag: list[list[float]],
    steady_populations: list[float],
    steady_purity: float,
    jump_operators: list[str],
    residual: float = 0.0,
) -> dict[str, Any]:
    """The open-quantum-system block (roadmap §6): dissipative density-matrix dynamics + steady state.

    `algorithm` is "lindblad" (exact master-equation propagation) or "dvqe" (variational steady
    state). `dimension` is the Hilbert-space size d (so `num_qubits` = log2 d); `num_ancilla` is the
    Sz.-Nagy / Kraus dilation overhead a hardware run would pay. The TIME SERIES (`times`,
    `populations` rows aligned to times, `coherence` = a representative |ρ_ij| off-diagonal,
    `purity_trace` = Tr(ρ²) per time) is the decoherence/thermalization trajectory; empty for a
    pure steady-state (dvqe) run. `steady_state_real`/`steady_state_imag` are the d×d steady density
    matrix (split because JSON has no complex); `steady_populations`/`steady_purity` summarize it.
    `jump_operators` are human-readable dissipator descriptions ("amplitude damping γ=0.7"); for
    dvqe, `residual` = ‖L·vec(ρ)‖ at the optimum (→0 converged).
    """
    return {
        "algorithm": str(algorithm),
        "dimension": int(dimension),
        "num_qubits": int(num_qubits),
        "num_ancilla": int(num_ancilla),
        "times": [float(t) for t in times],
        "populations": [[float(p) for p in row] for row in populations],
        "coherence": [float(c) for c in coherence],
        "purity_trace": [float(p) for p in purity_trace],
        "steady_state_real": [[float(x) for x in row] for row in steady_state_real],
        "steady_state_imag": [[float(x) for x in row] for row in steady_state_imag],
        "steady_populations": [float(p) for p in steady_populations],
        "steady_purity": float(steady_purity),
        "jump_operators": [str(j) for j in jump_operators],
        "residual": float(residual),
    }


def excited_state(
    energy_ev: float,
    wavelength_nm: float,
    osc_strength: float,
    symmetry: str = "",
    *,
    multiplicity: int = 1,
    transitions: list[dict[str, Any]] | None = None,
    transition_dipole: dict[str, float] | None = None,
    rotatory_strength: float = 0.0,
) -> dict[str, Any]:
    """An excited state. `multiplicity` is 1 (singlet) or 3 (triplet); `transitions` is
    the list of dominant occupied→virtual contributions (see [func]transition[/func]);
    `transition_dipole` is the electric transition dipole vector (a.u.).
    `rotatory_strength` is the length-gauge rotatory strength R = μ·m (electric·magnetic
    transition dipole) in 10⁻⁴⁰ cgs (esu·cm·erg/G) — the per-state intensity of the
    electronic CD (ECD) spectrum; ≈0 for achiral molecules, bisignate (±) for chiral
    ones. 0.0 when unavailable (e.g. magnetic dipole not exposed by the TD method)."""
    return {
        "energy_ev": float(energy_ev),
        "wavelength_nm": float(wavelength_nm),
        "osc_strength": float(osc_strength),
        "symmetry": str(symmetry),
        "multiplicity": int(multiplicity),
        "transitions": transitions or [],
        "transition_dipole": transition_dipole or {"x": 0.0, "y": 0.0, "z": 0.0},
        "rotatory_strength": float(rotatory_strength),
    }


def transition(
    from_mo: int, to_mo: int, weight: float, from_label: str = "", to_label: str = ""
) -> dict[str, Any]:
    """A single occupied→virtual contribution to an excited state. `from_mo`/`to_mo` are
    absolute MO indices; `weight` is its fractional contribution (0–1); the optional
    labels are frontier-relative names (HOMO, LUMO, HOMO-1, …) for display."""
    return {
        "from_mo": int(from_mo),
        "to_mo": int(to_mo),
        "weight": float(weight),
        "from_label": str(from_label),
        "to_label": str(to_label),
    }


def emission(
    energy_ev: float, wavelength_nm: float, state: int, adiabatic_ev: float = 0.0
) -> dict[str, float]:
    """Emission (fluorescence/phosphorescence) from a relaxed excited-state geometry:
    the vertical state→ground gap at the excited-state minimum, the emission wavelength,
    the emitting `state` index (1 = first excited), and the adiabatic (0–0) energy."""
    return {
        "energy_ev": float(energy_ev),
        "wavelength_nm": float(wavelength_nm),
        "state": int(state),
        "adiabatic_ev": float(adiabatic_ev),
    }


def nto_cube(
    state: int, weight: float, hole_path: str, particle_path: str
) -> dict[str, Any]:
    """A natural-transition-orbital pair for one excited state:
    {"state","weight","hole_path","particle_path"}.

    `state` is the 1-based excited-state index (matches the position in
    `excited_states`); `weight` is the dominant hole→particle pair weight (0–1, ≈1
    for a clean single-pair transition); `hole_path`/`particle_path` are the .cube
    files for the dominant occupied (hole) and virtual (particle) NTO."""
    return {
        "state": int(state),
        "weight": float(weight),
        "hole_path": str(hole_path),
        "particle_path": str(particle_path),
    }


def nmr_shielding(
    atom_index: int, isotropic: float, anisotropy: float = 0.0, symbol: str = ""
) -> dict[str, Any]:
    """An NMR shielding: {"atom_index","isotropic","anisotropy","symbol"} (ppm).

    `symbol` is the element symbol so the NMR tab can filter the spectrum by nucleus
    (¹H vs ¹³C); "" is tolerated (external engines that don't say) and renders for
    every nucleus."""
    return {
        "atom_index": int(atom_index),
        "isotropic": float(isotropic),
        "anisotropy": float(anisotropy),
        "symbol": str(symbol),
    }


def bond_order(a: int, b: int, order: float) -> dict[str, Any]:
    """A Mayer bond order: {"a","b","order"} with 0-indexed atoms a < b. `order` is
    the wavefunction-derived bond order (≈1 single, ≈2 double, ≈3 triple, ~1.5
    aromatic)."""
    return {"a": int(a), "b": int(b), "order": float(order)}


def fukui_index(
    atom: int, f_plus: float, f_minus: float, dual: float
) -> dict[str, Any]:
    """A condensed Fukui reactivity index for one atom (Yang–Mortier, Mulliken-based):
    {"atom","f_plus","f_minus","dual"} with `atom` 0-indexed (same order as `charges`).

    `f_plus` = q0 − q_anion is the nucleophilic Fukui function (where an added electron
    localizes); `f_minus` = q_cation − q0 is the electrophilic one (where a removed
    electron came from); `dual` = f_plus − f_minus is the dual descriptor — its most
    POSITIVE atom is the electrophilic site (a nucleophile attacks there), its most
    NEGATIVE the nucleophilic site."""
    return {
        "atom": int(atom),
        "f_plus": float(f_plus),
        "f_minus": float(f_minus),
        "dual": float(dual),
    }


def reactivity_block(
    *,
    ip_ev: float,
    ea_ev: float,
    electronegativity_ev: float,
    chemical_potential_ev: float,
    hardness_ev: float,
    softness: float,
    electrophilicity_ev: float,
    max_electron_flow: float,
    source: str = "ΔSCF",
) -> dict[str, Any]:
    """Global conceptual-DFT reactivity descriptors (Parr/Pearson) from the vertical
    ΔSCF N±1 finite differences computed alongside the condensed Fukui indices.

    `ip_ev` = E(N−1) − E(N) and `ea_ev` = E(N) − E(N+1) (the cation/anion total
    energies at the neutral geometry, eV). From them: `electronegativity_ev` χ =
    (IP+EA)/2, `chemical_potential_ev` μ = −χ, `hardness_ev` η = IP − EA, `softness`
    S = 1/η (eV⁻¹), `electrophilicity_ev` ω = μ²/2η (Parr's index), and the maximal
    electron flow `max_electron_flow` ΔN_max = −μ/η (electrons a strong nucleophile
    would donate). `source` records the scheme ("ΔSCF" finite difference — sharper than
    Koopmans' frontier-orbital estimate). All energies in eV."""
    return {
        "ip_ev": float(ip_ev),
        "ea_ev": float(ea_ev),
        "electronegativity_ev": float(electronegativity_ev),
        "chemical_potential_ev": float(chemical_potential_ev),
        "hardness_ev": float(hardness_ev),
        "softness": float(softness),
        "electrophilicity_ev": float(electrophilicity_ev),
        "max_electron_flow": float(max_electron_flow),
        "source": str(source),
    }


def bonding_orbital(
    kind: str,
    atoms: list[int],
    occupancy: float,
    energy: float,
    centers: list[dict[str, float]],
    cube_path: str = "",
) -> dict[str, Any]:
    """One localized bonding orbital in the NBO-style Lewis picture:
    {"kind","atoms","occupancy","energy","centers","cube_path"}.

    `kind` ∈ {"core","lone_pair","bond","delocalized"}; `atoms` are the 0-indexed atoms
    the orbital sits on (1 for core/lone pair, 2 for a 2-centre bond, ≥1 delocalized);
    `occupancy` is its electron population (≈2 for a doubly-occupied closed-shell
    orbital); `energy` is the Fock expectation ⟨φ|F|φ⟩ (Ha — localized orbitals are not
    eigenstates, so this is the diagonal energy, not an orbital eigenvalue); `centers`
    is the atomic composition [{"atom":int,"weight":float (0–1)}], descending by weight;
    `cube_path` is the .cube volumetric file for this localized orbital ("" when not
    generated — only written when the request asks for cubes)."""
    return {
        "kind": str(kind),
        "atoms": [int(a) for a in atoms],
        "occupancy": float(occupancy),
        "energy": float(energy),
        "centers": [
            {"atom": int(c["atom"]), "weight": float(c["weight"])} for c in centers
        ],
        "cube_path": str(cube_path),
    }


def mace_uncertainty(
    *, energy_std_ha: float, max_force_std_ev_ang: float, n_models: int, source: str = ""
) -> dict[str, Any]:
    """MACE committee uncertainty: the prediction spread across an N-model committee.

    `energy_std_ha` is the standard deviation of the committee total energies (Hartree);
    `max_force_std_ev_ang` the largest per-component force standard deviation (eV/Å) — the
    most-uncertain atom is the active-learning candidate; `n_models` the committee size;
    `source` a human description of the committee (e.g. "MACE-OFF small/medium/large"). A
    ROUGH, uncalibrated epistemic signal: a large spread means the geometry is off the
    models' shared training distribution, not a rigorous error bar."""
    return {
        "energy_std_ha": float(energy_std_ha),
        "max_force_std_ev_ang": float(max_force_std_ev_ang),
        "n_models": int(n_models),
        "source": str(source),
    }


def bonding_block(
    *,
    method: str,
    natural_charges: list[float],
    orbitals: list[dict[str, Any]],
) -> dict[str, Any]:
    """The localized-bonding (NBO-style) analysis block (the `nbo` calc).

    `method` is the localization actually used ("IBO" intrinsic bond orbitals, Knizia
    2013, or "Pipek-Mezey" fallback) — stamped honestly so the result never claims
    Weinhold NBO7 (which needs the external NBO program). `natural_charges` are the
    natural (meta-Löwdin / NAO) atomic charges, same atom order as `charges`. `orbitals`
    is the list of [func]bonding_orbital[/func] dicts (the Lewis structure)."""
    return {
        "method": str(method),
        "natural_charges": [float(c) for c in natural_charges],
        "orbitals": list(orbitals),
    }


def opt_step(
    energy: float, max_force: float = 0.0, rms_force: float = 0.0, max_disp: float = 0.0
) -> dict[str, Any]:
    """An optimization step: {"energy","max_force","rms_force","max_disp"}."""
    return {
        "energy": float(energy),
        "max_force": float(max_force),
        "rms_force": float(rms_force),
        "max_disp": float(max_disp),
    }


def irc_point(coordinate: float, energy: float) -> dict[str, Any]:
    """An IRC point: {"coordinate","energy"}."""
    return {"coordinate": float(coordinate), "energy": float(energy)}


def scan_point(coordinate: float, energy: float) -> dict[str, Any]:
    """A PES-scan point: {"coordinate","energy"} (coordinate in Å for a bond scan)."""
    return {"coordinate": float(coordinate), "energy": float(energy)}


def neb_point(
    image: int, coordinate: float, energy: float, coords: list[dict[str, float]]
) -> dict[str, Any]:
    """One image of an optimized NEB reaction path:
    {"image","coordinate","energy","coords"}.

    `image` is the 0-based image index along the band (0 = reactant, last = product);
    `coordinate` is the cumulative path length from the reactant in Å; `energy` the image
    energy (Ha); `coords` the image geometry [{"x","y","z"}] (Å). The activation barrier
    is read off the band as max(energy) − energy[0] (forward) / − energy[-1] (reverse)."""
    return {
        "image": int(image),
        "coordinate": float(coordinate),
        "energy": float(energy),
        "coords": coords,
    }


def thermochemistry(
    *,
    temperature_k: float,
    electronic_energy: float,
    zpe: float,
    internal_energy: float,
    enthalpy: float,
    gibbs: float,
    entropy: float,
    heat_capacity_cv: float,
) -> dict[str, float]:
    """Thermochemistry block (all energies Hartree, entropy/Cv Hartree/K) at one
    temperature. Empty {} when no frequency analysis ran (it is the source of these)."""
    return {
        "temperature_k": float(temperature_k),
        "electronic_energy": float(electronic_energy),
        "zpe": float(zpe),
        "internal_energy": float(internal_energy),
        "enthalpy": float(enthalpy),
        "gibbs": float(gibbs),
        "entropy": float(entropy),
        "heat_capacity_cv": float(heat_capacity_cv),
    }


def thermo_point(
    *,
    temperature_k: float,
    gibbs: float,
    enthalpy: float,
    entropy: float,
    zpe: float,
) -> dict[str, float]:
    """One row of the thermochemistry-vs-temperature scan: {"temperature_k","gibbs",
    "enthalpy","entropy","zpe"} (energies Hartree, entropy Hartree/K) — the same
    frequencies evaluated at a different temperature (constant pressure)."""
    return {
        "temperature_k": float(temperature_k),
        "gibbs": float(gibbs),
        "enthalpy": float(enthalpy),
        "entropy": float(entropy),
        "zpe": float(zpe),
    }


def stationary_label(n_imaginary: int) -> str:
    """Classify a stationary point from its imaginary-mode count: 0 → minimum,
    1 → transition_state (first-order saddle), ≥2 → higher_order_saddle."""
    if n_imaginary <= 0:
        return "minimum"
    if n_imaginary == 1:
        return "transition_state"
    return "higher_order_saddle"


def trajectory_frame(
    time: float, coords: list[dict[str, float]], energy: float, temperature: float
) -> dict[str, Any]:
    """An MD frame: {"time","coords","energy","temperature"}."""
    return {
        "time": float(time),
        "coords": coords,
        "energy": float(energy),
        "temperature": float(temperature),
    }


# ─────────────────────────── provenance ───────────────────────────


def library_versions() -> dict[str, str]:
    """Map of {package: version} for the scientific stack actually importable now."""
    versions: dict[str, str] = {}
    for pkg in _PROVENANCE_PACKAGES:
        try:
            mod = importlib.import_module(pkg)
            versions[pkg] = str(getattr(mod, "__version__", "unknown"))
        except Exception:
            # Missing dependency: record absence rather than crash (§15.4).
            versions[pkg] = "absent"
    return versions


def host() -> str:
    """A human-readable host string for provenance (§15.7)."""
    return f"{platform.node()} ({platform.system()} {platform.release()})"


def geometry_checksum(molecule: dict[str, Any]) -> str:
    """Deterministic sha256 of the molecule geometry (element + x,y,z), order-independent.

    Atoms are sorted by (element, x, y, z) so two equal geometries with different
    input ordering hash identically. Charge and multiplicity are folded in.
    """
    atoms = molecule.get("atoms", [])
    rows = sorted(
        (
            str(a.get("element", "")),
            float(a.get("x", 0.0)),
            float(a.get("y", 0.0)),
            float(a.get("z", 0.0)),
        )
        for a in atoms
    )
    payload = {
        "atoms": rows,
        "charge": int(molecule.get("charge", 0)),
        "multiplicity": int(molecule.get("multiplicity", 1)),
    }
    encoded = json.dumps(payload, sort_keys=True, separators=(",", ":")).encode("utf-8")
    return hashlib.sha256(encoded).hexdigest()


def formula_from_atoms(atoms: list[dict[str, Any]]) -> str:
    """Hill-system molecular formula (C first, H second, then alphabetical)."""
    counts: dict[str, int] = {}
    for a in atoms:
        el = str(a.get("element", "")).strip()
        if not el:
            continue
        counts[el] = counts.get(el, 0) + 1

    def fmt(el: str) -> str:
        n = counts[el]
        return el if n == 1 else f"{el}{n}"

    parts: list[str] = []
    if "C" in counts:
        parts.append(fmt("C"))
        if "H" in counts:
            parts.append(fmt("H"))
        for el in sorted(k for k in counts if k not in ("C", "H")):
            parts.append(fmt(el))
    else:
        for el in sorted(counts):
            parts.append(fmt(el))
    return "".join(parts)


def validate(result: dict[str, Any]) -> dict[str, Any]:
    """Assert the result carries exactly the contract keys; return it for chaining.

    Raises KeyError on any missing key and ValueError on any extra key. The sidecar
    runs this before writing so a contract drift fails loudly in tests, not silently
    on the GDScript side.
    """
    have = set(result.keys())
    want = set(CONTRACT_KEYS)
    missing = want - have
    extra = have - want
    if missing:
        raise KeyError(f"JobResult missing contract keys: {sorted(missing)}")
    if extra:
        raise ValueError(f"JobResult has unexpected keys: {sorted(extra)}")
    return result


def sanitize_non_finite(result: dict[str, Any]) -> list[str]:
    """Replace every non-finite float (NaN / ±inf) anywhere in `result` with 0.0,
    IN PLACE, and return a list of human-readable warnings naming where they were.

    Why this exists: `json.dump(..., allow_nan=False)` raises mid-write on the first
    non-finite float — discarding the WHOLE result behind a cryptic "Out of range
    float values are not JSON compliant" error AND (since the file is opened/truncated
    before the dump fails) potentially leaving a half-written file. And `allow_nan=True`
    would emit `NaN`/`Infinity` tokens, which are invalid JSON that GDScript's
    `JSON.parse_string` rejects (returning null → the result silently vanishes on load).

    A non-finite number in a result is real and happens (a diverged SCF whose energy
    prints as `NaN`/`************`, a `1e999` overflow in an imported XYZ comment, a
    blown-up coordinate). Rather than crash or corrupt the load, we neutralize the bad
    values to 0.0 and SAY SO in the warnings channel — the rest of the computed data
    survives and the file stays valid JSON.
    """
    notes: list[str] = []

    def _walk(node: Any, path: str) -> Any:
        if isinstance(node, float):
            if not math.isfinite(node):
                notes.append(
                    "non-finite value (%s) at %s replaced with 0.0 — the calculation "
                    "produced NaN/Inf there (e.g. a diverged SCF or an overflowed "
                    "import); treat that field as unavailable" % (node, path)
                )
                return 0.0
            return node
        if isinstance(node, dict):
            for k, v in list(node.items()):
                node[k] = _walk(v, f"{path}.{k}" if path else str(k))
            return node
        if isinstance(node, list):
            for i, v in enumerate(node):
                node[i] = _walk(v, f"{path}[{i}]")
            return node
        return node

    _walk(result, "")
    if notes:
        # Surface the sanitization through the normal warnings channel so the Analyze
        # tabs show it like any other honest degradation (never a silent 0.0).
        warnings = result.get("warnings")
        if not isinstance(warnings, list):
            warnings = []
            result["warnings"] = warnings
        warnings.extend(notes)
    return notes


def write_result(result: dict[str, Any], output_path: str) -> None:
    """Validate, sanitize non-finite floats, and atomically write the result as JSON.

    The write is atomic (temp file + os.replace) so a reader on the Godot side never
    observes a half-written result.json — a crash or a JSON-encode failure mid-write
    leaves the previous file (or no file), never a truncated one. Non-finite floats are
    neutralized to 0.0 with a warning first (see [func]sanitize_non_finite[/func]), so
    `allow_nan=False` here can only ever guard against a future regression, not a real
    diverged-calculation value.
    """
    validate(result)
    sanitize_non_finite(result)
    tmp_path = f"{output_path}.tmp"
    with open(tmp_path, "w", encoding="utf-8") as fh:
        json.dump(result, fh, indent=2, allow_nan=False)
    os.replace(tmp_path, output_path)
