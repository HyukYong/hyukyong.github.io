"""quchemy.sidecar — the JobResult contract builder and IPC plumbing.

The Godot app talks to exactly one Python process boundary (overhaul §6). A JSON
request envelope is passed as argv[1]; the sidecar dispatches on `action`, writes a
`result.json` in the `JobResult` schema (overhaul §3), and prints one line of status.

This package only owns the *contract* (`result_builder`). The runnable entrypoint
lives at the repo root (`sidecar.py`) and is re-exported as `quchemy.sidecar.__main__`
for `python -m` / console-script use.
"""

from __future__ import annotations

from .result_builder import (
    CONTRACT_KEYS,
    ENERGY_UNIT_HARTREE,
    SCHEMA_VERSION,
    blank_result,
    coords_from_atoms,
    error_result,
    excited_state,
    formula_from_atoms,
    geometry_checksum,
    host,
    irc_point,
    library_versions,
    nmr_shielding,
    opt_step,
    orbital,
    orbitals_from_mo,
    trajectory_frame,
    validate,
    vec3,
    vibration_mode,
    write_result,
)

__all__ = [
    "CONTRACT_KEYS",
    "ENERGY_UNIT_HARTREE",
    "SCHEMA_VERSION",
    "blank_result",
    "coords_from_atoms",
    "error_result",
    "excited_state",
    "formula_from_atoms",
    "geometry_checksum",
    "host",
    "irc_point",
    "library_versions",
    "nmr_shielding",
    "opt_step",
    "orbital",
    "orbitals_from_mo",
    "trajectory_frame",
    "validate",
    "vec3",
    "vibration_mode",
    "write_result",
]
