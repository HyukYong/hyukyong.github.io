"""State-preparation primitives (roadmap §5.5): Grover-Rudolph amplitude loading and QROM.

These build a NON-Hartree-Fock reference state — a warm start for the signal / Krylov eigensolvers,
which accept any statevector as their reference. A better-overlap reference means fewer time samples
/ Krylov vectors to converge.

  * Grover-Rudolph — load an arbitrary real amplitude vector by a binary tree of (uniformly-
    controlled) y-rotations: at each level a node's rotation angle splits the remaining probability
    mass between its two children. `grover_rudolph_angles` returns that angle tree (the circuit
    recipe); `grover_rudolph_statevector` replays it to the prepared statevector — which equals the
    normalized target, so a CISD / MPS amplitude list can be loaded as an eigensolver reference.
  * QROM — a coherent table lookup: |i>|0> -> |i>|table[i]>. `qrom_superposition` returns the state
    obtained by applying it to a uniform address register, the building block for sparse / database
    state preparation.

Real amplitudes (signed) are supported; the sign is carried as a +-1 factor per basis state (the
common warm-start case — HF / CISD / natural-orbital coefficients are real). Qubit 0 is the most
significant bit, matching the rest of quchemy.
"""

from __future__ import annotations

import numpy as np


def grover_rudolph_angles(amplitudes: np.ndarray) -> list[list[float]]:
    """The Grover-Rudolph y-rotation angle tree for a real amplitude vector (length 2^n).

    Returns one list of angles per qubit level: level k holds 2^k angles, one per length-k bit
    prefix, where angle = 2*arccos(sqrt(mass_left / mass_node)) splits the subtree probability mass.
    A node with zero mass contributes a 0 angle (its subtree is empty).
    """
    a = np.asarray(amplitudes, dtype=float)
    nrm = np.linalg.norm(a)
    if nrm == 0:
        raise ValueError("cannot prepare a zero-norm amplitude vector")
    a = a / nrm
    n = int(round(np.log2(a.size)))
    if (1 << n) != a.size:
        raise ValueError("amplitude vector length must be a power of two")
    prob = a ** 2

    angles: list[list[float]] = []
    for level in range(n):
        block = 1 << (n - level)          # size of a node's subtree at this level
        half = block >> 1
        level_angles: list[float] = []
        for node in range(1 << level):
            start = node * block
            mass = float(prob[start:start + block].sum())
            left = float(prob[start:start + half].sum())
            if mass <= 1e-15:
                level_angles.append(0.0)
            else:
                ratio = min(max(left / mass, 0.0), 1.0)
                level_angles.append(2.0 * np.arccos(np.sqrt(ratio)))
        angles.append(level_angles)
    return angles


def grover_rudolph_statevector(amplitudes: np.ndarray) -> np.ndarray:
    """The statevector Grover-Rudolph prepares for `amplitudes` — equals the normalized target.

    Builds it from the angle tree (replaying the controlled-rotation recipe), then restores the
    signs of the (real) amplitudes, so the result is usable directly as an eigensolver reference.
    """
    a = np.asarray(amplitudes, dtype=float)
    nrm = np.linalg.norm(a)
    if nrm == 0:
        raise ValueError("cannot prepare a zero-norm amplitude vector")
    a = a / nrm
    n = int(round(np.log2(a.size)))
    angles = grover_rudolph_angles(a)

    # Magnitude per basis state = product of the cos/sin half-angle factors down its path.
    mags = np.ones(a.size, dtype=float)
    for level in range(n):
        block = 1 << (n - level)
        half = block >> 1
        for node in range(1 << level):
            theta = angles[level][node]
            start = node * block
            mags[start:start + half] *= np.cos(theta / 2.0)
            mags[start + half:start + block] *= np.sin(theta / 2.0)
    # Restore signs (RY gives non-negative magnitudes; the target's signs are applied on top).
    signs = np.sign(a)
    signs[signs == 0] = 1.0
    return (mags * signs).astype(complex)


def qrom_superposition(table: list[int], num_data_qubits: int) -> np.ndarray:
    """Statevector from applying a QROM (|i>|0> -> |i>|table[i]>) to a uniform address register.

    `table` has one data value per address i (0 .. len(table)-1, padded to a power of two with 0);
    the result is (1/sqrt(N_addr)) sum_i |i>|table[i]>, address qubits most significant. Each data
    value must fit in `num_data_qubits` bits.
    """
    n_addr = max(1, int(np.ceil(np.log2(max(len(table), 1)))))
    n_addr_states = 1 << n_addr
    n_data_states = 1 << int(num_data_qubits)
    padded = list(table) + [0] * (n_addr_states - len(table))
    state = np.zeros(n_addr_states * n_data_states, dtype=complex)
    amp = 1.0 / np.sqrt(n_addr_states)
    for i in range(n_addr_states):
        val = int(padded[i])
        if val < 0 or val >= n_data_states:
            raise ValueError("table value %d does not fit in %d data qubits" % (val, num_data_qubits))
        # |i> (address, MSB) tensor |val> (data, LSB block).
        state[i * n_data_states + val] = amp
    return state
