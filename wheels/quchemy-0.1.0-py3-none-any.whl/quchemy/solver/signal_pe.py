"""Signal-based phase estimation for molecular Hamiltonians.

The shared primitive is :func:`hamiltonian_signal`, the time-domain overlap

    g(t) = <phi0| exp(-i H t) |phi0>,

which a quantum computer would obtain from a Hadamard test on the controlled
time-evolution.  On the classical statevector we generate it exactly by diagonalizing
the (dense) Hamiltonian once: with H = sum_m E_m |m><m| and c_m = <m|phi0>,

    g(t) = sum_m |c_m|^2 exp(-i E_m t).

Every algorithm in this module consumes ONLY the sampled signal g(t) (never the
eigendecomposition directly) — eigendecomposition is just how the simulator plays the
role of the quantum device.  :class:`QCELS` (Quantum Complex Exponential Least Squares)
recovers the ground-state energy as the dominant frequency of g(t).

Both helpers (:func:`bitstring_to_statevector`, :func:`dense_hamiltonian_matrix`) are
reused by :mod:`quchemy.solver.krylov`.
"""

from __future__ import annotations

import math
from dataclasses import dataclass, field
from typing import Callable

import numpy as np
from openfermion import QubitOperator, get_sparse_operator


# ---------------------------------------------------------------------------
# Shared low-level helpers (also used by quantum Krylov diagonalization)
# ---------------------------------------------------------------------------
def count_qubits(qubit_op: QubitOperator) -> int:
    """Number of qubits a QubitOperator acts on (max index + 1)."""
    max_qubit = -1
    for term in qubit_op.terms:
        for qubit, _ in term:
            if qubit > max_qubit:
                max_qubit = qubit
    return max_qubit + 1 if max_qubit >= 0 else 0


def bitstring_to_statevector(bits: np.ndarray, num_qubits: int) -> np.ndarray:
    """Computational-basis statevector for an occupation bitstring (1 = occupied).

    Matches the qubit ordering used throughout quchemy (qubit 0 is the MSB), so the
    index of a Hartree-Fock occupation array agrees with QPE/statevector_simulate:
    bit i set contributes 2**(num_qubits - 1 - i).
    """
    state = np.zeros(2**num_qubits, dtype=complex)
    idx = 0
    for i, bit in enumerate(bits):
        if bit:
            idx |= 1 << (num_qubits - 1 - i)
    state[idx] = 1.0
    return state


def dense_hamiltonian_matrix(qop: QubitOperator, num_qubits: int) -> np.ndarray:
    """Dense Hermitian matrix of a QubitOperator on `num_qubits` qubits.

    Symmetrized to kill the tiny non-Hermitian residue from floating-point assembly so
    downstream `eigh` is well behaved.
    """
    H = get_sparse_operator(qop, n_qubits=num_qubits).toarray()
    return 0.5 * (H + H.conj().T)


def _resolve_reference(ref_state: np.ndarray, num_qubits: int) -> np.ndarray:
    """Coerce a reference into a normalized statevector.

    Accepts either an occupation bitstring (length `num_qubits`, entries in {0,1}) — the
    `get_hf_state` convention — or a full statevector (length 2**num_qubits).
    """
    arr = np.asarray(ref_state)
    if arr.size == num_qubits and np.all(np.isin(arr, (0, 1))):
        return bitstring_to_statevector(arr.astype(int), num_qubits)
    if arr.size == 2**num_qubits:
        vec = arr.astype(complex)
        nrm = np.linalg.norm(vec)
        if nrm == 0:
            raise ValueError("reference statevector has zero norm")
        return vec / nrm
    raise ValueError(
        f"ref_state size {arr.size} is neither a {num_qubits}-bit occupation string "
        f"nor a length-{2**num_qubits} statevector"
    )


def _spectral_window(qop: QubitOperator) -> tuple[float, float, float]:
    """(center, radius, non_identity_one_norm) bounding the spectrum without peeking.

    The identity coefficient c0 shifts every eigenvalue; the remaining 1-norm R bounds
    the spread (Gershgorin), so all eigenvalues lie in [c0 - R, c0 + R].
    """
    c0 = 0.0
    R = 0.0
    for term, coeff in qop.terms.items():
        if term:
            R += abs(coeff)
        else:
            c0 += coeff.real
    return c0, R, R


def hamiltonian_signal(
    qop: QubitOperator,
    ref_state: np.ndarray,
    times: np.ndarray,
    num_qubits: int | None = None,
) -> np.ndarray:
    """Sample g(t) = <phi0| exp(-i H t) |phi0> at the given `times`.

    The eigendecomposition is computed once and reused for every time sample, so the
    cost is one dense `eigh` plus an O(len(times) * dim) evaluation.

    Parameters
    ----------
    qop : QubitOperator
        Qubit Hamiltonian (its identity term rides along, so energies are TOTAL energies).
    ref_state : ndarray
        Occupation bitstring or statevector for |phi0> (see `_resolve_reference`).
    times : ndarray
        Evolution times t_k.
    num_qubits : int, optional
        Qubit count; inferred from `qop` when omitted.

    Returns
    -------
    ndarray
        Complex signal g(t_k), same shape as `times`.
    """
    n = count_qubits(qop) if num_qubits is None else num_qubits
    psi0 = _resolve_reference(ref_state, n)
    H = dense_hamiltonian_matrix(qop, n)
    evals, evecs = np.linalg.eigh(H)
    weights = np.abs(evecs.conj().T @ psi0) ** 2  # |c_m|^2, sums to 1
    t = np.asarray(times, dtype=float)
    # g(t_k) = sum_m weights_m exp(-i E_m t_k)  ->  (len(t),)
    phases = np.exp(-1j * np.outer(t, evals))
    return phases @ weights


def _signal_dispatch(
    qop: QubitOperator,
    ref_state: np.ndarray,
    times: np.ndarray,
    num_qubits: int,
    use_hadamard_test: bool,
    trotter_dt: float,
) -> np.ndarray:
    """g(t) for a signal-PE solver: the exact dense path, or the real Hadamard-test GATE CIRCUIT.

    When `use_hadamard_test` is set, g(t) is sampled from the universal-gate Hadamard-test circuit
    (Trotterized controlled-e^{-iHt}, +1 ancilla, hardware-exportable) — approximate but the genuine
    on-hardware primitive shared by the whole signal-PE family. It needs a computational-basis (HF)
    reference (an occupation string); a non-basis statevector ref is dense-only and fails loud.
    """
    times = np.asarray(times)
    if not use_hadamard_test:
        return hamiltonian_signal(qop, ref_state, times, num_qubits)
    from .hadamard_test import hadamard_test_signal

    ref = np.asarray(ref_state)
    if not (ref.size == num_qubits and np.all(np.isin(ref, (0, 1)))):
        raise ValueError(
            "the Hadamard-test gate path needs a computational-basis (HF) reference — a "
            "length-num_qubits occupation string; arbitrary statevector refs are dense-only."
        )
    return hadamard_test_signal(qop, ref.astype(int), times, trotter_dt=trotter_dt)


@dataclass
class SignalPEResult:
    """Result of a signal-based phase-estimation run."""

    energy: float
    overlap_p0: float
    algorithm: str = "QCELS"
    num_samples: int = 0
    dt: float = 0.0
    t_max: float = 0.0
    signal_times: list[float] = field(default_factory=list)
    signal_real: list[float] = field(default_factory=list)
    signal_imag: list[float] = field(default_factory=list)
    # Multi-eigenvalue methods (QMEGS) fill this with the resolved eigenvalues, ascending; `energy`
    # is then energies[0] (the ground state). Single-eigenvalue methods leave it empty.
    energies: list[float] = field(default_factory=list)


class QCELS:
    """Quantum Complex Exponential Least Squares ground-state energy estimator.

    Fits the dominant complex exponential of g(t) = sum_k a_k exp(-i E_k t).  For a
    single frequency the least-squares optimum in the amplitude a is closed-form, so the
    problem reduces to maximizing |A(E)|^2 with A(E) = (1/N) sum_k g(t_k) exp(+i E t_k)
    over the spectral window — the dominant peak is the largest-overlap eigenvalue, which
    for a Hartree-Fock reference is the ground state.  A coarse grid search localizes the
    peak; a bounded scalar refinement sharpens it.

    Parameters
    ----------
    qubit_hamiltonian : QubitOperator
        Qubit Hamiltonian (energies are total energies — identity term included).
    ref_state : ndarray
        Reference |phi0> (occupation bitstring or statevector).
    num_samples : int
        Number of time samples N.
    dt : float, optional
        Time step.  Defaults to 0.9*pi / R (R = non-identity 1-norm), the QPE
        anti-aliasing heuristic.
    grid_points : int
        Coarse energy-grid resolution for the initial peak search.
    callback : callable, optional
        Called with (stage_name, info_dict) for progress reporting.
    """

    def __init__(
        self,
        qubit_hamiltonian: QubitOperator,
        ref_state: np.ndarray,
        num_samples: int = 200,
        dt: float | None = None,
        grid_points: int = 4000,
        callback: Callable | None = None,
        use_hadamard_test: bool = False,
        trotter_dt: float = 0.2,
        signal_fn: Callable | None = None,
    ):
        self.qop = qubit_hamiltonian
        self.num_qubits = count_qubits(qubit_hamiltonian)
        self.ref_state = ref_state
        self.num_samples = int(num_samples)
        self.grid_points = int(grid_points)
        self.callback = callback
        # Optional injected signal source g = signal_fn(times): computes g(t) on EXTERNAL hardware
        # (the sidecar passes a closure that batches the Hadamard-test circuits to IBM SamplerV2).
        # When set it overrides the local dense / gate path; the rest of the QCELS fit is unchanged.
        self.signal_fn = signal_fn
        # When True, g(t) is sampled from the Hadamard-test GATE CIRCUIT (universal gates, Trotterized
        # controlled-e^{-iHt}, exportable to real hardware) instead of the exact dense eigh. Approximate
        # (Trotter error) but hardware-faithful. Needs a computational-basis (HF) reference.
        self.use_hadamard_test = bool(use_hadamard_test)
        self.trotter_dt = float(trotter_dt)

        self.center, self.radius, one_norm = _spectral_window(qubit_hamiltonian)
        if dt is not None:
            self.dt = float(dt)
        elif one_norm > 1e-12:
            self.dt = 0.9 * math.pi / one_norm
        else:
            self.dt = 1.0

    def run(self) -> SignalPEResult:
        times = self.dt * np.arange(self.num_samples)
        if self.callback:
            backend = ("ibmq" if self.signal_fn is not None
                       else ("hadamard_test" if self.use_hadamard_test else "dense"))
            self.callback("sampling_signal", {"num_samples": self.num_samples, "dt": self.dt,
                                              "backend": backend})
        if self.signal_fn is not None:
            g = np.asarray(self.signal_fn(times), dtype=complex)
        else:
            g = _signal_dispatch(self.qop, self.ref_state, times, self.num_qubits,
                                 self.use_hadamard_test, self.trotter_dt)

        # |A(E)|^2 = |(1/N) sum_k g(t_k) exp(+i E t_k)|^2 ; maximize over the window.
        def neg_power(E: float) -> float:
            A = np.mean(g * np.exp(1j * E * times))
            return -float(np.abs(A) ** 2)

        e_lo = self.center - self.radius
        e_hi = self.center + self.radius
        grid = np.linspace(e_lo, e_hi, self.grid_points)
        powers = [neg_power(E) for E in grid]
        i_best = int(np.argmin(powers))
        e_coarse = float(grid[i_best])

        if self.callback:
            self.callback("refining", {"coarse_energy": e_coarse})

        # Bounded refinement within one coarse cell on each side.
        from scipy.optimize import minimize_scalar

        step = (e_hi - e_lo) / max(self.grid_points - 1, 1)
        res = minimize_scalar(
            neg_power,
            bounds=(e_coarse - step, e_coarse + step),
            method="bounded",
            options={"xatol": 1e-10},
        )
        energy = float(res.x)
        overlap = float(-res.fun)  # |A(E*)|^2 ~ |<phi0|ground>|^2

        if self.callback:
            self.callback("done", {"energy": energy, "overlap_p0": overlap})

        return SignalPEResult(
            energy=energy,
            overlap_p0=overlap,
            algorithm="QCELS",
            num_samples=self.num_samples,
            dt=self.dt,
            t_max=float(times[-1]) if self.num_samples else 0.0,
            signal_times=times.tolist(),
            signal_real=g.real.tolist(),
            signal_imag=g.imag.tolist(),
        )


def _base_time(qop: QubitOperator) -> tuple[float, float, float]:
    """(t0, center, radius) for phase estimation that maps the spectrum into one period.

    With the spectral window [center - R, center + R] and t0 = 0.9*pi / R, every eigenphase of
    exp(-i (H - center) t0) lands in (-0.9*pi, 0.9*pi) — no aliasing for any eigenvalue, with
    margin so the dominant (ground) phase stays clear of the +/-0.5 turn boundary.
    """
    center, radius, _ = _spectral_window(qop)
    t0 = 0.9 * math.pi / radius if radius > 1e-12 else 1.0
    return t0, center, radius


def _phase_to_energy(phi: float, t0: float, center: float) -> float:
    """Invert phi in [0,1) of exp(-i (E - center) t0) = exp(2*pi*i*phi) back to E (total energy).

    phi is folded to (-0.5, 0.5] before inversion since chemistry energies sit below `center`.
    """
    phi_signed = phi - 1.0 if phi > 0.5 else phi
    return center - 2.0 * math.pi * phi_signed / t0


class RobustPE:
    """Robust Phase Estimation (RPE) — Heisenberg-limited phase unwrapping.

    Estimates the eigenphase as a continuous value (not just bits) by doubling the evolution
    multiple K = 2**j each generation and unwrapping the measured angle against the running
    estimate (choose the period offset closest to the prediction).  Valid in the large-overlap
    regime, where the signal is dominated by a single eigenphase — Hartree-Fock near equilibrium.

    Parameters
    ----------
    qubit_hamiltonian : QubitOperator
    ref_state : ndarray
    num_generations : int
        Number of doublings; phase resolution ~ 2**-num_generations of a period.
    callback : callable, optional
    """

    def __init__(
        self,
        qubit_hamiltonian: QubitOperator,
        ref_state: np.ndarray,
        num_generations: int = 12,
        callback: Callable | None = None,
        use_hadamard_test: bool = False,
        trotter_dt: float = 0.2,
        signal_fn: Callable | None = None,
    ):
        self.qop = qubit_hamiltonian
        self.num_qubits = count_qubits(qubit_hamiltonian)
        self.ref_state = ref_state
        self.num_generations = int(num_generations)
        self.callback = callback
        self.use_hadamard_test = bool(use_hadamard_test)
        self.trotter_dt = float(trotter_dt)
        # Injected external g(t) source (IBM SamplerV2 — see QCELS.signal_fn). Overrides the local path.
        self.signal_fn = signal_fn
        self.t0, self.center, self.radius = _base_time(qubit_hamiltonian)

    def run(self) -> SignalPEResult:
        gens = self.num_generations
        Ks = 2.0 ** np.arange(gens + 1)                 # j = 0..gens
        times = Ks * self.t0
        if self.signal_fn is not None:
            g = np.asarray(self.signal_fn(times), dtype=complex)
        else:
            g = _signal_dispatch(self.qop, self.ref_state, times, self.num_qubits,
                                 self.use_hadamard_test, self.trotter_dt)
        g_shift = g * np.exp(1j * self.center * times)

        if self.callback:
            self.callback("rpe_generations", {"num_generations": gens})

        # Generation 0 (K=1) fixes the principal value; each later generation refines it.
        phi_hat = (math.atan2(g_shift[0].imag, g_shift[0].real) / (2.0 * math.pi)) % 1.0
        for j in range(1, gens + 1):
            Kj = Ks[j]
            meas = (math.atan2(g_shift[j].imag, g_shift[j].real) / (2.0 * math.pi)) % 1.0
            n = round(Kj * phi_hat - meas)              # period offset closest to the prediction
            phi_hat = (meas + n) / Kj

        energy = _phase_to_energy(phi_hat % 1.0, self.t0, self.center)
        if self.callback:
            self.callback("done", {"energy": energy, "phi": phi_hat})

        return SignalPEResult(
            energy=energy,
            overlap_p0=float(np.abs(g_shift[0])),
            algorithm="RPE",
            num_samples=gens + 1,
            dt=self.t0,
            t_max=float(times[-1]),
            signal_times=times.tolist(),
            signal_real=g.real.tolist(),
            signal_imag=g.imag.tolist(),
        )


class QMEGS:
    """Quantum Multiple Eigenvalue Gaussian-filter Search.

    Resolves SEVERAL eigenvalues at once (the excited-state spectrum, not just the ground state)
    from one time-domain signal g(t) = sum_m |c_m|^2 exp(-i E_m t).  A Gaussian-windowed transform
    of the signal,

        F(lambda) = sum_k a(t_k) g(t_k) exp(+i lambda t_k) / sum_k a(t_k),
        a(t) = exp(-t^2 / (2 sigma_t^2))   (a Gaussian time window),

    is a smoothed estimate of the spectral density at energy lambda: |F(lambda)| peaks at each
    eigenvalue E_m that the reference overlaps, with height ~ |c_m|^2.  Scanning lambda over the
    spectral window and picking the peaks gives the dominant eigenvalues.  The time window width
    sigma_t sets the energy resolution (~1/sigma_t); a symmetric grid t in [-t_max, t_max] with
    t_max = 3 sigma_t captures the window (g(-t) = conj(g(t))).

    This complements VQD: one signal dataset, several states.  `energies` is returned ascending;
    `energy` (the ground state) is energies[0].

    Parameters
    ----------
    qubit_hamiltonian : QubitOperator
        Qubit Hamiltonian (total energies — identity term included).
    ref_state : ndarray
        Reference |phi0> (occupation bitstring or statevector); the states it overlaps are the ones
        resolved (a Hartree-Fock reference overlaps the totally-symmetric subspace incl. the ground).
    num_samples : int
        Number of time samples across the symmetric window.
    resolution : float, optional
        Target energy resolution (Hartree).  Defaults to spectral_radius / 40.  Sets sigma_t = 1/res.
    grid_points : int
        Energy-grid resolution for the peak scan.
    peak_threshold : float
        Keep peaks whose |F| exceeds this fraction of the tallest peak (filters spectral leakage).
    max_eigenvalues : int
        Cap on the number of eigenvalues returned (the strongest peaks).
    callback : callable, optional
    """

    def __init__(
        self,
        qubit_hamiltonian: QubitOperator,
        ref_state: np.ndarray,
        num_samples: int = 400,
        resolution: float | None = None,
        grid_points: int = 4000,
        peak_threshold: float = 0.05,
        max_eigenvalues: int = 8,
        callback: Callable | None = None,
        use_hadamard_test: bool = False,
        trotter_dt: float = 0.2,
        signal_fn: Callable | None = None,
    ):
        self.qop = qubit_hamiltonian
        self.num_qubits = count_qubits(qubit_hamiltonian)
        self.ref_state = ref_state
        self.num_samples = int(num_samples)
        self.grid_points = int(grid_points)
        self.peak_threshold = float(peak_threshold)
        self.max_eigenvalues = int(max_eigenvalues)
        self.callback = callback
        self.use_hadamard_test = bool(use_hadamard_test)
        self.trotter_dt = float(trotter_dt)
        # Injected external g(t) source (IBM SamplerV2 — see QCELS.signal_fn). Overrides the local path.
        self.signal_fn = signal_fn

        self.center, self.radius, _one_norm = _spectral_window(qubit_hamiltonian)
        res = resolution if resolution is not None else max(self.radius / 40.0, 1e-6)
        self.sigma_t = 1.0 / res
        self.t_max = 3.0 * self.sigma_t

    def run(self) -> SignalPEResult:
        times = np.linspace(-self.t_max, self.t_max, self.num_samples)
        weights = np.exp(-(times ** 2) / (2.0 * self.sigma_t ** 2))
        if self.callback:
            self.callback("sampling_signal", {"num_samples": self.num_samples})
        if self.signal_fn is not None:
            g = np.asarray(self.signal_fn(times), dtype=complex)
        else:
            g = _signal_dispatch(self.qop, self.ref_state, times, self.num_qubits,
                                 self.use_hadamard_test, self.trotter_dt)
        wg = weights * g
        wsum = float(np.sum(weights))

        # Gaussian-windowed spectral density |F(lambda)| over the spectral window.
        grid = np.linspace(self.center - self.radius, self.center + self.radius, self.grid_points)
        # F(lambda) = sum_k wg_k exp(+i lambda t_k) / sum(weights) -> (grid,)
        phases = np.exp(1j * np.outer(grid, times))
        spectrum = np.abs(phases @ wg) / wsum

        if self.callback:
            self.callback("peak_search", {"grid_points": self.grid_points})
        peaks = self._find_peaks(grid, spectrum)

        energies = [float(e) for e, _h in peaks]
        ground = energies[0] if energies else self.center
        overlap = float(peaks[0][1]) if peaks else 0.0

        if self.callback:
            self.callback("done", {"num_eigenvalues": len(energies), "ground": ground})

        return SignalPEResult(
            energy=ground,
            overlap_p0=overlap,
            algorithm="QMEGS",
            num_samples=self.num_samples,
            dt=float(times[1] - times[0]) if self.num_samples > 1 else 0.0,
            t_max=float(self.t_max),
            signal_times=grid.tolist(),       # the scanned energies …
            signal_real=spectrum.tolist(),    # … and the spectral density (a stick/line spectrum)
            energies=energies,
        )

    def _find_peaks(self, grid: np.ndarray, spectrum: np.ndarray) -> list[tuple[float, float]]:
        """Local maxima of `spectrum` above peak_threshold * max, sorted ascending in energy.

        Each returned peak energy is parabola-refined against its two neighbours for sub-grid
        accuracy. Returns [(energy, height), …] truncated to the strongest max_eigenvalues.
        """
        if spectrum.size < 3:
            return []
        hi = float(spectrum.max())
        if hi <= 0.0:
            return []
        thresh = self.peak_threshold * hi
        found: list[tuple[float, float]] = []
        for i in range(1, spectrum.size - 1):
            s = spectrum[i]
            if s >= thresh and s > spectrum[i - 1] and s >= spectrum[i + 1]:
                # Parabolic vertex refinement from the three samples around the peak.
                y0, y1, y2 = spectrum[i - 1], spectrum[i], spectrum[i + 1]
                denom = (y0 - 2.0 * y1 + y2)
                delta = 0.5 * (y0 - y2) / denom if abs(denom) > 1e-15 else 0.0
                step = grid[1] - grid[0]
                found.append((float(grid[i] + delta * step), float(s)))
        # Keep the strongest peaks, then return them ordered by energy.
        found.sort(key=lambda p: p[1], reverse=True)
        found = found[: self.max_eigenvalues]
        found.sort(key=lambda p: p[0])
        return found
