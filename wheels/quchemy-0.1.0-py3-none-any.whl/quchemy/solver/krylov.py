"""Quantum Krylov Diagonalization (real-time / VQPE flavor).

Projects the Hamiltonian into the Krylov space spanned by real-time-evolved copies of a
reference state,

    |phi_j> = U(j*dt) |phi0>,   U(t) = exp(-i H t),   j = 0 .. D-1,

then solves the generalized eigenproblem  H c = E S c  with

    S_jk = <phi_j|phi_k>,   H_jk = <phi_j|H|phi_k>.

S is generally ill-conditioned (the time-evolved states are nearly linearly dependent),
so it is regularized by a thresholded eigendecomposition: directions of S whose
eigenvalue falls below `regularization * lambda_max` are discarded, and the problem is
solved in the well-conditioned subspace.  No optimizer, no barren plateaus; the lowest
Ritz value is the ground-state estimate and the higher Ritz values approximate low-lying
excited states.

On the classical statevector the basis is built exactly from one dense eigendecomposition
(shared helpers in :mod:`quchemy.solver.signal_pe`), so there is no Trotter error.
"""

from __future__ import annotations

import math
from dataclasses import dataclass, field
from typing import Callable

import numpy as np
from openfermion import QubitOperator

from .signal_pe import (
    count_qubits,
    dense_hamiltonian_matrix,
    _resolve_reference,
    _spectral_window,
)


@dataclass
class KrylovResult:
    """Result of a quantum Krylov diagonalization."""

    ground_energy: float
    energies: list[float] = field(default_factory=list)
    krylov_dim: int = 0
    effective_dim: int = 0
    dt: float = 0.0
    condition_number: float = 0.0


class QuantumKrylov:
    """Quantum Krylov diagonalization for a qubit Hamiltonian.

    Parameters
    ----------
    qubit_hamiltonian : QubitOperator
        Qubit Hamiltonian (energies are total energies — identity term included).
    ref_state : ndarray
        Reference |phi0> (occupation bitstring or statevector).  Must overlap the target
        eigenstates (Hartree-Fock is the usual choice).
    krylov_dim : int
        Number of time-evolved basis states D.
    dt : float, optional
        Time step between basis states.  Defaults to 0.9*pi / R (R = non-identity 1-norm).
    regularization : float
        Relative threshold for discarding small-eigenvalue directions of the overlap
        matrix S (keeps lambda > regularization * lambda_max).
    callback : callable, optional
        Called with (stage_name, info_dict) for progress reporting.
    """

    def __init__(
        self,
        qubit_hamiltonian: QubitOperator,
        ref_state: np.ndarray,
        krylov_dim: int = 6,
        dt: float | None = None,
        regularization: float = 1e-8,
        callback: Callable | None = None,
        use_hadamard_test: bool = False,
        trotter_dt: float = 0.2,
        signal_fn: Callable | None = None,
        signal_delta_frac: float = 1.0 / 20.0,
    ):
        self.qop = qubit_hamiltonian
        self.num_qubits = count_qubits(qubit_hamiltonian)
        self.ref_state = ref_state
        self.krylov_dim = int(krylov_dim)
        self.regularization = float(regularization)
        self.callback = callback
        # Injected external g(t) source (IBM SamplerV2 — see QCELS.signal_fn). When set, the Krylov
        # S/H matrices are built from g(t) sampled on hardware (the 3 time grids batched into one
        # call); it implies the Hadamard-test signal path and overrides the dense basis.
        self.signal_fn = signal_fn
        # Central-difference step for H_jk = i·g'(t) as a fraction of dt. The exact/noiseless path
        # wants it small (low bias); a SHOT-NOISY signal (real hardware) amplifies that derivative
        # by 1/(2·delta), so the IBM path widens it (≈dt/8) to trade a little bias for noise robustness.
        self.signal_delta_frac = float(signal_delta_frac)
        # When True, the Krylov overlap (S) and Hamiltonian (H) subspace matrices are built from the
        # real Hadamard-test signal g(t) instead of the exact basis: S_jk = g((k-j)dt) and
        # H_jk = i g'((k-j)dt) (since d/dt g = -i <phi|e^{-iHt} H|phi>), the derivative by a central
        # finite difference. Hardware-exportable (one ancilla), Trotter-approximate. HF basis ref only.
        self.use_hadamard_test = bool(use_hadamard_test)
        self.trotter_dt = float(trotter_dt)

        _center, _radius, one_norm = _spectral_window(qubit_hamiltonian)
        if dt is not None:
            self.dt = float(dt)
        elif one_norm > 1e-12:
            self.dt = 0.9 * math.pi / one_norm
        else:
            self.dt = 1.0

    def _build_basis(self, H: np.ndarray) -> np.ndarray:
        """Columns |phi_j> = exp(-i H j dt) |phi0>, built from one eigendecomposition."""
        evals, evecs = np.linalg.eigh(H)
        psi0 = _resolve_reference(self.ref_state, self.num_qubits)
        c = evecs.conj().T @ psi0  # reference in the eigenbasis
        dim = H.shape[0]
        basis = np.empty((dim, self.krylov_dim), dtype=complex)
        for j in range(self.krylov_dim):
            if self.callback:
                self.callback("evolving", {"j": j, "of": self.krylov_dim})
            phases = np.exp(-1j * evals * (j * self.dt))
            basis[:, j] = evecs @ (phases * c)
        return basis

    def _build_subspace_from_signal(self) -> tuple[np.ndarray, np.ndarray]:
        """S and Hsub from the Hadamard-test signal g(t) (the real gate-circuit path).

        S_jk = g((k-j)dt); H_jk = i g'((k-j)dt) with g'(t) a central finite difference of g
        (delta = dt/20). Only k>=j is sampled (diff = 0..D-1); the lower triangle is the conjugate.
        """
        from .hadamard_test import hadamard_test_signal

        ref = np.asarray(self.ref_state)
        if not (ref.size == self.num_qubits and np.all(np.isin(ref, (0, 1)))):
            raise ValueError(
                "the Hadamard-test gate path needs a computational-basis (HF) reference — a "
                "length-num_qubits occupation string; arbitrary statevector refs are dense-only."
            )
        ref = ref.astype(int)
        D = self.krylov_dim
        dt = self.dt
        delta = dt * self.signal_delta_frac
        diffs = np.arange(D) * dt                                    # tau = 0, dt, .., (D-1)dt
        if self.callback:
            self.callback("sampling_signal", {"num_times": 3 * D})
        if self.signal_fn is not None:
            # Batch all three time grids (g0 | g+ | g-) into ONE injected-sampler call (one
            # hardware job), then split — the IBM path. Order matches the slices below.
            g_all = np.asarray(self.signal_fn(
                np.concatenate([diffs, diffs + delta, diffs - delta])), dtype=complex)
            g0, gp, gm = g_all[:D], g_all[D:2 * D], g_all[2 * D:3 * D]
        else:
            g0 = hadamard_test_signal(self.qop, ref, diffs, trotter_dt=self.trotter_dt)
            gp = hadamard_test_signal(self.qop, ref, diffs + delta, trotter_dt=self.trotter_dt)
            gm = hadamard_test_signal(self.qop, ref, diffs - delta, trotter_dt=self.trotter_dt)
        gderiv = (gp - gm) / (2.0 * delta)                          # g'(tau)

        S = np.empty((D, D), dtype=complex)
        Hsub = np.empty((D, D), dtype=complex)
        for j in range(D):
            for k in range(j, D):
                d = k - j
                S[j, k] = g0[d]
                S[k, j] = np.conj(g0[d])
                Hsub[j, k] = 1j * gderiv[d]
                Hsub[k, j] = np.conj(1j * gderiv[d])
        return 0.5 * (S + S.conj().T), 0.5 * (Hsub + Hsub.conj().T)

    def run(self) -> KrylovResult:
        if self.callback:
            self.callback("building_hamiltonian", {"num_qubits": self.num_qubits})
        if self.use_hadamard_test or self.signal_fn is not None:
            S, Hsub = self._build_subspace_from_signal()
        else:
            H = dense_hamiltonian_matrix(self.qop, self.num_qubits)
            basis = self._build_basis(H)
            # Subspace matrices (Hermitize away float residue).
            S = basis.conj().T @ basis
            Hsub = basis.conj().T @ (H @ basis)
            S = 0.5 * (S + S.conj().T)
            Hsub = 0.5 * (Hsub + Hsub.conj().T)

        # Regularize S: keep directions with eigenvalue above the relative threshold.
        s_vals, s_vecs = np.linalg.eigh(S)  # ascending, real
        lam_max = s_vals[-1]
        keep = s_vals > self.regularization * lam_max
        s_vals_k = s_vals[keep]
        s_vecs_k = s_vecs[:, keep]
        if s_vals_k.size == 0:
            raise ValueError("overlap matrix collapsed under regularization")

        # Whiten: X maps the kept subspace to an orthonormal basis (X^dag S X = I).
        X = s_vecs_k / np.sqrt(s_vals_k)
        Ht = X.conj().T @ Hsub @ X
        Ht = 0.5 * (Ht + Ht.conj().T)
        ritz = np.linalg.eigvalsh(Ht)  # ascending, real

        energies = [float(e) for e in ritz]
        cond = float(lam_max / s_vals_k[0])

        if self.callback:
            self.callback("done", {"ground_energy": energies[0], "effective_dim": int(s_vals_k.size)})

        return KrylovResult(
            ground_energy=energies[0],
            energies=energies,
            krylov_dim=self.krylov_dim,
            effective_dim=int(s_vals_k.size),
            dt=self.dt,
            condition_number=cond,
        )
