"""Variational Quantum Eigensolver (VQE) implementation."""

from __future__ import annotations

from dataclasses import dataclass, field
from typing import Optional, Callable

import numpy as np
from scipy.optimize import minimize
from openfermion import QubitOperator

from ..circuit.circuit import ParameterizedCircuit
from .expectation import statevector_simulate, compute_expectation


@dataclass
class VQEResult:
    """Results from a VQE optimization."""

    energy: float
    optimal_parameters: np.ndarray
    num_iterations: int
    converged: bool
    history: list[float] = field(default_factory=list)


class VQE:
    """Variational Quantum Eigensolver.

    Parameters
    ----------
    ansatz : ParameterizedCircuit
        The variational ansatz circuit.
    qubit_hamiltonian : QubitOperator
        The qubit Hamiltonian.
    optimizer : str
        Optimizer: 'SLSQP', 'COBYLA', 'L-BFGS-B', 'Nelder-Mead', 'Powell',
        'SPSA', or 'ADAM'.
    max_iterations : int
        Maximum optimization iterations.
    initial_parameters : ndarray, optional
        Starting parameters. Random if not provided.
    callback : callable, optional
        Called with (iteration, energy, parameters) each step.
    tol : float
        Convergence tolerance.
    """

    def __init__(
        self,
        ansatz: ParameterizedCircuit,
        qubit_hamiltonian: QubitOperator,
        optimizer: str = "COBYLA",
        max_iterations: int = 500,
        initial_parameters: Optional[np.ndarray] = None,
        callback: Optional[Callable] = None,
        tol: float = 1e-8,
    ):
        self.ansatz = ansatz
        self.hamiltonian = qubit_hamiltonian
        self.optimizer = optimizer
        self.max_iterations = max_iterations
        self.initial_parameters = initial_parameters
        self.callback = callback
        self.tol = tol

    def _cost_function(self, parameters: np.ndarray) -> float:
        """Evaluate the energy for given parameters."""
        state = statevector_simulate(self.ansatz, parameters)
        return compute_expectation(self.hamiltonian, state)

    def run(self) -> VQEResult:
        """Run the VQE optimization.

        Returns
        -------
        VQEResult
            Optimization results.
        """
        n_params = self.ansatz.num_parameters
        if n_params == 0:
            energy = self._cost_function(np.array([]))
            return VQEResult(
                energy=energy,
                optimal_parameters=np.array([]),
                num_iterations=0,
                converged=True,
                history=[energy],
            )

        if self.initial_parameters is not None:
            x0 = np.array(self.initial_parameters, dtype=float)
        else:
            x0 = np.random.uniform(-0.1, 0.1, n_params)

        history = []
        iteration_count = [0]

        def tracked_cost(params):
            energy = self._cost_function(params)
            history.append(energy)
            iteration_count[0] += 1
            if self.callback:
                self.callback(iteration_count[0], energy, params)
            return energy

        if self.optimizer == "SPSA":
            result_params, result_energy = _spsa_optimize(
                tracked_cost, x0, self.max_iterations, self.tol
            )
            return VQEResult(
                energy=result_energy,
                optimal_parameters=result_params,
                num_iterations=len(history),
                converged=True,
                history=history,
            )
        elif self.optimizer == "ADAM":
            result_params, result_energy = _adam_optimize(
                self._cost_function, x0, self.max_iterations, self.tol,
                history, self.callback,
            )
            return VQEResult(
                energy=result_energy,
                optimal_parameters=result_params,
                num_iterations=len(history),
                converged=True,
                history=history,
            )
        else:
            result = minimize(
                tracked_cost,
                x0,
                method=self.optimizer,
                options={"maxiter": self.max_iterations},
                tol=self.tol,
            )
            return VQEResult(
                energy=float(result.fun),
                optimal_parameters=result.x,
                num_iterations=len(history),
                converged=result.success,
                history=history,
            )


def _spsa_optimize(
    cost_fn: Callable,
    x0: np.ndarray,
    max_iter: int,
    tol: float,
    a: float = 0.1,
    c: float = 0.1,
    alpha: float = 0.602,
    gamma: float = 0.101,
) -> tuple[np.ndarray, float]:
    """Simultaneous Perturbation Stochastic Approximation (SPSA).

    Two-point gradient estimate using random perturbation vectors.
    """
    A = max_iter * 0.1
    params = x0.copy()
    best_energy = float("inf")
    best_params = params.copy()

    for k in range(1, max_iter + 1):
        ak = a / (k + A) ** alpha
        ck = c / k**gamma

        # Random perturbation (Bernoulli ±1)
        delta = np.random.choice([-1, 1], size=len(params)).astype(float)

        # Two-point gradient estimate
        e_plus = cost_fn(params + ck * delta)
        e_minus = cost_fn(params - ck * delta)
        gradient = (e_plus - e_minus) / (2 * ck * delta)

        params -= ak * gradient

        energy = min(e_plus, e_minus)
        if energy < best_energy:
            best_energy = energy
            best_params = params.copy()

        if abs(e_plus - e_minus) < tol:
            break

    return best_params, best_energy


def _adam_optimize(
    cost_fn: Callable,
    x0: np.ndarray,
    max_iter: int,
    tol: float,
    history: list,
    callback: Optional[Callable],
    lr: float = 0.01,
    beta1: float = 0.9,
    beta2: float = 0.999,
    eps: float = 1e-8,
    grad_eps: float = 1e-5,
) -> tuple[np.ndarray, float]:
    """ADAM optimizer with numerical gradient."""
    params = x0.copy()
    m = np.zeros_like(params)
    v = np.zeros_like(params)

    best_energy = float("inf")
    best_params = params.copy()

    for t in range(1, max_iter + 1):
        # Numerical gradient
        grad = np.zeros_like(params)
        for i in range(len(params)):
            params_p = params.copy()
            params_m = params.copy()
            params_p[i] += grad_eps
            params_m[i] -= grad_eps
            grad[i] = (cost_fn(params_p) - cost_fn(params_m)) / (2 * grad_eps)

        # ADAM update
        m = beta1 * m + (1 - beta1) * grad
        v = beta2 * v + (1 - beta2) * grad**2
        m_hat = m / (1 - beta1**t)
        v_hat = v / (1 - beta2**t)
        params -= lr * m_hat / (np.sqrt(v_hat) + eps)

        energy = cost_fn(params)
        history.append(energy)

        if callback:
            callback(t, energy, params)

        if energy < best_energy:
            best_energy = energy
            best_params = params.copy()

        if np.linalg.norm(grad) < tol:
            break

    return best_params, best_energy
