"""Bayesian Phase Estimation (BPE) — single-ancilla, posterior-tracking ground-state energy.

Maintains a Gaussian posterior over the ground-state eigenphase and refines it round by round.
Each round picks an evolution time M*t0 and a measurement angle beta, takes a (simulated) single-
ancilla Hadamard-test outcome whose +1 probability is

    p(+1) = (1 + Re[ exp(i beta) g(M t0) ]) / 2,        g(t) = <phi0| exp(-i H t) |phi0>,

draws `shots` Bernoulli outcomes, and does a Bayesian update of the posterior mean/variance against
the likelihood.  The evolution time grows as the posterior sharpens (the particle-guess heuristic
M ~ 1/sigma), so BPE approaches the Heisenberg-limited 1/N scaling with one ancilla qubit — the
hardware-friendly alternative to textbook QPE.

The signal g(t) is the exact statevector overlap (the same primitive QCELS/RPE/QMEGS use); `shots`
injects honest finite-sampling noise so the posterior reflects a realistic measurement budget.
Set `shots=0` for the noiseless (infinite-shot) limit.
"""

from __future__ import annotations

import math
from dataclasses import dataclass, field
from typing import Callable

import numpy as np
from openfermion import QubitOperator

from .signal_pe import (
    hamiltonian_signal, _signal_dispatch, count_qubits, _base_time, _phase_to_energy,
)


@dataclass
class BayesianPEResult:
    """Result of a Bayesian phase-estimation run."""

    energy: float
    sigma_energy: float            # posterior 1-sigma uncertainty on the energy (Hartree)
    algorithm: str = "BPE"
    rounds: int = 0
    phi_mean: float = 0.0
    phi_sigma: float = 0.0
    energy_history: list[float] = field(default_factory=list)


class BPE:
    """Bayesian Phase Estimation for a molecular ground-state energy.

    Parameters
    ----------
    qubit_hamiltonian : QubitOperator
        Qubit Hamiltonian (total energies — identity term included).
    ref_state : ndarray
        Reference |phi0> (occupation bitstring or statevector); a Hartree-Fock reference with strong
        ground-state overlap is the intended input (BPE tracks the dominant eigenphase).
    num_rounds : int
        Number of Bayesian-update rounds.
    shots : int
        Single-ancilla measurements per round (finite-sampling noise). 0 = noiseless limit.
    seed : int or None
        RNG seed for reproducible sampling.
    callback : callable, optional
        Called with (round, energy_estimate) each round.
    """

    def __init__(
        self,
        qubit_hamiltonian: QubitOperator,
        ref_state: np.ndarray,
        num_rounds: int = 24,
        shots: int = 200,
        seed: int | None = 0,
        callback: Callable | None = None,
        use_hadamard_test: bool = False,
        trotter_dt: float = 0.2,
    ):
        self.qop = qubit_hamiltonian
        self.num_qubits = count_qubits(qubit_hamiltonian)
        self.ref_state = ref_state
        self.num_rounds = int(num_rounds)
        self.shots = int(shots)
        self.seed = seed
        self.callback = callback
        self.use_hadamard_test = bool(use_hadamard_test)
        self.trotter_dt = float(trotter_dt)
        self.t0, self.center, self.radius = _base_time(qubit_hamiltonian)

    def run(self) -> BayesianPEResult:
        rng = np.random.default_rng(self.seed)

        # Phase phi in (-0.5, 0.5] of exp(-i (H - center) t0); shifted eigenphases live in
        # (-0.9*pi, 0.9*pi) by construction of t0, so phi is unambiguous near the ground state.
        # Prior: flat-ish, centered at 0 with a wide sigma (a third of the period).
        mu = 0.0
        sigma = 0.25
        history: list[float] = []

        for r in range(self.num_rounds):
            # Particle-guess heuristic: keep the prior comfortably NARROWER than one likelihood
            # fringe (period 1/M) so the posterior stays unimodal. Start at M=1 (sigma~0.25) and let
            # M grow only as the posterior sharpens — int-floor of 0.25/sigma gives M=1 first.
            M = max(1, int(0.25 / max(sigma, 1e-6)))
            t = M * self.t0
            g = _signal_dispatch(self.qop, self.ref_state, np.array([t]), self.num_qubits,
                                 self.use_hadamard_test, self.trotter_dt)[0]
            g_shift = g * np.exp(1j * self.center * t)

            # TWO measurement bases per round break the cos sign-degeneracy (beta=0 senses the real
            # part cos(2*pi*M*phi); beta=pi/2 the imaginary part sin(2*pi*M*phi)) — without the
            # sin branch +phi and -phi are indistinguishable and the posterior collapses to phi=0.
            for beta in (0.0, math.pi / 2.0):
                p_plus = float(np.clip((1.0 + (np.exp(1j * beta) * g_shift).real) / 2.0, 0.0, 1.0))
                if self.shots > 0:
                    f_plus = int(rng.binomial(self.shots, p_plus)) / self.shots
                else:
                    f_plus = p_plus
                mu, sigma = _bayes_update(mu, sigma, M, beta, f_plus)

            energy = _phase_to_energy(mu % 1.0, self.t0, self.center)
            history.append(energy)
            if self.callback:
                self.callback(r + 1, energy)

        energy = _phase_to_energy(mu % 1.0, self.t0, self.center)
        sigma_energy = 2.0 * math.pi * sigma / self.t0
        return BayesianPEResult(
            energy=energy,
            sigma_energy=sigma_energy,
            algorithm="BPE",
            rounds=self.num_rounds,
            phi_mean=mu,
            phi_sigma=sigma,
            energy_history=history,
        )


def _bayes_update(mu: float, sigma: float, M: int, beta: float, f_plus: float
                  ) -> tuple[float, float]:
    """Gaussian-posterior update against the round's likelihood, by moment matching.

    The likelihood of phi given the measured +1 frequency is p(+1|phi) = (1 + cos(2*pi*M*phi +
    beta))/2.  We evaluate prior x likelihood on a local grid around mu and re-fit a Gaussian
    (mean/variance) — robust and cheap for one parameter, and it keeps the posterior unimodal so
    the period-2pi/M fringes don't split it (the wide prior + growing M is the standard BPE
    schedule that avoids aliasing). Shared by BPE (ground energy) and BPDE (energy gap).
    """
    grid = np.linspace(mu - 4.0 * sigma, mu + 4.0 * sigma, 257)
    prior = np.exp(-0.5 * ((grid - mu) / sigma) ** 2)
    like_plus = 0.5 * (1.0 + np.cos(2.0 * math.pi * M * grid + beta))
    # Mix the measured outcome: weight the +1 / -1 branches by the observed frequency.
    like = f_plus * like_plus + (1.0 - f_plus) * (1.0 - like_plus)
    post = prior * np.clip(like, 1e-12, None)
    norm = float(np.sum(post))
    if norm <= 0.0:
        return mu, sigma
    post /= norm
    new_mu = float(np.sum(grid * post))
    var = float(np.sum((grid - new_mu) ** 2 * post))
    new_sigma = math.sqrt(max(var, 1e-12))
    # Never let the posterior collapse to a delta (numerical floor) or widen past the prior.
    return new_mu, min(max(new_sigma, 1e-5), sigma)


@dataclass
class BPDEResult:
    """Result of a Bayesian phase-DIFFERENCE estimation (an energy gap)."""

    gap: float                     # E_excited - E_ground (same unit as the Hamiltonian)
    sigma_gap: float               # posterior 1-sigma uncertainty on the gap
    algorithm: str = "BPDE"
    rounds: int = 0
    gap_history: list[float] = field(default_factory=list)


class BPDE:
    """Bayesian Phase-Difference Estimation — the energy GAP between two states, directly.

    Rather than estimate two absolute energies and subtract (doubling the error), BPDE estimates the
    phase DIFFERENCE that accumulates between a ground and an excited reference under the same time
    evolution. For (approximate) eigenstates |g>, |e> the product signal

        s(t) = <g|U(t)|g> * conj(<e|U(t)|e>)   (both shifted by the spectral center)

    is a single complex exponential exp(+i 2*pi*M*phi_gap) whose frequency IS the gap, so a Bayesian
    posterior over phi_gap (same schedule as BPE, two measurement bases per round) yields the gap and
    its uncertainty with no controlled-U. The references come from VQD (states[0], states[1]); the
    cleaner they are as eigenstates, the purer the single-frequency signal.

    Parameters
    ----------
    qubit_hamiltonian : QubitOperator
    ref_ground, ref_excited : ndarray
        The two reference statevectors (or occupation bitstrings) whose energy gap is sought.
    num_rounds : int
    shots : int
        Single-ancilla measurements per round (0 = noiseless limit).
    seed : int or None
    callback : callable, optional
        Called with (round, gap_estimate) each round.
    """

    def __init__(
        self,
        qubit_hamiltonian: QubitOperator,
        ref_ground: np.ndarray,
        ref_excited: np.ndarray,
        num_rounds: int = 24,
        shots: int = 200,
        seed: int | None = 0,
        callback: Callable | None = None,
        prep_ground: list | None = None,
        prep_excited: list | None = None,
        trotter_dt: float = 0.2,
    ):
        self.qop = qubit_hamiltonian
        self.num_qubits = count_qubits(qubit_hamiltonian)
        self.ref_g = ref_ground
        self.ref_e = ref_excited
        self.num_rounds = int(num_rounds)
        self.shots = int(shots)
        self.seed = seed
        self.callback = callback
        # Gate-circuit path: when prep_ground/prep_excited (bound state-prep gate lists, e.g. the VQD
        # ansatz at its optimal parameters) are supplied, both reference signals g_g(t)/g_e(t) are
        # sampled from the real Hadamard-test gate circuit instead of the dense eigh. Trotter-approximate.
        self.prep_g = prep_ground
        self.prep_e = prep_excited
        self.use_gate_circuit = prep_ground is not None and prep_excited is not None
        self.trotter_dt = float(trotter_dt)
        self.t0, self.center, self.radius = _base_time(qubit_hamiltonian)

    def _diff_signal(self, M: int) -> complex:
        """s(M t0) = g_g_shift * conj(g_e_shift): a single exponential exp(+i 2pi M phi_gap)."""
        t = M * self.t0
        if self.use_gate_circuit:
            from .hadamard_test import hadamard_test_signal_prep

            gg = hadamard_test_signal_prep(self.qop, self.prep_g, self.num_qubits,
                                           np.array([t]), trotter_dt=self.trotter_dt)[0]
            ge = hadamard_test_signal_prep(self.qop, self.prep_e, self.num_qubits,
                                           np.array([t]), trotter_dt=self.trotter_dt)[0]
        else:
            gg = hamiltonian_signal(self.qop, self.ref_g, np.array([t]), self.num_qubits)[0]
            ge = hamiltonian_signal(self.qop, self.ref_e, np.array([t]), self.num_qubits)[0]
        gg_s = gg * np.exp(1j * self.center * t)
        ge_s = ge * np.exp(1j * self.center * t)
        return gg_s * np.conjugate(ge_s)

    def run(self) -> BPDEResult:
        rng = np.random.default_rng(self.seed)
        mu = 0.25      # phi_gap is positive (E_e > E_g); start mid-range with a wide prior
        sigma = 0.25
        history: list[float] = []

        for r in range(self.num_rounds):
            M = max(1, int(0.25 / max(sigma, 1e-6)))
            s = self._diff_signal(M)
            for beta in (0.0, math.pi / 2.0):
                p_plus = float(np.clip((1.0 + (np.exp(1j * beta) * s).real) / 2.0, 0.0, 1.0))
                if self.shots > 0:
                    f_plus = int(rng.binomial(self.shots, p_plus)) / self.shots
                else:
                    f_plus = p_plus
                mu, sigma = _bayes_update(mu, sigma, M, beta, f_plus)
            gap = 2.0 * math.pi * (mu % 1.0) / self.t0
            history.append(gap)
            if self.callback:
                self.callback(r + 1, gap)

        gap = 2.0 * math.pi * (mu % 1.0) / self.t0
        sigma_gap = 2.0 * math.pi * sigma / self.t0
        return BPDEResult(
            gap=gap, sigma_gap=sigma_gap, algorithm="BPDE",
            rounds=self.num_rounds, gap_history=history,
        )
