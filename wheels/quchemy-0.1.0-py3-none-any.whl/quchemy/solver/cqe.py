"""Contracted Quantum Eigensolver (CQE) via the Anti-Hermitian Contracted Schrodinger Equation.

Solves the many-electron problem by iterating a two-body anti-Hermitian unitary:

    |psi_{k+1}> = exp(eps * A_k) |psi_k>,   A_k = sum_i g_i^(k) A_i,

where {A_i} are the two-body (and one-body) anti-Hermitian generators of the UCCSD operator pool
and the residual gradient is the ACSE contraction

    g_i^(k) = <psi_k| [H, A_i] |psi_k> = 2 Re <psi_k| H A_i |psi_k>.

At a stationary point every residual vanishes (the anti-Hermitian part of the contracted
Schrodinger equation is satisfied), which for a complete pool is the exact ground state.  This is
the collective cousin of ADAPT-VQE (which adds one pool operator at a time); CQE applies the full
residual-weighted exponential each iteration.

Implementation is sparse throughout — `get_sparse_operator` for the pool/Hamiltonian and
`scipy.sparse.linalg.expm_multiply` for the propagation — so it never forms a dense 2^n x 2^n
matrix and scales to the same system sizes as the rest of the statevector path.
"""

from __future__ import annotations

import math
from dataclasses import dataclass, field
from typing import Callable

import numpy as np
from openfermion import QubitOperator, get_sparse_operator

from ..circuit.gates import H, RX, RZ, CNOT
from .expectation import apply_gates_to_state
from .signal_pe import count_qubits, _resolve_reference


def _pauli_rotation_gates(term: tuple, theta: float) -> list:
    """Concrete gates for exp(-i*theta*P) on a Pauli string P (basis change → CNOT staircase →
    RZ(2*theta) → uncompute), the building block of a Trotterized anti-Hermitian exponential."""
    qubits = [q for q, _ in sorted(term)]
    paulis = [p for _, p in sorted(term)]
    gates = []
    for q, p in zip(qubits, paulis):
        if p == "X":
            gates.append(H(q))
        elif p == "Y":
            gates.append(RX(q, angle=math.pi / 2))
    for i in range(len(qubits) - 1):
        gates.append(CNOT(qubits[i], qubits[i + 1]))
    gates.append(RZ(qubits[-1], angle=2.0 * theta))      # exp(-i theta Z) = RZ(2 theta)
    for i in range(len(qubits) - 2, -1, -1):
        gates.append(CNOT(qubits[i], qubits[i + 1]))
    for q, p in zip(qubits, paulis):
        if p == "X":
            gates.append(H(q))
        elif p == "Y":
            gates.append(RX(q, angle=-math.pi / 2))
    return gates


def _gate_propagate(
    psi: np.ndarray, a_hat: QubitOperator, eps: float, num_qubits: int, trotter_steps: int = 1
) -> np.ndarray:
    """Apply the Trotterized exp(-eps * A_hat) to `psi` with GATES (the gate analog of
    expm_multiply). A_hat is anti-Hermitian (pure-imaginary Pauli coeffs); each term P with
    coeff i*b contributes a Pauli rotation exp(-i (eps*b) P)."""
    state = psi.copy()
    dt = eps / trotter_steps
    layer = []
    for term, coeff in a_hat.terms.items():
        if not term:
            continue
        theta = dt * float(coeff.imag)                   # exp(-eps * i b P) = exp(-i (eps b) P)
        if abs(theta) > 1e-15:
            layer.extend(_pauli_rotation_gates(term, theta))
    for _ in range(trotter_steps):
        apply_gates_to_state(layer, state, num_qubits)
    return state


@dataclass
class CQEResult:
    """Result of a Contracted Quantum Eigensolver run."""

    energy: float
    iterations: int
    converged: bool
    energy_history: list[float] = field(default_factory=list)
    residual_norm_history: list[float] = field(default_factory=list)


class CQE:
    """Contracted Quantum Eigensolver (ACSE form) over the UCCSD operator pool.

    Parameters
    ----------
    qubit_hamiltonian : QubitOperator
        Qubit Hamiltonian (total energies — identity term included).
    pool : list[QubitOperator]
        Anti-Hermitian one-/two-body generators, mapped under the same fermion-to-qubit transform
        as the Hamiltonian. Use `build_generalized_pool` (the FULL generalized two-body set) to
        reach FCI — the UCCSD subset (`build_uccsd_pool`, occupied→virtual only) has ACSE
        stationary points above the ground state, so CQE plateaus there.
    num_qubits : int
        Number of qubits (system register width).
    ref_state : ndarray
        Reference |psi_0> (occupation bitstring or statevector); Hartree-Fock is the usual choice.
    epsilon : float
        Initial trial step for the per-iteration line search (warm-started thereafter); not a
        fixed step. 0.1 is a robust default.
    max_iterations : int
        Maximum CQE iterations.
    residual_tol : float
        Convergence threshold on the residual-gradient 2-norm.
    callback : callable, optional
        Called with (iteration, energy, residual_norm) each iteration.
    """

    def __init__(
        self,
        qubit_hamiltonian: QubitOperator,
        pool: list[QubitOperator],
        num_qubits: int,
        ref_state: np.ndarray,
        epsilon: float = 0.1,
        max_iterations: int = 200,
        residual_tol: float = 1e-6,
        callback: Callable | None = None,
        use_gate_circuit: bool = False,
        trotter_steps: int = 1,
    ):
        self.qop = qubit_hamiltonian
        self.pool = pool
        self.num_qubits = num_qubits or count_qubits(qubit_hamiltonian)
        self.ref_state = ref_state
        self.epsilon = float(epsilon)
        self.max_iterations = int(max_iterations)
        self.residual_tol = float(residual_tol)
        self.callback = callback
        # When True, each exp(-eps A) step is a REAL gate circuit (Trotterized Pauli-exponential
        # layers via _gate_propagate) instead of the exact sparse expm_multiply — so the prepared
        # state is produced by hardware-runnable gates. Trotter-approximate; residuals/energy are
        # still read from the resulting statevector (the "measurements").
        self.use_gate_circuit = bool(use_gate_circuit)
        self.trotter_steps = int(trotter_steps)

    def _line_search(self, psi, propagate, e0, slope0, energy_of, init_step, eps_cap=2.0):
        """Pick the step eps>0 in |psi'> = normalize(exp(-eps A_hat)|psi>) that lowers the energy.

        Uses the exact slope at 0 (dE/deps = slope0 = -|g|^2) plus one trial evaluation to fit a
        parabola E(eps) ~ e0 + slope0*eps + c*eps^2 and jump to its vertex; backtracks (halving)
        when the trial overshoots. Returns (step, psi_new, energy_new); step 0.0 means no downhill
        step was found (stationary). `propagate(psi, eps)` returns exp(-eps A_hat)|psi> (sparse
        expm_multiply on the dense path, Trotterized gates on the circuit path)."""
        def eval_at(eps: float):
            p = propagate(psi, eps)
            nrm = np.linalg.norm(p)
            if nrm > 0:
                p = p / nrm
            return energy_of(p), p

        t = float(min(max(init_step, 1e-3), eps_cap))
        et, pt = eval_at(t)
        if et < e0:
            # Parabolic interpolation through (0, e0, slope0) and (t, et).
            c = (et - e0 - slope0 * t) / (t * t)
            if c > 1e-12:
                es = min(max(-slope0 / (2.0 * c), 1e-6), eps_cap)
                ee, pe = eval_at(es)
                if ee <= et:
                    return es, pe, ee
            return t, pt, et
        # Trial overshot (energy rose): backtrack until it descends.
        while t > 1e-6:
            t *= 0.5
            et, pt = eval_at(t)
            if et < e0:
                return t, pt, et
        return 0.0, psi, e0

    def run(self) -> CQEResult:
        from scipy.sparse.linalg import expm_multiply

        n = self.num_qubits
        Hmat = get_sparse_operator(self.qop, n_qubits=n)
        H = Hmat
        pool_sp = [get_sparse_operator(A, n_qubits=n) for A in self.pool]
        psi = _resolve_reference(self.ref_state, n)

        energy_history: list[float] = []
        residual_history: list[float] = []
        converged = False
        iterations = 0
        prev_step = self.epsilon  # warm-start the line search

        def energy_of(state: np.ndarray) -> float:
            return float(np.vdot(state, H @ state).real)

        for it in range(self.max_iterations):
            iterations = it + 1
            Hpsi = H @ psi
            # ACSE residual gradient g_i = 2 Re <psi| H A_i |psi> = 2 Re <H psi | A_i psi>.
            g = np.array([2.0 * np.vdot(Hpsi, Asp @ psi).real for Asp in pool_sp])
            res_norm = float(np.linalg.norm(g))
            residual_history.append(res_norm)

            if res_norm < self.residual_tol:
                converged = True
                energy_history.append(float(np.vdot(psi, Hpsi).real))
                if self.callback:
                    self.callback(iterations, energy_history[-1], res_norm)
                break

            # Steepest-descent direction is -A_k (A_k = sum_i g_i A_i): dE/dtheta_i = <[H,A_i]> = g_i,
            # and along eps>0 in exp(-eps A_k) the slope at 0 is dE/deps = -|g|^2. A line search picks
            # the energy-optimal step each iteration (a fixed eps converges far too slowly).
            if self.use_gate_circuit:
                # A_hat as a QubitOperator → Trotterized gate propagation (real circuit).
                a_hat_qop = QubitOperator()
                for gi, A in zip(g, self.pool):
                    a_hat_qop += gi * A
                propagate = (lambda p, eps, _q=a_hat_qop:
                             _gate_propagate(p, _q, eps, n, self.trotter_steps))
            else:
                A_hat = pool_sp[0] * g[0]
                for gi, Asp in zip(g[1:], pool_sp[1:]):
                    A_hat = A_hat + gi * Asp
                propagate = lambda p, eps, _A=A_hat: expm_multiply(-eps * _A, p)
            e0 = float(np.vdot(psi, Hpsi).real)
            slope0 = -res_norm * res_norm
            step, psi, e = self._line_search(psi, propagate, e0, slope0, energy_of, prev_step)
            energy_history.append(e)
            if self.callback:
                self.callback(iterations, e, res_norm)
            if step <= 0.0:
                # No downhill step along the residual — stationary within numerical limits.
                converged = True
                break
            prev_step = step

        if not energy_history:
            energy_history.append(energy_of(psi))

        return CQEResult(
            energy=energy_history[-1],
            iterations=iterations,
            converged=converged,
            energy_history=energy_history,
            residual_norm_history=residual_history,
        )
