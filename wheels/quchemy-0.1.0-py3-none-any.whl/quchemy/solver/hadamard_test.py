"""Hadamard-test estimation of the time-domain signal g(t) = <phi0| e^{-iHt} |phi0> as a REAL
universal-gate circuit (not a dense matrix exponential).

The signal-based phase estimators (QCELS / RPE / QMEGS / BPE) all consume g(t).  The default
path computes it classically by one dense `eigh` (signal_pe.hamiltonian_signal) — exact, but not a
circuit.  This module builds the genuine hardware primitive instead: the Hadamard test.

For U = e^{-iHt}, with one ancilla and the system prepared in |phi0>,

    real part:  H_a · (ctrl-U) · H_a            measure <Z_a>  =  Re <phi0|U|phi0>
    imag part:  H_a · S†_a · (ctrl-U) · H_a     measure <Z_a>  =  Im <phi0|U|phi0>

so g(t) = <Z_a>_real + i <Z_a>_imag.  The controlled e^{-iHt} is FIRST-ORDER TROTTERIZED into the
gate set {H, RX, RZ, CNOT, S, Z}: each Hamiltonian Pauli term c_k P_k contributes a controlled
Pauli-exponential (basis change → CNOT parity staircase → controlled-RZ → uncompute), and the
identity term c_0·I contributes a controlled global phase (an ancilla RZ — observable here because
it is *controlled*, and it is exactly the energy offset that fixes g(t)'s frequency).

Everything here is a `ParameterizedCircuit` of universal gates, simulated by applying gates one at a
time (`statevector_simulate`) and exportable to Qiskit (`to_qiskit_circuit`) — so the SAME circuit
runs on real gate-based hardware.  It is APPROXIMATE (Trotter error ~ O((t/steps)^2)); the dense path
stays the exact default.  Ancilla is qubit 0 (the MSB in the simulator's convention); the system
register is qubits 1..n_sys.
"""

from __future__ import annotations

import math

import numpy as np
from openfermion import QubitOperator

from ..circuit.circuit import ParameterizedCircuit
from ..circuit.gates import Gate, H, RX, RZ, CNOT, S, Z, X


def _controlled_pauli_exponential(
    circuit: ParameterizedCircuit, ancilla: int, term: tuple, theta: float, offset: int
) -> None:
    """Append a controlled exp(-i*theta*P) onto the system, controlled by `ancilla`.

    `term` is an OpenFermion Pauli string ((qubit, 'X'|'Y'|'Z'), ...) in SYSTEM indices; `offset`
    maps system qubit q -> circuit qubit q+offset.  The basis change and CNOT staircase are
    UNCONDITIONAL (they cancel when the control is |0>); only the central RZ is controlled, so this
    is controlled-(B† e^{-i theta Z} B) = controlled-e^{-i theta P}.
    """
    if not term or abs(theta) < 1e-15:
        return
    qubits = [q + offset for q, _ in sorted(term)]
    paulis = [p for _, p in sorted(term)]

    # 1. Basis change into the Z eigenbasis (unconditional).
    for q, p in zip(qubits, paulis):
        if p == "X":
            circuit.append(H(q))
        elif p == "Y":
            circuit.append(RX(q, angle=math.pi / 2))
    # 2. CNOT staircase: parity of the term onto the last qubit (unconditional).
    for i in range(len(qubits) - 1):
        circuit.append(CNOT(qubits[i], qubits[i + 1]))
    # 3. Controlled-RZ(2*theta) from the ancilla onto the parity qubit, since e^{-i theta Z} = RZ(2 theta).
    #    CRZ(2 theta) = RZ(theta) · CX · RZ(-theta) · CX  (target = parity qubit).
    target = qubits[-1]
    circuit.append(RZ(target, angle=theta))
    circuit.append(CNOT(ancilla, target))
    circuit.append(RZ(target, angle=-theta))
    circuit.append(CNOT(ancilla, target))
    # 4. Uncompute the staircase and basis change.
    for i in range(len(qubits) - 2, -1, -1):
        circuit.append(CNOT(qubits[i], qubits[i + 1]))
    for q, p in zip(qubits, paulis):
        if p == "X":
            circuit.append(H(q))
        elif p == "Y":
            circuit.append(RX(q, angle=-math.pi / 2))


def _controlled_time_evolution(
    circuit: ParameterizedCircuit, ancilla: int, qop: QubitOperator, t: float, steps: int, offset: int
) -> None:
    """Append a first-order Trotterized controlled-e^{-iHt} onto the circuit (control = `ancilla`)."""
    terms = list(qop.terms.items())
    dt = t / steps
    for _ in range(steps):
        for term, coeff in terms:
            c = float(np.real(coeff))
            if not term:
                # Identity term: controlled global phase diag(1, e^{-i c dt}) on the ancilla.
                # RZ(lam) gives the ancilla |1>/|0> relative phase e^{i lam}; want e^{-i c dt} -> lam = -c dt.
                circuit.append(RZ(ancilla, angle=-c * dt))
            else:
                _controlled_pauli_exponential(circuit, ancilla, term, c * dt, offset)


def _prepare_reference(circuit: ParameterizedCircuit, ref_bits: np.ndarray, offset: int) -> None:
    """X gates to set the system register to the computational-basis reference |phi0>."""
    for i, bit in enumerate(ref_bits):
        if int(bit):
            circuit.append(X(i + offset))


def _append_prep(circuit: ParameterizedCircuit, prep_gates: list, offset: int) -> None:
    """Append a (bound) state-prep gate list to the system register, shifting each gate's qubits by
    `offset` (the ancilla sits at qubit 0). Lets the Hadamard test use an arbitrary prepared
    reference (e.g. a VQD ansatz bound to its optimal parameters), not just a basis string."""
    for g in prep_gates:
        circuit.append(Gate(g.name, tuple(q + offset for q in g.qubits),
                            parameter=g.parameter, param_index=None, param_coeff=g.param_coeff))


def hadamard_test_circuit(
    qop: QubitOperator,
    ref_bits: np.ndarray,
    t: float,
    steps: int,
    part: str,
    prep_gates: list | None = None,
    n_sys: int | None = None,
) -> ParameterizedCircuit:
    """The Hadamard-test circuit for the real ('re') or imaginary ('im') part of g(t).

    Qubit 0 is the ancilla; qubits 1..n_sys are the system. The reference is either the computational
    occupation `ref_bits` (X-gate prep) or, when `prep_gates` is given (with `n_sys`), an arbitrary
    bound state-prep gate list (e.g. a VQD ansatz). Measuring <Z> on the ancilla yields Re (or Im) of
    <phi0|e^{-iHt}|phi0>.
    """
    if prep_gates is not None:
        nq = int(n_sys)
        circuit = ParameterizedCircuit(nq + 1)
        _append_prep(circuit, prep_gates, offset=1)
    else:
        nq = len(ref_bits)
        circuit = ParameterizedCircuit(nq + 1)
        _prepare_reference(circuit, ref_bits, offset=1)
    ancilla = 0
    circuit.append(H(ancilla))
    if part == "im":
        # S† on the ancilla (S then Z = diag(1, i)·diag(1, -1) = diag(1, -i)) rotates the
        # measurement to the imaginary part.
        circuit.append(S(ancilla))
        circuit.append(Z(ancilla))
    _controlled_time_evolution(circuit, ancilla, qop, t, steps, offset=1)
    circuit.append(H(ancilla))
    return circuit


def _ancilla_z_expectation(state: np.ndarray) -> float:
    """<Z> on qubit 0 (the MSB): P(anc=0) - P(anc=1) = ||state[:half]||^2 - ||state[half:]||^2."""
    half = state.size // 2
    p0 = float(np.sum(np.abs(state[:half]) ** 2))
    p1 = float(np.sum(np.abs(state[half:]) ** 2))
    return p0 - p1


def hadamard_test_signal(
    qop: QubitOperator,
    ref_bits: np.ndarray,
    times: np.ndarray,
    trotter_dt: float = 0.2,
    max_steps: int = 4000,
) -> np.ndarray:
    """g(t_k) = <phi0|e^{-iHt_k}|phi0> for each t_k, via the Hadamard-test GATE CIRCUIT.

    Each time uses first-order Trotter with `ceil(|t|/trotter_dt)` steps (capped at `max_steps`) so
    the per-step error stays bounded as t grows.  `ref_bits` is a computational-basis occupation
    string (the HF reference); a non-basis reference is not supported on the gate path (it would
    need arbitrary state preparation).  Returns the complex signal, same shape as `times`.
    """
    from .expectation import statevector_simulate

    ref_bits = np.asarray(ref_bits).astype(int)
    out = np.empty(len(times), dtype=complex)
    for k, t in enumerate(times):
        tt = float(t)
        steps = 1 if tt == 0.0 else min(max_steps, max(1, math.ceil(abs(tt) / trotter_dt)))
        re_state = statevector_simulate(hadamard_test_circuit(qop, ref_bits, tt, steps, "re"))
        im_state = statevector_simulate(hadamard_test_circuit(qop, ref_bits, tt, steps, "im"))
        out[k] = _ancilla_z_expectation(re_state) + 1j * _ancilla_z_expectation(im_state)
    return out


def hadamard_test_signal_prep(
    qop: QubitOperator,
    prep_gates: list,
    n_sys: int,
    times: np.ndarray,
    trotter_dt: float = 0.2,
    max_steps: int = 4000,
) -> np.ndarray:
    """g(t_k) = <phi|e^{-iHt_k}|phi> where |phi> is prepared by the bound gate list `prep_gates` (on
    `n_sys` system qubits) — e.g. a VQD ansatz at its optimal parameters. Same Hadamard-test machinery
    as hadamard_test_signal, but with an arbitrary state-prep prefix instead of an X-gate HF prep."""
    from .expectation import statevector_simulate

    out = np.empty(len(times), dtype=complex)
    for k, t in enumerate(times):
        tt = float(t)
        steps = 1 if tt == 0.0 else min(max_steps, max(1, math.ceil(abs(tt) / trotter_dt)))
        re_state = statevector_simulate(
            hadamard_test_circuit(qop, None, tt, steps, "re", prep_gates=prep_gates, n_sys=n_sys))
        im_state = statevector_simulate(
            hadamard_test_circuit(qop, None, tt, steps, "im", prep_gates=prep_gates, n_sys=n_sys))
        out[k] = _ancilla_z_expectation(re_state) + 1j * _ancilla_z_expectation(im_state)
    return out
