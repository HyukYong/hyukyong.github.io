"""QAAE — quantum amplitude-amplification eigensolver (Ch "Amplitude-amp eigensolver").

A NISQ ground-state method that is NOT energy minimization: instead of optimizing an ansatz, it
repeatedly applies a spectral FILTER that amplifies the ground-state component of a trial state and
LEARNS the energy from the filtered state (an "amplify-learn" loop).

The filter is the contraction M = (c·I - H)/(2R), where [c-2R, c] bounds the spectrum (Gershgorin,
no peeking at the eigenvalues): every eigenstate |E_k> is an eigenvector of M with eigenvalue
(c - E_k)/(2R) in [0, 1], LARGEST for the ground state (smallest E).  Repeated application is the
power method on that filter — the ground component grows round over round — and the Rayleigh
quotient <psi_k|H|psi_k> converges to E0.

On hardware each filter step is the good branch of a Sz.-Nagy dilation of M (open_system.dilation);
amplitude amplification boosts the post-selection success probability.  Here, on the statevector,
the renormalized good branch is exact, so the iterate is `apply_nonunitary(M, psi)` normalized.
This is amplitude AMPLIFICATION (Grover/Brassard, open prior art), not Robust Amplitude ESTIMATION.

Patent note: deliberately avoids any amplitude-ESTIMATION subroutine (Zapata RAE watch-list); the
amplify-learn loop reads the energy from the Rayleigh quotient, not from an estimated amplitude.
"""

from __future__ import annotations

from dataclasses import dataclass, field

import numpy as np
from openfermion import QubitOperator

from .signal_pe import (
    count_qubits,
    dense_hamiltonian_matrix,
    _resolve_reference,
    _spectral_window,
)
from ..open_system import apply_nonunitary, spectral_norm


@dataclass
class QAAEResult:
    energy: float                                  # learned ground-state energy (Rayleigh quotient)
    energy_history: list[float] = field(default_factory=list)   # <H> per amplify-learn round
    overlap_history: list[float] = field(default_factory=list)  # filter success prob ||M psi||^2
    rounds: int = 0
    converged: bool = False


class QAAE:
    """Amplitude-amplification eigensolver: amplify the ground component, learn the energy.

    Parameters
    ----------
    qubit_hamiltonian : QubitOperator
    ref_state : a `num_qubits`-bit occupation string (HF convention) or a full statevector.
    rounds : maximum amplify-learn rounds.
    tol : stop when |E_k - E_{k-1}| < tol.
    num_qubits : inferred from the operator when omitted.
    """

    def __init__(
        self,
        qubit_hamiltonian: QubitOperator,
        ref_state: np.ndarray,
        rounds: int = 40,
        tol: float = 1e-9,
        num_qubits: int | None = None,
        use_gate_circuit: bool = False,
    ) -> None:
        self.qop = qubit_hamiltonian
        self.num_qubits = num_qubits if num_qubits is not None else count_qubits(qubit_hamiltonian)
        self.ref_state = ref_state
        self.rounds = int(rounds)
        self.tol = float(tol)
        # When True, the spectral filter M is applied as the good branch of its Sz.-Nagy dilation,
        # COMPILED TO GATES (exact Quantum Shannon Decomposition, +1 ancilla) and post-selected — the
        # genuine on-hardware amplitude-amplification step. Exact (no Trotter error), but the dilation
        # synthesis is O(4^n) gates, so it is only practical for small registers.
        self.use_gate_circuit = bool(use_gate_circuit)

    def run(self) -> QAAEResult:
        n = self.num_qubits
        H = dense_hamiltonian_matrix(self.qop, n)
        d = H.shape[0]
        psi = _resolve_reference(self.ref_state, n)

        # Spectral bounds without diagonalizing H: all eigenvalues lie in [c0 - R, c0 + R].
        c0, R, _ = _spectral_window(self.qop)
        if R < 1e-12:
            # H is (almost) a constant — the reference is already an eigenstate.
            e = float(np.real(np.vdot(psi, H @ psi)))
            return QAAEResult(energy=e, energy_history=[e], overlap_history=[1.0],
                              rounds=1, converged=True)
        c = c0 + R
        denom = 2.0 * R
        M = (c * np.eye(d, dtype=complex) - H) / denom
        # Guard the contraction property (rounding can nudge it a hair over 1).
        sn = spectral_norm(M)
        if sn > 1.0:
            M = M / sn

        # The filter step M|psi> as the good branch of its dilation: a dense matmul, or — on the gate
        # path — the exact Sz.-Nagy dilation unitary compiled to gates (+1 ancilla) and post-selected.
        if self.use_gate_circuit:
            from ..open_system.dilation import sz_nagy_dilation
            from ..circuit.synthesis import synthesize_unitary
            from .expectation import apply_gates_to_state

            n_dil = n + 1
            dil_gates = synthesize_unitary(sz_nagy_dilation(M), list(range(n_dil)))

            def apply_filter(state: np.ndarray) -> np.ndarray:
                big = np.zeros(2 * d, dtype=complex)
                big[:d] = state                          # ancilla |0> (x) state
                apply_gates_to_state(dil_gates, big, n_dil)
                return big[:d]                           # post-select ancilla |0>
        else:
            def apply_filter(state: np.ndarray) -> np.ndarray:
                return apply_nonunitary(M, state)

        energy_history: list[float] = []
        overlap_history: list[float] = []
        e_prev = float(np.real(np.vdot(psi, H @ psi)))
        energy_history.append(e_prev)
        overlap_history.append(1.0)
        converged = False
        used = 0
        for _ in range(self.rounds):
            used += 1
            out = apply_filter(psi)                  # good branch of the dilation = M psi
            amp = float(np.linalg.norm(out))
            if amp < 1e-14:
                break
            psi = out / amp
            e = float(np.real(np.vdot(psi, H @ psi)))
            energy_history.append(e)
            overlap_history.append(amp * amp)
            if abs(e - e_prev) < self.tol:
                converged = True
                e_prev = e
                break
            e_prev = e

        return QAAEResult(
            energy=e_prev,
            energy_history=energy_history,
            overlap_history=overlap_history,
            rounds=used,
            converged=converged,
        )
