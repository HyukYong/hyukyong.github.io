"""Quantum Phase Estimation as a REAL universal-gate circuit (QFT + controlled-e^{-iHt} powers).

The canonical gate algorithm: an n-ancilla phase register, Hadamarded, drives controlled powers of
the time-evolution U = e^{-iHt} on the system, and an inverse QFT writes the eigenphase into the
ancilla register in binary.  The existing `QPE` solver builds U as a DENSE matrix exponential (a
simulator object); this builds the SAME algorithm as a `ParameterizedCircuit` of {H, RX, RZ, CNOT}
gates — Trotterized controlled-U via `hadamard_test._controlled_time_evolution`, plus a gate inverse
QFT — so it is exportable to real hardware via `to_qiskit_circuit`.

Conventions match the dense `QPE` so the phase→energy readout is shared: ancilla qubit 0 is the MSB
of the phase register, ancilla k drives U^(2^(n_anc-1-k)), the identity term is removed before QPE
and added back as a constant shift (it would only alias the phase), and the evolution time is the
0.9*pi/one_norm anti-aliasing heuristic.  Approximate (Trotter error + finite phase resolution
2^-n_anc); the dense path stays the exact default.
"""

from __future__ import annotations

import math

import numpy as np
from openfermion import QubitOperator

from ..circuit.circuit import ParameterizedCircuit
from ..circuit.gates import Gate, H, RZ, CNOT
from .hadamard_test import _controlled_time_evolution, _prepare_reference


def _cphase(circuit: ParameterizedCircuit, control: int, target: int, theta: float) -> None:
    """Controlled-phase diag(1, 1, 1, e^{i theta}) on (control, target), from RZ + CNOT.

    Symmetric decomposition: P(theta/2) on each qubit and a -theta/2 conjugated by CNOTs. Built from
    RZ (= P up to a global phase, irrelevant inside the QFT)."""
    circuit.append(RZ(control, angle=theta / 2.0))
    circuit.append(RZ(target, angle=theta / 2.0))
    circuit.append(CNOT(control, target))
    circuit.append(RZ(target, angle=-theta / 2.0))
    circuit.append(CNOT(control, target))


def _inverse_qft(circuit: ParameterizedCircuit, qubits: list[int]) -> None:
    """Inverse QFT on `qubits` (qubits[0] = MSB), as gates. Includes the bit-reversal swaps so the
    register holds the phase integer in standard binary (matching the dense QPE's IQFT matrix)."""
    n = len(qubits)
    # Undo the QFT's trailing bit-reversal swaps first (SWAP = three CNOTs).
    for i in range(n // 2):
        a, b = qubits[i], qubits[n - 1 - i]
        circuit.append(CNOT(a, b))
        circuit.append(CNOT(b, a))
        circuit.append(CNOT(a, b))
    # Inverse of the H + controlled-phase ladder, in reverse order with negated angles.
    for j in range(n - 1, -1, -1):
        for k in range(n - 1, j, -1):
            angle = -2.0 * math.pi / (2.0 ** (k - j + 1))
            _cphase(circuit, qubits[k], qubits[j], angle)
        circuit.append(H(qubits[j]))


def _strip_identity(qop: QubitOperator) -> tuple[QubitOperator, float]:
    """Return (qop without its identity term, identity coefficient) — the QPE phase-aliasing shift."""
    shift = 0.0
    key = ()
    if key in qop.terms:
        shift = float(np.real(qop.terms[key]))
        qop = qop - QubitOperator((), shift)
    return qop, shift


def qpe_circuit(
    qop_no_identity: QubitOperator,
    ref_bits: np.ndarray,
    n_ancilla: int,
    t0: float,
    num_trotter_steps: int = 1,
) -> ParameterizedCircuit:
    """The full QPE gate circuit: ancillas 0..n_ancilla-1 (qubit 0 = MSB) over the system register.

    `qop_no_identity` must have its identity term removed (see `_strip_identity`); `t0` is the base
    evolution time. Controlled-U^(2^(n_anc-1-k)) is built — like the dense QPE — by REPEATING the
    single base step U(t0) = Trotter(e^{-iHt0}, num_trotter_steps) `2^(n_anc-1-k)` times (controlled
    by ancilla k), so the gate count is bounded (sum of powers = 2^n_anc - 1 base evolutions) instead
    of exploding with a per-power re-Trotterization.
    """
    n_sys = len(ref_bits)
    circuit = ParameterizedCircuit(n_ancilla + n_sys)
    _prepare_reference(circuit, ref_bits, offset=n_ancilla)
    for a in range(n_ancilla):
        circuit.append(H(a))
    for k in range(n_ancilla):
        power = 2 ** (n_ancilla - 1 - k)
        for _ in range(power):
            _controlled_time_evolution(circuit, k, qop_no_identity, t0, num_trotter_steps,
                                       offset=n_ancilla)
    _inverse_qft(circuit, list(range(n_ancilla)))
    return circuit


def qpe_gate_estimate(
    qop: QubitOperator,
    ref_bits: np.ndarray,
    n_ancilla: int = 6,
    evolution_time: float | None = None,
    num_trotter_steps: int = 1,
) -> dict:
    """Estimate the ground-state energy of `qop` with the QPE GATE CIRCUIT (HF reference `ref_bits`).

    Returns {energy, phase, num_ancilla, evolution_time, phase_probabilities}. The phase→energy
    mapping matches the dense `QPE` (E = -2*pi*phase/t + identity_shift, phase wrapped to (-0.5, 0.5]),
    and `num_trotter_steps` mirrors the dense QPE's per-base-step Trotterization.
    """
    from .expectation import statevector_simulate

    ref_bits = np.asarray(ref_bits).astype(int)
    n_sys = len(ref_bits)
    qop_ni, shift = _strip_identity(qop)

    # Anti-aliasing evolution time = 0.9*pi / (non-identity 1-norm), same as the dense QPE.
    if evolution_time is None:
        one_norm = sum(abs(c) for term, c in qop_ni.terms.items() if term)
        t0 = 0.9 * math.pi / one_norm if one_norm > 1e-12 else 1.0
    else:
        t0 = float(evolution_time)

    circuit = qpe_circuit(qop_ni, ref_bits, n_ancilla, t0, num_trotter_steps)
    state = statevector_simulate(circuit)

    # Ancilla register marginal (ancilla = the high n_ancilla qubits; qubit 0 = MSB).
    probs = (np.abs(state) ** 2).reshape(2 ** n_ancilla, 2 ** n_sys).sum(axis=1)
    best = int(np.argmax(probs))
    phase = best / (2 ** n_ancilla)
    wrapped = phase - 1.0 if phase > 0.5 else phase
    energy = -2.0 * math.pi * wrapped / t0 + shift
    phase_probs = {i: float(p) for i, p in enumerate(probs) if p > 1e-10}
    return {
        "energy": float(energy),
        "phase": float(phase),
        "num_ancilla": int(n_ancilla),
        "evolution_time": float(t0),
        "phase_probabilities": phase_probs,
    }
