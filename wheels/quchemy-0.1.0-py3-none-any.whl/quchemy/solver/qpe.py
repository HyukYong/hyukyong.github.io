"""Quantum Phase Estimation (QPE) solver for molecular Hamiltonians."""

from __future__ import annotations

import math
from dataclasses import dataclass, field
from typing import Callable

import numpy as np
from openfermion import QubitOperator


@dataclass
class QPEResult:
    """Results from a QPE computation.

    Attributes
    ----------
    energy : float
        Ground state energy estimate (Hartree).
    phase : float
        Raw phase in [0, 1).
    eigenvalue : complex
        exp(2*pi*i*phase).
    phase_probabilities : dict[int, float]
        Mapping from ancilla state (int) to probability.
    num_ancilla : int
        Number of ancilla qubits used.
    num_system : int
        Number of system qubits.
    num_trotter_steps : int
        Number of Trotter steps per controlled-U.
    evolution_time : float
        Evolution time parameter t.
    circuit_depth : int
        Approximate depth of the QPE circuit.
    total_qubits : int
        Total qubit count (ancilla + system).
    """

    energy: float
    phase: float
    eigenvalue: complex
    phase_probabilities: dict[int, float] = field(default_factory=dict)
    num_ancilla: int = 0
    num_system: int = 0
    num_trotter_steps: int = 0
    evolution_time: float = 0.0
    circuit_depth: int = 0
    total_qubits: int = 0


class QPE:
    """Quantum Phase Estimation for molecular Hamiltonians.

    Estimates eigenvalues of U = exp(-i*H*t) by encoding the phase into
    ancilla qubits via controlled-U operations and inverse QFT.

    Uses direct statevector manipulation for efficiency: the Trotterized
    unitary is computed as a matrix once, then applied as controlled
    operations via tensor reshaping.

    Parameters
    ----------
    qubit_hamiltonian : QubitOperator
        The qubit Hamiltonian (e.g., from Jordan-Wigner mapping).
    num_ancilla : int
        Number of ancilla qubits for phase precision.
    num_trotter_steps : int
        Number of Trotter steps for the base evolution exp(-i*H*t).
    evolution_time : float or None
        Evolution time t. Auto-estimated from Hamiltonian if None.
    initial_state : ndarray or None
        Binary array for system initial state (1 = occupied).
        If None, uses |00...0>.
    callback : callable or None
        Called with (step_name, info_dict) for progress reporting.
    """

    def __init__(
        self,
        qubit_hamiltonian: QubitOperator,
        num_ancilla: int = 6,
        num_trotter_steps: int = 1,
        evolution_time: float | None = None,
        initial_state: np.ndarray | None = None,
        callback: Callable | None = None,
    ):
        # Extract identity (constant) term to avoid phase aliasing.
        # QPE resolves phases in [0,1); a large constant shifts all
        # eigenvalues and causes wrapping.  We subtract it before QPE
        # and add it back to the final energy.
        self.identity_shift = 0.0
        identity_key = ()  # empty tuple = identity in OpenFermion
        if identity_key in qubit_hamiltonian.terms:
            self.identity_shift = qubit_hamiltonian.terms[identity_key].real
            self.hamiltonian = qubit_hamiltonian - QubitOperator((), self.identity_shift)
        else:
            self.hamiltonian = qubit_hamiltonian

        self.num_ancilla = num_ancilla
        self.num_trotter_steps = num_trotter_steps
        self.initial_state = initial_state
        self.callback = callback

        # Determine number of system qubits from Hamiltonian
        self.num_system = _count_qubits(qubit_hamiltonian)
        self.total_qubits = num_ancilla + self.num_system

        # Auto-estimate evolution time if not provided
        if evolution_time is None:
            self.evolution_time = self._estimate_evolution_time()
        else:
            self.evolution_time = evolution_time

    def _estimate_evolution_time(self) -> float:
        """Estimate evolution time to avoid phase aliasing.

        Uses t = 0.9*pi / sum(|c_j|) where the sum is over all
        non-identity Hamiltonian term coefficients (1-norm spectral bound).
        """
        one_norm = 0.0
        for term, coeff in self.hamiltonian.terms.items():
            if term:  # Skip identity
                one_norm += abs(coeff)
        if one_norm < 1e-12:
            return 1.0
        return 0.9 * math.pi / one_norm

    def run(self) -> QPEResult:
        """Run the QPE algorithm.

        Returns
        -------
        QPEResult
            The QPE results including estimated energy.
        """
        n_anc = self.num_ancilla
        n_sys = self.num_system
        N_anc = 2 ** n_anc
        N_sys = 2 ** n_sys
        N_total = N_anc * N_sys

        if self.callback:
            self.callback("building_circuit", {
                "num_ancilla": n_anc,
                "num_system": n_sys,
                "evolution_time": self.evolution_time,
            })

        # 1. Prepare initial statevector: |0...0>_anc |init>_sys
        state = np.zeros(N_total, dtype=complex)
        if self.initial_state is not None:
            # Build system initial state index from binary array
            sys_idx = 0
            for i, bit in enumerate(self.initial_state):
                if bit:
                    sys_idx |= (1 << (n_sys - 1 - i))
            state[sys_idx] = 1.0
        else:
            state[0] = 1.0

        # 2. Hadamard on all ancilla qubits
        #    Transforms |0...0>_anc to uniform superposition (1/sqrt(N_anc)) sum|a>
        state = state.reshape(N_anc, N_sys)
        h_vec = np.ones(N_anc, dtype=complex) / math.sqrt(N_anc)
        # state[a, s] = h_vec[a] * init_sys[s]
        state = np.outer(h_vec, state[0])
        state = state.reshape(-1)

        # 3. Build Trotterized unitary as a matrix and apply controlled-U^power
        if self.callback:
            self.callback("building_unitary", {"num_trotter_steps": self.num_trotter_steps})

        U_trotter = self._build_trotter_unitary()

        # Estimate circuit depth: each Trotter step has ~6 gates per H term
        num_terms = sum(1 for t in self.hamiltonian.terms if t)
        gates_per_step = num_terms * 6
        total_steps = sum(
            self.num_trotter_steps * 2 ** (n_anc - 1 - k)
            for k in range(n_anc)
        )
        approx_depth = total_steps * gates_per_step

        # Apply controlled-U^{2^{n-1-k}} for each ancilla qubit k
        # Qubit 0 is MSB, so qubit k controls U^{2^{n-1-k}}
        for k in range(n_anc):
            if self.callback:
                self.callback("controlled_unitary", {"ancilla": k, "of": n_anc})
            power = 2 ** (n_anc - 1 - k)
            U_power = np.linalg.matrix_power(U_trotter, power)
            state = self._apply_controlled_unitary(state, k, U_power)

        if self.callback:
            self.callback("inverse_qft", {})

        # 4. Apply inverse QFT on ancilla register
        state = self._apply_inverse_qft(state)

        # 5. Extract phase from ancilla probabilities
        phase, phase_probs = self._extract_phase(state)
        energy = self._phase_to_energy(phase) + self.identity_shift

        if self.callback:
            self.callback("done", {"energy": energy, "phase": phase})

        return QPEResult(
            energy=energy,
            phase=phase,
            eigenvalue=np.exp(2j * math.pi * phase),
            phase_probabilities=phase_probs,
            num_ancilla=n_anc,
            num_system=n_sys,
            num_trotter_steps=self.num_trotter_steps,
            evolution_time=self.evolution_time,
            circuit_depth=approx_depth,
            total_qubits=self.total_qubits,
        )

    def _build_trotter_unitary(self) -> np.ndarray:
        """Build the Trotterized time-evolution unitary exp(-i*H*t).

        Applies first-order Trotter decomposition:
          exp(-i*H*t) ≈ [prod_j exp(-i*c_j*P_j*dt)]^num_steps
        where dt = t / num_steps.

        Returns
        -------
        ndarray
            N_sys x N_sys unitary matrix.
        """
        from scipy.linalg import expm
        from openfermion import get_sparse_operator

        n_sys = self.num_system
        N_sys = 2 ** n_sys
        dt = self.evolution_time / self.num_trotter_steps

        # Build each term's unitary and accumulate
        U_step = np.eye(N_sys, dtype=complex)
        for term, coeff in self.hamiltonian.terms.items():
            c = coeff.real
            if abs(c) < 1e-15:
                continue
            if not term:
                # Identity: global phase
                U_step *= np.exp(-1j * c * dt)
            else:
                P_mat = get_sparse_operator(
                    QubitOperator(term, 1.0), n_qubits=n_sys
                ).toarray()
                U_step = expm(-1j * c * dt * P_mat) @ U_step

        # Repeat for num_trotter_steps
        if self.num_trotter_steps == 1:
            return U_step
        return np.linalg.matrix_power(U_step, self.num_trotter_steps)

    def _apply_controlled_unitary(
        self, state: np.ndarray, control_qubit: int, U: np.ndarray
    ) -> np.ndarray:
        """Apply controlled-U where control is an ancilla qubit.

        When control_qubit is |1>, apply U to the system register.
        When control_qubit is |0>, do nothing.

        The statevector has layout: ancilla qubits (MSB) then system qubits (LSB).
        """
        n_anc = self.num_ancilla
        n_sys = self.num_system
        N_sys = 2 ** n_sys

        # Reshape state into per-ancilla-state blocks
        # state[ancilla_state * N_sys + sys_state]
        state_2d = state.reshape(2 ** n_anc, N_sys)

        # For each ancilla basis state where control_qubit = 1, apply U
        for a in range(2 ** n_anc):
            # Check if control_qubit bit is set (MSB ordering: bit position n_anc-1-k)
            bit_pos = n_anc - 1 - control_qubit
            if (a >> bit_pos) & 1:
                state_2d[a] = U @ state_2d[a]

        return state_2d.reshape(-1)

    def _apply_inverse_qft(self, statevector: np.ndarray) -> np.ndarray:
        """Apply inverse QFT to the ancilla register of the statevector.

        Uses direct matrix multiplication on the ancilla subspace.
        IQFT[j,k] = (1/sqrt(N)) * exp(-2*pi*i*j*k/N)
        """
        n_anc = self.num_ancilla
        n_sys = self.num_system
        N_anc = 2 ** n_anc

        # Build IQFT matrix efficiently using outer product
        js = np.arange(N_anc)
        iqft = np.exp(-2j * math.pi * np.outer(js, js) / N_anc) / math.sqrt(N_anc)

        # Apply to ancilla dimension
        state_2d = statevector.reshape(N_anc, 2 ** n_sys)
        state_2d = iqft @ state_2d
        return state_2d.reshape(-1)

    def _extract_phase(
        self, statevector: np.ndarray
    ) -> tuple[float, dict[int, float]]:
        """Extract phase from the statevector by measuring ancilla probabilities."""
        probs = np.abs(statevector) ** 2
        n_anc = self.num_ancilla
        n_sys = self.num_system

        prob_matrix = probs.reshape(2**n_anc, 2**n_sys)
        ancilla_probs = prob_matrix.sum(axis=1)

        phase_probs = {}
        for state_int in range(2**n_anc):
            if ancilla_probs[state_int] > 1e-10:
                phase_probs[state_int] = float(ancilla_probs[state_int])

        best_state = int(np.argmax(ancilla_probs))
        phase = best_state / (2**n_anc)

        return phase, phase_probs

    def _phase_to_energy(self, phase: float) -> float:
        """Convert measured phase to energy.

        U = exp(-i*H*t) has eigenvalue exp(-i*E*t) = exp(2*pi*i*phase),
        so E = -2*pi*phase / t.

        For negative energies (typical in chemistry), the phase wraps:
        if phase > 0.5, the actual phase is phase - 1.
        """
        if phase > 0.5:
            phase = phase - 1.0
        return -2.0 * math.pi * phase / self.evolution_time


def _count_qubits(qubit_op: QubitOperator) -> int:
    """Determine the number of qubits needed for a QubitOperator."""
    max_qubit = -1
    for term in qubit_op.terms:
        for qubit, _ in term:
            if qubit > max_qubit:
                max_qubit = qubit
    return max_qubit + 1 if max_qubit >= 0 else 0
