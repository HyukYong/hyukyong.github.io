"""Variational Quantum Deflation (VQD) for excited states."""

from __future__ import annotations

from dataclasses import dataclass, field
from typing import Optional, Callable

import numpy as np
from scipy.optimize import minimize
from openfermion import QubitOperator

from ..circuit.circuit import ParameterizedCircuit
from .expectation import statevector_simulate, compute_expectation


@dataclass
class VQDResult:
    """Results from a VQD optimization."""

    energies: list[float]
    parameters: list[np.ndarray]
    states: list[np.ndarray]
    num_iterations: list[int]


class VQD:
    """Variational Quantum Deflation for excited states.

    Finds k lowest eigenstates by sequential VQE optimizations,
    adding an overlap penalty to push away from previously found states.

    Parameters
    ----------
    ansatz : ParameterizedCircuit
        The variational ansatz.
    qubit_hamiltonian : QubitOperator
        The qubit Hamiltonian.
    k : int
        Number of states to find.
    beta : float
        Overlap penalty weight.
    optimizer : str
        SciPy optimizer name. L-BFGS-B is recommended (gradient-based, fast
        convergence). COBYLA works but is ~50x slower and less accurate.
    max_iterations : int
        Max iterations per state.
    callback : callable, optional
        Called with (state_index, iteration, energy).
    """

    def __init__(
        self,
        ansatz: ParameterizedCircuit,
        qubit_hamiltonian: QubitOperator,
        k: int = 3,
        beta: float = 10.0,
        optimizer: str = "L-BFGS-B",
        max_iterations: int = 500,
        callback: Optional[Callable] = None,
    ):
        self.ansatz = ansatz
        self.hamiltonian = qubit_hamiltonian
        self.k = k
        self.beta = beta
        self.optimizer = optimizer
        self.max_iterations = max_iterations
        self.callback = callback

    def run(self) -> VQDResult:
        """Run VQD for k states.

        Returns
        -------
        VQDResult
            Contains energies, parameters, and states for each eigenstate.
        """
        n_params = self.ansatz.num_parameters
        found_states: list[np.ndarray] = []
        energies: list[float] = []
        all_params: list[np.ndarray] = []
        all_iterations: list[int] = []

        for state_idx in range(self.k):
            iteration_count = [0]
            prev_states = list(found_states)  # snapshot

            def cost_fn(params):
                state = statevector_simulate(self.ansatz, params)
                energy = compute_expectation(self.hamiltonian, state)

                # Overlap penalty
                penalty = 0.0
                for prev in prev_states:
                    overlap = abs(np.vdot(prev, state)) ** 2
                    penalty += self.beta * overlap

                return energy + penalty

            def scipy_callback(params):
                iteration_count[0] += 1
                if self.callback:
                    state = statevector_simulate(self.ansatz, params)
                    energy = compute_expectation(self.hamiltonian, state)
                    self.callback(state_idx, iteration_count[0], energy)

            x0 = np.random.uniform(-0.1, 0.1, n_params)

            result = minimize(
                cost_fn,
                x0,
                method=self.optimizer,
                options={"maxiter": self.max_iterations},
                callback=scipy_callback,
            )

            opt_state = statevector_simulate(self.ansatz, result.x)
            energy = compute_expectation(self.hamiltonian, opt_state)

            found_states.append(opt_state)
            energies.append(energy)
            all_params.append(result.x)
            all_iterations.append(iteration_count[0])

        return VQDResult(
            energies=energies,
            parameters=all_params,
            states=found_states,
            num_iterations=all_iterations,
        )
