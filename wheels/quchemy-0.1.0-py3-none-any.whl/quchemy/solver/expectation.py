"""Statevector simulation and Pauli expectation value computation."""

from __future__ import annotations

import numpy as np
from openfermion import QubitOperator

from ..circuit.circuit import ParameterizedCircuit
from ..circuit.gates import Gate


def statevector_simulate(
    circuit: ParameterizedCircuit, parameters: np.ndarray | None = None
) -> np.ndarray:
    """Simulate a circuit and return the statevector.

    Uses efficient single-gate application via tensor reshaping rather than
    building the full 2^n x 2^n unitary.

    Parameters
    ----------
    circuit : ParameterizedCircuit
        The circuit to simulate.
    parameters : ndarray, optional
        Parameter values for parameterized gates.

    Returns
    -------
    ndarray
        Complex statevector of length 2^n.
    """
    n = circuit.num_qubits
    state = np.zeros(2**n, dtype=complex)
    state[0] = 1.0  # |00...0>

    for gate in circuit.gates:
        if gate.param_index is not None and gate.parameter is None:
            if parameters is None:
                raise ValueError("Parameters required for parameterized circuit")
            param_val = parameters[gate.param_index]
        else:
            param_val = gate.parameter

        mat = gate.matrix(param_val)

        if gate.num_qubits == 1:
            _apply_single_qubit_gate(state, mat, gate.qubits[0], n)
        elif gate.num_qubits == 2:
            _apply_two_qubit_gate(state, mat, gate.qubits[0], gate.qubits[1], n)
        else:
            raise ValueError(f"Gates on {gate.num_qubits} qubits not supported")

    return state


def _apply_single_qubit_gate(
    state: np.ndarray, mat: np.ndarray, qubit: int, num_qubits: int
) -> None:
    """Apply a single-qubit gate in-place via tensor reshaping.

    Qubit ordering: qubit 0 is the most significant bit.
    State index bit layout: |q0 q1 ... q_{n-1}>
    """
    # Reshape to (2^qubit, 2, 2^(n-qubit-1))
    shape = (2**qubit, 2, 2 ** (num_qubits - qubit - 1))
    state_reshaped = state.reshape(shape)
    # Apply 2x2 matrix on axis 1
    out = np.einsum("ij,ajb->aib", mat, state_reshaped)
    state[:] = out.reshape(-1)


def _apply_two_qubit_gate(
    state: np.ndarray,
    mat: np.ndarray,
    q0: int,
    q1: int,
    num_qubits: int,
) -> None:
    """Apply a two-qubit gate in-place.

    Uses the full state reshape approach for arbitrary qubit pairs.
    q0, q1 are the gate's qubit indices (e.g., control, target for CNOT).
    """
    n = num_qubits
    # Reshape state into n-index tensor, each index has dimension 2
    tensor = state.reshape([2] * n)

    # Apply the 4x4 matrix reshaped as (2,2,2,2) to axes (q0, q1)
    mat4 = mat.reshape(2, 2, 2, 2)

    # Contract: result[...,i,...,j,...] = sum_{k,l} mat4[i,j,k,l] * tensor[...,k,...,l,...]
    # Use tensordot on axes (q0, q1)
    # Move q0 and q1 to the last two axes
    axes_order = [i for i in range(n) if i != q0 and i != q1] + [q0, q1]
    tensor = tensor.transpose(axes_order)

    # Reshape to (2^(n-2), 4)
    flat = tensor.reshape(-1, 4)
    flat = (mat @ flat.T).T  # (2^(n-2), 4)

    # Reshape back and undo transpose
    tensor = flat.reshape([2] * (n - 2) + [2, 2])
    inv_order = [0] * n
    for new_pos, old_pos in enumerate(axes_order):
        inv_order[old_pos] = new_pos
    tensor = tensor.transpose(inv_order)

    state[:] = tensor.reshape(-1)


def apply_gates_to_state(gates: list, state: np.ndarray, num_qubits: int) -> np.ndarray:
    """Apply a list of Gates to `state` IN PLACE (and return it).

    Like `statevector_simulate` but acting on an arbitrary input state instead of |0...0> — the
    gate-level analog of a matrix `expm_multiply` (used by the gate-circuit CQE to evolve the state
    through Trotterized exp(-eps A) layers). Only concrete (bound) gates are accepted.
    """
    for gate in gates:
        mat = gate.matrix(gate.parameter)
        if gate.num_qubits == 1:
            _apply_single_qubit_gate(state, mat, gate.qubits[0], num_qubits)
        elif gate.num_qubits == 2:
            _apply_two_qubit_gate(state, mat, gate.qubits[0], gate.qubits[1], num_qubits)
        else:
            raise ValueError(f"Gates on {gate.num_qubits} qubits not supported")
    return state


def compute_expectation(qubit_op: QubitOperator, state: np.ndarray) -> float:
    """Compute <state|qubit_op|state> for a QubitOperator.

    Parameters
    ----------
    qubit_op : QubitOperator
        OpenFermion QubitOperator (sum of weighted Pauli strings).
    state : ndarray
        Complex statevector.

    Returns
    -------
    float
        Real part of the expectation value.
    """
    n = int(np.log2(len(state)))
    result = 0.0

    for term, coeff in qubit_op.terms.items():
        if not term:
            # Identity term
            result += coeff.real * np.vdot(state, state).real
            continue

        # Apply Pauli string to state
        psi = state.copy()
        phase = 1.0 + 0j
        for qubit, pauli in term:
            if pauli == "X":
                _apply_pauli_x(psi, qubit, n)
            elif pauli == "Y":
                _apply_pauli_x(psi, qubit, n)
                _apply_pauli_z(psi, qubit, n)
                phase *= 1j
            elif pauli == "Z":
                _apply_pauli_z(psi, qubit, n)

        result += coeff.real * (phase * np.vdot(state, psi)).real

    return result


def _apply_pauli_x(state: np.ndarray, qubit: int, num_qubits: int) -> None:
    """Apply Pauli X (bit-flip) on a qubit in-place."""
    shape = (2**qubit, 2, 2 ** (num_qubits - qubit - 1))
    s = state.reshape(shape)
    s[:, 0, :], s[:, 1, :] = s[:, 1, :].copy(), s[:, 0, :].copy()


def _apply_pauli_z(state: np.ndarray, qubit: int, num_qubits: int) -> None:
    """Apply Pauli Z (phase-flip) on a qubit in-place."""
    shape = (2**qubit, 2, 2 ** (num_qubits - qubit - 1))
    s = state.reshape(shape)
    s[:, 1, :] *= -1


def compute_energy(
    circuit: ParameterizedCircuit,
    parameters: np.ndarray,
    qubit_op: QubitOperator,
) -> float:
    """Convenience: simulate circuit and compute expectation value."""
    state = statevector_simulate(circuit, parameters)
    return compute_expectation(qubit_op, state)
