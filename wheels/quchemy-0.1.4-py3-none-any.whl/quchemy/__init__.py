"""quchemy — Quantum chemistry library for the Quchemy application.

Uses OpenFermion for operator algebra and PySCF for molecular integrals.
Provides custom circuit IR, ansatz generators, VQE/VQD solvers,
statevector simulation, Qiskit circuit export, and Analyzer-compatible output.
"""

__version__ = "0.1.4"

# Circuit
from .circuit import (
    ParameterizedCircuit,
    Gate,
    H, X, Y, Z, S, T,
    RX, RY, RZ,
    CNOT, CZ, SWAP,
)

# Integral bridge
from .integral import (
    get_molecular_hamiltonian,
    map_to_qubits,
    get_num_qubits,
    get_hf_state,
)

# Ansatz
from .ansatz import (
    make_uccsd_ansatz,
    get_uccsd_num_parameters,
    make_hf_state_circuit,
    make_hardware_efficient_ansatz,
    AdaptVQE,
    build_uccsd_pool,
    build_generalized_pool,
)

# Solver
from .solver import (
    statevector_simulate,
    compute_expectation,
    compute_energy,
    VQE,
    VQEResult,
    VQD,
    VQDResult,
    QPE,
    QPEResult,
    QCELS,
    RobustPE,
    QMEGS,
    BPE,
    BayesianPEResult,
    BPDE,
    BPDEResult,
    grover_rudolph_angles,
    grover_rudolph_statevector,
    qrom_superposition,
    SignalPEResult,
    hamiltonian_signal,
    QuantumKrylov,
    KrylovResult,
    CQE,
    CQEResult,
    QAAE,
    QAAEResult,
    hadamard_test_signal,
    hadamard_test_signal_prep,
    hadamard_test_circuit,
    qpe_gate_estimate,
    qpe_circuit,
)

# Open quantum systems (dissipative dynamics, channels, dilation, dissipative VQE)
from .open_system import (
    liouvillian,
    propagate,
    steady_state,
    sz_nagy_dilation,
    apply_nonunitary,
    apply_kraus,
    superop_to_kraus,
    amplitude_damping_kraus,
    dissipative_vqe,
    DVQEResult,
)

# Measurement
from .measurement import group_commuting_terms, qubitwise_commute

# Export
from .export import to_qiskit_circuit

# I/O
from .io import (
    print_methodology,
    print_circuit_info,
    print_energies,
    print_mo_energies,
    print_mulliken_charges,
)

__all__ = [
    # Version
    "__version__",
    # Circuit
    "ParameterizedCircuit", "Gate",
    "H", "X", "Y", "Z", "S", "T",
    "RX", "RY", "RZ", "CNOT", "CZ", "SWAP",
    # Integral
    "get_molecular_hamiltonian", "map_to_qubits",
    "get_num_qubits", "get_hf_state",
    # Ansatz
    "make_uccsd_ansatz", "get_uccsd_num_parameters", "make_hf_state_circuit",
    "make_hardware_efficient_ansatz",
    "AdaptVQE", "build_uccsd_pool", "build_generalized_pool",
    # Solver
    "statevector_simulate", "compute_expectation", "compute_energy",
    "VQE", "VQEResult", "VQD", "VQDResult", "QPE", "QPEResult",
    "QCELS", "RobustPE", "QMEGS", "BPE", "BayesianPEResult",
    "BPDE", "BPDEResult", "grover_rudolph_angles", "grover_rudolph_statevector",
    "qrom_superposition", "SignalPEResult", "hamiltonian_signal",
    "QuantumKrylov", "KrylovResult", "CQE", "CQEResult", "QAAE", "QAAEResult",
    "hadamard_test_signal", "hadamard_test_signal_prep", "hadamard_test_circuit",
    "qpe_gate_estimate", "qpe_circuit",
    # Open quantum systems
    "liouvillian", "propagate", "steady_state", "sz_nagy_dilation",
    "apply_nonunitary", "apply_kraus", "superop_to_kraus",
    "amplitude_damping_kraus", "dissipative_vqe", "DVQEResult",
    # Measurement
    "group_commuting_terms", "qubitwise_commute",
    # Export
    "to_qiskit_circuit",
    # I/O
    "print_methodology", "print_circuit_info", "print_energies",
    "print_mo_energies", "print_mulliken_charges",
]
