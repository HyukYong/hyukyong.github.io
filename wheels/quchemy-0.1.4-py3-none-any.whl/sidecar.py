#!/usr/bin/env python3
"""Qemica Python sidecar entrypoint (overhaul §6, §13.4, §15.4).

Usage:
    python sidecar.py <request.json>

The request envelope (JSON file) is:
    {
      "action": "capabilities" | "energy" | "vqe" | "qpe" | "signal_pe" | "krylov" | "vibrational_vqe" | "ibmq" | "parse" | "parse_trajectory",
      "spec":     <JobSpec.to_dict()>,
      "molecule": {"atoms":[{"element","x","y","z"},...],"charge":int,"multiplicity":int},
      "output_path": "<abs path to write result.json>",
      "parse_path": "<for action=parse: external-engine output; parse_trajectory: .xyz>"
    }

The sidecar writes a `JobResult` JSON (overhaul §3 schema) to request["output_path"]
and prints one status line to stdout: "OK <output_path>" on success, "ERR <message>"
on failure. Scientific data is NEVER scraped from stdout (overhaul §3) — only this
single status line is printed.

This file's directory is placed on sys.path so `import quchemy` works when run
directly. Everything is wrapped in try/except: a failure still writes a result with
success=false and an error message, so the Godot side always has a file to read.
"""

from __future__ import annotations

import json
import os
import platform
import sys
import time
import traceback
from typing import Any

# Ensure the package next to this script is importable when run directly.
_HERE = os.path.dirname(os.path.abspath(__file__))
if _HERE not in sys.path:
    sys.path.insert(0, _HERE)

from quchemy.sidecar import result_builder as rb  # noqa: E402


# ─────────────────────────── live progress telemetry (§13.4) ───────────────────────────
#
# Structured single-line records on STDOUT, prefixed "QPROG ", one JSON object per
# line, flushed immediately: SCF cycles, geometry-opt steps, MD steps, and coarse
# phase markers for the long non-streamable stretches (Hessian, TDDFT, cubes, …).
# This is EPHEMERAL display telemetry for the Run screen's live charts — it is NOT
# the result channel. Scientific results stay in result.json (overhaul §3: no stdout
# scraping for science); the Godot client must never feed these lines into JobResult.
#
# stdout is otherwise quiet by protocol: the only other line ever printed is main()'s
# final "OK <path>" / "ERR <msg>" status line, so the channel is collision-free.

_PROGRESS_PREFIX = "QPROG "

# While `_quiet()` redirects sys.stdout into a sink (to swallow geomeTRIC's chatty
# optimizer log), progress records must still reach the REAL stdout pipe — the
# redirect would silently eat the geomeTRIC step callbacks otherwise. `_quiet()`
# parks the pre-redirect stream here; emission prefers it when set.
_PROGRESS_OUT: Any = None

# Engine-log capture (§3-safe diagnostics): while a compute action runs, `run()` parks a
# StringIO here. When set, pyscf builds at verbose=5 (rich SCF detail) and `_quiet()` funnels
# into THIS buffer instead of a throwaway sink, so the human-readable engine log (pyscf SCF
# cycles + IBM/qiskit runtime logs + any prints) is captured verbatim. This is NOT the result
# channel — science still comes from the structured JobResult fields (no stdout scraping); the
# log is an opaque diagnostic blob persisted to a separate `engine_log_<id>.txt` file-of-record.
_ENGINE_LOG: Any = None


def _emit_progress(record: dict[str, Any]) -> None:
    """Print one telemetry record as a single flushed QPROG line. Never fatal —
    telemetry must not be able to kill a calculation (a closed pipe is ignored)."""
    try:
        out = _PROGRESS_OUT if _PROGRESS_OUT is not None else sys.stdout
        out.write(_PROGRESS_PREFIX + json.dumps(record, separators=(",", ":")) + "\n")
        out.flush()
    except Exception:
        pass


def _emit_phase(name: str) -> None:
    """Coarse phase marker for a long stretch with no per-step stream
    (e.g. {"t":"phase","name":"hessian"})."""
    _emit_progress({"t": "phase", "name": str(name)})


def _attach_scf_progress(mf):
    """Stream one {"t":"scf","cycle":n,"e":E} record per SCF cycle of THIS mean-field
    via pyscf's kernel callback (envs = kernel locals: `cycle` 0-based, `e_tot`).

    Attached ONLY to the main SCF of a job (`_build_mol(..., progress=True)`) —
    displaced-geometry rebuilds (MD steps, finite-difference intensities, PES points,
    gas-fallback Hessians) go through `_make_mf` and stay silent, so the live chart
    is never polluted by restarting cycle counts."""

    def _cb(envs: dict[str, Any]) -> None:
        cycle = envs.get("cycle")
        e_tot = envs.get("e_tot")
        if cycle is not None and e_tot is not None:
            _emit_progress({"t": "scf", "cycle": int(cycle) + 1, "e": float(e_tot)})

    mf.callback = _cb
    return mf


# Methods `_build_mol` itself can serve (it builds the MEAN-FIELD). The guard in
# `_build_mol` fails loud on anything else, so EVERY classical action (energy, TS, IRC,
# PES scan, es_opt) refuses to hand back Hartree-Fock numbers under another name.
# CASSCF and the post-HF set (`_POST_HF`) are genuinely handled only by `action_energy`,
# which strips a post-HF spec to HF for the reference build and then correlates it; the
# other actions reject CASSCF via `_reject_casscf` and post-HF via this guard.
_IMPLEMENTED_METHODS: frozenset[str] = frozenset({"HF", "DFT", "CASSCF"})

# Post-HF correlation methods, run by `action_energy` on top of a converged HF reference.
# MP2/CCSD have analytic PySCF gradients, so they also serve `optimize` (geomeTRIC drives
# the correlated scanner); CCSD(T)/FCI are single-point energy ONLY. No Hessian/MD/excited
# path is wired for any of them, so those calc types are refused loud (same policy as
# CASSCF). They are deliberately ABSENT from `_IMPLEMENTED_METHODS` so the `_build_mol`
# guard still fails loud when a mechanism action (TS/IRC/PES/es_opt) is handed one —
# those only ever build the mean-field.
_POST_HF: frozenset[str] = frozenset({"MP2", "CCSD", "CCSD(T)", "FCI"})
# The post-HF subset with analytic nuclear gradients wired (geometry optimization).
_POST_HF_OPTIMIZABLE: frozenset[str] = frozenset({"MP2", "CCSD"})
# FCI cost guard: the determinant space explodes combinatorially — refuse anything past
# these caps (≈ C(14,8)² ~ 9e6 determinants) instead of hanging/OOMing the sidecar.
_FCI_MAX_ORBITALS: int = 14
_FCI_MAX_ELECTRONS: int = 16
# Correlated methods whose response properties (NMR/polarizability/Fukui) would run on the
# HF reference rather than the correlated wavefunction — skipped with a warning, not faked.
_CORRELATED: frozenset[str] = _POST_HF | frozenset({"CASSCF"})


def _warn(result: dict[str, Any], message: str) -> None:
    """Append a non-fatal warning to the result (contract key `warnings`).

    The job still succeeds — this exists so a degraded feature (empty tab, gas-phase
    fallback, unconverged intermediate) is SAID out loud instead of hidden behind a
    blanket `except: pass`."""
    result.setdefault("warnings", []).append(str(message))


# ─────────────────────────── capability probe (§15.4) ───────────────────────────


def _probe(module_name: str) -> bool:
    """Return True if `module_name` is importable (capability detection)."""
    import importlib.util

    try:
        return importlib.util.find_spec(module_name) is not None
    except Exception:
        return False


def _smd_available() -> bool:
    """True only when SMD continuum solvation can actually run in THIS PySCF build.

    `from pyscf.solvent import smd` always imports — but the SMD kernel needs the
    compiled C extension `libsolvent` (cmake `-DENABLE_SMD=ON`), and `mf.SMD()`
    *constructs* fine even when that extension is absent: the RuntimeError only
    surfaces at `.kernel()` time. So importability (find_spec) is NOT a real check —
    we probe `smd.libsolvent is not None` directly, which is cheap (no kernel run)
    and the exact predicate that decides whether the SMD kernel will succeed. When
    False, the Method screen drops SMD from the solvent segment (§15.4) and
    `_apply_solvent` fails loud with an actionable message rather than the raw pyscf
    RuntimeError."""
    try:
        from pyscf.solvent import smd

        return smd.libsolvent is not None
    except Exception:
        return False


def detect_capabilities() -> dict[str, bool]:
    """Probe importability of every optional + required engine package."""
    return {
        "pyscf": _probe("pyscf"),
        "openfermion": _probe("openfermion"),
        "cclib": _probe("cclib"),
        "rdkit": _probe("rdkit"),
        "openbabel": _probe("openbabel"),
        "qiskit": _probe("qiskit"),
        # IBM Quantum cloud execution (Run-screen "IBM Quantum" backend) needs the runtime
        # client; absent → the ibmq action fails loud with an install hint (§13.4 / P4.1).
        "qiskit_ibm_runtime": _probe("qiskit_ibm_runtime"),
        # SQD (sample-based quantum diagonalization) needs qiskit-addon-sqd + ffsim; the
        # Method screen greys out the SQD card when this is False (fail-loud install hint).
        "sqd": _probe("qiskit_addon_sqd") and _probe("ffsim"),
        # geomeTRIC drives every geometry search (optimize/opt+freq/TS/IRC-start/es_opt);
        # the Method screen greys those calc types out when it is absent (§15.4).
        "geometric": _probe("geometric"),
        # SMD continuum solvation needs a compiled libsolvent — most builds lack it
        # (mf.SMD() constructs but its kernel raises). The Method screen drops SMD from
        # the solvent segment when this is False, so the user can't pick a dead option.
        "smd": _smd_available(),
        # DFT-D dispersion (D3/D3(BJ)/D4): needs a usable pyscf.dispersion backend. The
        # bundled pyscf-dispersion wheel is x86_64-only on Apple Silicon, so the arch shim
        # falls back to the arm64 standalone dftd3/dftd4 libraries — this reflects whether
        # the corrected import actually works.
        "dispersion": _dispersion_available(),
        # MACE ML interatomic potential (the "ML potential (MACE)" compute backend): a fast
        # DFT surrogate for energy/optimize/freq/MD via mace-torch + ASE (+ torch). The Method
        # screen greys the MACE card when this is False; the mace action fails loud with an
        # install hint otherwise.
        "mace": _probe("mace") and _probe("ase") and _probe("torch"),
    }


# ─────────────────────────── PySCF helpers ───────────────────────────


def _require_atoms(molecule: dict[str, Any]) -> list[dict[str, Any]]:
    """Validate the molecule envelope and return its atom list, failing LOUD with a clear
    message instead of a cryptic KeyError / pyscf crash when it is missing, empty, or
    malformed. Raised ValueErrors propagate to main(), which writes a clean error result."""
    if not isinstance(molecule, dict):
        raise ValueError("molecule must be an object with an 'atoms' list")
    atoms = molecule.get("atoms")
    if not isinstance(atoms, list) or len(atoms) == 0:
        raise ValueError("molecule has no atoms")
    for i, a in enumerate(atoms):
        if not isinstance(a, dict):
            raise ValueError(f"atom {i} is not an object with element/x/y/z")
        if not str(a.get("element", "")).strip():
            raise ValueError(f"atom {i} is missing its element")
        for k in ("x", "y", "z"):
            if k not in a:
                raise ValueError(f"atom {i} is missing the '{k}' coordinate")
            try:
                float(a[k])
            except (TypeError, ValueError):
                raise ValueError(f"atom {i} has a non-numeric '{k}' coordinate")
    return atoms


def _atom_string(molecule: dict[str, Any]) -> str:
    """PySCF atom spec: 'El x y z; El x y z; ...'."""
    return "; ".join(
        f"{a['element']} {a['x']} {a['y']} {a['z']}" for a in _require_atoms(molecule)
    )


# Canonical named-solvent table for the UI's solvent list. Display name (lowercased)
# -> {"eps": relative permittivity @298K, "smd": the pyscf SMD solvent_db key}. The eps
# drives the eps-only continuum models (C-PCM/IEF-PCM, ddCOSMO); SMD instead keys off pyscf's own
# descriptor database via "smd" (a bare eps is NOT enough for SMD — it needs the full
# n/alpha/beta/gamma/surface-tension descriptor set). The "smd" key is the EXACT
# pyscf.solvent.smd.solvent_db name (case- and spelling-sensitive — e.g. "dmso" is
# "dimethylsulfoxide" there, not "dmso"), so SMD no longer fails on a name mismatch.
# eps + smd keys sourced from pyscf.solvent.smd.solvent_db (descriptor index 5).
_SOLVENTS: dict[str, dict[str, Any]] = {
    "water": {"eps": 78.355, "smd": "water"},
    "dmso": {"eps": 46.826, "smd": "dimethylsulfoxide"},
    "dmf": {"eps": 37.219, "smd": "N,N-dimethylformamide"},
    "nitromethane": {"eps": 36.562, "smd": "nitromethane"},
    "acetonitrile": {"eps": 35.688, "smd": "acetonitrile"},
    "methanol": {"eps": 32.613, "smd": "methanol"},
    "ethanol": {"eps": 24.852, "smd": "ethanol"},
    "acetone": {"eps": 20.493, "smd": "acetone"},
    "pyridine": {"eps": 12.978, "smd": "pyridine"},
    "dichloromethane": {"eps": 8.93, "smd": "dichloromethane"},
    "thf": {"eps": 7.4257, "smd": "tetrahydrofuran"},
    "aniline": {"eps": 6.8882, "smd": "aniline"},
    "acetic acid": {"eps": 6.2528, "smd": "acetic acid"},
    "ethyl acetate": {"eps": 5.9867, "smd": "ethylethanoate"},
    "chloroform": {"eps": 4.7113, "smd": "chloroform"},
    "diethyl ether": {"eps": 4.24, "smd": "diethylether"},
    "toluene": {"eps": 2.3741, "smd": "toluene"},
    "carbon tetrachloride": {"eps": 2.228, "smd": "carbon tetrachloride"},
    "benzene": {"eps": 2.2706, "smd": "benzene"},
    "1,4-dioxane": {"eps": 2.2099, "smd": "1,4-dioxane"},
    "cyclohexane": {"eps": 2.0165, "smd": "cyclohexane"},
    "n-hexane": {"eps": 1.8819, "smd": "n-hexane"},
}


def _solvent_request(spec: dict[str, Any]) -> tuple[str, str]:
    """Return (model, solvent_name) the recipe asks for, normalized. ('', '') means gas.

    `model` is read from spec.params.solvent_model (the Method screen's
    Gas/C-PCM/IEF-PCM/SMD/COSMO segment; legacy specs may say "PCM");
    `solvent_name` from spec.solvent. Gas / empty → no reaction field.
    """
    params = spec.get("params", {})
    params = params if isinstance(params, dict) else {}
    model = str(params.get("solvent_model", "")).strip()
    name = str(spec.get("solvent", "")).strip()
    if not model or model.lower() == "gas":
        return "", ""
    return model.upper(), name


def _resolve_solvent(spec: dict[str, Any]) -> tuple[str, float, str, bool]:
    """Resolve a recipe's solvation request to (model, eps, smd_key, is_custom).

    model == "" means gas (no reaction field). A numeric `params.solvent_eps`
    (the Method screen's "Custom…" dielectric) takes precedence over the named
    solvent and drives the eps-only models directly. Raises ValueError on an
    unknown named solvent, a non-physical custom eps (must be a finite number > 1;
    vacuum = 1), or a custom eps under SMD — SMD needs the full descriptor set, not
    a bare dielectric, so it only accepts a named solvent from its database.
    """
    params = spec.get("params", {})
    params = params if isinstance(params, dict) else {}
    model = str(params.get("solvent_model", "")).strip()
    if not model or model.lower() == "gas":
        return "", 0.0, "", False
    model = model.upper()

    raw_eps = params.get("solvent_eps", None)
    if raw_eps is not None and str(raw_eps).strip() != "":
        try:
            eps = float(raw_eps)
        except (TypeError, ValueError):
            raise ValueError(
                f"Invalid dielectric constant {raw_eps!r} — expected a number > 1."
            )
        # NaN (eps != eps), +inf, and eps <= 1 (a vacuum has eps = 1) are non-physical.
        if eps != eps or eps == float("inf") or eps <= 1.0:
            raise ValueError(
                f"Dielectric constant must be a finite number > 1 (vacuum = 1); got {eps}."
            )
        if model == "SMD":
            raise ValueError(
                "A custom dielectric works with C-PCM, IEF-PCM, or COSMO. SMD needs a "
                "named solvent from its database — it uses more than the dielectric "
                "(refractive index, Abraham acidity/basicity, surface tension), so a bare "
                "eps is insufficient. Pick a named solvent, or switch the model to C-PCM, "
                "IEF-PCM, or COSMO."
            )
        return model, eps, "", True

    name = str(spec.get("solvent", "")).strip()
    entry = _SOLVENTS.get(name.lower())
    if entry is None:
        raise ValueError(
            f"Unknown solvent {name!r}; known: {sorted(_SOLVENTS)} "
            "(or choose Custom… and enter a dielectric constant)."
        )
    return model, float(entry["eps"]), str(entry["smd"]), False


def _apply_solvent(mf, spec: dict[str, Any]):
    """Attach an implicit-solvent reaction field to a mean-field per the recipe, BEFORE
    its kernel runs. Returns the (possibly wrapped) mf. Gas/empty → mf unchanged.

    This is the fix for the silent no-op: previously the Method screen offered
    PCM/SMD/COSMO + a solvent but the engine built a bare gas-phase SCF and stamped the
    chosen solvent into provenance anyway. Now an unknown solvent or an unavailable model
    fails loudly instead of lying.
    """
    model, eps, smd_key, _is_custom = _resolve_solvent(spec)
    if not model:
        return mf
    if model in ("PCM", "C-PCM", "CPCM", "IEF-PCM", "IEFPCM"):
        sol = mf.PCM()
        # Legacy recipes saying just "PCM" always ran as C-PCM — keep that mapping.
        # IEF-PCM is the dielectric-exact formalism (matters most at low eps).
        sol.with_solvent.method = (
            "IEF-PCM" if model in ("IEF-PCM", "IEFPCM") else "C-PCM"
        )
        sol.with_solvent.eps = eps
        return sol
    if model in ("COSMO", "DDCOSMO"):
        sol = mf.ddCOSMO()
        sol.with_solvent.eps = eps
        return sol
    if model == "SMD":
        # Pre-check, not a try/except around mf.SMD(): the SMD object CONSTRUCTS fine
        # even when the compiled libsolvent is absent — the RuntimeError only surfaces
        # at kernel time. So fail loud HERE, before the build, with an actionable
        # message instead of the raw pyscf "SMD module is not available" later.
        if not _smd_available():
            raise ValueError(
                "SMD is not available in this PySCF build (libsolvent not compiled) "
                "— use C-PCM, IEF-PCM, or COSMO for continuum solvation."
            )
        sol = mf.SMD()
        # smd_key is the exact pyscf solvent_db name (resolver maps the UI display name);
        # a custom eps never reaches here (the resolver rejects custom+SMD upstream).
        sol.with_solvent.solvent = smd_key or "water"
        return sol
    raise ValueError(f"Unsupported solvent model {model!r}")


def _gas_phase_spec(spec: dict[str, Any]) -> dict[str, Any]:
    """A copy of the recipe with the implicit solvent stripped (gas phase)."""
    params = spec.get("params", {})
    params = dict(params) if isinstance(params, dict) else {}
    params.pop("solvent_model", None)
    params.pop("solvent_eps", None)
    return {**spec, "solvent": "", "params": params}


# UI dispersion choice -> the pyscf `mf.disp` token (pyscf >= 2.x dispersion hook,
# backed by the `pyscf-dispersion` package). Matched case-insensitively.
_DISPERSION_KEYS: dict[str, str] = {
    "D3": "d3zero",    # original Grimme D3, zero damping
    "D3(BJ)": "d3bj",  # D3 with Becke-Johnson damping
    "D4": "d4",
}


def _dispersion_request(spec: dict[str, Any]) -> str:
    """The dispersion correction the recipe asks for ("", "D3", "D3(BJ)", "D4")."""
    params = spec.get("params", {})
    params = params if isinstance(params, dict) else {}
    return str(params.get("dispersion", "")).strip()


_DISP_SHIM_INSTALLED = False


def _install_dispersion_arch_shim() -> None:
    """Make `from pyscf.dispersion import dftd3, dftd4` importable where the pyscf-dispersion
    wheel itself is unusable. pyscf-dispersion 1.0.0's macOS "universal2" wheel ships
    x86_64-ONLY libs-dftd3/libdftd4 and calls `np.ctypeslib.load_library()` without the
    loader_path numpy 2 requires — on Apple Silicon BOTH break the module-level import
    (wrong arch / missing arg). We redirect ONLY those two loads to the arm64 C libraries
    carried by the standalone `dftd3` / `dftd4` PyPI packages (CFFI extensions that re-export
    the full s-dftd3 / dftd4 C API — the exact symbols pyscf.dispersion's ctypes bindings
    call). The patch delegates unchanged for every other library and tries the original load
    first, so on a platform with a correct pyscf-dispersion build it is a complete no-op.

    Installed process-wide (numpy is global) so it also covers pyscf's OWN lazy
    `from pyscf.dispersion import …` at kernel time when `mf.disp` is set. Idempotent."""
    global _DISP_SHIM_INSTALLED
    if _DISP_SHIM_INSTALLED:
        return
    _DISP_SHIM_INSTALLED = True
    try:
        import ctypes
        import importlib

        import numpy as np
    except Exception:
        return

    _orig = np.ctypeslib.load_library
    _redirect = {"libs-dftd3": ("dftd3", "_libdftd3"), "libdftd4": ("dftd4", "_libdftd4")}

    def _patched(libname, *args, **kwargs):
        base = os.path.basename(str(libname))
        if base in _redirect:
            try:
                return _orig(libname, *args, **kwargs)
            except Exception:
                pkg, mod = _redirect[base]
                ext = importlib.import_module(f"{pkg}.{mod}")
                # Load by the extension's real path so its @loader_path/.dylibs rpath
                # resolves the vendored libgfortran/libquadmath.
                return ctypes.CDLL(ext.__file__)
        return _orig(libname, *args, **kwargs)

    np.ctypeslib.load_library = _patched


def _dispersion_available() -> bool:
    """True when pyscf's dispersion backend (pyscf.dispersion.dftd3/dftd4) actually imports.
    A real import is attempted — find_spec is not enough, since a broken wheel can be present
    but unusable. The arch shim (installed here, before any dispersion import in the process)
    lets the arm64 standalone dftd3/dftd4 libraries stand in for an unusable bundled wheel."""
    _install_dispersion_arch_shim()
    try:
        from pyscf.dispersion import dftd3, dftd4  # noqa: F401

        return True
    except Exception:
        return False


def _apply_dispersion(mf, spec: dict[str, Any]):
    """Attach the requested DFT-D dispersion correction to a mean-field, BEFORE its
    kernel runs. Returns mf. Empty request → mf unchanged.

    Fix for a silent no-op: the Method screen (and the shipped "B3LYP-D3(BJ)" preset)
    sends spec.params.dispersion, but the engine never read it — the preset silently
    ran plain B3LYP. Now the correction is either really applied (`mf.disp`, which
    folds the -D term into the energy, gradient and Hessian everywhere downstream)
    or the job fails loud when the backend is missing — same policy as SMD."""
    disp = _dispersion_request(spec)
    if not disp:
        return mf
    key = disp.upper()
    token = {k.upper(): v for k, v in _DISPERSION_KEYS.items()}.get(key)
    if token is None:
        raise ValueError(
            f"Unknown dispersion correction {disp!r}; known: {sorted(_DISPERSION_KEYS)}"
        )
    if not _dispersion_available():
        raise NotImplementedError(
            "dispersion correction %s needs the pyscf-dispersion backend "
            "(pyscf.dispersion: dftd3/dftd4), which is not installed/usable in this "
            "environment — refusing to silently run without dispersion. "
            "Install a working `pyscf-dispersion` wheel or set dispersion to none."
            % disp
        )
    mf.disp = token
    return mf


# spec.params.reference tokens the Method/contract accept (case-insensitive).
_REFERENCE_TOKENS: frozenset[str] = frozenset({"AUTO", "RHF", "ROHF", "UHF"})


def _reference_request(spec: dict[str, Any]) -> str:
    """The SCF reference the recipe asks for: "AUTO" (default), "RHF", "ROHF", "UHF".
    Unknown tokens fail loud — a typo must not silently fall back to AUTO."""
    params = spec.get("params", {})
    params = params if isinstance(params, dict) else {}
    ref = str(params.get("reference", "")).strip().upper() or "AUTO"
    if ref not in _REFERENCE_TOKENS:
        raise ValueError(
            f"Unknown SCF reference {ref!r}; known: {sorted(_REFERENCE_TOKENS)} "
            "(auto = UHF/UKS for open shell, RHF/RKS for closed shell)"
        )
    return ref


def _is_unrestricted(mf) -> bool:
    """True when the mean-field is unrestricted (UHF/UKS — spin-separated orbitals).
    isinstance survives the dynamic solvent-wrapper subclassing."""
    from pyscf import scf

    return isinstance(mf, scf.uhf.UHF)


def _is_rohf(mf) -> bool:
    """True for a restricted-open-shell mean-field (ROHF/ROKS)."""
    from pyscf import scf

    return isinstance(mf, scf.rohf.ROHF)


def _reference_label(mf) -> str:
    """The honest reference name of a built mean-field: RHF/RKS/UHF/UKS/ROHF/ROKS."""
    is_ks = hasattr(mf, "xc")
    if _is_unrestricted(mf):
        return "UKS" if is_ks else "UHF"
    if _is_rohf(mf):
        return "ROKS" if is_ks else "ROHF"
    return "RKS" if is_ks else "RHF"


# Display functional name -> libxc name where they differ. libxc is case-insensitive, so
# most names pass through unchanged; only those whose UI/punctuation form libxc rejects
# need an entry. Empty today — kept as the seam for the next such spelling.
_LIBXC_ALIASES: dict[str, str] = {}


# Functionals whose DEFINITION includes an empirical dispersion term this stack cannot
# evaluate -> what to use instead. pyscf refuses them in `pyscf/scf/dispersion.py`
# (`_black_list`), and that refusal is UNCONDITIONAL: no backend, wheel or install makes
# them work, because the -D2 parameters simply are not implemented there.
#
# wB97X-D used to be aliased to libxc's "wb97xd" to get PAST that refusal. libxc supplies
# only the exchange-correlation part; the -D2 term is empirical and separate, so the alias
# produced a DISPERSION-FREE functional stamped `functional: "wB97X-D"` with an empty
# warnings channel — and it was the ✨Suggest wizard's pick for "Accurate" and "Benchmark".
# Measured on a CH4 dimer at 3.7 Å / 6-31G: the alias gives +0.298 kcal/mol (repulsive,
# alongside dispersion-blind B3LYP's +0.430) while genuinely dispersion-corrected wB97X-V
# gives -0.461. Silently answering a request for one method with a different, weaker one is
# precisely what `_apply_dispersion` refuses to do, so this refuses it the same way.
_UNSUPPORTED_DISPERSION_FUNCTIONALS: dict[str, str] = {
    "wb97x-d": "wB97X-V or wB97M-V — range-separated with nonlocal VV10 dispersion, both "
               "fully supported here — or M06-2X",
    "wb97x-d3": "wB97X-V or wB97M-V",
}


def _geometric_optimize(target, **kwargs):
    """geomeTRIC geometry optimization that REPORTS whether it converged -> (converged, mol).

    Use this, never `pyscf.geomopt.geometric_solver.optimize`: that helper is literally
    `kernel(...)[1]`, so it throws the convergence flag away. Exhausting `maxsteps` does
    NOT raise either — `assert_convergence` guards the inner SCF/gradient, not the outer
    optimization — so a starved optimization returned a geometry indistinguishable from a
    converged one. `result["converged"]` then came from the SCF at that last geometry, and
    a job that ran out of steps reported converged=true, `stationary_point: "minimum"` and
    full thermochemistry with an empty warnings channel. Callers must record the flag.
    """
    from pyscf.geomopt.geometric_solver import kernel
    conv, mol_eq = kernel(target, **kwargs)
    return bool(conv), mol_eq


def _warn_unconverged_geometry(result: dict[str, Any], converged: bool, maxsteps: int) -> None:
    """Record geometry-optimization convergence and, when it failed, say so loudly.

    A non-converged geometry is not a stationary point, so everything downstream of it —
    frequencies, ZPE, H, G, the stationary-point label — describes a structure the optimizer
    was still moving. `converged` is forced false so the Overview pill cannot read green off
    the final SCF alone.
    """
    result["geometry_converged"] = bool(converged)
    if converged:
        return
    result["converged"] = False
    _warn(result,
          "Geometry optimization did NOT converge within %d steps — this structure is not a "
          "stationary point. Its energy, and any frequencies or thermochemistry derived from "
          "it, are not usable; re-run with more steps or from a better starting geometry."
          % maxsteps)


def _libxc_name(functional: str) -> str:
    """Map a UI functional name to the name libxc/pyscf accepts (lowercased, aliased).

    Fails loud for a functional whose dispersion term this stack cannot evaluate, rather
    than quietly computing its dispersion-free parent under the requested name.
    """
    key = functional.strip().lower()
    alternative = _UNSUPPORTED_DISPERSION_FUNCTIONALS.get(key)
    if alternative is not None:
        raise NotImplementedError(
            "%s includes an empirical dispersion term that pyscf does not implement "
            "(pyscf.scf.dispersion refuses it outright, on every platform). Running its "
            "exchange-correlation part alone would be a DIFFERENT, dispersion-free "
            "functional reported under the name you asked for — refusing that. Use %s."
            % (functional.strip(), alternative)
        )
    return _LIBXC_ALIASES.get(key, functional.strip())


def _make_mf(mol, spec: dict[str, Any]):
    """Build the (not yet converged) mean-field for `mol` per the recipe: the right
    restricted/unrestricted HF or KS class plus the requested implicit solvent and
    dispersion correction. Returns (mf, is_dft).

    Open shell (mol.spin != 0) defaults to UHF/UKS — GaussView/ORCA parity — instead
    of pyscf's RO auto-dispatch; spec.params.reference ∈ {auto, RHF, ROHF, UHF}
    overrides. RHF on an open shell is impossible and fails loud. CASSCF jobs keep a
    restricted(-open) reference: mcscf works on ONE set of spatial orbitals and the
    Analyze active-space picker's MO indices refer to exactly that set.

    This is the ONE code path for the initial SCF and for every displaced-geometry
    rebuild (MD steps, finite-difference intensities, gas-fallback Hessians), so a
    PCM/dispersion recipe is never silently dropped on a rebuild."""
    from pyscf import dft, scf

    functional = str(spec.get("functional", "")).strip()
    method = str(spec.get("method", "HF")).upper()
    is_dft = method == "DFT" or bool(functional)
    open_shell = int(getattr(mol, "spin", 0)) != 0

    ref = _reference_request(spec)
    if ref == "RHF" and open_shell:
        raise ValueError(
            "reference RHF is impossible for an open-shell molecule "
            "(multiplicity > 1) — use UHF, ROHF, or auto."
        )
    if ref == "UHF" and method == "CASSCF":
        raise ValueError(
            "CASSCF needs a restricted(-open) reference — its active space is "
            "defined on one set of spatial orbitals. Use ROHF or auto."
        )
    if ref == "AUTO":
        if method == "CASSCF":
            ref = "ROHF" if open_shell else "RHF"
        else:
            ref = "UHF" if open_shell else "RHF"

    if is_dft:
        mf = {"RHF": dft.RKS, "ROHF": dft.ROKS, "UHF": dft.UKS}[ref](mol)
        mf.xc = _libxc_name(functional) if functional else "B3LYP"
    else:
        mf = {"RHF": scf.RHF, "ROHF": scf.ROHF, "UHF": scf.UHF}[ref](mol)
    # Verbose 5 (rich SCF detail) when an engine-log capture is active; silent (0) otherwise so
    # the default stdout protocol stays clean. Verbosity is logging-only — the converged energy
    # is byte-identical, so the pinned anchors are unaffected.
    mf.verbose = 5 if _ENGINE_LOG is not None else 0
    mf = _apply_solvent(mf, spec)  # gas-phase unless the recipe asks otherwise
    mf = _apply_dispersion(mf, spec)
    mf = _apply_scf_knobs(mf, spec)
    mf = _apply_checkpoint(mf, spec)
    return mf, is_dft


def _apply_checkpoint(mf, spec: dict[str, Any]):
    """Wire SCF checkpointing onto a (not yet converged) mean-field.

    Two independent knobs from spec.params, applied AFTER the solvent/dispersion wraps
    so they land on the object whose kernel actually runs:

    - `scf_chkfile` (internal — injected by action_energy from the request's
      output_path, never user-supplied): where THIS run dumps its converged SCF.
    - `restart_from` (user/Reproduce-supplied): a prior run's chkfile to reuse as the
      initial guess. PySCF's `from_chk` projects the stored MOs onto the current
      geometry/basis; anything unusable (missing file, incompatible/corrupt content)
      DEGRADES to the default guess with a note — restart is an optimization, never a
      correctness change, so it must not kill the job. Notes are stashed on the mf
      (`_qc_notes`) because the result dict does not exist yet; action_energy surfaces
      them into the warnings channel.

    The projected density rides as `mf._qc_dm0` and `_build_mol` passes it to kernel().
    """
    params = dict(spec.get("params", {}) or {})
    notes: list[str] = []

    chk = str(params.get("scf_chkfile", "") or "").strip()
    if chk:
        mf.chkfile = chk

    restart = str(params.get("restart_from", "") or "").strip()
    if restart:
        try:
            if not os.path.isfile(restart):
                raise FileNotFoundError("checkpoint file not found")
            dm0 = mf.from_chk(restart)
            mf._qc_dm0 = dm0
        except Exception as exc:  # noqa: BLE001 — degrade + say so (see docstring)
            notes.append(
                "restart_from checkpoint %r was not usable (%s: %s) — the SCF started "
                "from the default initial guess instead"
                % (restart, type(exc).__name__, exc)
            )
    if notes:
        mf._qc_notes = notes
    return mf


def _apply_scf_knobs(mf, spec: dict[str, Any]):
    """Honor optional SCF-convergence knobs from spec.params (the self-healing SCF rungs set these).

    Defaults are pyscf's, so a recipe WITHOUT these keys is byte-for-byte unchanged — the pinned
    HF/DFT anchors stand. Knobs: scf_max_cycle (int), scf_level_shift (float, Ha; a pure
    convergence aid — the self-consistent density is its own fixed point, so the converged energy
    is unchanged), scf_init_guess (minao|atom|huckel|1e|vsap). Bad values are ignored rather than
    crashing a rescue attempt."""
    params = dict(spec.get("params", {}) or {})
    mc = params.get("scf_max_cycle")
    if mc is not None:
        try:
            mf.max_cycle = max(1, int(mc))
        except (TypeError, ValueError):
            pass
    ls = params.get("scf_level_shift")
    if ls is not None:
        try:
            mf.level_shift = float(ls)
        except (TypeError, ValueError):
            pass
    ig = params.get("scf_init_guess")
    if ig:
        guess = str(ig).strip().lower()
        if guess in ("minao", "atom", "huckel", "1e", "vsap"):
            mf.init_guess = guess
    return mf


def _build_mol(spec: dict[str, Any], molecule: dict[str, Any], *, progress: bool = False):
    """Construct and return a converged PySCF Mole + mean-field object.

    method 'DFT' (or any non-empty functional) -> RKS with that xc functional,
    otherwise -> RHF. An implicit-solvent reaction field and a DFT-D dispersion
    correction are attached when the recipe asks. Returns (mol, mf, is_dft).

    `progress=True` streams per-cycle QPROG telemetry from THIS kernel (the job's
    MAIN SCF); rebuilds at displaced/optimized geometries keep the default False.
    """
    from pyscf import gto

    # Fail loud on declared-but-unimplemented methods, for EVERY classical action that
    # builds a mean-field. Previously this guard lived only in action_energy, so MP2/
    # CCSD/FCI requests to TS/IRC/PES/es_opt fell through to RHF and were written back
    # labeled "HF" — a silent lie. main() turns this raise into an error_result the
    # Godot side surfaces.
    method = str(spec.get("method", "HF")).upper()
    if method not in _IMPLEMENTED_METHODS:
        hint = (
            " MP2/CCSD run as energy/optimize and CCSD(T)/FCI as a single-point energy "
            "(the energy action); this calculation only builds the mean-field."
            if method in _POST_HF else ""
        )
        raise NotImplementedError(
            "method %s is not implemented for this calculation — it would silently "
            "run Hartree-Fock. Use HF or DFT here.%s" % (method, hint)
        )

    charge = int(molecule.get("charge", spec.get("charge", 0)))
    multiplicity = int(molecule.get("multiplicity", spec.get("multiplicity", 1)))
    basis, ecp = _resolve_basis_ecp(spec)

    _capturing = _ENGINE_LOG is not None
    try:
        mol = gto.M(
            atom=_atom_string(molecule),
            basis=basis,
            ecp=ecp,
            charge=charge,
            spin=multiplicity - 1,  # PySCF spin = 2S = (multiplicity - 1)
            unit="Angstrom",
            verbose=5 if _capturing else 0,
            # verbose>=4 otherwise dumps the ENTIRE calling script (sidecar.py) as the "input
            # file" header — hundreds of KB of noise. Keep the useful log (geometry, basis, SCF
            # cycles, MO energies), drop the source dump.
            dump_input=False,
        )
    except (gto.basis.BasisNotFoundError, KeyError, RuntimeError) as exc:
        # Surface PySCF's basis/ECP lookup failure as a clean, actionable message — the
        # custom-basis field is freeform, so a typo must fail loud, not as a raw
        # KeyError. An unknown ECP raises a bare RuntimeError ("Unable to load ECP"),
        # so RuntimeErrors are relabeled only when they are really about the basis/ECP —
        # anything else (spin/charge inconsistency, …) propagates untouched.
        text = str(exc).lower()
        if isinstance(exc, RuntimeError) and "basis" not in text and "ecp" not in text:
            raise
        raise ValueError(
            "PySCF rejected the basis/ECP specification (basis=%r, ecp=%r): %s "
            "— use a basis-set name PySCF knows (e.g. 'sto-3g', 'def2-svp', 'cc-pvtz') "
            "or a per-element mapping." % (basis, ecp, exc)
        ) from exc
    # Bind the log stream to the CURRENT sys.stdout (the engine-log capture buffer
    # during a request). PySCF's Mole.stdout is a CLASS attribute frozen to whatever
    # sys.stdout was at pyscf-import time — in --serve mode that is request #1's dead
    # capture buffer (every later request's verbose-5 SCF log vanished into it), and
    # with pyscf pre-imported it leaks the log onto the QPROG protocol stream.
    mol.stdout = sys.stdout

    _apply_resources(mol, spec)

    mf, is_dft = _make_mf(mol, spec)
    if progress:
        _attach_scf_progress(mf)
    dm0 = getattr(mf, "_qc_dm0", None)  # restart_from projected guess (see _apply_checkpoint)
    if dm0 is not None:
        mf.kernel(dm0=dm0)
    else:
        mf.kernel()
    return mol, mf, is_dft


def _resolve_basis_ecp(spec: dict[str, Any]) -> tuple[Any, Any]:
    """The (basis, ecp) arguments for gto.M from a recipe.

    `spec.basis_set` is normally a plain PySCF basis name (freeform — passed through
    verbatim), but a per-element mapping {element: basis_name} is also accepted, either
    directly in basis_set or via `spec.params.basis` (which wins when present, same
    string-or-dict shapes). `spec.params.ecp` (string or {element: ecp_name}) rides to
    mol.ecp; None/empty means all-electron. Validation of the actual names is PySCF's —
    `_build_mol` converts its lookup failure into a clean ValueError."""
    params = spec.get("params", {})
    params = params if isinstance(params, dict) else {}

    basis: Any = spec.get("basis_set", _DEFAULT_BASIS)
    override = params.get("basis")
    if override is not None and override != "":
        basis = override
    if isinstance(basis, dict):
        basis = {str(k): str(v) for k, v in basis.items()}
    else:
        basis = str(basis)
        if not basis.strip():
            basis = "STO-3G"

    ecp: Any = params.get("ecp")
    if isinstance(ecp, dict):
        ecp = {str(k): str(v) for k, v in ecp.items()} or None
    elif ecp is not None:
        ecp = str(ecp).strip() or None
    return basis, ecp


def _basis_label(spec: dict[str, Any]) -> str:
    """A human-readable provenance label for the recipe's basis (+ ECP): the plain name
    for a string basis, 'El:name, El:name' for a per-element mapping, '· ECP <name>'
    appended when an effective core potential is attached."""
    basis, ecp = _resolve_basis_ecp(spec)
    if isinstance(basis, dict):
        label = ", ".join("%s:%s" % (k, v) for k, v in sorted(basis.items()))
    else:
        label = str(basis)
    if isinstance(ecp, dict):
        label += " · ECP " + ", ".join("%s:%s" % (k, v) for k, v in sorted(ecp.items()))
    elif ecp:
        label += " · ECP %s" % ecp
    return label


def _apply_resources(mol, spec: dict[str, Any]) -> None:
    """Honor the Method screen's Step-5 resource sliders (spec.resources, previously
    a silent no-op): cap PySCF's per-Mole memory budget and the OpenMP thread count.

    Lives in `_build_mol` — the one Mole factory — so every geometry rebuild that goes
    through it (PES scan points, IRC descent, es_opt re-characterization, VQE/QPE)
    inherits the budget. Displaced rebuilds via `mol.set_geom_(inplace=False)`
    (`_run_md`, `_vib_intensities`, gas-fallback Hessians) copy the Mole, so
    `max_memory` carries over there too. Thread count is process-global, so setting
    it once on the first Mole of a request covers everything after it."""
    resources = spec.get("resources", {})
    resources = resources if isinstance(resources, dict) else {}
    memory_gb = float(resources.get("memory_gb", 0) or 0)
    if memory_gb > 0:
        mol.max_memory = memory_gb * 1024.0  # PySCF budgets in MB
    cores = int(resources.get("cores", 0) or 0)
    if cores > 0:
        from pyscf import lib

        lib.num_threads(cores)


def _reject_casscf(spec: dict[str, Any], action: str) -> None:
    """Refuse CASSCF for actions that would only ever run its HF/DFT reference.

    `_build_mol` lets CASSCF through (action_energy genuinely runs the active-space
    SCF on the converged reference), but TS/IRC/PES/es_opt use the mean-field
    directly — accepting CASSCF there would silently hand back single-reference
    numbers labeled CASSCF."""
    if str(spec.get("method", "HF")).upper() == "CASSCF":
        raise NotImplementedError(
            "method CASSCF is not implemented for %s — it would silently run the "
            "HF/DFT reference instead. Use HF or DFT here, or run CASSCF as an "
            "energy calculation." % action
        )


def _fill_overview(
    result: dict[str, Any],
    spec: dict[str, Any],
    molecule: dict[str, Any],
    *,
    seed: int,
) -> None:
    """Fill the provenance + overview fields common to every computed result."""
    result["charge"] = int(molecule.get("charge", spec.get("charge", 0)))
    result["multiplicity"] = int(molecule.get("multiplicity", spec.get("multiplicity", 1)))
    # Human-readable basis provenance: handles a per-element {element: basis} mapping and
    # an attached ECP, not just the plain string name. An empty basis (imported/degraded
    # specs) stays empty rather than claiming the engine default.
    has_basis = bool(spec.get("basis_set")) or bool(
        isinstance(spec.get("params"), dict) and spec["params"].get("basis"))
    # Record the basis that ACTUALLY ran, including the default. Declining to claim a basis
    # nobody asked for was the right instinct, but the run still used one — STO-3G, the
    # smallest available — and a result whose provenance said basis: "" had silently been
    # computed in it. That bites hand-built, imported and degraded specs, which are exactly
    # the ones whose provenance matters most.
    # An ML interatomic potential has no basis set, no atomic orbitals and no SCF, so
    # defaulting its provenance to STO-3G was a false record on EVERY MACE job — and the
    # Overview tab then read that basis back through exploratory_reason and labelled
    # MACE-OFF23 (a surrogate for wB97M-D3(BJ)/def2-TZVPPD) a "quick tests only" calculation.
    _is_ml_potential = str(spec.get("backend", "")).lower() == "mace" or \
        str(spec.get("method", "")).lower().startswith("mace")
    if _is_ml_potential:
        result["basis"] = ""
    else:
        result["basis"] = _basis_label(spec) if has_basis else _DEFAULT_BASIS
    if not has_basis and not _is_ml_potential:
        _warn(result,
              "No basis set was specified, so the engine default (%s) was used. That is a "
              "minimal basis suitable for smoke tests only — set spec.basis_set explicitly "
              "for any number you intend to use." % _DEFAULT_BASIS)
    result["functional"] = str(spec.get("functional", ""))
    result["formula"] = rb.formula_from_atoms(molecule.get("atoms", []))
    result["final_coords"] = rb.coords_from_atoms(molecule.get("atoms", []))
    # The result's own atom identity (same order as final_coords) — opt/MD paths
    # overwrite final_coords with moved geometry but never reorder atoms, so the
    # symbol list filled here stays correct for every calc type.
    result["atom_symbols"] = rb.symbols_from_atoms(molecule.get("atoms", []))
    result["host"] = rb.host()
    result["rng_seed"] = int(seed)
    result["geometry_checksum"] = rb.geometry_checksum(molecule)
    result["library_versions"] = rb.library_versions()
    # Carry calc_type so a stored result can regenerate its exact input
    # ("Reproduce this calculation", §15.7). Solvent provenance is stamped in
    # _fill_scf from the actual mean-field, so a gas run can never be mislabeled.
    result["calc_type"] = str(spec.get("calc_type", "energy"))
    result["solvent"] = ""
    result["solvent_model"] = ""
    # The request's params, verbatim — Reproduce (§15.7) rebuilds the input JobSpec
    # from the result, and every params-driven knob (md_steps, excited_nstates, cas,
    # dispersion, solvent_model, …) lives here. The values arrive from JSON, so a
    # plain copy is always serializable.
    params = spec.get("params", {})
    result["spec_params"] = dict(params) if isinstance(params, dict) else {}


# Merz–Kollman ESP fit: shells at these multiples of the vdW radius, sampled at
# ~1 point per Å² of shell surface (the classic MK recipe).
_MK_SHELL_SCALES: tuple[float, ...] = (1.4, 1.6, 1.8, 2.0)
_MK_POINT_DENSITY: float = 1.0  # grid points per Å²


def _esp_charges(mol, dm) -> list[float]:
    """ESP-fitted (Merz–Kollman) atomic charges, same atom order as `charges`.

    Least-squares fit of one point charge per atom to the QM electrostatic potential
    V(r) = Σ_A Z_A/|r−R_A| − ∫ρ(r')/|r−r'| dr', sampled on four scaled-vdW shells
    (1.4/1.6/1.8/2.0×, points inside any atom's scaled shell excluded), with the
    total constrained exactly to the molecule's net charge via a Lagrange multiplier.
    Open-shell density-matrix pairs (2, nao, nao) are spin-traced — the ESP sees the
    total electron density. Raises on failure; the caller degrades to [] + warning.
    """
    import numpy as np
    from pyscf.data import radii
    from pyscf.data.elements import charge as _elem_charge
    from pyscf.lib.parameters import BOHR

    dm = np.asarray(dm)
    if dm.ndim == 3:  # UHF/UKS/ROHF (alpha, beta) pair → spin-traced total density
        dm = dm[0] + dm[1]

    coords = mol.atom_coords()  # Bohr
    # Effective nuclear charges (ECP-consistent — matches the valence density)…
    z_eff = np.asarray(mol.atom_charges(), dtype=float)
    # …but vdW radii are looked up by the TRUE element, never the ECP-reduced charge.
    z_true = [int(_elem_charge(mol.atom_pure_symbol(i))) for i in range(mol.natm)]
    fallback = 2.0 / BOHR  # 2.0 Å for elements past the table (Z > 103)
    vdw = np.array([
        radii.VDW[z] if 0 < z < len(radii.VDW) else fallback for z in z_true
    ])

    # Quasi-uniform unit-sphere points (Fibonacci spiral), scaled per shell/atom.
    def _sphere(n: int) -> np.ndarray:
        i = np.arange(n) + 0.5
        polar = np.arccos(1.0 - 2.0 * i / n)
        azim = np.pi * (1.0 + 5.0 ** 0.5) * i
        return np.column_stack([
            np.cos(azim) * np.sin(polar), np.sin(azim) * np.sin(polar), np.cos(polar)
        ])

    shells = []
    for scale in _MK_SHELL_SCALES:
        r = vdw * scale
        for a in range(mol.natm):
            area = 4.0 * np.pi * (r[a] * BOHR) ** 2
            pts = coords[a] + r[a] * _sphere(max(int(_MK_POINT_DENSITY * area), 12))
            dist = np.linalg.norm(pts[:, None, :] - coords[None, :, :], axis=2)
            shells.append(pts[np.all(dist >= r[None, :] - 1e-9, axis=1)])
    grid = np.vstack(shells)
    if len(grid) == 0:
        raise RuntimeError("empty MK grid (all shell points buried)")

    # ESP at the grid points: nuclear part analytically, electronic part via the
    # int1e_grids Coulomb integrals, chunked so memory stays ~64 MB at any nao.
    dist = np.linalg.norm(grid[:, None, :] - coords[None, :, :], axis=2)
    esp = (z_eff[None, :] / dist).sum(axis=1)
    nao = mol.nao
    chunk = max(1, int(8e6 / max(nao * nao, 1)))
    for g0 in range(0, len(grid), chunk):
        block = mol.intor("int1e_grids", grids=grid[g0:g0 + chunk])
        esp[g0:g0 + chunk] -= np.einsum("gij,ij->g", block, dm)

    # Constrained least squares: minimize |D q − esp|² s.t. Σq = net charge (KKT).
    inv_d = 1.0 / dist
    n = mol.natm
    kkt = np.zeros((n + 1, n + 1))
    kkt[:n, :n] = inv_d.T @ inv_d
    kkt[:n, n] = 1.0
    kkt[n, :n] = 1.0
    rhs = np.append(inv_d.T @ esp, float(mol.charge))
    q = np.linalg.solve(kkt, rhs)[:n]
    return [float(c) for c in q]


# Mayer bond orders below this magnitude are not reported — keeps a result to its
# actual bonds (~natom rows) instead of every O(natom²) pair (a 30-atom molecule
# has 435 pairs, almost all ~0). 0.3 cleanly separates a real chemical bond
# (single ≈ 1, weak/partial down to ~0.4) from non-bonded ~0 noise.
_BOND_ORDER_THRESHOLD: float = 0.3


def _mayer_bond_orders(mol, dm) -> list[dict[str, Any]]:
    """Mayer bond orders for every atom pair from the AO density `dm`, GaussView/
    Multiwfn parity — the wavefunction-derived bond order that reveals actual bond
    character (single/double/triple/aromatic/partial) vs the drawn Lewis structure.

    B_AB = Σ_{a∈A,b∈B} (PS)_ab (PS)_ba, with P the AO density and S the overlap.
    For a spin-separated density (UHF/UKS/ROHF — a (2, nao, nao) pair) the correct
    open-shell form adds a spin term:
        B_AB = Σ(P^tot S)(P^tot S)_ab,ba + Σ(P^spin S)(P^spin S)_ab,ba
    where P^tot = Pα + Pβ and P^spin = Pα − Pβ. For a restricted density P^spin = 0,
    so the formula collapses to the total-density form — the same code path covers both.

    Returns the SIGNIFICANT pairs only (B ≥ `_BOND_ORDER_THRESHOLD`) as
    {"a","b","order"} with 0-indexed atoms a < b, descending by order. Cost is one
    PS matmul plus an O(natom²) pair loop over per-atom AO blocks — cheap to a few
    hundred atoms. Raises on failure; the caller degrades to [] + a warning.
    """
    import numpy as np

    s = np.asarray(mol.intor("int1e_ovlp"))
    dm = np.asarray(dm)
    if dm.ndim == 3:  # (alpha, beta) spin-separated density
        p_tot = dm[0] + dm[1]
        p_spin = dm[0] - dm[1]
    else:
        p_tot = dm
        p_spin = None

    ps_tot = p_tot @ s
    ps_spin = (p_spin @ s) if p_spin is not None else None

    # Per-atom AO index ranges: aoslice_by_atom() rows are [shl0, shl1, ao0, ao1].
    slices = mol.aoslice_by_atom()
    natom = mol.natm
    bonds: list[dict[str, Any]] = []
    for a in range(natom):
        a0, a1 = int(slices[a][2]), int(slices[a][3])
        for b in range(a + 1, natom):
            b0, b1 = int(slices[b][2]), int(slices[b][3])
            blk_tot = ps_tot[a0:a1, b0:b1]
            order = float(np.einsum("ij,ji->", blk_tot, ps_tot[b0:b1, a0:a1]))
            if ps_spin is not None:
                blk_spin = ps_spin[a0:a1, b0:b1]
                order += float(np.einsum("ij,ji->", blk_spin, ps_spin[b0:b1, a0:a1]))
            if order >= _BOND_ORDER_THRESHOLD:
                bonds.append({"a": a, "b": b, "order": order})

    bonds.sort(key=lambda d: d["order"], reverse=True)
    return bonds


def _fill_bond_orders(result: dict[str, Any], mol, dm) -> None:
    """Fill the `bond_orders` contract field (Mayer bond orders, significant pairs)
    from the AO density `dm`. Like `_fill_charges`, the density is passed explicitly
    so a post-HF method (CASSCF) re-fills from its natural density (mc.make_rdm1()).
    Failure degrades to [] + a warning — a bond-order glitch never kills the job."""
    try:
        result["bond_orders"] = _mayer_bond_orders(mol, dm)
    except Exception as exc:  # noqa: BLE001 — degrade, but say so (warnings channel)
        result["bond_orders"] = []
        _warn(result, f"Mayer bond orders unavailable: {exc}")


def _fill_charges(result: dict[str, Any], mol, mf, dm) -> None:
    """Fill Mulliken / meta-Löwdin / ESP atomic charges from the AO density `dm`.

    Passing `dm` explicitly (rather than letting pyscf default to the mean-field's own
    density) lets a post-HF method re-fill the charges from its correlated density:
    `_fill_scf` calls this with `mf.make_rdm1()`, and CASSCF re-calls it with
    `mc.make_rdm1()` (the natural density), so a CASSCF result's charges describe the
    CASSCF wavefunction, not the HF reference. Each scheme degrades to [] + a warning."""
    import numpy as np

    try:
        _pop, charges = mf.mulliken_pop(mol, dm, verbose=0)
        result["charges"] = [float(c) for c in np.asarray(charges).ravel()]
    except Exception as exc:  # noqa: BLE001 — degrade, but say so (warnings channel)
        result["charges"] = []
        _warn(result, f"Mulliken charges unavailable: {exc}")

    try:
        _mpop, lowdin = mf.mulliken_meta(mol, dm, verbose=0)
        result["charges_lowdin"] = [float(c) for c in np.asarray(lowdin).ravel()]
    except Exception as exc:  # noqa: BLE001
        result["charges_lowdin"] = []
        _warn(result, f"Löwdin (meta-Löwdin) charges unavailable: {exc}")

    try:
        result["charges_esp"] = _esp_charges(mol, dm)
    except Exception as exc:  # noqa: BLE001
        result["charges_esp"] = []
        _warn(result, f"ESP (Merz-Kollman) charges unavailable: {exc}")


def _basis_has_diffuse(basis: str) -> bool:
    """True when the basis name carries a diffuse (augmented) set.

    Pople sets mark them with '+' (6-31+G(d), 6-311++G(d,p)); Dunning/Karlsruhe with an
    'aug-'/'ma-' prefix or a 'D' (def2-TZVPD, def2-QZVPPD). Name-based by necessity —
    basis_set is freeform and may be a custom dict — so it errs toward "no diffuse", i.e.
    toward warning.
    """
    b = basis.strip().lower()
    if not b:
        return False
    if "+" in b or b.startswith("aug-") or b.startswith("ma-"):
        return True
    # def2-*D / def2-*PD carry diffuse; def2-SVP / def2-TZVP do not.
    return b.startswith("def2-") and b.endswith("d")


def _is_minimal_basis(basis: str) -> bool:
    """True for a minimal (single-zeta) basis — no virtual space worth exciting into."""
    return basis.strip().lower().replace(" ", "") in {"sto-3g", "sto3g", "sto-6g", "sto6g", "minao"}


def _homo_energy(mf) -> float | None:
    """Energy of the highest OCCUPIED orbital (Hartree), or None when unavailable.
    Handles the unrestricted case by taking the higher of the two spin HOMOs."""
    import numpy as np

    try:
        e = np.asarray(mf.mo_energy)
        occ = np.asarray(mf.mo_occ)
        if e.ndim == 2:  # unrestricted: (2, nmo)
            per_spin = [float(e[s][occ[s] > 0].max()) for s in (0, 1) if (occ[s] > 0).any()]
            return max(per_spin) if per_spin else None
        vals = e[occ > 0]
        return float(vals.max()) if vals.size else None
    except Exception:  # noqa: BLE001 — a diagnostic must never fail the job
        return None


def _check_anion_basis(
    result: dict[str, Any], mol, mf, spec: dict[str, Any], is_dft: bool = False
) -> None:
    """Warn when an anion is run in a basis with no diffuse functions (M1).

    An added electron is spatially diffuse. Without diffuse functions it is described by
    the tails of valence functions, which both raises the energy enormously and leaves the
    extra electron formally unbound. Measured on OH-/B3LYP at one geometry: 6-31G(d) sits
    49.5 kcal/mol above 6-31+G(d) and 63.1 above aug-cc-pVDZ, with epsilon_HOMO = +0.166 Ha
    — and the app reported converged with an empty warnings channel.

    A POSITIVE HOMO eigenvalue on an anion is the textbook signature of that failure, so it
    is checked directly as well: it catches the case whatever the basis is called.
    """
    charge = int(getattr(mol, "charge", 0) or 0)
    if charge >= 0:
        return
    basis = _basis_label(spec) if spec else ""
    if not _basis_has_diffuse(basis):
        _warn(result,
              "This is an anion (charge %+d) in %s, a basis with no diffuse functions. The "
              "extra electron is spatially diffuse and cannot be described without them: the "
              "energy is far too high and the anion may not be bound at all. Use an "
              "augmented basis (6-31+G(d), aug-cc-pVDZ, def2-TZVPD)."
              % (charge, basis or "this basis"))
    e_homo = _homo_energy(mf)
    if e_homo is None or e_homo <= 0.0:
        return
    # A positive HOMO eigenvalue on an anion means different things by method, and saying
    # the strong version for DFT would fire on almost every anion job — approximate
    # functionals put anion HOMOs above zero through self-interaction error even in a good
    # augmented basis (OH- / B3LYP: +0.049 Ha in 6-31+G(d), +0.039 in aug-cc-pVDZ). A
    # warning that cries wolf teaches people to ignore the channel.
    if is_dft:
        _warn(result,
              "The highest occupied orbital of this anion has a positive energy "
              "(%+.4f Ha). For an anion with an approximate functional this is usually "
              "self-interaction error rather than a genuinely unbound electron, but it does "
              "mean the HOMO eigenvalue must not be read as minus the ionization potential "
              "(no Koopmans interpretation), and orbital-energy-based quantities inherit "
              "that error." % e_homo)
    else:
        _warn(result,
              "The highest occupied orbital of this anion has a POSITIVE energy "
              "(%+.4f Ha) at this wavefunction level — the extra electron is not bound in "
              "this basis, and properties derived from it are unphysical." % e_homo)


def _check_excited_state_basis(
    result: dict[str, Any], mf, spec: dict[str, Any], energies_ev: list[float]
) -> None:
    """Warn when excited states are being reported outside the basis's competence (M2).

    Two failure modes, both silent before:
      * A minimal basis has essentially no virtual space — TD-DFT in STO-3G is meaningless.
      * States above the Koopmans ionization threshold (-epsilon_HOMO) are, without diffuse
        functions, basis-set-boundary artifacts rather than Rydberg states: the real Rydberg
        manifold is absent from the basis entirely. Measured on formaldehyde/6-31G(d):
        states 2-5 (9.1-10.4 eV) all sit above the 7.27 eV threshold and arrived with
        oscillator strengths, ready to be plotted as absorption bands.
    """
    basis = _basis_label(spec) if spec else ""
    if _is_minimal_basis(basis):
        _warn(result,
              "Excited states computed in %s, a minimal basis: there is almost no virtual "
              "space, so these excitation energies are not meaningful. Use at least a "
              "polarized double-zeta basis, augmented if you need Rydberg or "
              "charge-transfer states." % basis)
    e_homo = _homo_energy(mf)
    if e_homo is None or not energies_ev:
        return
    ip_ev = -e_homo * 27.211386245988   # Koopmans estimate of the ionization threshold
    if ip_ev <= 0.0:
        return
    above = [e for e in energies_ev if e > ip_ev]
    if not above:
        return
    if _basis_has_diffuse(basis):
        _warn(result,
              "%d of %d excited states lie above the Koopmans ionization threshold "
              "(%.2f eV). These are resonances embedded in the continuum; treat their "
              "energies and intensities with care."
              % (len(above), len(energies_ev), ip_ev))
    else:
        _warn(result,
              "%d of %d excited states lie above the Koopmans ionization threshold "
              "(%.2f eV) in %s, which has no diffuse functions. The Rydberg manifold is "
              "absent from this basis, so these are basis-set-boundary artifacts rather "
              "than physical states — do not plot them as absorption bands. Re-run with an "
              "augmented basis (aug-cc-pVDZ, 6-311++G(d,p))."
              % (len(above), len(energies_ev), ip_ev, basis or "this basis"))


def _warn_continuum_is_electrostatic_only(result: dict[str, Any], model: str) -> None:
    """Say that a PCM/COSMO number is DeltaG_electrostatic, not DeltaG_solv (M5).

    pyscf's `solvent.pcm` implements the reaction field only — it carries no cavitation,
    dispersion or repulsion term (SMD, which does, is not compiled in this build and fails
    loud). For a neutral nonpolar solute the omitted terms dominate and even the SIGN can be
    wrong: methane's electrostatic contribution is ~0 while its experimental DeltaG_solv is
    +2.0 kcal/mol. Anything calling a PCM difference "the solvation free energy" is
    overclaiming, so the result says so at the source.
    """
    if not model:
        return
    _warn(result,
          "%s here is electrostatic-only: pyscf's continuum implements the reaction field "
          "but no cavitation, dispersion or repulsion term. An energy difference against gas "
          "phase is therefore DeltaG_electrostatic, not the full solvation free energy — for "
          "small or nonpolar solutes the missing terms can exceed it and change its sign."
          % model)


def _fill_scf(
    result: dict[str, Any], mol, mf, is_dft: bool, spec: dict[str, Any] | None = None
) -> None:
    """Fill SCF energy, orbitals, charges, dipole, point group from a mean-field object.

    When the mean-field carries a solvent reaction field, the applied model + solvent
    are recorded as provenance from the recipe — stamped only because one was actually
    attached, so the result never claims a solvent it did not use."""
    import numpy as np

    e_tot = float(mf.e_tot)
    result["scf_energy"] = e_tot
    result["converged"] = bool(getattr(mf, "converged", False))
    # Say it out loud: a non-converged SCF makes the energy and every derived property
    # (orbitals, charges, dipole) unreliable. Every other action warns on this; energy/
    # optimize/frequencies/md route through here, so warn here too rather than returning
    # a clean-looking success (§ honest-failure: degrade into the warnings channel).
    if not result["converged"]:
        _warn(result, "SCF did not converge — energy and derived properties are unreliable.")

    # Honest solvent provenance: only when a reaction field is really on the mf.
    if getattr(mf, "with_solvent", None) is not None and spec is not None:
        model, name = _solvent_request(spec)
        result["solvent_model"] = model
        result["solvent"] = name
        _warn_continuum_is_electrostatic_only(result, model)

    # An anion without diffuse functions is the most common way to get a badly wrong
    # energy while everything still reports success.
    if spec is not None:
        _check_anion_basis(result, mol, mf, spec, is_dft)

    # Record the numerical settings behind this number (M8/M9): all engine defaults, but a
    # default nobody wrote down cannot answer "what grid, what SCF threshold?" later.
    result["numerical_settings"] = rb.numerical_settings(
        scf_conv_tol=float(getattr(mf, "conv_tol", 0.0) or 0.0),
        scf_max_cycle=int(getattr(mf, "max_cycle", 0) or 0),
        dft_grid_level=(int(getattr(getattr(mf, "grids", None), "level", 3))
                        if is_dft and getattr(mf, "grids", None) is not None else None),
        cartesian_basis=bool(getattr(mol, "cart", False)),
        frozen_core=bool(((spec or {}).get("params", {}) or {}).get("frozen_core", False)),
    )

    # Honest dispersion provenance: only when the -D correction is really on the mf.
    if getattr(mf, "disp", None) and spec is not None:
        result["dispersion"] = _dispersion_request(spec)

    # Honest reference provenance — derived from the converged mf object itself.
    result["reference"] = _reference_label(mf)

    unrestricted = _is_unrestricted(mf)
    # Per-MO Löwdin atomic composition (which atoms own each orbital) — degrades to
    # empty compositions with a warning; the orbital ladder itself must never be lost
    # to a population-analysis failure.
    comp_a = comp_b = comp_r = None
    try:
        ovlp = mf.get_ovlp()
        if unrestricted:
            comp_a = _mo_compositions(mol, ovlp, np.asarray(mf.mo_coeff)[0])
            comp_b = _mo_compositions(mol, ovlp, np.asarray(mf.mo_coeff)[1])
        else:
            comp_r = _mo_compositions(mol, ovlp, mf.mo_coeff)
    except Exception as exc:  # noqa: BLE001
        _warn(result, f"orbital composition unavailable: {exc}")
    if unrestricted:
        # UHF/UKS: mo_energy / mo_occ are (alpha, beta) pairs. The orbital list is
        # all alpha entries (spin "a") followed by all beta (spin "b"), each indexed
        # WITHIN its channel. homo_index/lumo_index name the ALPHA frontier (the
        # alpha HOMO is the SOMO); the Orbitals tab resolves per-channel frontiers
        # from occupations when spin labels are present.
        e_a, e_b = (np.asarray(x, dtype=float).ravel() for x in mf.mo_energy)
        o_a, o_b = (np.asarray(x, dtype=float).ravel() for x in mf.mo_occ)
        orbs_a, homo, lumo = rb.orbitals_from_mo(
            list(e_a), list(o_a), spin="a", compositions=comp_a
        )
        orbs_b, _homo_b, _lumo_b = rb.orbitals_from_mo(
            list(e_b), list(o_b), spin="b", compositions=comp_b
        )
        orbs = orbs_a + orbs_b
    else:
        orbs, homo, lumo = rb.orbitals_from_mo(
            [float(e) for e in mf.mo_energy],
            [float(o) for o in mf.mo_occ],
            compositions=comp_r,
        )
    result["orbitals"] = orbs
    result["homo_index"] = homo
    result["lumo_index"] = lumo

    # Atomic charges (Mulliken / meta-Löwdin / ESP) from the mean-field density. Split
    # into a helper so a post-HF method (CASSCF) can re-fill them from its OWN density
    # rather than leave the HF-reference charges mislabeled as the method's.
    dm = mf.make_rdm1()
    _fill_charges(result, mol, mf, dm)

    # Mayer bond orders (GaussView/Multiwfn parity) from the SAME density — the actual
    # bond character per atom pair. CASSCF re-fills from its natural density alongside
    # the charges (action_energy), so a CASSCF result shows CASSCF bond orders.
    _fill_bond_orders(result, mol, dm)

    _fill_spin_diagnostics(result, mol, mf, unrestricted)

    # Dipole moment in Debye (x,y,z).
    try:
        dip = np.asarray(mf.dip_moment(unit="Debye", verbose=0), dtype=float).ravel()
        if dip.size >= 3:
            result["dipole"] = rb.vec3(dip[0], dip[1], dip[2])
    except Exception as exc:  # noqa: BLE001
        _warn(result, f"dipole moment unavailable: {exc}")

    # Point group from PySCF topology detection. detect_symm returns (group, origin,
    # axes) on pyscf 2.13 — the old 2-tuple unpack raised on EVERY run and the blanket
    # except hid it, so point_group was always "" (exactly the silent-failure class
    # the warnings channel exists to expose).
    try:
        from pyscf import symm

        groupname = symm.detect_symm(mol._atom)[0]
        result["point_group"] = str(groupname)
    except Exception as exc:  # noqa: BLE001
        result["point_group"] = ""
        _warn(result, f"point-group detection unavailable: {exc}")


def _fill_spin_diagnostics(
    result: dict[str, Any], mol, mf, unrestricted: bool
) -> None:
    """Fill ⟨S²⟩ + per-atom spin populations for open-shell (or forced-unrestricted)
    mean-fields. Closed-shell restricted runs leave the contract defaults untouched.

    s_squared is the actual ⟨S²⟩ of the converged wavefunction (mf.spin_square);
    s_squared_exact is S(S+1) for the molecule's spin. A deviation beyond ~10% of
    exact (or 0.1 absolute for a forced-UHF singlet) is spin contamination and is
    SAID out loud. spin_populations is the Mulliken spin density (alpha−beta) summed
    per atom, same order as `charges` — works for UHF/UKS and ROHF/ROKS (both carry
    spin-separated density matrices)."""
    import numpy as np

    open_shell = int(getattr(mol, "spin", 0)) != 0
    if not (open_shell or unrestricted):
        return

    try:
        ss = float(mf.spin_square()[0])
        s = 0.5 * float(mol.spin)
        exact = s * (s + 1.0)
        result["s_squared"] = ss
        result["s_squared_exact"] = exact
        tol = 0.1 * exact if exact > 0.0 else 0.1
        if abs(ss - exact) > tol:
            _warn(result,
                  "spin contamination: <S²> = %.4f vs exact S(S+1) = %.3f for "
                  "multiplicity %d — the wavefunction is not a pure spin state; "
                  "energies/properties carry contamination error"
                  % (ss, exact, int(mol.spin) + 1))
    except Exception as exc:  # noqa: BLE001
        _warn(result, f"<S²> diagnostic unavailable: {exc}")

    try:
        dm = np.asarray(mf.make_rdm1())
        if dm.ndim == 3 and dm.shape[0] == 2:
            s1e = np.asarray(mf.get_ovlp())
            ao_spin = np.einsum("ij,ji->i", dm[0] - dm[1], s1e).real
            spins = [0.0] * int(mol.natm)
            for ao, label in enumerate(mol.ao_labels(fmt=None)):
                spins[int(label[0])] += float(ao_spin[ao])
            result["spin_populations"] = spins
        else:
            _warn(result, "spin populations unavailable: the mean-field carries no "
                          "spin-separated density matrix")
    except Exception as exc:  # noqa: BLE001
        _warn(result, f"spin populations unavailable: {exc}")


_COMPOSITION_MIN_WEIGHT = 0.05  # per-atom Löwdin weight below this is noise, not character
_COMPOSITION_MAX_ENTRIES = 4    # the Orbitals tab shows a one-line summary, not a table


def _lowdin_weights(ovlp, mo_coeff):
    """Per-AO Löwdin weight of every MO column: |S^{1/2} C|², shape (nao, nmo).

    Each column sums to exactly 1 (CᵀSC = 1), so the weights ARE the fraction of the
    MO living on each AO — the basis-set-stable population that Mulliken is not."""
    import numpy as np

    s = np.asarray(ovlp, dtype=float)
    evals, vecs = np.linalg.eigh(s)
    s_half = vecs @ np.diag(np.sqrt(np.clip(evals, 1e-12, None))) @ vecs.T
    c_l = s_half @ np.asarray(mo_coeff, dtype=float)
    return c_l * c_l


def _composition_entries(
    col_weights, ao_labels: list[tuple]
) -> list[dict[str, Any]]:
    """Bucket one MO's per-AO Löwdin weights into per-atom character entries.

    `ao_labels` is mol.ao_labels(fmt=None): (atom-idx, element, shell "3d", m-label).
    Returns [{"atom","element","weight","shell"}] — dominant shell per atom, filtered
    at _COMPOSITION_MIN_WEIGHT, descending weight, truncated to _COMPOSITION_MAX_ENTRIES.
    Pure over plain sequences so it is unit-testable without an SCF."""
    atoms: dict[int, dict[str, Any]] = {}
    for w, label in zip(col_weights, ao_labels):
        idx = int(label[0])
        entry = atoms.setdefault(
            idx, {"element": str(label[1]), "weight": 0.0, "shells": {}}
        )
        entry["weight"] += float(w)
        shell = str(label[2])
        entry["shells"][shell] = entry["shells"].get(shell, 0.0) + float(w)
    out: list[dict[str, Any]] = []
    for idx, entry in atoms.items():
        if entry["weight"] < _COMPOSITION_MIN_WEIGHT:
            continue
        shells = entry["shells"]
        shell = max(shells, key=shells.get) if shells else ""
        out.append(
            {
                "atom": idx,
                "element": entry["element"],
                "weight": round(float(entry["weight"]), 4),
                "shell": shell,
            }
        )
    out.sort(key=lambda e: (-e["weight"], e["atom"]))
    return out[:_COMPOSITION_MAX_ENTRIES]


def _mo_compositions(mol, ovlp, mo_coeff) -> list[list[dict[str, Any]]]:
    """Per-MO Löwdin atomic composition for one set of MO coefficients (one spin
    channel, or the restricted set) — pairs 1:1 with the MO columns."""
    weights = _lowdin_weights(ovlp, mo_coeff)
    labels = mol.ao_labels(fmt=None)
    return [_composition_entries(weights[:, i], labels) for i in range(weights.shape[1])]


def _split_nelecas(total: int, multiplicity: int) -> tuple[int, int]:
    """Split a total active-electron count into (na, nb) by the molecule's spin, so
    na+nb matches the total and na-nb equals the unpaired count. Matches AVAS's own
    nalpha = (nelecas + spin)//2 convention, so AVAS seeds split identically."""
    unpaired = abs(int(multiplicity) - 1)
    na = (int(total) + unpaired) // 2
    nb = int(total) - na
    return na, nb


def _note_reference_spin_diagnostics(result: dict[str, Any], mol, mf, method: str) -> None:
    """Say that s_squared / spin_populations describe the SCF reference when a
    correlated method replaced the headline energy. Charges/bond orders are re-filled
    from the correlated density; the spin diagnostics are not — an open-shell CCSD or
    CASSCF result would otherwise show UHF/ROHF spin data under a correlated label."""
    if int(getattr(mol, "spin", 0)) != 0 or _is_unrestricted(mf):
        _warn(result,
              "spin diagnostics (<S²>, spin populations) describe the %s reference, "
              "not the %s wavefunction" % (_reference_label(mf), method))


def _parse_active_space(
    spec: dict[str, Any], n_electrons: int, multiplicity: int | None = None
) -> tuple[int, tuple[int, int], list[int]]:
    """Read + validate the CASSCF active space from spec.params.

    Returns (ncas, (na, nb), mo_list). `mo_list` is the 0-based absolute MO indices the
    Analyze picker chose (empty -> let PySCF take the ncas orbitals around the Fermi
    level). nelecas may arrive as a total int or an explicit [na, nb]; an int is split
    by the molecule's spin so na+nb matches and na-nb equals the unpaired count.

    `multiplicity` should be the one the Mole was actually built with (mol.spin + 1) —
    the request's molecule block wins over spec.multiplicity at build time (sidecar
    precedence), so splitting by spec here could target a different spin state than
    the reference SCF. Falls back to spec when not given.
    """
    params = spec.get("params", {})
    params = params if isinstance(params, dict) else {}
    if "ncas" not in params or "nelecas" not in params:
        raise ValueError(
            "CASSCF requires an active space — set params.ncas (active orbitals) and "
            "params.nelecas (active electrons). Choose it in Analyze -> Orbitals after a "
            "reference run."
        )
    ncas = int(params["ncas"])
    if ncas < 1:
        raise ValueError("CASSCF params.ncas must be >= 1 (got %d)." % ncas)

    mult = int(multiplicity) if multiplicity is not None else int(spec.get("multiplicity", 1))
    unpaired = abs(mult - 1)
    raw = params["nelecas"]
    if isinstance(raw, (list, tuple)):
        na, nb = int(raw[0]), int(raw[1])
        # An explicit pair must agree with the molecule's spin — otherwise CASSCF
        # silently solves a DIFFERENT spin state (e.g. an Sz=0 active space under a
        # declared triplet) while the result still reports the declared multiplicity.
        if na - nb != unpaired:
            raise ValueError(
                "CASSCF params.nelecas [%d, %d] implies %d unpaired active electron(s), "
                "but multiplicity %d requires %d — the pair must match the molecule's "
                "spin state." % (na, nb, na - nb, mult, unpaired)
            )
    else:
        na, nb = _split_nelecas(int(raw), mult)
    if na < 0 or nb < 0:
        raise ValueError("CASSCF params.nelecas must be non-negative (got %r)." % (raw,))
    n_active = na + nb
    if n_active > 2 * ncas:
        raise ValueError(
            "CASSCF active space is impossible: %d active electrons cannot fit in %d "
            "active orbitals (max %d)." % (n_active, ncas, 2 * ncas)
        )
    # The doubly-occupied core is (n_electrons - n_active) / 2 orbitals — an odd
    # remainder means the active space misses an electron and pyscf dies later on a
    # bare AssertionError; say it here with names.
    if (n_electrons - n_active) % 2 != 0:
        raise ValueError(
            "CASSCF active space leaves an odd core electron count: %d total electrons "
            "minus %d active leaves %d, which cannot form doubly-occupied core orbitals. "
            "Adjust params.nelecas (unpaired electrons must all be active)."
            % (n_electrons, n_active, n_electrons - n_active)
        )

    mo_list = [int(i) for i in params.get("cas_mo_list", [])]
    if mo_list and len(mo_list) != ncas:
        raise ValueError(
            "CASSCF params.cas_mo_list selects %d orbitals but params.ncas is %d — they "
            "must match." % (len(mo_list), ncas)
        )
    return ncas, (na, nb), mo_list


def _run_casscf(
    mol, mf, spec: dict[str, Any]
) -> tuple[float, dict[str, Any], list[float], list[float], Any]:
    """Run CASSCF on a converged mean-field reference.

    Returns (total_energy, cas_block, mo_energy, mo_occ, mc): the CASSCF total energy,
    the result-contract block, a full-length MO energy/occupation pair (core=2,
    active=natural occupations, virtual=0) so the Analyze Orbitals tab can render the
    CASSCF natural orbitals, and the converged CASSCF object itself (the cube
    generator needs `mc.mo_coeff` / `mc.make_rdm1()` — previously cubes were written
    from the HF reference orbitals underneath the natural-occupation ladder).

    `natorb=True` pins the active block of `mc.mo_coeff` to the NATURAL orbitals
    (occupation-sorted), so column i of mo_coeff genuinely corresponds to mo_occ[i]
    — without it the active columns are arbitrary rotations of the active space and
    the occupation ladder would label the wrong surfaces.
    """
    n_electrons = int(mol.nelectron)
    # Multiplicity from the Mole itself (mol.spin + 1) — the molecule block wins over
    # spec.multiplicity at build time, so the split must follow the same authority.
    ncas, nelecas, mo_list = _parse_active_space(spec, n_electrons, int(mol.spin) + 1)

    mc = _make_casscf(mf, ncas, nelecas, spec)
    if mo_list:
        # 0-based absolute MO indices the user picked in Analyze -> sort them to the front
        # of the active window. base=0 matches Orbital.index (PySCF defaults to base=1).
        mo = mc.sort_mo(mo_list, base=0)
        mc.kernel(mo)
    else:
        mc.kernel()

    ncore = int(mc.ncore)
    natural_occ, ci_weights, cas_s_squared = _casscf_summary(mc, ncas, nelecas)

    active_mos = sorted(mo_list) if mo_list else list(range(ncore, ncore + ncas))
    block = rb.cas_block(
        ncas=ncas,
        nelecas=nelecas,
        ncore=ncore,
        active_mos=active_mos,
        natural_occ=natural_occ,
        ci_weights=ci_weights,
        converged=bool(getattr(mc, "converged", False)),
    )
    if cas_s_squared is not None:
        block["s_squared"] = cas_s_squared  # the CAS wavefunction's own <S²>

    mo_energy, mo_occ = _casscf_mo_ladder(mc, mf, ncore, ncas, natural_occ)
    return float(mc.e_tot), block, mo_energy, mo_occ, mc


def _make_casscf(mf, ncas: int, nelecas: tuple[int, int], spec: dict[str, Any]):
    """A fresh CASSCF object with the sidecar's conventions applied: natorb=True (the
    active mo_coeff block = natural orbitals, see _run_casscf docstring) plus the
    params.cas_max_cycle_macro / cas_conv_tol knobs. Fresh per kernel run — a reused
    mc retains converged/ci state across kernels."""
    from pyscf import mcscf

    mc = mcscf.CASSCF(mf, ncas, nelecas)
    mc.natorb = True
    params = spec.get("params", {})
    params = params if isinstance(params, dict) else {}
    mc.max_cycle_macro = int(params.get("cas_max_cycle_macro", 50))
    if "cas_conv_tol" in params:
        mc.conv_tol = float(params["cas_conv_tol"])
    return mc


def _casscf_summary(
    mc, ncas: int, nelecas: tuple[int, int]
) -> tuple[list[float], list[float], float | None]:
    """(natural_occ, ci_weights, s_squared) of a converged CASSCF: active
    natural-orbital occupations from the active-space 1-RDM (spin-traced, 0..2,
    descending), the leading determinant weights (|c|², a multireference diagnostic),
    and the CAS wavefunction's own <S²> (None if the solver can't provide it) — the
    top-level s_squared describes the SCF reference, not this wavefunction."""
    import numpy as np

    casdm1 = mc.fcisolver.make_rdm1(mc.ci, ncas, nelecas)
    natural_occ = sorted((float(x) for x in np.linalg.eigvalsh(casdm1)), reverse=True)

    ci = np.asarray(mc.ci, dtype=float).ravel()
    weights = sorted((float(c * c) for c in ci), reverse=True)
    ci_weights = [w for w in weights[:6] if w > 1e-3]

    try:
        s_squared = float(mc.fcisolver.spin_square(mc.ci, ncas, nelecas)[0])
    except Exception:  # noqa: BLE001 — diagnostic only; never fails the run
        s_squared = None
    return natural_occ, ci_weights, s_squared


def _casscf_mo_ladder(
    mc, mf, ncore: int, ncas: int, natural_occ: list[float]
) -> tuple[list[float], list[float]]:
    """Full MO (energy, occupation) picture for the Orbitals tab: doubly-occupied core,
    fractional active naturals, empty virtuals. Energies from the CASSCF canonical MOs
    when present."""
    import numpy as np

    mo_energy_src = getattr(mc, "mo_energy", None)
    if mo_energy_src is None:
        mo_energy_src = mf.mo_energy
    mo_energy = [float(e) for e in np.asarray(mo_energy_src, dtype=float).ravel()]
    nmo = len(mo_energy)
    nvirt = max(0, nmo - ncore - ncas)
    mo_occ = [2.0] * ncore + list(natural_occ) + [0.0] * nvirt
    if len(mo_occ) < nmo:  # guard against any off-by-one from a custom solver
        mo_occ += [0.0] * (nmo - len(mo_occ))
    mo_occ = mo_occ[:nmo]
    return mo_energy, mo_occ


# ───────────────────── automatic active-space selection (cas_auto) ─────────────────────

_CAS_AUTO_TARGETS = {"metal_d", "atoms_p", "custom"}

# Natural-occupation window OUTSIDE which an orbital is correlation-inactive
# (occ ≈ 2 or ≈ 0): such an orbital only stays active on target character.
_CAS_AUTO_OCC_LO = 0.02
_CAS_AUTO_OCC_HI = 1.98


def _transition_metal_d_labels(symbols: list[str]) -> list[str]:
    """AVAS AO labels for every transition metal present: "<El> 3d/4d/5d" by row
    (Sc–Zn → 3d, Y–Cd → 4d, La + Hf–Hg → 5d), deduplicated by element. Pure over a
    symbol list — unit-testable without an SCF. No transition metal → ValueError."""
    from pyscf.data import elements

    labels: list[str] = []
    seen: set[str] = set()
    for sym in symbols:
        s = str(sym)
        if s in seen:
            continue
        seen.add(s)
        z = int(elements.charge(s))
        if 21 <= z <= 30:
            shell = "3d"
        elif 39 <= z <= 48:
            shell = "4d"
        elif z == 57 or 72 <= z <= 80:
            shell = "5d"
        else:
            continue
        labels.append(f"{s} {shell}")
    if not labels:
        raise ValueError(
            "cas_auto target 'metal_d' found no transition metal in this molecule — "
            "use target 'atoms_p' (pick the ligand atoms) or 'custom' AO labels instead."
        )
    return labels


def _atoms_p_labels(symbols: list[str], atoms: list[int]) -> list[str]:
    """AVAS AO labels for the valence p shell of specific atoms: "<idx> <El> <n>p"
    (atom-index-qualified, so only THOSE atoms' shells enter the target). Pure over a
    symbol list. H/He (no p shell) or an out-of-range index → ValueError."""
    from pyscf.data import elements

    if not atoms:
        raise ValueError(
            "cas_auto target 'atoms_p' needs params.cas_auto.atoms — the 0-based "
            "indices of the atoms whose valence p shells define the target."
        )
    labels: list[str] = []
    for idx_raw in atoms:
        idx = int(idx_raw)
        if idx < 0 or idx >= len(symbols):
            raise ValueError(
                "cas_auto.atoms index %d is out of range for a %d-atom molecule."
                % (idx, len(symbols))
            )
        s = str(symbols[idx])
        z = int(elements.charge(s))
        if z <= 2:
            raise ValueError(
                "cas_auto target 'atoms_p': atom %d (%s) has no valence p shell." % (idx, s)
            )
        n = 2 if z <= 10 else 3 if z <= 18 else 4 if z <= 36 else 5 if z <= 54 else 6
        labels.append(f"{idx} {s} {n}p")
    return labels


def _parse_cas_auto(spec: dict[str, Any]) -> dict[str, Any]:
    """Validated params.cas_auto knobs with defaults. Fail-loud: unknown target,
    coexistence with a manual active space, and a custom target without labels are
    all rejected here rather than degrading into a silently-wrong active space."""
    params = spec.get("params", {})
    params = params if isinstance(params, dict) else {}
    raw = params.get("cas_auto")
    if not isinstance(raw, dict):
        raise ValueError("params.cas_auto must be a dict of auto-active-space settings.")
    if "ncas" in params or "nelecas" in params:
        raise ValueError(
            "params.cas_auto and a manual active space (params.ncas / params.nelecas) "
            "are mutually exclusive — pick one."
        )
    target = str(raw.get("target", "")).strip().lower()
    if target not in _CAS_AUTO_TARGETS:
        raise ValueError(
            "Unknown cas_auto.target %r; known: %s." % (target, sorted(_CAS_AUTO_TARGETS))
        )
    out = {
        "target": target,
        "atoms": [int(i) for i in raw.get("atoms", [])],
        "ao_labels": [str(s) for s in raw.get("ao_labels", [])],
        "avas_threshold": float(raw.get("avas_threshold", 0.2)),
        "char_threshold": float(raw.get("char_threshold", 0.4)),
        "max_iter": max(1, int(raw.get("max_iter", 3))),
        "max_ncas": int(raw.get("max_ncas", 12)),
        # Open-shell AVAS: 2 (pyscf default) may rotate a low-target-character SOMO
        # into the doubly-occupied core; 3 keeps the SOMOs fully active.
        "openshell_option": int(raw.get("openshell_option", 2)),
    }
    if out["openshell_option"] not in (2, 3):
        raise ValueError(
            "cas_auto.openshell_option must be 2 (project SOMOs with the occupied "
            "block, pyscf default) or 3 (keep SOMOs fully active); got %r."
            % raw.get("openshell_option")
        )
    if target == "custom" and not out["ao_labels"]:
        raise ValueError(
            "cas_auto target 'custom' needs params.cas_auto.ao_labels — pyscf AO-label "
            "patterns such as 'Fe 3d' or '1 N 2p'."
        )
    return out


def _run_auto_casscf(
    mol, mf, spec: dict[str, Any]
) -> tuple[float, dict[str, Any], list[float], list[float], Any, list[str]]:
    """Automatic CASSCF active-space selection: AVAS seed → CASSCF → score the
    converged natural orbitals' target character (Löwdin weight on the target AOs)
    → swap junk actives for characterful externals → re-kernel, up to max_iter.

    An active orbital SURVIVES on either target character ≥ char_threshold or a
    fractional natural occupation (correlation-active); one failing both is junk.
    Swaps are occupancy-class-matched — a doubly-occupied junk active only trades
    with a core candidate, an empty one only with a virtual — so the active-electron
    count the guess implies stays consistent with nelecas.

    Returns (_run_casscf's tuple..., notes): honesty notes the caller relays into the
    result's warnings channel (unstable search, unpairable junk)."""
    import re

    import numpy as np
    from pyscf.mcscf import avas as avas_mod

    auto = _parse_cas_auto(spec)
    symbols = [mol.atom_symbol(i) for i in range(mol.natm)]
    if auto["target"] == "metal_d":
        labels = _transition_metal_d_labels(symbols)
    elif auto["target"] == "atoms_p":
        labels = _atoms_p_labels(symbols, auto["atoms"])
    else:
        labels = auto["ao_labels"]

    _emit_phase("casscf")

    try:
        target_idx = np.asarray(mol.search_ao_label(labels), dtype=int)
    except re.error as exc:
        raise ValueError("cas_auto AO label pattern is invalid: %s" % exc) from exc
    if target_idx.size == 0:
        raise ValueError(
            "cas_auto AO labels %r match no basis function of this molecule/basis."
            % (labels,)
        )

    # AVAS returns numpy ints — cast NOW or json.dumps rejects the result downstream.
    # verbose=0: AVAS logs its projection analysis to stdout, which must stay silent
    # (the QPROG line protocol owns it).
    ncas_seed, nelecas_total, mo = avas_mod.avas(
        mf, labels, threshold=auto["avas_threshold"],
        openshell_option=auto["openshell_option"], verbose=0,
    )
    ncas = int(ncas_seed)
    if ncas < 1:
        raise ValueError(
            "cas_auto AVAS seeding selected an empty active space for labels %r — "
            "either lower params.cas_auto.avas_threshold (currently %.2f), or the "
            "labels name shells that are unoccupied in the free atoms (AVAS projects "
            "onto a minimal atomic reference, so e.g. Li 2p cannot be targeted)."
            % (labels, auto["avas_threshold"])
        )
    if ncas > auto["max_ncas"]:
        raise ValueError(
            "cas_auto AVAS seeding selected %d active orbitals, above the max_ncas cap "
            "of %d — raise params.cas_auto.max_ncas or raise avas_threshold to shrink "
            "the space." % (ncas, auto["max_ncas"])
        )
    # mol.spin + 1, not spec.multiplicity: the Mole's spin is the authority (the
    # molecule block wins at build time) and matches what AVAS itself split by.
    nelecas = _split_nelecas(int(nelecas_total), int(mol.spin) + 1)

    ovlp = mf.get_ovlp()
    char_min = auto["char_threshold"]
    iterations: list[dict[str, Any]] = []
    best: tuple | None = None  # (rank, mc, natural_occ, ci_weights)
    converged_search = False
    unpairable = 0

    for k in range(1, auto["max_iter"] + 1):
        mc = _make_casscf(mf, ncas, nelecas, spec)  # fresh: a reused mc retains state
        mc.kernel(mo)
        _emit_progress({"t": "cas", "iter": k, "e": float(mc.e_tot), "ncas": ncas})
        natural_occ, ci_weights, cas_s_squared = _casscf_summary(mc, ncas, nelecas)
        ncore = int(mc.ncore)
        # natorb=True pins active columns to occupation-DESCENDING natural orbitals,
        # so natural_occ[i] belongs to absolute column ncore+i of THIS iteration's
        # mo_coeff (indices are not comparable across iterations).
        char = _lowdin_weights(ovlp, mc.mo_coeff)[target_idx, :].sum(axis=0)
        nmo = int(char.shape[0])
        active = list(range(ncore, ncore + ncas))

        junk = [
            (col, natural_occ[i])
            for i, col in enumerate(active)
            if char[col] < char_min
            and not (_CAS_AUTO_OCC_LO < natural_occ[i] < _CAS_AUTO_OCC_HI)
        ]
        core_cands = [c for c in range(ncore) if char[c] >= char_min]
        virt_cands = [c for c in range(ncore + ncas, nmo) if char[c] >= char_min]
        # Deterministic order: worst-character junk goes first, best-character
        # candidates come first.
        junk.sort(key=lambda t: (float(char[t[0]]), t[0]))
        core_cands.sort(key=lambda c: (-float(char[c]), c))
        virt_cands.sort(key=lambda c: (-float(char[c]), c))

        swaps: list[dict[str, int]] = []
        new_active = set(active)
        for col, occ in junk:
            pool = core_cands if occ >= _CAS_AUTO_OCC_HI else virt_cands
            if not pool:
                unpairable += 1
                continue
            cand = pool.pop(0)
            new_active.discard(col)
            new_active.add(cand)
            swaps.append({"out": int(col), "in": int(cand)})

        iterations.append(
            {
                "iter": k,
                "energy": float(mc.e_tot),
                "converged": bool(getattr(mc, "converged", False)),
                "active_mos": [int(c) for c in active],
                "char_scores": [round(float(char[c]), 4) for c in active],
                "swaps": swaps,
            }
        )

        rank = (0 if getattr(mc, "converged", False) else 1, float(mc.e_tot))
        if best is None or rank < best[0]:
            best = (rank, mc, natural_occ, ci_weights, cas_s_squared)

        if not swaps:
            converged_search = True
            break
        if k < auto["max_iter"]:
            mo = mc.sort_mo(sorted(new_active), base=0)

    notes: list[str] = []
    if not converged_search:
        notes.append(
            "cas_auto search did not stabilize within %d iterations — keeping the best "
            "iteration found; raise params.cas_auto.max_iter or adjust char_threshold."
            % auto["max_iter"]
        )
    if unpairable:
        notes.append(
            "cas_auto: %d low-character inactive orbital(s) stayed in the active space "
            "— no same-occupancy candidate with target character was available to swap "
            "in." % unpairable
        )

    _rank, mc, natural_occ, ci_weights, cas_s_squared = best
    ncore = int(mc.ncore)
    auto_search = {
        "target": auto["target"],
        "ao_labels": [str(s) for s in labels],
        "avas_threshold": auto["avas_threshold"],
        "char_threshold": auto["char_threshold"],
        "iterations": iterations,
        "converged_search": converged_search,
    }
    block = rb.cas_block(
        ncas=ncas,
        nelecas=nelecas,
        ncore=ncore,
        active_mos=list(range(ncore, ncore + ncas)),
        natural_occ=natural_occ,
        ci_weights=ci_weights,
        converged=bool(getattr(mc, "converged", False)),
        auto_search=auto_search,
    )
    if cas_s_squared is not None:
        block["s_squared"] = cas_s_squared  # the CAS wavefunction's own <S²>
    mo_energy, mo_occ = _casscf_mo_ladder(mc, mf, ncore, ncas, natural_occ)
    return float(mc.e_tot), block, mo_energy, mo_occ, mc, notes


# ─────────────────────────── post-HF correlation (MP2 / CCSD / FCI) ───────────────────────────


def _post_hf_density_ao(obj, mf):
    """AO-basis 1-RDM from an MP2/CCSD object's make_rdm1() (MO basis), restricted or
    unrestricted. Returns None on any failure so the caller degrades to the HF-reference
    charges with a warning rather than crashing the whole job."""
    import numpy as np

    try:
        dm_mo = obj.make_rdm1()
        if _is_unrestricted(mf):
            mo_a, mo_b = np.asarray(mf.mo_coeff[0]), np.asarray(mf.mo_coeff[1])
            dma, dmb = np.asarray(dm_mo[0]), np.asarray(dm_mo[1])
            # Keep the (alpha, beta) pair — summing here would drop the (P^spin·S)²
            # term from the Mayer bond orders downstream (charges split a summed dm
            # fine, but the open-shell bond-order formula needs the spin density).
            return np.asarray([mo_a @ dma @ mo_a.T, mo_b @ dmb @ mo_b.T])
        mo = np.asarray(mf.mo_coeff)
        return mo @ np.asarray(dm_mo) @ mo.T
    except Exception:  # noqa: BLE001 — caller warns + falls back to HF charges
        return None


def _fci_density_ao(cisolver, civec, mf):
    """AO-basis 1-RDM from an FCI solution (restricted reference only). None on failure."""
    import numpy as np

    try:
        if _is_unrestricted(mf):
            return None  # UHF-FCI rdm1 transform not wired — degrade to HF charges
        mo = np.asarray(mf.mo_coeff)
        norb = mo.shape[1]
        dm_mo = cisolver.make_rdm1(civec, norb, mf.mol.nelec)
        return mo @ np.asarray(dm_mo) @ mo.T
    except Exception:  # noqa: BLE001
        return None


def _guard_fci_size(mf) -> None:
    """Refuse an FCI whose determinant space would hang/OOM the sidecar — fail loud
    with the cap in the message instead of letting the solver run away."""
    import numpy as np

    mo = mf.mo_coeff[0] if _is_unrestricted(mf) else mf.mo_coeff
    norb = int(np.asarray(mo).shape[-1])
    nelec = int(mf.mol.nelectron)
    if norb > _FCI_MAX_ORBITALS or nelec > _FCI_MAX_ELECTRONS:
        raise ValueError(
            "FCI is refused for this system: %d spatial orbitals / %d electrons exceeds "
            "the sidecar cap of %d orbitals / %d electrons (the determinant space grows "
            "combinatorially). Use a smaller basis, CASSCF with a picked active space, "
            "or CCSD(T)." % (norb, nelec, _FCI_MAX_ORBITALS, _FCI_MAX_ELECTRONS)
        )


def _frozen_core_orbitals(mf, frozen_core: bool) -> int | None:
    """Number of lowest MOs to freeze, or None to correlate all electrons.

    Frozen core is the default in Gaussian, ORCA and Q-Chem, so essentially every published
    MP2/CCSD/CCSD(T) number is frozen-core; correlating the core in a VALENCE
    correlation-consistent set (cc-pVXZ, def2-XVP) is also unbalanced and converges badly
    with basis. The composer's "Frozen core" control used to reach only the quantum backend,
    so the classical path was always all-electron — 1.45 kcal/mol off on water/cc-pVDZ MP2,
    and not comparable to literature at the stated level.

    pyscf counts the frozen orbitals, so map the standard core per element (He-core for
    Li-Ne, Ne-core for Na-Ar, and so on) onto an orbital count.
    """
    if not frozen_core:
        return None
    mol = mf.mol
    n_core = 0
    for z in mol.atom_charges():
        z = int(z)
        if z <= 2:
            continue          # H, He: no core
        elif z <= 10:
            n_core += 1       # Li-Ne: 1s
        elif z <= 18:
            n_core += 5       # Na-Ar: 1s2s2p
        elif z <= 36:
            n_core += 9       # K-Kr: + 3s3p
        elif z <= 54:
            n_core += 18
        else:
            n_core += 27
    return n_core or None


def _t1_diagnostic(cc_obj, mf) -> float | None:
    """T1 diagnostic = ||t1|| / sqrt(n_correlated_electrons), or None if unavailable.

    The standard single-reference sanity check on a coupled-cluster result. Above ~0.02
    (0.045 for open shell) the reference is too multireference for CCSD to be trusted, and
    nothing computed it before.
    """
    import numpy as np

    try:
        t1 = cc_obj.t1
        if isinstance(t1, (tuple, list)):   # unrestricted: (t1a, t1b)
            norm = float(np.linalg.norm(
                np.concatenate([np.asarray(x).ravel() for x in t1])))
        else:
            norm = float(np.linalg.norm(np.asarray(t1)))
        occ = np.asarray(mf.mo_occ)
        n_elec = int(occ.sum())             # works for both restricted and unrestricted
        return norm / float(max(n_elec, 1) ** 0.5)
    except Exception:  # noqa: BLE001 — a diagnostic must never fail the job
        return None


def _warn_estimator_uncertainty(
    result: dict[str, Any], method_label: str, params: dict[str, Any],
    *, stochastic: bool = False, extra: str = "",
) -> None:
    """State what a signal-based phase estimate's `converged: true` is actually worth.

    QPE's resolution honesty (it quantizes to a phase-register bin, so it is not a
    variational bound) was applied to `action_qpe` alone. Every sibling — QCELS, RPE, QMEGS,
    BPE, BPDE, QKD — ends with the same bare unconditional flag while fitting a phase to a
    FINITE signal: least squares, Bayesian inference or a Krylov projection, none of them
    variational, none carrying an error bound. Measured on H2/STO-3G against exact FCI,
    QCELS and RPE both landed BELOW the true eigenvalue.

    `stochastic` adds the shot-noise caveat: seeding those runs makes them reproducible,
    which hides rather than removes the noise — change the seed and the number moves with
    nothing on screen to explain it.
    """
    msg = ("%s estimates the eigenvalue by fitting a finite signal, so it is NOT a "
           "variational upper bound — the error has no guaranteed sign or magnitude and the "
           "result can fall below the exact eigenvalue. Treat the reported energy as an "
           "estimate without an error bar, not as a converged variational result."
           % method_label)
    if extra:
        msg += " Note that %s." % extra
    _warn(result, msg)
    if stochastic:
        _warn(result,
              "%s is a SAMPLED estimate (shots = %s per round). The run is seeded, so it "
              "reproduces exactly — but that fixes the noise in place rather than removing "
              "it: a different seed gives a different answer, and the spread is not reported."
              % (method_label, params.get("shots", "engine default")))


def _check_multireference(result: dict[str, Any], cas: dict[str, Any]) -> None:
    """Interpret a CASSCF wavefunction's multireference character out loud (M7).

    The `cas` block already carried natural occupations and CI weights; nothing read them.
    The standard flags are a leading CI weight below ~0.9, or an active natural occupation
    more than ~0.1 away from a clean 2 or 0. Measured on H2 at 2.5 A / 6-31G: occupations
    1.291/0.709 and a reference weight of 0.645 — as multireference as it gets — reported
    with an empty warnings channel. It matters beyond CASSCF itself: at that reference
    quality a single-reference CCSD or MP2 on the same system is not trustworthy.
    """
    try:
        occ = [float(x) for x in (cas.get("natural_occ") or [])]
        weights = [float(w) for w in (cas.get("ci_weights") or [])]
    except (TypeError, ValueError):
        return
    lead = max(weights) if weights else None
    worst = max((min(abs(o - 2.0), abs(o)) for o in occ), default=0.0)
    if (lead is not None and lead < 0.9) or worst > 0.1:
        detail = []
        if lead is not None:
            detail.append("leading configuration weight %.3f" % lead)
        if occ:
            detail.append("active natural occupations %s"
                          % ", ".join("%.3f" % o for o in occ))
        _warn(result,
              "Strong multireference character (%s). A single determinant does not describe "
              "this system, so single-reference results on it (MP2, CCSD, and DFT energies) "
              "are unreliable here — this is the regime CASSCF/CASPT2 or NEVPT2 exists for."
              % "; ".join(detail))


def _run_post_hf(method: str, mf, frozen_core: bool = False):
    """Run an MP2/CCSD/CCSD(T)/FCI correlation calculation on a converged mean-field `mf`.

    Returns (total_energy, corr_energy, converged, dm_ao, notes) where dm_ao is the
    correlated AO 1-RDM (or None when it could not be formed) and `notes` are non-fatal
    honesty warnings for the result's warnings channel. The reference is HF:
    `action_energy` builds `mf` with the method stripped to HF, so `mf.e_tot` is the SCF
    energy and total_energy is the correlated total (electronic + nuclear)."""
    notes: list[str] = []
    frozen = _frozen_core_orbitals(mf, frozen_core)
    if frozen:
        notes.append("frozen core: the lowest %d orbital(s) were not correlated "
                     "(the Gaussian/ORCA/Q-Chem default)" % frozen)
    elif frozen_core:
        pass  # asked for, but this system has no core orbitals (H/He only) — nothing to say
    else:
        notes.append("ALL-ELECTRON correlation (frozen core explicitly off) — published "
                     "MP2/CCSD numbers are usually frozen-core, and correlating the core in "
                     "a valence correlation-consistent basis (cc-pVXZ, def2-XVP) is "
                     "unbalanced, so this energy is not directly comparable to literature "
                     "at the stated level")
    # PySCF has no RO-MP2/RO-CCSD: an ROHF reference is silently converted to UHF and
    # UMP2/UCCSD runs on the copied orbitals (pyscf logs this at a verbosity we mute).
    # Say it — "ROHF-MP2" on the result would otherwise imply ROMP2.
    if _is_rohf(mf) and method in ("MP2", "CCSD", "CCSD(T)"):
        notes.append(
            "ROHF reference: PySCF computes %s as the unrestricted U%s on the ROHF "
            "orbitals converted to UHF (no RO-correlation implementation)"
            % (method, method)
        )
    def _t1_note(c) -> None:
        """Attach the single-reference sanity check to the notes (M7)."""
        t1 = _t1_diagnostic(c, mf)
        if t1 is None:
            return
        limit = 0.045 if _is_unrestricted(mf) or _is_rohf(mf) else 0.02
        if t1 > limit:
            notes.append(
                "T1 diagnostic = %.4f, above the %.3f single-reference guideline: this "
                "system has significant multireference character and the coupled-cluster "
                "energy may be unreliable. Consider CASSCF/CASPT2 or check for strong "
                "static correlation (stretched bonds, diradicals, transition metals)."
                % (t1, limit))
        else:
            notes.append("T1 diagnostic = %.4f (below the %.3f single-reference guideline)"
                         % (t1, limit))

    if method == "MP2":
        from pyscf import mp

        m = mp.MP2(mf, frozen=frozen).run()
        return float(m.e_tot), float(m.e_corr), True, _post_hf_density_ao(m, mf), notes
    if method == "CCSD":
        from pyscf import cc

        c = cc.CCSD(mf, frozen=frozen).run()
        _t1_note(c)
        return (float(c.e_tot), float(c.e_corr),
                bool(getattr(c, "converged", False)), _post_hf_density_ao(c, mf), notes)
    if method == "CCSD(T)":
        from pyscf import cc

        c = cc.CCSD(mf, frozen=frozen).run()
        _t1_note(c)
        e_t = float(c.ccsd_t())  # perturbative triples correction
        notes.append(
            "CCSD(T) charges/bond orders are reported from the CCSD density — the (T) "
            "correction is an energy-only perturbation with no relaxed density here"
        )
        return (float(c.e_tot) + e_t, float(c.e_corr) + e_t,
                bool(getattr(c, "converged", False)), _post_hf_density_ao(c, mf), notes)
    if method == "FCI":
        from pyscf import fci

        _guard_fci_size(mf)
        cisolver = fci.FCI(mf)
        e_tot, civec = cisolver.kernel()
        e_corr = float(e_tot) - float(mf.e_tot)
        return float(e_tot), e_corr, True, _fci_density_ao(cisolver, civec, mf), notes
    raise NotImplementedError("unhandled post-HF method %r" % method)


# ─────────────────────────── actions ───────────────────────────


def action_capabilities(request: dict[str, Any]) -> dict[str, Any]:
    """Write the capability probe document (NOT a JobResult). Returns it too.

    `engine_version` lets the app compare the installed engine against the version it
    was released with (user-managed venv model) and surface an update hint on mismatch.
    """
    import quchemy

    doc = {
        "capabilities": detect_capabilities(),
        "engine_version": str(getattr(quchemy, "__version__", "")),
        "ok": True,
    }
    with open(request["output_path"], "w", encoding="utf-8") as fh:
        json.dump(doc, fh, indent=2)
    return doc


# Capability → pip requirements. Architecture-specific extras are resolved against THIS
# interpreter's platform in _packages_for_capability (the authoritative source — the
# sidecar's own machine, not the UI's guess). Versions mirror pyproject.toml.
_CAPABILITY_PACKAGES: dict[str, list[str]] = {
    "pyscf": ["pyscf==2.13.1"],
    "openfermion": ["openfermion==1.7.1"],
    "cclib": ["cclib==1.8.1"],
    "rdkit": ["rdkit==2026.3.2"],
    "openbabel": ["openbabel-wheel==3.1.1.23"],
    "geometric": ["geometric==1.1.1"],
    # qiskit 1.x has no Python-3.14 wheel (a Rust source build that fails without a toolchain),
    # so pin to the 2.x line — it ships cp314 wheels, qiskit-ibm-runtime accepts it, and
    # EfficientSU2 still exists (removed in 3.0; the ibmq action also falls back to the
    # efficient_su2 function).
    "qiskit": ["qiskit>=2.0,<3"],
    # qiskit-ibm-runtime >=0.40: the legacy "ibm_quantum" channel was removed and IBM Quantum
    # Platform Classic sunset 2025-07-01, so action_ibmq targets the new platform
    # (channel="ibm_quantum_platform" + instance CRN, EstimatorV2/Session) — which needs a 0.40+
    # runtime. The floor keeps an old wheel from satisfying the install with a broken channel.
    "qiskit_ibm_runtime": ["qiskit>=2.0,<3", "qiskit-ibm-runtime>=0.40"],
    # SQD (sample-based quantum diagonalization): the addon (jax/jaxlib/pyscf/qiskit) + ffsim
    # for the LUCJ ansatz. Installed wheels-only (see _pip_commands_for_capability) — the
    # resolver otherwise backtracks into a from-source numpy build that fails on Python 3.14.
    "sqd": ["qiskit-addon-sqd", "ffsim"],
    "dispersion": ["pyscf-dispersion==1.0.0"],
    # MACE ML potential: mace-torch's full dependency set MINUS matscipy (no Python-3.14 wheel —
    # the sidecar's ASE-backed shim covers its one neighbour-list call). mace-torch itself is
    # then installed --no-deps (see _pip_commands_for_capability) so pip never tries to build
    # matscipy. e3nn is pinned as mace-torch pins it.
    "mace": [
        "torch", "ase", "e3nn==0.4.4", "numpy", "opt_einsum", "torch-ema", "prettytable",
        "h5py", "torchmetrics", "python-hostlist", "configargparse", "GitPython", "pyYAML",
        "tqdm", "lmdb", "orjson", "matplotlib", "pandas", "mace-torch",
    ],
}


def _pip_commands_for_capability(capability: str, packages: list[str]) -> list[list[str]]:
    """The pip-argument lists to run (in order) to install `capability`. One command for most
    capabilities; MACE needs two — its deps WITH their sub-deps, then `mace-torch --no-deps`
    so pip never tries to build matscipy (the sidecar's shim provides it at runtime)."""
    if capability == "mace":
        deps = [p for p in packages if p != "mace-torch"]
        return [deps, ["--no-deps", "mace-torch"]]
    if capability == "sqd":
        # Wheels-only: ffsim ships cp310-abi3 wheels (run on 3.14) and jaxlib cp314 wheels;
        # forcing binaries stops the resolver building numpy from source on Python 3.14.
        return [["--only-binary=:all:", *packages]]
    return [list(packages)]


def _packages_for_capability(capability: str) -> list[str]:
    """pip requirements that provide `capability` ON THIS interpreter's platform.

    Architecture matters for dispersion: pyscf-dispersion's macOS wheel ships x86_64-ONLY
    libs-dftd3/libdftd4, so on Apple Silicon we ALSO install the arm64 standalone dftd3/
    dftd4 packages (the sidecar's load shim redirects pyscf.dispersion to their C libraries).
    Returns [] for an unknown or non-pip-installable capability (e.g. 'smd', which needs a
    PySCF rebuilt with -DENABLE_SMD)."""
    pkgs = list(_CAPABILITY_PACKAGES.get(capability, []))
    if not pkgs:
        return []
    machine = platform.machine().lower()
    is_arm = machine in ("arm64", "aarch64")
    if capability == "dispersion" and sys.platform == "darwin" and is_arm:
        pkgs += ["dftd3==1.4.0", "dftd4==4.2.0"]
    return pkgs


def action_install_capability(request: dict[str, Any]) -> dict[str, Any]:
    """Quick-install the pip package(s) providing a missing sidecar capability, choosing the
    right ones for THIS interpreter's architecture (the Config → Engines "missing" click).

    pip runs against the running interpreter (`sys.executable -m pip install …`), so it
    lands in the exact venv the sidecar uses. The capability name comes from a fixed map —
    never an arbitrary package string — so there is no package-injection surface. Returns a
    simple doc {ok, capability, packages, returncode, installed, message, capabilities, log};
    never raises (a failed install reports installed=False with the pip log tail)."""
    import importlib
    import subprocess

    capability = str(request.get("capability", "")).strip()
    packages = _packages_for_capability(capability)
    if not packages:
        msg = (
            "%r needs a PySCF built with that feature (e.g. -DENABLE_SMD) — pip cannot "
            "install it." % capability if capability == "smd"
            else "Unknown capability %r — nothing to install." % capability)
        return _write_doc(request, {
            "ok": False, "capability": capability, "packages": [], "returncode": -1,
            "installed": bool(detect_capabilities().get(capability, False)),
            "message": msg, "capabilities": detect_capabilities(), "log": "",
        })

    # Most capabilities install in one pip command; some (MACE) need a sequence — run each
    # in order and stop at the first failure, accumulating the log.
    rc, log = 0, ""
    try:
        for args in _pip_commands_for_capability(capability, packages):
            proc = subprocess.run(
                [sys.executable, "-m", "pip", "install", *args],
                capture_output=True, text=True, timeout=1800)
            rc = proc.returncode
            log = (log + "\n" + proc.stdout + "\n" + proc.stderr).strip()
            if rc != 0:
                break
    except Exception as exc:  # noqa: BLE001 — report, never crash the sidecar
        rc, log = -1, f"{type(exc).__name__}: {exc}"

    # Make freshly-installed packages importable in THIS process before re-probing.
    importlib.invalidate_caches()
    caps = detect_capabilities()
    installed = bool(caps.get(capability, False))
    message = (
        "Installed %s — %s is now available." % (", ".join(packages), capability)
        if installed
        else "pip exited %d and %s is still unavailable; see the log." % (rc, capability))
    return _write_doc(request, {
        "ok": rc == 0, "capability": capability, "packages": packages, "returncode": rc,
        "installed": installed, "message": message, "capabilities": caps,
        "log": log[-4000:],
    })


# ─────────────────────────── cheminformatics actions (§12.2) ───────────────────────────
#
# These write a SIMPLE document (NOT a JobResult): {"ok": true, ...} on success or
# {"ok": false, "error": ...} on any rdkit failure. They write output_path themselves
# and are dispatched before the JobResult path in run() (no rb.validate / rb.write_result).


def _write_doc(request: dict[str, Any], doc: dict[str, Any]) -> dict[str, Any]:
    """Write a simple {ok:...} document to request['output_path'] and return it."""
    with open(request["output_path"], "w", encoding="utf-8") as fh:
        json.dump(doc, fh, indent=2)
    return doc


def action_depict(request: dict[str, Any]) -> dict[str, Any]:
    """graph -> clean 2D layout. -> {"ok":true,"coords_2d":[{x,y},...]}."""
    try:
        from quchemy.cheminformatics import depict_2d

        coords = depict_2d(request["graph"])
        doc: dict[str, Any] = {"ok": True, "coords_2d": coords}
    except Exception as exc:  # noqa: BLE001 — degrade gracefully (§15.4)
        doc = {"ok": False, "error": f"{type(exc).__name__}: {exc}"}
    return _write_doc(request, doc)


def action_embed(request: dict[str, Any]) -> dict[str, Any]:
    """graph -> 3D conformer (ETKDG v3 + MMFF). -> {"ok":true,"coords_3d":[{x,y,z},...]}."""
    try:
        from quchemy.cheminformatics import embed_3d

        res = embed_3d(request["graph"])
        doc: dict[str, Any] = {
            "ok": True,
            "coords_3d": res["coords_3d"],
            "added_hs": res["added_hs"],
            "num_heavy": res["num_heavy"],
            # Degraded-capability / arbitrary-placement notes (e.g. MMFF skipped, or
            # multi-fragment spacing) — forwarded so the modeler can surface them
            # instead of silently returning a questionable geometry.
            "warnings": res.get("warnings", []),
        }
    except Exception as exc:  # noqa: BLE001
        doc = {"ok": False, "error": f"{type(exc).__name__}: {exc}"}
    return _write_doc(request, doc)


def action_generate_conformers(request: dict[str, Any]) -> dict[str, Any]:
    """graph -> ETKDG conformer ensemble, MMFF-ranked ascending.

    Request: {"molecule": <graph dict> (or legacy "graph"), "n_confs": int=20,
    "seed": int=42}. Returns {"ok":true, "conformers":[{rank, energy_kcalmol,
    delta_e_kcalmol, coords_3d}], "atom_symbols":[...], "num_heavy", "n_generated",
    "n_unique", "warnings":[...]}. Bad valence / failed embed -> {"ok":false,"error":...}.
    """
    try:
        from quchemy.cheminformatics import generate_conformers

        graph = request.get("molecule")
        if graph is None:
            graph = request.get("graph")  # accept the embed/depict key too
        if not isinstance(graph, dict):
            raise ValueError("generate_conformers requires a 'molecule' graph dict")
        res = generate_conformers(
            graph,
            n_confs=int(request.get("n_confs", 20)),
            seed=int(request.get("seed", 42)),
        )
        doc: dict[str, Any] = {"ok": True, **res}
    except Exception as exc:  # noqa: BLE001 — degrade gracefully (§15.4)
        doc = {"ok": False, "error": f"{type(exc).__name__}: {exc}"}
    return _write_doc(request, doc)


def action_smiles(request: dict[str, Any]) -> dict[str, Any]:
    """graph (or smiles) -> canonical SMILES + InChIKey. -> {"ok":true,"smiles":...,"inchikey":...}."""
    try:
        from quchemy.cheminformatics import canonical_smiles

        payload = request.get("graph")
        if payload is None:
            payload = request.get("smiles", "")
        smiles, inchikey = canonical_smiles(payload)
        doc: dict[str, Any] = {"ok": True, "smiles": smiles, "inchikey": inchikey}
    except Exception as exc:  # noqa: BLE001
        doc = {"ok": False, "error": f"{type(exc).__name__}: {exc}"}
    return _write_doc(request, doc)


def action_inchikey(request: dict[str, Any]) -> dict[str, Any]:
    """graph (or smiles) -> InChIKey only. -> {"ok":true,"inchikey":...}."""
    try:
        from quchemy.cheminformatics import canonical_smiles

        payload = request.get("graph")
        if payload is None:
            payload = request.get("smiles", "")
        _smiles, inchikey = canonical_smiles(payload)
        doc: dict[str, Any] = {"ok": True, "inchikey": inchikey}
    except Exception as exc:  # noqa: BLE001
        doc = {"ok": False, "error": f"{type(exc).__name__}: {exc}"}
    return _write_doc(request, doc)


def action_parse_smiles(request: dict[str, Any]) -> dict[str, Any]:
    """smiles -> (graph, 2D coords). -> {"ok":true,"graph":...,"coords_2d":[{x,y},...]}."""
    try:
        from quchemy.cheminformatics import parse_smiles

        graph, coords = parse_smiles(str(request.get("smiles", "")))
        doc: dict[str, Any] = {"ok": True, "graph": graph, "coords_2d": coords}
    except Exception as exc:  # noqa: BLE001
        doc = {"ok": False, "error": f"{type(exc).__name__}: {exc}"}
    return _write_doc(request, doc)


def action_parse_structure(request: dict[str, Any]) -> dict[str, Any]:
    """file_path (.xyz/.mol/.sdf/.pdb via RDKit; .mol2/.cif/.cml/.gro/.pdbqt via
    OpenBabel when installed) -> molecule document (same graph contract as
    parse_smiles, plus coords_3d + net charge + multiplicity + warnings).
    -> {"ok":true, "graph":..., "coords_3d":[{x,y,z},...], "charge":int, ...}.
    Missing/garbage/unsupported files -> {"ok":false,"error":...} naming the format."""
    try:
        from quchemy.cheminformatics import parse_structure

        doc: dict[str, Any] = parse_structure(str(request.get("file_path", "")))
        doc["ok"] = True
    except Exception as exc:  # noqa: BLE001
        doc = {"ok": False, "error": f"{type(exc).__name__}: {exc}"}
    return _write_doc(request, doc)


def action_fetch_pubchem(request: dict[str, Any]) -> dict[str, Any]:
    """{"query": "aspirin" | "2244", "query_type": "auto"|"name"|"cid"} -> the
    PubChem compound as a molecule document (same contract as parse_structure,
    plus "cid" + "source": "pubchem"). Prefers the 3D conformer SDF; a 2D-only
    record is embedded locally (RDKit ETKDG + MMFF) with a warning saying so.
    Unknown compound / offline / unparseable -> {"ok":false,"error":...}."""
    try:
        from quchemy.cheminformatics import fetch_pubchem

        doc: dict[str, Any] = fetch_pubchem(
            str(request.get("query", "")),
            query_type=str(request.get("query_type", "auto")),
        )
        doc["ok"] = True
    except Exception as exc:  # noqa: BLE001 — degrade gracefully (§15.4)
        doc = {"ok": False, "error": f"{type(exc).__name__}: {exc}"}
    return _write_doc(request, doc)


def action_write_structure(request: dict[str, Any]) -> dict[str, Any]:
    """{"file_path", "format" ("mol"|"sdf"|"mol2"|"pdb"|"xyz"), "molecule": {...}}
    -> write the structure file (RDKit; mol2 via pybel) and return
    {"ok":true, "path":..., "format":..., "warnings":[...]}. The molecule dict is
    the parse_structure contract (graph + optional coords_3d / coords_2d + name).
    Unsupported formats / empty molecules -> {"ok":false,"error":...}."""
    try:
        from quchemy.cheminformatics import write_structure

        doc: dict[str, Any] = write_structure(
            str(request.get("file_path", "")),
            str(request.get("format", "")),
            request.get("molecule") or {},
        )
        doc["ok"] = True
    except Exception as exc:  # noqa: BLE001
        doc = {"ok": False, "error": f"{type(exc).__name__}: {exc}"}
    return _write_doc(request, doc)


_BOHR_TO_ANG: float = 0.529177210903

## Basis used when a spec names none. ONE definition, so the value that runs and the value
## recorded in provenance cannot drift apart (they did: the run used STO-3G, the result said "").
_DEFAULT_BASIS: str = "STO-3G"


def _quiet():
    """Context manager redirecting stdout to a sink so geomeTRIC's chatty optimizer
    log never pollutes the sidecar's `OK <path>` stdout protocol. The pre-redirect
    stream is parked in `_PROGRESS_OUT` so QPROG telemetry emitted from inside the
    quieted block (geomeTRIC step callbacks, phase markers) still reaches the real
    pipe instead of the sink."""
    import contextlib
    import io

    @contextlib.contextmanager
    def _ctx():
        global _PROGRESS_OUT
        prev = _PROGRESS_OUT
        # Park the CURRENT stdout only when nothing is parked yet. When the engine-log
        # capture (run()) already redirected stdout into its buffer and parked the real
        # pipe, re-parking sys.stdout here would clobber that park with the log buffer —
        # every QPROG record from inside this block (geomeTRIC opt steps) would silently
        # land in the engine log instead of the live-progress pipe.
        _PROGRESS_OUT = _PROGRESS_OUT if _PROGRESS_OUT is not None else sys.stdout
        # When engine-log capture is active, funnel the quieted stdout INTO the log buffer
        # (so pyscf/geomeTRIC output run inside _quiet() still lands in the engine log)
        # rather than the throwaway sink.
        sink = _ENGINE_LOG if _ENGINE_LOG is not None else io.StringIO()
        try:
            with contextlib.redirect_stdout(sink):
                yield
        finally:
            _PROGRESS_OUT = prev

    return _ctx()


def _engine_log_capture(enabled: bool):
    """Context manager that captures a compute action's human-readable engine log.

    Redirects stdout+stderr into a StringIO parked at `_ENGINE_LOG` (so pyscf, run at verbose=5,
    writes its SCF log there), attaches a logging handler to the qiskit / qiskit-ibm-runtime
    loggers (so IBM job submission / backend / transpile records are captured), and parks the
    real stdout for QPROG telemetry. Yields the buffer (or None when disabled). Never the result
    channel — see `_ENGINE_LOG`."""
    import contextlib
    import io
    import logging

    @contextlib.contextmanager
    def _ctx():
        global _ENGINE_LOG, _PROGRESS_OUT
        if not enabled:
            yield None
            return
        buf = io.StringIO()
        prev_log = _ENGINE_LOG
        prev_progress = _PROGRESS_OUT
        _ENGINE_LOG = buf
        # Park the real stdout so QPROG telemetry still reaches the pipe under the redirect.
        if _PROGRESS_OUT is None:
            _PROGRESS_OUT = sys.stdout
        handler = logging.StreamHandler(buf)
        handler.setLevel(logging.INFO)
        handler.setFormatter(logging.Formatter("%(asctime)s %(name)s %(levelname)s: %(message)s"))
        loggers = [logging.getLogger("qiskit"), logging.getLogger("qiskit_ibm_runtime")]
        prev_levels = [lg.level for lg in loggers]
        for lg in loggers:
            lg.addHandler(handler)
            lg.setLevel(logging.INFO)
        try:
            with contextlib.redirect_stdout(buf), contextlib.redirect_stderr(buf):
                yield buf
        finally:
            for lg, lvl in zip(loggers, prev_levels):
                lg.removeHandler(handler)
                lg.setLevel(lvl)
            _ENGINE_LOG = prev_log
            _PROGRESS_OUT = prev_progress

    return _ctx()


def _molecule_at(molecule: dict[str, Any], coords_ang) -> dict[str, Any]:
    """A shallow copy of `molecule` with its atom positions replaced by `coords_ang`
    (an (natoms, 3) array in Å), preserving element order, charge and multiplicity."""
    atoms = molecule.get("atoms", [])
    new_atoms = [
        {**a, "x": float(coords_ang[i][0]), "y": float(coords_ang[i][1]),
         "z": float(coords_ang[i][2])}
        for i, a in enumerate(atoms)
    ]
    return {**molecule, "atoms": new_atoms}


# ─────────────────────────── geometry constraints (relaxed-scan / freeze) ───────────────────────────
#
# Constrained optimization: hold a bond length / angle / dihedral at its current
# geometry value while everything else relaxes (GaussView/ORCA parity, the
# relaxed-scan setup). The request carries spec.params.constraints — a list of
#   {"kind": "distance"|"angle"|"dihedral", "atoms": [i, j, ...]}  (0-indexed)
# which we translate into a geomeTRIC text constraints file ("$freeze" section)
# and hand to geometric_solver.optimize(constraints=<path>). FREEZE only: the
# coordinate is held at where it starts (geomeTRIC reads the value off the input
# geometry) — $set-to-target / $scan are a clean follow-up.

# How many atoms each constraint kind names, and geomeTRIC's token for it.
_CONSTRAINT_KINDS: dict[str, tuple[int, str]] = {
    "distance": (2, "distance"),
    "angle": (3, "angle"),
    "dihedral": (4, "dihedral"),
}


def _normalize_constraints(spec: dict[str, Any], natom: int) -> list[dict[str, Any]]:
    """Validate spec.params.constraints against a molecule of `natom` atoms and return
    them as clean {"kind","atoms"} dicts (0-indexed atoms, as received). Returns [] when
    none were requested.

    VALIDATES every constraint and raises ValueError naming the problem rather than
    silently dropping one (the project's cardinal sin): the kind must be known, the atom
    count must match the kind (distance=2/angle=3/dihedral=4), each atom index must be an
    integer in range [0, natom), and a constraint must not name the same atom twice."""
    params = spec.get("params", {})
    params = params if isinstance(params, dict) else {}
    raw = params.get("constraints", [])
    if raw in (None, ""):
        return []
    if not isinstance(raw, (list, tuple)):
        raise ValueError(
            "spec.params.constraints must be a list of {kind, atoms} dicts (got %r)"
            % type(raw).__name__
        )

    out: list[dict[str, Any]] = []
    for n, c in enumerate(raw):
        if not isinstance(c, dict):
            raise ValueError("constraint %d must be a {kind, atoms} dict (got %r)" % (n, c))
        kind = str(c.get("kind", "")).strip().lower()
        if kind not in _CONSTRAINT_KINDS:
            raise ValueError(
                "constraint %d has unknown kind %r; known: %s"
                % (n, c.get("kind"), sorted(_CONSTRAINT_KINDS))
            )
        want, _token = _CONSTRAINT_KINDS[kind]
        atoms_raw = c.get("atoms", [])
        if not isinstance(atoms_raw, (list, tuple)):
            raise ValueError("constraint %d: 'atoms' must be a list (got %r)" % (n, atoms_raw))
        try:
            atoms = [int(a) for a in atoms_raw]
        except (TypeError, ValueError) as exc:
            raise ValueError(
                "constraint %d: 'atoms' must be integer indices (got %r)" % (n, atoms_raw)
            ) from exc
        if len(atoms) != want:
            raise ValueError(
                "constraint %d (%s) needs exactly %d atom%s, got %d (%r)"
                % (n, kind, want, "" if want == 1 else "s", len(atoms), atoms)
            )
        for a in atoms:
            if not (0 <= a < natom):
                raise ValueError(
                    "constraint %d (%s) atom index %d is out of range for a %d-atom "
                    "molecule (valid 0..%d)" % (n, kind, a, natom, natom - 1)
                )
        if len(set(atoms)) != len(atoms):
            raise ValueError(
                "constraint %d (%s) names the same atom twice (%r)" % (n, kind, atoms)
            )
        out.append({"kind": kind, "atoms": atoms})
    return out


def _write_constraints_file(constraints: list[dict[str, Any]]) -> str:
    """Write the geomeTRIC `$freeze` constraints file for `constraints` (already
    validated by `_normalize_constraints`) to a temp path and return it. geomeTRIC
    uses 1-indexed atoms, so the UI's 0-indexed atoms are bumped by one here. The
    caller must delete the returned file. Returns "" for an empty list (no file)."""
    import tempfile

    if not constraints:
        return ""
    lines = ["$freeze"]
    for c in constraints:
        _want, token = _CONSTRAINT_KINDS[c["kind"]]
        one_indexed = " ".join(str(int(a) + 1) for a in c["atoms"])  # geomeTRIC is 1-based
        lines.append("%s %s" % (token, one_indexed))
    fd, path = tempfile.mkstemp(prefix="qemica_constraints_", suffix=".txt")
    try:
        with os.fdopen(fd, "w", encoding="utf-8") as fh:
            fh.write("\n".join(lines) + "\n")
    except Exception:
        os.unlink(path)
        raise
    return path


def _write_set_constraints_file(kind: str, atoms: list[int], value: float) -> str:
    """Write a geomeTRIC `$set` constraints file driving one bond/angle/dihedral to
    `value` while everything else relaxes — the relaxed-scan per-step constraint. Returns
    a temp path the caller must delete.

    Units match geomeTRIC's textual `$set` reader (geometric/prepare.py): a distance value
    is Å (read as `value * ang2bohr`), an angle/dihedral value is DEGREES (read as
    `value * pi/180`). So we hand the value straight through — Å for distance, degrees for
    angle/dihedral. Atoms arrive 0-indexed (UI convention) and are bumped to geomeTRIC's
    1-based numbering here, exactly like `_write_constraints_file` does for $freeze."""
    import tempfile

    _want, token = _CONSTRAINT_KINDS[kind]
    one_indexed = " ".join(str(int(a) + 1) for a in atoms)  # geomeTRIC is 1-based
    # geomeTRIC's parser reads distance in Å and angle/dihedral in degrees, so the value
    # is formatted verbatim (no unit conversion); %.10g keeps full scan-target precision.
    body = "$set\n%s %s %.10g\n" % (token, one_indexed, float(value))
    fd, path = tempfile.mkstemp(prefix="qemica_scan_set_", suffix=".txt")
    try:
        with os.fdopen(fd, "w", encoding="utf-8") as fh:
            fh.write(body)
    except Exception:
        os.unlink(path)
        raise
    return path


def _constraint_label(c: dict[str, Any]) -> str:
    """A short human label for a frozen constraint, echoed into provenance/warnings,
    e.g. "distance(0,1)". Atoms are 0-indexed (UI convention)."""
    return "%s(%s)" % (c["kind"], ",".join(str(int(a)) for a in c["atoms"]))


def _warn_constraints_ignored(
    result: dict[str, Any], spec: dict[str, Any], molecule: dict[str, Any], calc_type: str
) -> None:
    """Shared guard for the non-`optimize` calc types (TS / IRC / PES scan / es_opt):
    build_spec only attaches params.constraints for an optimize/opt+freq job, but a saved
    preset or a direct-to-Run spec could still carry them. Those paths run their own
    geometry search (or none) and DON'T honor a freeze, so emit the same "constraints
    ignored for <calc_type>" warning action_energy uses rather than dropping them silently.

    Still VALIDATES (via _normalize_constraints) so a malformed constraint fails loud the
    same way it would on an opt path — never a quietly-swallowed bad index."""
    constraints = _normalize_constraints(spec, len(molecule.get("atoms", [])))
    if constraints:
        _warn(result,
              "geometry constraints (%s) were ignored — they only apply to "
              "optimize / opt+freq calculations, not %r"
              % (", ".join(_constraint_label(c) for c in constraints), calc_type))


def _optimize_geometry(
    spec: dict[str, Any], molecule: dict[str, Any], *, transition: bool = False,
    maxsteps: int = 100, constraints: list[dict[str, Any]] | None = None,
):
    """Optimize the geometry with geomeTRIC (a minimum, or a first-order saddle when
    `transition=True`), honoring the recipe's solvent. Returns
    (mol, mf, is_dft, step_energies, coords_ang, step_coords) where mol/mf are rebuilt (and
    re-converged) at the optimized geometry so frequencies / properties run at the true
    stationary point. `step_coords` is the per-cycle geometry list (Å), one (natoms, 3) array
    per optimizer step — the scrubbable optimization trajectory.

    `constraints` (already validated by `_normalize_constraints`) freezes the named bond
    lengths / angles / dihedrals at their input value while everything else relaxes — the
    relaxed-scan / hold-a-key-coordinate workflow. They are written to a geomeTRIC `$freeze`
    file passed as `constraints=<path>`; the temp file is always cleaned up.
    """
    import numpy as np
    from pyscf.geomopt.geometric_solver import optimize

    # Post-HF (MP2/CCSD) optimizations relax on the CORRELATED analytic gradient: build
    # the HF reference (method stripped so `_build_mol`'s guard passes and the SCF is
    # RHF/UHF, never DFT), then hand geomeTRIC the correlated scanner. Anything else
    # optimizes the mean-field itself, exactly as before.
    method = str(spec.get("method", "HF")).upper()
    post_hf_opt = method in _POST_HF_OPTIMIZABLE and not transition
    build_spec = spec
    if post_hf_opt:
        build_spec = dict(spec)
        build_spec["method"] = "HF"
        build_spec["functional"] = ""

    # The initial kernel is the job's main SCF → stream its cycles. The callback is
    # then cleared so geomeTRIC's per-step kernel reruns don't emit restarting
    # (sawtooth) cycle counts — the per-STEP records below are the opt stream.
    _mol, mf, is_dft = _build_mol(build_spec, molecule, progress=True)
    mf.callback = None

    opt_target = mf
    if post_hf_opt:
        if method == "MP2":
            from pyscf import mp

            opt_target = mp.MP2(mf)
        else:  # CCSD (the only other member of _POST_HF_OPTIMIZABLE)
            from pyscf import cc

            opt_target = cc.CCSD(mf)
    step_energies: list[float] = []
    # Per-step geometries (Å), one frame per optimizer cycle — so a native opt scrubs in
    # the MD/Trajectory tab exactly like an imported optimization. geomeTRIC's callback
    # fires with the cycle's locals(): `mol` has already had set_geom_(coords) applied, so
    # `mol.atom_coords()` (Bohr) is the geometry at THIS step. (energy + grad were just
    # computed on it.) See pyscf.geomopt.geometric_solver.PySCFEngine.calc_new.
    step_coords: list[Any] = []

    def _cb(envs: dict[str, Any]) -> None:
        e = envs.get("energy")
        if e is not None:
            step_energies.append(float(e))
            _emit_progress({"t": "opt", "step": len(step_energies), "e": float(e)})
        step_mol = envs.get("mol")
        if step_mol is not None:
            step_coords.append(np.asarray(step_mol.atom_coords()) * _BOHR_TO_ANG)

    constraints_path = _write_constraints_file(constraints or [])
    try:
        with _quiet():
            if constraints_path:
                geom_converged, mol_eq = _geometric_optimize(
                    opt_target, transition=transition, maxsteps=maxsteps, callback=_cb,
                    constraints=constraints_path,
                )
            else:
                geom_converged, mol_eq = _geometric_optimize(
                    opt_target, transition=transition, maxsteps=maxsteps, callback=_cb)
    finally:
        if constraints_path:
            try:
                os.unlink(constraints_path)
            except OSError:
                pass

    coords_ang = np.asarray(mol_eq.atom_coords()) * _BOHR_TO_ANG
    # Rebuild at the optimized geometry (solvent re-applied) for downstream props/freq.
    # A post-HF opt rebuilds the HF REFERENCE (build_spec) — action_energy then reruns
    # the correlation on it, so the reported energy is the correlated one at the
    # correlated minimum.
    mol2, mf2, is_dft2 = _build_mol(build_spec, _molecule_at(molecule, coords_ang))
    return mol2, mf2, is_dft2, step_energies, coords_ang, step_coords, geom_converged


def _energy_grad_at(spec: dict[str, Any], molecule: dict[str, Any], coords_ang):
    """Single-point (energy Hartree, nuclear gradient Hartree/Bohr, converged) at
    `coords_ang`. The shared gradient seam — dispatched by engine: the MACE ML potential
    (Phase 2) or a PySCF mean-field (honoring the recipe's solvent + dispersion). Used by
    the IRC steepest-descent path and the NEB band."""
    import numpy as np

    if _is_mace(spec):
        return _mace_energy_grad(spec, molecule, coords_ang)
    _mol, mf, _is_dft = _build_mol(spec, _molecule_at(molecule, coords_ang))
    g = np.asarray(mf.nuc_grad_method().kernel())  # Hartree/Bohr
    return float(mf.e_tot), g, bool(getattr(mf, "converged", False))


def _irc_descent(
    spec: dict[str, Any], molecule: dict[str, Any], mode, result: dict[str, Any],
    *, nsteps: int = 12, step_ang: float = 0.10, kick_ang: float = 0.15,
):
    """A steepest-descent reaction path from a transition state, in both directions along
    the imaginary normal mode `mode` (an (natoms, 3) Cartesian displacement). Returns a
    list of {"coordinate","energy"} points along a signed arc-length coordinate (Å), TS at 0.

    Delegates to quchemy.paths.irc_steepest_descent — the SAME function the Method
    screen's generated input scripts import — through the engine's energy/gradient seam
    (so it honors the recipe's solvent, and MACE recipes ride their potential)."""
    import numpy as np

    from quchemy.paths import irc_steepest_descent

    base = np.asarray([[a["x"], a["y"], a["z"]] for a in molecule["atoms"]], dtype=float)
    points, reached_basin, final_gradient = irc_steepest_descent(
        lambda x: _energy_grad_at(spec, molecule, x),
        base, mode,
        nsteps=nsteps, step_ang=step_ang, kick_ang=kick_ang,
        on_warn=lambda m: _warn(result, m),
    )
    # A direction that merely ran out of steps has NOT reached a product basin, and the
    # two were indistinguishable in the result: the endpoints were reported as if they were
    # the reactant and product, and the Analyze tab read activation energies off them.
    # Measured on HCN<=>HNC at HF/STO-3G with the defaults: both ends stopped ~35 kcal/mol
    # above their basins, and the barriers on screen came out 2-3.5x too small.
    stalled = [d for d, ok in reached_basin.items() if not ok]
    if stalled:
        which = " and ".join("forward" if d > 0 else "reverse" for d in sorted(stalled, reverse=True))
        _warn(result,
              "IRC did not reach a minimum in the %s direction: the walk used all %d steps "
              "of %.3f Å and stopped with |grad| = %s Hartree/Å, still descending. The path "
              "endpoints are NOT the reactant/product, so any activation energy measured "
              "between them is a LOWER BOUND, not a barrier. Raise params.irc_steps or "
              "params.irc_step_ang, or optimize the endpoints separately."
              % (which, nsteps, step_ang,
                 ", ".join("%.2e" % final_gradient[d] for d in sorted(stalled, reverse=True))))
    result["irc_reached_minimum"] = bool(all(reached_basin.values()))
    return [
        rb.irc_point(c, e, [rb.vec3(float(r[0]), float(r[1]), float(r[2])) for r in x])
        for c, e, x in points
    ]


def _pbc_energy(
    spec: dict[str, Any], molecule: dict[str, Any], lattice: dict[str, Any], *, seed: int
) -> dict[str, Any]:
    """Periodic single-point HF/DFT via pyscf.pbc (KRHF/KRKS, k-point mesh).

    The unit cell rides the molecule document as {a, b, c} vectors (Angstrom).
    Plain molecular gaussian bases are not PBC-ready, so GTH-SZV + GTH-PADE
    pseudopotentials replace spec.basis_set — recorded in the result's basis
    field AND a warning, never silently (params.pbc_basis overrides the basis).
    v1 scope is deliberate and loud: closed-shell single-point energy only.
    """
    import numpy as np
    import pyscf
    from pyscf.pbc import gto as pgto
    from pyscf.pbc import scf as pscf
    from pyscf.pbc import dft as pdft

    calc_type = str(spec.get("calc_type", "energy"))
    if calc_type != "energy":
        raise ValueError(
            "PBC supports single-point energy only — calc_type %r is not implemented "
            "for periodic systems (disable PBC in the Builder for molecular runs)"
            % calc_type
        )
    method = str(spec.get("method", "HF")).upper()
    if method not in ("HF", "DFT"):
        raise ValueError("PBC runs HF or DFT only (pyscf.pbc), not %s" % method)
    if int(molecule.get("multiplicity", spec.get("multiplicity", 1))) != 1:
        raise ValueError("the PBC branch is closed-shell only (multiplicity 1)")

    vecs = [lattice.get("a"), lattice.get("b"), lattice.get("c")]
    if any(not isinstance(v, (list, tuple)) or len(v) < 3 for v in vecs):
        raise ValueError("PBC lattice must carry three 3-vectors a/b/c (Angstrom)")
    a_mat = np.array(vecs, dtype=float)
    if abs(np.linalg.det(a_mat)) < 1e-6:
        raise ValueError("degenerate unit cell (zero volume) — fix the lattice in the Builder")

    params = spec.get("params", {}) if isinstance(spec.get("params"), dict) else {}
    cell = pgto.Cell()
    cell.a = a_mat
    cell.unit = "Angstrom"
    cell.atom = "; ".join(
        "%s %.10f %.10f %.10f"
        % (at.get("element", "X"), float(at.get("x", 0)), float(at.get("y", 0)), float(at.get("z", 0)))
        for at in molecule.get("atoms", [])
    )
    pbc_basis = str(params.get("pbc_basis", "gth-szv"))
    cell.basis = pbc_basis
    cell.pseudo = "gth-pade"
    cell.charge = int(molecule.get("charge", spec.get("charge", 0)))
    cell.verbose = 0
    cell.build()

    kpts_in = params.get("kpts", [1, 1, 1])
    if not isinstance(kpts_in, (list, tuple)):
        kpts_in = [1, 1, 1]
    kmesh = [max(1, int(k)) for k in list(kpts_in)[:3]]
    while len(kmesh) < 3:
        kmesh.append(1)
    kpts = cell.make_kpts(kmesh)

    t0 = time.perf_counter()
    is_dft = method == "DFT"
    if is_dft:
        functional = str(spec.get("functional", "")).strip() or "PBE"
        mf = pdft.KRKS(cell, kpts=kpts)
        mf.xc = _libxc_name(functional)
    else:
        mf = pscf.KRHF(cell, kpts=kpts)
    # Gaussian density fitting — the robust default for gaussian-basis PBC SCF.
    mf = mf.density_fit()
    energy = float(mf.kernel())
    wall = time.perf_counter() - t0

    result = rb.blank_result()
    _fill_overview(result, spec, molecule, seed=seed)
    result["method"] = "DFT" if is_dft else "HF"
    result["engine"] = "pyscf"
    result["engine_version"] = str(pyscf.__version__)
    result["wall_clock_s"] = float(wall)
    result["converged"] = bool(getattr(mf, "converged", False))
    result["success"] = result["converged"]
    if not result["converged"]:
        result["error"] = "periodic SCF did not converge"
    result["scf_energy"] = energy
    result["total_energy"] = energy
    result["basis"] = "%s + GTH-PADE (PBC)" % pbc_basis
    if is_dft:
        result["functional"] = str(spec.get("functional", "")).strip() or "PBE"
    result["reference"] = "KRKS" if is_dft else "KRHF"
    # Periodic provenance block (consumed by Analyze Overview as extra fields).
    bohr3_to_a3 = 0.529177210903 ** 3
    result["periodic"] = {
        "kpts": kmesh,
        "n_kpts": int(len(kpts)),
        "cell_volume_a3": float(cell.vol * bohr3_to_a3),
        "lattice": {"a": vecs[0], "b": vecs[1], "c": vecs[2]},
    }
    _warn(
        result,
        "periodic run: %s basis + GTH-PADE pseudopotentials replaced the molecular "
        "basis '%s'; the energy is PER UNIT CELL on a %dx%dx%d k-mesh"
        % (pbc_basis, str(spec.get("basis_set", "")), kmesh[0], kmesh[1], kmesh[2]),
    )
    return result


def action_energy(request: dict[str, Any]) -> dict[str, Any]:
    """RHF/RKS energy via PySCF -> JobResult. Optimizes the geometry first for the
    `optimize` / `opt+freq` calc types (frequencies then run at the true minimum)."""
    import pyscf

    spec = request.get("spec", {})
    molecule = request["molecule"]
    seed = int(spec.get("rng_seed", 0) or 0)
    calc_type = str(spec.get("calc_type", "energy"))
    # Unimplemented methods (MP2/CCSD/FCI/…) fail loud inside _build_mol; CASSCF is
    # genuinely handled below, on the converged reference.
    energy_method = str(spec.get("method", "HF")).upper()

    # CASSCF is implemented ONLY as a single-point energy. Geometry optimization,
    # the Hessian (frequencies/thermochemistry), MD forces and TDDFT response all
    # come off the mean-field — i.e. the HF/ROHF *reference* — so running them
    # inside a result labeled method=CASSCF would be a partial mislabel (the UI
    # blocks most of these combos; this is the contract-level guard, same policy
    # as `_reject_casscf` in TS/IRC/PES/es_opt).
    if energy_method == "CASSCF":
        if calc_type in ("optimize", "opt+freq", "frequencies", "md"):
            _reject_casscf(spec, "calc_type %r" % calc_type)
        if _spec_flag(spec, "compute_excited"):
            _reject_casscf(spec, "excited states (compute_excited)")

    # MP2/CCSD/CCSD(T)/FCI: correlation on top of a converged HF reference. MP2/CCSD
    # also serve `optimize` (analytic PySCF gradients through geomeTRIC); everything
    # else off the energy is refused loudly (same policy as CASSCF) rather than
    # silently returning HF-reference frequencies/forces under a correlated label.
    is_post_hf = energy_method in _POST_HF
    if is_post_hf:
        optimizable = energy_method in _POST_HF_OPTIMIZABLE
        if calc_type in ("opt+freq", "frequencies", "md") or (
            calc_type == "optimize" and not optimizable
        ):
            supported = ("a single-point energy or a geometry optimization"
                         if optimizable else "a single-point energy only")
            raise NotImplementedError(
                "method %s is implemented as %s — %r would run off the mean-field "
                "Hessian/forces and be mislabeled (no analytic %s Hessian is wired; "
                "a numeric one would be prohibitively expensive). Use HF or DFT for "
                "%r, or run %s as %s."
                % (energy_method, supported, calc_type, energy_method, calc_type,
                   energy_method, supported)
            )
        if calc_type == "optimize" and _solvent_request(spec)[0]:
            raise NotImplementedError(
                "a %s geometry optimization with implicit solvent is not available — "
                "PySCF has no %s nuclear gradient for the solvated reference. Optimize "
                "in the gas phase, or use HF/DFT for the solvated optimization."
                % (energy_method, energy_method)
            )
        if _spec_flag(spec, "compute_excited"):
            raise NotImplementedError(
                "excited states (compute_excited) are not available for %s — the TDDFT "
                "response runs on the HF reference. Use HF or DFT." % energy_method
            )
        if _dispersion_request(spec):
            raise NotImplementedError(
                "a DFT-D dispersion correction (%s) cannot be combined with %s — the "
                "empirical -D term is parameterized against DFT/HF and would double-"
                "count the dispersion the correlated wavefunction already captures. "
                "Set dispersion to none." % (_dispersion_request(spec), energy_method)
            )

    # Geometry constraints (freeze a bond/angle/dihedral while relaxing the rest) apply
    # only to the geomeTRIC optimize paths. Validated up front so a bad constraint fails
    # loud BEFORE any SCF runs, and recorded in provenance so Reproduce re-freezes them.
    constraints = _normalize_constraints(spec, len(molecule.get("atoms", [])))

    # Periodic system? The molecule document carries its unit cell — run the
    # dedicated pyscf.pbc branch (single-point HF/DFT on a k-point mesh) and
    # never thread a Cell through the molecular result pipeline.
    lattice = molecule.get("lattice")
    if isinstance(lattice, dict) and lattice.get("use_pbc"):
        return _pbc_energy(spec, molecule, lattice, seed=seed)

    # SCF checkpoint: every single-molecule HF/DFT/post-HF run dumps its converged SCF
    # next to the result (<result stem>.chk, per-job stem so concurrent jobs never
    # collide) for a later restart (params.restart_from). Injected as an INTERNAL param
    # on a COPY of the spec so provenance (result.spec_params, stamped from the
    # original) never carries the machine-local path.
    chk_path = ""
    _op_chk = str(request.get("output_path", ""))
    if (_op_chk and energy_method != "CASSCF"
            and calc_type in ("energy", "optimize", "opt+freq", "frequencies")):
        chk_path = os.path.splitext(_op_chk)[0] + ".chk"
    run_spec = spec
    if chk_path:
        _run_params = dict(spec.get("params", {}) or {})
        _run_params["scf_chkfile"] = chk_path
        run_spec = {**spec, "params": _run_params}

    t0 = time.perf_counter()
    opt_energies: list[float] | None = None
    opt_coords = None
    opt_step_coords: list[Any] = []
    geom_converged = True   # no optimization ran → nothing to disbelieve
    _opt_steps = 0
    if calc_type in ("optimize", "opt+freq"):
        # opt_max_cycle (the self-healing opt rung) raises the geomeTRIC step cap; default 100.
        _opt_steps = max(1, int((spec.get("params", {}) or {}).get("opt_max_cycle", 100) or 100))
        mol, mf, is_dft, opt_energies, opt_coords, opt_step_coords, geom_converged = \
            _optimize_geometry(
                run_spec, molecule, maxsteps=_opt_steps, constraints=constraints
            )
    else:
        # For a post-HF method the mean-field is the HF *reference* it correlates: build
        # it with the method stripped to HF (functional cleared) so `_build_mol`'s guard
        # passes and the SCF is RHF/UHF, never DFT. Solvent rides through (dispersion is
        # refused above for post-HF).
        build_spec = run_spec
        if is_post_hf:
            build_spec = dict(run_spec)
            build_spec["method"] = "HF"
            build_spec["functional"] = ""
        mol, mf, is_dft = _build_mol(build_spec, molecule, progress=True)
    wall = time.perf_counter() - t0

    result = rb.blank_result()
    _fill_overview(result, spec, molecule, seed=seed)
    result["method"] = "DFT" if is_dft else "HF"
    result["engine"] = "pyscf"
    result["engine_version"] = str(pyscf.__version__)
    result["wall_clock_s"] = float(wall)
    # Echo the frozen coordinates in provenance (what was actually held). For an
    # optimize/opt+freq these were applied; for any other calc type they were ignored,
    # so DON'T claim them and SAY so instead (no silent constraint).
    if constraints:
        if calc_type in ("optimize", "opt+freq"):
            result["constraints"] = [dict(c) for c in constraints]
        else:
            _warn(result,
                  "geometry constraints (%s) were ignored — they only apply to "
                  "optimize / opt+freq calculations, not %r"
                  % (", ".join(_constraint_label(c) for c in constraints), calc_type))
    _fill_scf(result, mol, mf, is_dft, spec)
    # _fill_scf's `converged` describes the SCF at the FINAL geometry, which converges
    # happily on a structure the optimizer was still moving. Fold in whether the geometry
    # itself converged, before anything downstream reads that flag.
    _warn_unconverged_geometry(result, geom_converged, _opt_steps)
    result["total_energy"] = result["scf_energy"]
    # Surface any restart/checkpoint notes stashed on the mean-field by _apply_checkpoint
    # (an unusable params.restart_from degrades to the default guess — SAY so).
    for _note in getattr(mf, "_qc_notes", []):
        _warn(result, _note)

    # CASSCF rides on the converged RHF reference: run the active-space SCF, then replace
    # the energy/method and re-render the Orbitals tab with the CASSCF natural orbitals.
    mc = None  # the converged CASSCF object (cube generation reads it below)
    if energy_method == "CASSCF":
        _cas_params = spec.get("params", {})
        _cas_params = _cas_params if isinstance(_cas_params, dict) else {}
        if "cas_auto" in _cas_params:
            # Automatic active-space selection: AVAS seed + character-scored iteration.
            cas_energy, cas, cas_mo_energy, cas_mo_occ, mc, cas_auto_notes = (
                _run_auto_casscf(mol, mf, spec)
            )
            for _note in cas_auto_notes:
                _warn(result, _note)
        else:
            cas_energy, cas, cas_mo_energy, cas_mo_occ, mc = _run_casscf(mol, mf, spec)
        result["method"] = "CASSCF"
        result["scf_energy"] = float(mf.e_tot)  # the HF reference, kept for provenance
        result["total_energy"] = cas_energy
        result["converged"] = bool(cas.get("converged", False))
        result["cas"] = cas
        _check_multireference(result, cas)
        # Compositions from mc.mo_coeff — valid per-column because natorb=True pins
        # the active block to the natural orbitals the occupation ladder describes.
        cas_comps = None
        try:
            cas_comps = _mo_compositions(mol, mf.get_ovlp(), mc.mo_coeff)
        except Exception as exc:  # noqa: BLE001
            _warn(result, f"orbital composition unavailable: {exc}")
        orbs, homo, lumo = rb.orbitals_from_mo(
            cas_mo_energy, cas_mo_occ, compositions=cas_comps
        )
        result["orbitals"] = orbs
        result["homo_index"] = homo
        result["lumo_index"] = lumo
        # Relay the Analyze picker's reference-mismatch note (params.cas_note): the
        # active-space MO indices may have been chosen on a DFT/UHF/solvated orbital
        # ladder that this run's restricted(-open) HF reference does not reproduce.
        # Only the UI knows what reference the picker displayed, so it travels as a
        # note; the sidecar just says it out loud in the result's warnings channel.
        ps = spec.get("params", {})
        cas_note = str((ps if isinstance(ps, dict) else {}).get("cas_note", "")).strip()
        if cas_note:
            _warn(result, cas_note)
        # Charge honesty: _fill_scf filled Mulliken/Löwdin/ESP from the HF reference
        # density. Re-fill them from the CASSCF natural density (mc.make_rdm1(), AO
        # basis) so a CASSCF result's charges describe the CASSCF wavefunction, not
        # the HF reference. Degrades per-scheme with a warning if it fails.
        try:
            cas_dm = mc.make_rdm1()
            _fill_charges(result, mol, mf, cas_dm)
            # Mayer bond orders from the CASSCF natural density too — a CASSCF result
            # shows CASSCF bond orders, not the HF reference's (consistency with charges).
            _fill_bond_orders(result, mol, cas_dm)
        except Exception as exc:  # noqa: BLE001
            _warn(result, f"CASSCF-density charges unavailable: {exc}")
        _note_reference_spin_diagnostics(result, mol, mf, "CASSCF")

    # MP2 / CCSD / CCSD(T) / FCI: correlate the converged HF reference, then replace the
    # energy and method label. scf_energy stays the HF reference (provenance),
    # correlation_energy the E_corr it added, total_energy the correlated total.
    # Charges/bond orders refill from the correlated 1-RDM when it can be formed, else
    # fall back to the HF-reference density with a warning (honest). For optimize this
    # runs at the optimized geometry's rebuilt reference, so the reported energy is the
    # correlated one at the correlated minimum.
    if is_post_hf:
        _emit_phase("ccsd" if energy_method == "CCSD(T)" else energy_method.lower())
        # Frozen core DEFAULTS ON for classical correlation, matching Gaussian, ORCA and
        # Q-Chem — essentially every published MP2/CCSD/CCSD(T) number is frozen-core, and
        # correlating the core in a valence correlation-consistent basis (cc-pVXZ,
        # def2-XVP) is unbalanced besides. It was previously all-electron with no way to
        # change it from the classical composer (the toggle reached the quantum path only),
        # so results were not comparable to literature at the stated level. Pass
        # params.frozen_core = false for an explicit all-electron run.
        _frozen_core = bool((spec.get("params", {}) or {}).get("frozen_core", True))
        corr_energy, corr_e_corr, corr_converged, corr_dm, corr_notes = _run_post_hf(
            energy_method, mf, frozen_core=_frozen_core)
        # Record what actually happened, not the raw request (the default differs by path).
        if isinstance(result.get("numerical_settings"), dict):
            result["numerical_settings"]["frozen_core"] = _frozen_core
        result["method"] = energy_method
        result["scf_energy"] = float(mf.e_tot)
        result["total_energy"] = float(corr_energy)
        result["correlation_energy"] = float(corr_e_corr)
        result["converged"] = bool(getattr(mf, "converged", False) and corr_converged)
        for note in corr_notes:
            _warn(result, note)
        if _solvent_request(spec)[0]:
            _warn(result,
                  "implicit solvation is treated at the SCF level only — the %s "
                  "correlation was computed on the solvated HF reference, not with a "
                  "correlated reaction field" % energy_method)
        if corr_dm is not None:
            try:
                _fill_charges(result, mol, mf, corr_dm)
                _fill_bond_orders(result, mol, corr_dm)
            except Exception as exc:  # noqa: BLE001
                _warn(result, f"{energy_method}-density charges unavailable: {exc}")
        else:
            _warn(result,
                  "%s charges/bond orders are reported from the HF reference density — "
                  "the correlated 1-RDM could not be formed for this reference"
                  % energy_method)
        _note_reference_spin_diagnostics(result, mol, mf, energy_method)

    # Record the optimized geometry + per-step energies (geometry now reflects the run).
    if opt_coords is not None:
        result["final_coords"] = [rb.vec3(r[0], r[1], r[2]) for r in opt_coords]
        result["opt_steps"] = [rb.opt_step(e) for e in (opt_energies or [])]
        # Emit the scrubbable optimization trajectory: one frame per optimizer cycle
        # (geometry + energy), so a native opt scrubs in the MD/Trajectory tab exactly
        # like an imported opt. opt_steps (above) stays the Overview opt-energy chart;
        # this is the geometry stream. frame "time" carries the step index (the MD tab
        # labels an "optimization" trajectory by step, not fs); temperature is 0.
        opt_es = opt_energies or []
        frames: list[dict[str, Any]] = []
        for i, step_xyz in enumerate(opt_step_coords):
            step_e = float(opt_es[i]) if i < len(opt_es) else 0.0
            coords_vec = [rb.vec3(r[0], r[1], r[2]) for r in step_xyz]
            frames.append(rb.trajectory_frame(float(i), coords_vec, step_e, 0.0))
        if frames:
            result["trajectory"] = frames
            result["trajectory_kind"] = "optimization"
            result["atom_symbols"] = [
                str(a.get("element", "")) for a in molecule.get("atoms", [])
            ]
    # Vibrational frequencies for the Analyze IR/Raman tab when the recipe asks for
    # them (the Hessian is expensive, so only on freq calc types). For opt+freq, mf is
    # already the optimized stationary point, so the frequencies are physically valid.
    if calc_type in ("frequencies", "opt+freq"):
        _compute_frequencies(mol, mf, result, spec)
    if str(spec.get("calc_type", "energy")) == "md":
        params = spec.get("params", {})
        params = params if isinstance(params, dict) else {}
        _run_md(
            mol, mf, result, spec,
            seed=int(spec.get("rng_seed", 0) or 0),
            nsteps=int(params.get("md_steps", 20)),
            dt_fs=float(params.get("md_dt_fs", 0.5)),
            temp_k=float(params.get("md_temp_k", 300.0)),
        )
        # The properties below (cubes / excited states / NMR / polarizability) run on
        # the INPUT-geometry mean-field, while final_coords now points at the END of
        # the trajectory — say the geometry mismatch out loud (same policy as the
        # PES-scan "tabs describe the minimum-energy point" warning).
        if (_wants_cubes(spec) or _spec_flag(spec, "compute_excited")
                or _spec_flag(spec, "compute_nmr")
                or _spec_flag(spec, "compute_polarizability")):
            _warn(result,
                  "orbital cubes / excited states / NMR / polarizability are computed "
                  "at the INPUT geometry, but final_coords is the END of the MD "
                  "trajectory — these properties do not describe the final frame")
    # TDA/TDDFT excited states for the Analyze UV-Vis tab (opt-in via Method toggle).
    if _spec_flag(spec, "compute_excited"):
        ep = spec.get("params", {})
        ep = ep if isinstance(ep, dict) else {}
        # NTO cubes (opt-in) land next to result.json with the per-job stem, same as the
        # orbital/density cubes — so concurrent jobs never collide and an imported result
        # carries valid user:// paths.
        want_nto = _spec_flag(spec, "compute_nto")
        op_nto = str(request.get("output_path", ""))
        nto_out_dir = (os.path.dirname(op_nto) or ".") if want_nto else None
        nto_stem = (os.path.splitext(os.path.basename(op_nto))[0] or "job") if want_nto else "job"
        if want_nto:
            _emit_phase("nto")
        _compute_excited_states(
            mf, result,
            nstates=int(ep.get("excited_nstates", 5)),
            td_method=str(ep.get("td_method", "TDA")),
            triplet=bool(ep.get("excited_triplet", False)),
            mol=mol, out_dir=nto_out_dir, stem=nto_stem, compute_nto=want_nto, spec=spec,
        )
    # NMR shieldings + static polarizability for the Analyze NMR tab / Overview row.
    # Both are extra response calculations (coupled-perturbed SCF), so opt-in via the
    # Method toggles (spec.params.compute_nmr / compute_polarizability) — never free-
    # riding on every energy job. CASSCF is refused: the response would be computed on
    # the HF reference and silently mislabeled.
    if _spec_flag(spec, "compute_nmr") or _spec_flag(spec, "compute_polarizability"):
        if energy_method in _CORRELATED:
            _warn(result, "NMR/polarizability skipped for %s: the response would run on "
                          "the HF reference, not the correlated wavefunction" % energy_method)
        else:
            if _spec_flag(spec, "compute_nmr"):
                _compute_nmr_shieldings(mol, mf, result)
            if _spec_flag(spec, "compute_polarizability"):
                _compute_polarizability(mf, result)
    # Condensed Fukui reactivity indices (Yang–Mortier, Mulliken-based) for the Analyze
    # Overview dual-descriptor bar — predict WHERE a molecule reacts. Opt-in (two extra
    # SCFs: the N±1 ions). SCOPE: a plain closed-shell-singlet single-point energy on a
    # neutral. CASSCF / a non-energy calc type / an open-shell or charged neutral are
    # refused (the driver itself fail-loud-skips the last); say so and skip the others.
    if _spec_flag(spec, "compute_fukui"):
        if energy_method in _CORRELATED:
            _warn(result, "Fukui indices skipped for %s: the condensed scheme differences "
                          "single-determinant ion charges, not the correlated "
                          "wavefunction" % energy_method)
        elif calc_type not in ("energy", "reactivity"):
            _warn(result, "Fukui indices skipped: they are offered only for a "
                          "single-point energy / reactivity calculation (the N±1 ions are "
                          "built at the input geometry), not %r" % calc_type)
        else:
            # Difference the neutral's Mulliken charges (filled by _fill_scf) against
            # the cation/anion charges at the same geometry/recipe; also pass the neutral
            # energy so the global conceptual-DFT descriptors (μ/η/ω/…) come along.
            _compute_fukui(spec, molecule, list(result.get("charges", [])), result,
                           e_neutral=float(result.get("scf_energy", 0.0)))
    # Localized-bonding (NBO-style) analysis — IBO/Pipek–Mezey localization of the occupied
    # MOs → the Lewis picture (core / lone pair / 2-centre bond) + natural charges. Opt-in
    # (the Method "Bonding (NBO)" property toggle). SCOPE: a ground-state single-point on a
    # restricted closed-shell reference — the localization reads the mean-field's occupied
    # block, so a correlated wavefunction (would localize the HF reference) and any non-energy
    # calc type are refused with a warning; open-shell degrades to natural charges (in-helper).
    if _spec_flag(spec, "compute_nbo"):
        if energy_method in _CORRELATED:
            _warn(result, "Bonding (NBO) analysis skipped for %s: the localization would run "
                          "on the HF reference, not the correlated wavefunction" % energy_method)
        elif calc_type != "energy":
            _warn(result, "Bonding (NBO) analysis skipped: it is offered only for a "
                          "single-point energy calculation (the localization reads the "
                          "input-geometry wavefunction), not %r" % calc_type)
        else:
            _compute_nbo_block(spec, request, mol, mf, result)
    # Optional orbital .cube files for the Analyze isosurface viewer. Expensive, so
    # opt-in via spec.params.compute_cubes (the Method "visualize orbitals" toggle).
    if _wants_cubes(spec):
        _emit_phase("cubes")
        op = str(request.get("output_path", ""))
        out_dir = os.path.dirname(op) or "."
        # Prefix cubes with the result's unique stem so concurrent jobs (and reloads)
        # never collide on a shared orbital_<idx>.cube in user://jobs.
        stem = os.path.splitext(os.path.basename(op))[0] or "job"
        if mc is not None:
            # CASSCF: cubes must come from the CASSCF wavefunction — natural
            # orbitals (mc.mo_coeff, natorb=True) and the spin-traced natural
            # density (mc.make_rdm1()). Previously this path wrote the HF
            # reference orbitals/density under the natural-occupation ladder.
            result["cube_files"] = _generate_casscf_orbital_cubes(
                mol, mc, result, out_dir, stem)
            result["density_cubes"] = _generate_density_cubes(
                mol, mc, result, out_dir, stem)  # mc.make_rdm1() = natural density
        else:
            n_occ, n_virt = _cube_window(spec)
            result["cube_files"] = _generate_orbital_cubes(
                mol, mf, result, out_dir, stem, n_occ, n_virt)
            result["density_cubes"] = _generate_density_cubes(mol, mf, result, out_dir, stem)
    # Checkpoint provenance: where this run's converged SCF was dumped (warnings-free
    # metadata — Reproduce threads it back as params.restart_from). Recorded only when
    # the file really exists so a result never points at a checkpoint that isn't there.
    if chk_path and os.path.isfile(chk_path):
        result["checkpoint_path"] = chk_path
    result["success"] = True
    return result


def action_transition_state(request: dict[str, Any]) -> dict[str, Any]:
    """Locate a first-order saddle (transition state) with geomeTRIC, then characterize it:
    SCF properties, an immediate frequency analysis (which fills n_imaginary — a true TS has
    exactly one — plus thermochemistry), and the optimization trace. -> JobResult."""
    import pyscf

    spec = request.get("spec", {})
    molecule = request["molecule"]
    seed = int(spec.get("rng_seed", 0) or 0)
    _reject_casscf(spec, "transition_state")

    t0 = time.perf_counter()
    mol, mf, is_dft, opt_energies, opt_coords, _step_coords, geom_converged = \
        _optimize_geometry(spec, molecule, transition=True)
    wall = time.perf_counter() - t0

    result = rb.blank_result()
    _fill_overview(result, spec, molecule, seed=seed)
    # A TS search ignores freeze constraints (geomeTRIC saddle search, not a relaxed
    # scan) — validate + warn rather than swallow a stray params.constraints (L5).
    _warn_constraints_ignored(result, spec, molecule, "transition_state")
    result["method"] = "DFT" if is_dft else "HF"
    result["engine"] = "pyscf"
    result["engine_version"] = str(pyscf.__version__)
    result["wall_clock_s"] = float(wall)
    _fill_scf(result, mol, mf, is_dft, spec)
    # A saddle search that ran out of steps is not a transition state, whatever the SCF
    # at its last geometry says (default maxsteps=100 — _optimize_geometry's own default).
    _warn_unconverged_geometry(result, geom_converged, 100)
    result["total_energy"] = result["scf_energy"]
    result["final_coords"] = [rb.vec3(r[0], r[1], r[2]) for r in opt_coords]
    result["opt_steps"] = [rb.opt_step(e) for e in opt_energies]
    _compute_frequencies(mol, mf, result, spec)  # fills n_imaginary / stationary_point / thermo
    _warn_if_not_first_order_saddle(result)
    result["calc_type"] = "transition_state"
    result["success"] = True
    return result


def _warn_if_not_first_order_saddle(result: dict[str, Any]) -> None:
    """Say loudly when a transition_state job converged anywhere but a first-order saddle.

    A saddle search that relaxes onto a minimum (or a higher-order saddle) still
    converges "successfully" — but its energy is NOT a barrier, and without this
    warning the result reads as a found TS (QA mission-2 blocker: two of three
    plausible SN2 guesses landed on the ion-dipole complex with zero warnings).
    Runs off the frequency analysis _compute_frequencies just filled; if that
    analysis itself degraded, the character is unverified and says so.
    """
    if not result.get("vibrations"):
        _warn(
            result,
            "Transition-state character could NOT be verified (frequency analysis "
            "unavailable) — do not trust this energy as a barrier.",
        )
        return
    n_imag = int(result.get("n_imaginary", 0))
    if n_imag == 0:
        _warn(
            result,
            "Transition-state search converged to a MINIMUM (0 imaginary frequencies) "
            "— this structure is not a transition state and its energy is not a "
            "barrier. Restart from a geometry closer to the crossing point (stretch "
            "the forming and breaking bonds toward halfway).",
        )
    elif n_imag > 1:
        _warn(
            result,
            f"Transition-state search found a higher-order saddle ({n_imag} imaginary "
            "frequencies), not a first-order transition state — distort the structure "
            "along the extra imaginary modes and re-run.",
        )


def _action_irc_mace(request: dict[str, Any], spec: dict[str, Any],
                     molecule: dict[str, Any], seed: int, params: dict[str, Any]):
    """IRC on the MACE backend: the imaginary normal mode comes from a NUMERICAL Hessian
    (ASE finite-difference on the ML forces), then the shared steepest-descent path
    [func]_irc_descent[/func] follows it (the descent already dispatches its energy/gradient
    to MACE). Energies/forces only — no electronic structure on the path."""
    import numpy as np

    t0 = time.perf_counter()
    result = rb.blank_result()
    _fill_overview(result, spec, molecule, seed=seed)
    _warn_constraints_ignored(result, spec, molecule, "irc")
    result["engine"] = "mace"
    result["method"] = _mace_model_id(spec)
    result["calc_type"] = "irc"
    r0 = np.asarray([[a["x"], a["y"], a["z"]] for a in molecule["atoms"]], dtype=float)
    e0, _conv = _mace_point_energy(spec, molecule, r0)
    result["total_energy"] = e0
    result["scf_energy"] = e0
    result["converged"] = True
    result["final_coords"] = [rb.vec3(a["x"], a["y"], a["z"]) for a in molecule["atoms"]]
    result["atom_symbols"] = [str(a.get("element", "")) for a in molecule["atoms"]]
    _warn(result, "MACE is an ML interatomic potential (%s): energies/forces only — no "
                  "electronic structure on the IRC path." % result["method"])
    try:
        _emit_phase("hessian")
        signed, modes = _mace_normal_modes(spec, molecule)
        k = int(np.argmin(signed))
        if signed[k] < -_IMAG_TOL_CM:
            result["n_imaginary"] = int(np.sum(signed < -_IMAG_TOL_CM))
            result["stationary_point"] = rb.stationary_label(result["n_imaginary"])
            _emit_phase("irc")
            result["irc_path"] = _irc_descent(
                spec, molecule, modes[k], result,
                # 12 x 0.10 A reaches only 1.2 A per side, which does not get out of
                # the saddle region for most reactions — HCN<=>HNC at HF/STO-3G stopped
                # ~35 kcal/mol above both basins, and the barriers read off those
                # endpoints were 2-3.5x too small. 30 steps is still bounded and usually
                # arrives; the walk exits early the moment a basin is reached, so a short
                # reaction pays nothing for the higher cap.
                nsteps=int(params.get("irc_steps", 30)),
                step_ang=float(params.get("irc_step_ang", 0.10)),
            )
        else:
            _warn(result, "IRC path empty: no imaginary mode at the input geometry "
                          "(is this an optimized transition state?)")
    except Exception as exc:  # noqa: BLE001 — keep the characterization, say why
        _warn(result, f"IRC path unavailable (numerical Hessian / mode analysis failed): {exc}")
    result["wall_clock_s"] = float(time.perf_counter() - t0)
    result["success"] = True
    return result


def action_irc(request: dict[str, Any]) -> dict[str, Any]:
    """Intrinsic-reaction-coordinate path from a transition state. Identifies the imaginary
    normal mode at the input (TS) geometry and follows steepest descent both ways, filling
    `irc_path` with {coordinate, energy} points (TS at coordinate 0). -> JobResult.

    Input molecule should be an optimized TS; if no imaginary mode is found the path is
    empty and the result still carries the SCF characterization."""
    import numpy as np
    import pyscf
    from pyscf.hessian import thermo

    spec = request.get("spec", {})
    molecule = request["molecule"]
    seed = int(spec.get("rng_seed", 0) or 0)
    params = spec.get("params", {})
    params = params if isinstance(params, dict) else {}
    _reject_casscf(spec, "irc")
    if _is_mace(spec):
        # MACE IRC: numerical Hessian for the imaginary mode, then the shared descent.
        return _action_irc_mace(request, spec, molecule, seed, params)

    t0 = time.perf_counter()
    mol, mf, is_dft = _build_mol(spec, molecule, progress=True)

    result = rb.blank_result()
    _fill_overview(result, spec, molecule, seed=seed)
    # IRC follows steepest descent from a TS — no constrained optimizer runs, so a stray
    # params.constraints is ignored. Validate + say so (L5).
    _warn_constraints_ignored(result, spec, molecule, "irc")
    result["method"] = "DFT" if is_dft else "HF"
    result["engine"] = "pyscf"
    result["engine_version"] = str(pyscf.__version__)
    _fill_scf(result, mol, mf, is_dft, spec)
    result["total_energy"] = result["scf_energy"]

    # Find the imaginary mode (most negative signed wavenumber) at the TS geometry.
    try:
        _emit_phase("hessian")
        try:
            hess = mf.Hessian().kernel()
        except Exception as hess_exc:  # noqa: BLE001 — solvated Hessian missing?
            # Same fallback policy as _compute_frequencies: PySCF cannot
            # differentiate every reaction field twice (ddCOSMO has no analytic
            # Hessian) — recompute GAS-PHASE at the same geometry and SAY so.
            model, name = _solvent_request(spec)
            if not model:
                raise  # the gas-phase Hessian failed for real — outer except warns
            mf_gas, _ = _make_mf(mol, _gas_phase_spec(spec))
            mf_gas.kernel()
            if not getattr(mf_gas, "converged", False):
                _warn(result, "gas-phase fallback SCF not converged at the input "
                              "(TS) geometry — the fallback Hessian is unreliable")
            hess = mf_gas.Hessian().kernel()
            _warn(result,
                  "%s(%s) Hessian unavailable (%s) — the IRC imaginary mode comes "
                  "from a GAS-PHASE Hessian at the solvated geometry"
                  % (model, name, hess_exc))
        info = thermo.harmonic_analysis(mol, hess)
        raw = np.asarray(info["freq_wavenumber"]).ravel()
        signed = np.where(np.abs(raw.imag) > np.abs(raw.real), -np.abs(raw.imag), raw.real)
        modes = np.asarray(info["norm_mode"])
        k = int(np.argmin(signed))
        if signed[k] < -_IMAG_TOL_CM:
            result["n_imaginary"] = int(np.sum(signed < -_IMAG_TOL_CM))
            result["stationary_point"] = rb.stationary_label(result["n_imaginary"])
            _emit_phase("irc")
            result["irc_path"] = _irc_descent(
                spec, molecule, modes[k], result,
                # 12 x 0.10 A reaches only 1.2 A per side, which does not get out of
                # the saddle region for most reactions — HCN<=>HNC at HF/STO-3G stopped
                # ~35 kcal/mol above both basins, and the barriers read off those
                # endpoints were 2-3.5x too small. 30 steps is still bounded and usually
                # arrives; the walk exits early the moment a basin is reached, so a short
                # reaction pays nothing for the higher cap.
                nsteps=int(params.get("irc_steps", 30)),
                step_ang=float(params.get("irc_step_ang", 0.10)),
            )
        else:
            _warn(result, "IRC path empty: no imaginary mode at the input geometry "
                          "(is this an optimized transition state?)")
    except Exception as exc:  # noqa: BLE001 — keep the SCF characterization, but say why
        hint = (" — ROHF/ROKS has no analytic Hessian in PySCF; use UHF/UKS "
                "(params.reference)") if _is_rohf(mf) else ""
        _warn(result, f"IRC path unavailable (Hessian / normal-mode analysis failed): {exc}{hint}")

    result["wall_clock_s"] = float(time.perf_counter() - t0)
    result["calc_type"] = "irc"
    result["success"] = True
    return result


def action_pes_scan(request: dict[str, Any]) -> dict[str, Any]:
    """Rigid potential-energy-surface scan of the distance between two atoms. params:
    scan_atoms [i, j], scan_start, scan_end (Å), scan_steps. Moves atom j along the i→j
    axis and takes a single-point energy at each distance, filling `scan_points`. -> JobResult.

    Rigid scan (the rest of the molecule is frozen); a relaxed scan is future work."""
    import numpy as np
    import pyscf

    spec = request.get("spec", {})
    molecule = request["molecule"]
    seed = int(spec.get("rng_seed", 0) or 0)
    params = spec.get("params", {})
    params = params if isinstance(params, dict) else {}

    _reject_casscf(spec, "pes_scan")

    atoms = molecule.get("atoms", [])
    if len(atoms) < 2:
        raise ValueError("PES scan needs at least 2 atoms to define a bond coordinate")
    scan_atoms = params.get("scan_atoms", [0, 1])
    i, j = int(scan_atoms[0]), int(scan_atoms[1])
    n = len(atoms)
    if not (0 <= i < n and 0 <= j < n) or i == j:
        raise ValueError(
            "scan_atoms must be two distinct in-range atom indices (got %r for %d atoms)"
            % (scan_atoms, n)
        )
    start = float(params.get("scan_start", 0.6))
    end = float(params.get("scan_end", 2.4))
    steps = max(2, min(int(params.get("scan_steps", 12)), 60))

    base = np.asarray([[a["x"], a["y"], a["z"]] for a in atoms], dtype=float)
    axis = base[j] - base[i]
    axis_norm = float(np.linalg.norm(axis))
    axis = axis / axis_norm if axis_norm > 1e-9 else np.array([1.0, 0.0, 0.0])

    # Build the result up front so per-point SCF convergence problems can be warned
    # about (an unconverged point is recorded, not silently plotted).
    result = rb.blank_result()
    _fill_overview(result, spec, molecule, seed=seed)
    # A rigid PES scan freezes everything but the scanned bond — geomeTRIC freeze
    # constraints don't apply, so validate + warn rather than swallow them (L5).
    _warn_constraints_ignored(result, spec, molecule, "pes_scan")

    is_mace = _is_mace(spec)
    t0 = time.perf_counter()
    pts: list[dict[str, Any]] = []
    # Track the minimum-energy scan point. The Orbitals/Charges/Dipole tabs are
    # filled from ITS mean-field and final_coords is set to ITS geometry, so every
    # tab describes the same structure (previously _fill_scf used the LAST — most
    # stretched — point while final_coords stayed at the input geometry).
    best: tuple[float, float, Any, Any, Any, bool] | None = None
    for point, d in enumerate(np.linspace(start, end, steps)):
        coords = base.copy()
        coords[j] = base[i] + axis * float(d)  # set |i-j| = d, frozen elsewhere
        if is_mace:
            # ML potential: energy only — no mean-field, no electronic-structure tabs.
            e, _conv = _mace_point_energy(spec, molecule, coords)
            mol = mf = None
            is_dft = False
        else:
            mol, mf, is_dft = _build_mol(spec, _molecule_at(molecule, coords))
            if not getattr(mf, "converged", False):
                _warn(result, "SCF not converged at scan point d=%.3f Å" % float(d))
            e = float(mf.e_tot)
        # Live telemetry: one record per scan point (the per-point rebuilds are
        # deliberately silent, so this is the scan job's only step stream).
        _emit_progress({"t": "scan", "point": int(point), "e": e})
        pts.append(rb.scan_point(float(d), e))
        if best is None or e < best[0]:
            best = (e, float(d), coords, mol, mf, is_dft)

    if is_mace:
        result["engine"] = "mace"
        result["method"] = _mace_model_id(spec)
    else:
        result["engine"] = "pyscf"
        result["engine_version"] = str(pyscf.__version__)
    if best is not None:
        e_min, d_min, coords_min, mol_min, mf_min, is_dft_min = best
        result["final_coords"] = [rb.vec3(r[0], r[1], r[2]) for r in coords_min]
        if is_mace:
            result["total_energy"] = float(e_min)
            result["scf_energy"] = float(e_min)
            result["converged"] = True
            _warn(result, "MACE is an ML interatomic potential (%s): energies only — no "
                          "orbitals/charges/dipole. Geometry is the minimum-energy scan "
                          "point d=%.3f Å." % (result["method"], d_min))
        else:
            result["method"] = "DFT" if is_dft_min else "HF"
            _fill_scf(result, mol_min, mf_min, is_dft_min, spec)
            result["total_energy"] = result["scf_energy"]
            _warn(result,
                  "orbitals/charges/dipole and final geometry are reported at the "
                  "minimum-energy scan point d=%.3f Å" % d_min)
    result["scan_points"] = pts
    result["wall_clock_s"] = float(time.perf_counter() - t0)
    result["calc_type"] = "pes_scan"
    result["success"] = True
    return result


# A relaxed scan runs a FULL constrained optimization at every point, so each step costs a
# whole geometry opt — the step count is capped hard (the UI caps too) and a request over
# the cap is honored at the cap with a warning, never silently truncated.
_RELAXED_SCAN_MAX_STEPS: int = 24


def _constrained_opt_to_value(
    spec: dict[str, Any], molecule: dict[str, Any], kind: str, atoms: list[int],
    value: float, *, maxsteps: int = 100,
):
    """One relaxed-scan step: optimize `molecule` while DRIVING the (kind, atoms) coordinate
    to `value` (distance Å / angle·dihedral degrees) and relaxing everything else, via a
    geomeTRIC `$set` constraints file. Returns (energy_Ha, coords_ang, converged) at the
    constrained minimum. Reuses the same recipe (solvent/dispersion) as every other path
    through `_build_mol`; the temp $set file is always cleaned up."""
    import numpy as np
    from pyscf.geomopt.geometric_solver import optimize

    _mol, mf, _is_dft = _build_mol(spec, molecule)
    mf.callback = None  # per-step opt kernels would otherwise emit sawtooth SCF cycles

    set_path = _write_set_constraints_file(kind, atoms, value)
    try:
        with _quiet():
            geom_conv, mol_eq = _geometric_optimize(
                mf, maxsteps=maxsteps, constraints=set_path)
    finally:
        try:
            os.unlink(set_path)
        except OSError:
            pass

    coords_ang = np.asarray(mol_eq.atom_coords()) * _BOHR_TO_ANG
    # Re-converge at the constrained minimum (solvent re-applied) so the reported energy is
    # the SCF energy AT that geometry, and capture convergence honestly.
    _mol2, mf2, _is_dft2 = _build_mol(spec, _molecule_at(molecule, coords_ang))
    # BOTH must hold for this scan point to be a real constrained minimum: the geometry
    # optimization converged, and the SCF re-converged there.
    return (float(mf2.e_tot), coords_ang,
            bool(geom_conv) and bool(getattr(mf2, "converged", False)))


def action_relaxed_scan(request: dict[str, Any]) -> dict[str, Any]:
    """RELAXED coordinate scan: drive a bond/angle/dihedral through a range, optimizing all
    OTHER coordinates at every fixed value (GaussView/ORCA relaxed scan). params:
    scan_kind ("distance"|"angle"|"dihedral", default distance), scan_atoms (2/3/4 0-indexed
    indices per kind), scan_start, scan_end (Å for distance, degrees for angle/dihedral),
    scan_steps (capped at _RELAXED_SCAN_MAX_STEPS — each step is a full opt). -> JobResult.

    Unlike the rigid `pes_scan` (single-point per displaced geometry), each point here is a
    constrained geometry optimization (geomeTRIC `$set`), so the energy curve is a genuine
    reaction-energy profile and every point carries a meaningful relaxed geometry. The scan
    is CHAINED — point i starts from point i−1's optimized geometry (standard relaxed-scan
    practice: smoother profiles, faster convergence) — with point 0 starting from the input.

    Fills `scan_points` (the energy-vs-coordinate profile, same shape as pes_scan) AND a
    `trajectory` of one frame per point (the optimized geometry; energy = the optimized
    energy; "time" = the scan value) with trajectory_kind "relaxed_scan", so the profile
    shows in the reaction-profile view and the optimized geometries scrub in the MD tab.
    final_coords + the SCF tabs report the MINIMUM-energy scan point (the pes_scan policy).
    A non-convergent step is WARNED (named) and the scan continues from that geometry."""
    import numpy as np
    import pyscf

    spec = request.get("spec", {})
    molecule = request["molecule"]
    seed = int(spec.get("rng_seed", 0) or 0)
    params = spec.get("params", {})
    params = params if isinstance(params, dict) else {}

    _reject_casscf(spec, "relaxed_scan")
    is_mace = _is_mace(spec)

    atoms_in = molecule.get("atoms", [])
    n = len(atoms_in)
    kind = str(params.get("scan_kind", "distance")).strip().lower()
    if kind not in _CONSTRAINT_KINDS:
        raise ValueError(
            "scan_kind must be one of %s (got %r)"
            % (sorted(_CONSTRAINT_KINDS), params.get("scan_kind"))
        )
    want, _token = _CONSTRAINT_KINDS[kind]
    raw_atoms = params.get("scan_atoms", [0, 1])
    if not isinstance(raw_atoms, (list, tuple)):
        raise ValueError("scan_atoms must be a list of atom indices (got %r)" % (raw_atoms,))
    try:
        scan_atoms = [int(a) for a in raw_atoms]
    except (TypeError, ValueError) as exc:
        raise ValueError("scan_atoms must be integer indices (got %r)" % (raw_atoms,)) from exc
    if len(scan_atoms) != want:
        raise ValueError(
            "a %s scan needs exactly %d atom%s, got %d (%r)"
            % (kind, want, "" if want == 1 else "s", len(scan_atoms), scan_atoms)
        )
    for a in scan_atoms:
        if not (0 <= a < n):
            raise ValueError(
                "scan_atoms index %d is out of range for a %d-atom molecule (valid 0..%d)"
                % (a, n, n - 1)
            )
    if len(set(scan_atoms)) != len(scan_atoms):
        raise ValueError("scan_atoms names the same atom twice (%r)" % (scan_atoms,))

    unit = "Å" if kind == "distance" else "°"
    start = float(params.get("scan_start", 0.8 if kind == "distance" else 90.0))
    end = float(params.get("scan_end", 2.0 if kind == "distance" else 120.0))
    requested_steps = int(params.get("scan_steps", 6))
    steps = max(2, min(requested_steps, _RELAXED_SCAN_MAX_STEPS))

    result = rb.blank_result()
    _fill_overview(result, spec, molecule, seed=seed)
    if requested_steps > _RELAXED_SCAN_MAX_STEPS:
        _warn(result,
              "relaxed scan capped at %d steps (requested %d) — each step is a full "
              "geometry optimization" % (_RELAXED_SCAN_MAX_STEPS, requested_steps))

    t0 = time.perf_counter()
    pts: list[dict[str, Any]] = []
    frames: list[dict[str, Any]] = []
    symbols = [str(a.get("element", "")) for a in atoms_in]
    # Chain the scan: each point optimizes from the PREVIOUS point's relaxed geometry.
    current = molecule
    # Track the minimum-energy scan point — final_coords + the SCF tabs describe IT, so
    # every tab reports the same structure (same policy as the rigid pes_scan fix).
    best: tuple[float, float, Any] | None = None
    for point, v in enumerate(np.linspace(start, end, steps)):
        value = float(v)
        if is_mace:
            energy, coords_ang, converged = _mace_constrained_opt_to_value(
                spec, current, kind, scan_atoms, value
            )
        else:
            energy, coords_ang, converged = _constrained_opt_to_value(
                spec, current, kind, scan_atoms, value
            )
        if not converged:
            _warn(result,
                  "constrained optimization did not converge at scan point %d "
                  "(%s = %.4g %s) — continuing the scan from that geometry"
                  % (point, kind, value, unit))
        _emit_progress({"t": "scan", "point": int(point), "e": float(energy)})
        pts.append(rb.scan_point(value, float(energy)))
        coords_vec = [rb.vec3(r[0], r[1], r[2]) for r in coords_ang]
        # Frame "time" carries the scan VALUE (the coordinate axis), not a fs time — the
        # MD tab is kind-aware and labels relaxed_scan frames by step, not time.
        frames.append(rb.trajectory_frame(value, coords_vec, float(energy), 0.0))
        if best is None or energy < best[0]:
            best = (float(energy), value, coords_ang)
        current = _molecule_at(current, coords_ang)  # chain from this relaxed geometry

    if is_mace:
        result["engine"] = "mace"
        result["method"] = _mace_model_id(spec)
    else:
        result["engine"] = "pyscf"
        result["engine_version"] = str(pyscf.__version__)
    if best is not None:
        e_min, v_min, coords_min = best
        result["final_coords"] = [rb.vec3(r[0], r[1], r[2]) for r in coords_min]
        if is_mace:
            result["total_energy"] = float(e_min)
            result["scf_energy"] = float(e_min)
            result["converged"] = True
            _warn(result, "MACE is an ML interatomic potential (%s): energies only — no "
                          "orbitals/charges/dipole. Geometry is the minimum-energy scan "
                          "point (%s = %.4g %s)." % (result["method"], kind, v_min, unit))
        else:
            # Re-converge at the min-energy point to fill orbitals/charges/dipole there.
            mol_min, mf_min, is_dft_min = _build_mol(spec, _molecule_at(molecule, coords_min))
            result["method"] = "DFT" if is_dft_min else "HF"
            _fill_scf(result, mol_min, mf_min, is_dft_min, spec)
            result["total_energy"] = result["scf_energy"]
            _warn(result,
                  "orbitals/charges/dipole and final geometry are reported at the "
                  "minimum-energy scan point (%s = %.4g %s)" % (kind, v_min, unit))
    result["scan_points"] = pts
    result["trajectory"] = frames
    result["trajectory_kind"] = "relaxed_scan"
    result["atom_symbols"] = list(symbols)
    result["wall_clock_s"] = float(time.perf_counter() - t0)
    result["calc_type"] = "relaxed_scan"
    result["success"] = True
    return result


def action_es_opt(request: dict[str, Any]) -> dict[str, Any]:
    """Relax an excited-state geometry on its TDDFT/TDA analytic gradient (default S1) and
    report emission (fluorescence/phosphorescence): the state→ground vertical gap AT the
    relaxed excited-state minimum, the emission wavelength, and the adiabatic 0–0 energy
    (which assumes the input geometry is the S0 minimum — optimize the ground state first).
    Also fills the excited-state list at the relaxed geometry. -> JobResult."""
    import numpy as np
    import pyscf
    from pyscf.geomopt.geometric_solver import optimize

    EH_EV = 27.211386245988
    spec = request.get("spec", {})
    molecule = request["molecule"]
    seed = int(spec.get("rng_seed", 0) or 0)
    params = spec.get("params", {})
    params = params if isinstance(params, dict) else {}
    state = max(1, int(params.get("emission_state", 1)))
    nstates = max(state, int(params.get("excited_nstates", state + 1)))
    td_method = str(params.get("td_method", "TDDFT"))
    triplet = bool(params.get("excited_triplet", False))
    _reject_casscf(spec, "es_opt")

    # Result exists before the heavy lifting so intermediate convergence problems
    # can be warned about as they happen.
    result = rb.blank_result()
    _fill_overview(result, spec, molecule, seed=seed)
    # The excited-state optimizer relaxes on the TDDFT gradient unconstrained — a stray
    # ground-state freeze does not apply, so validate + warn rather than swallow it (L5).
    _warn_constraints_ignored(result, spec, molecule, "es_opt")

    t0 = time.perf_counter()
    _mol0, mf0, _is_dft = _build_mol(spec, molecule, progress=True)
    mf0.callback = None  # the TD gradient scanner reruns this kernel per opt step
    if not getattr(mf0, "converged", False):
        _warn(result, "SCF not converged at the input (ground-state) geometry")
    e_s0_input = float(mf0.e_tot)  # ground-state total energy at the input geometry

    # Optimize the chosen excited state's geometry on its analytic gradient.
    _emit_phase("tddft")
    td0, _method = _build_td(mf0, td_method, triplet, nstates)
    with _quiet():
        td0.kernel()
    _warn_td_unconverged(result, td0, " at the input geometry")
    grad = td0.nuc_grad_method()
    grad.state = state  # 1 = first excited state
    step_energies: list[float] = []

    def _cb(envs: dict[str, Any]) -> None:
        e = envs.get("energy")
        if e is not None:
            step_energies.append(float(e))
            _emit_progress({"t": "opt", "step": len(step_energies), "e": float(e)})

    # The TD-gradient optimizer can fail to converge when the chosen state is unbound at
    # this level (e.g. a diffuse/Rydberg state in a minimal basis) — pyscf raises a hard
    # RuntimeError. Degrade instead of crashing: keep the INPUT geometry, report the
    # vertical excited states there, and SAY emission/adiabatic are unavailable (L5).
    opt_converged = True
    try:
        with _quiet():
            opt_converged, mol_eq = _geometric_optimize(grad, callback=_cb)
        coords_ang = np.asarray(mol_eq.atom_coords()) * _BOHR_TO_ANG
        if not opt_converged:
            # Ran out of steps rather than raising: same degradation as the exception
            # path below, so say the same thing instead of reporting a relaxed geometry.
            _warn(result,
                  "excited-state geometry optimization did not converge within the step "
                  "limit — the reported geometry is not an excited-state minimum, and "
                  "emission / adiabatic energies from it are unreliable.")
    except Exception as exc:  # noqa: BLE001 — degrade with a named warning, not a crash
        opt_converged = False
        coords_ang = np.asarray(_mol0.atom_coords()) * _BOHR_TO_ANG
        _warn(result,
              "excited-state geometry optimization did not converge (%s: %s) — reporting "
              "the vertical excited states at the INPUT geometry; emission and the "
              "adiabatic 0–0 energy are unavailable. Try a larger basis set, a different "
              "emission_state, or optimize the ground-state geometry first."
              % (type(exc).__name__, exc))

    # Characterize at the relaxed excited-state minimum.
    mol1, mf1, is_dft1 = _build_mol(spec, _molecule_at(molecule, coords_ang))
    e_s0_at_min = float(mf1.e_tot)  # ground-state energy at the ES-min geometry
    wall = time.perf_counter() - t0

    result["method"] = "DFT" if is_dft1 else "HF"
    result["engine"] = "pyscf"
    result["engine_version"] = str(pyscf.__version__)
    result["wall_clock_s"] = float(wall)
    _fill_scf(result, mol1, mf1, is_dft1, spec)
    result["total_energy"] = result["scf_energy"]
    result["final_coords"] = [rb.vec3(r[0], r[1], r[2]) for r in coords_ang]
    result["opt_steps"] = [rb.opt_step(e) for e in step_energies]
    # Excited states at the relaxed geometry — the emission state is among them.
    _compute_excited_states(mf1, result, nstates=nstates, td_method=td_method,
                            triplet=triplet, spec=spec)

    # Emission = the emitting state's vertical gap to the ground state at the ES minimum.
    # Only meaningful when the excited-state geometry actually relaxed; on a failed opt the
    # geometry is still the input one (vertical absorption, not emission) so we DON'T fake it.
    if opt_converged:
        e_gap_ev = 0.0
        states = result.get("excited_states", [])
        if 0 < state <= len(states):
            e_gap_ev = float(states[state - 1]["energy_ev"])
        wl = (1239.841984 / e_gap_ev) if e_gap_ev > 1e-6 else 0.0
        # Adiabatic 0-0 ≈ E(excited total at its min) − E(S0 at input geom).
        e_es_total_min = e_s0_at_min + e_gap_ev / EH_EV
        adiabatic_ev = (e_es_total_min - e_s0_input) * EH_EV
        result["emission"] = rb.emission(e_gap_ev, wl, state, adiabatic_ev)
    # The optimizer converges on the excited-state GRADIENT, so this is a stationary point of
    # that surface — but nothing establishes it is a MINIMUM, and no excited-state Hessian is
    # computed anywhere. That distinction bites in the textbook case: formaldehyde's S1 is
    # pyramidal, yet a planar start converges to the planar saddle and reports it as the
    # relaxed geometry. A rigid 10-degree out-of-plane tilt of the reported "minimum" LOWERS
    # the energy by 0.17 kcal/mol, so the emission energy from it is an upper bound.
    _warn(result,
          "This is a stationary point on the excited-state surface, NOT verified to be a "
          "minimum — no excited-state frequency analysis is performed. A symmetric starting "
          "geometry commonly converges to a saddle (formaldehyde's S1 is pyramidal, but a "
          "planar start stays planar), which makes the emission energy an upper bound. "
          "Distort the starting geometry along the coordinate you expect to relax and "
          "re-run if the two disagree.")
    result["calc_type"] = "es_opt"
    result["success"] = True
    return result


# ─────────────────────────── localized bonding (NBO-style) ───────────────────────────


def _ao_atom_map(mol):
    """Per-AO atom index (length mol.nao), via the canonical aoslice_by_atom ranges."""
    import numpy as np

    amap = np.zeros(mol.nao, dtype=int)
    aoslices = mol.aoslice_by_atom()
    for atom in range(mol.natm):
        p0, p1 = int(aoslices[atom, 2]), int(aoslices[atom, 3])
        amap[p0:p1] = atom
    return amap


def _localize_occupied(mol, c_occ, result):
    """Localize the occupied MO block `c_occ` (nao, nocc). Intrinsic Bond Orbitals
    (Knizia 2013, pyscf.lo.ibo) when available — a Pipek–Mezey localization otherwise,
    and the canonical (delocalized) orbitals as a last resort. Returns (method_label,
    c_loc (nao, nocc))."""
    import numpy as np
    from pyscf import lo

    try:
        c_loc = lo.ibo.ibo(mol, c_occ)
        if c_loc is not None and np.asarray(c_loc).shape[1] == c_occ.shape[1]:
            return "IBO", np.asarray(c_loc)
    except Exception:  # noqa: BLE001 — IBO is finicky on minimal bases; fall back cleanly
        pass
    try:
        c_loc = lo.PM(mol, c_occ).kernel()
        return "Pipek-Mezey", np.asarray(c_loc)
    except Exception as exc:  # noqa: BLE001 — last resort: report the canonical MOs
        _warn(result, f"Orbital localization failed ({exc}); reporting canonical "
                      "(delocalized) orbitals")
        return "canonical", np.asarray(c_occ)


def _classify_localized(pop, energy):
    """Classify a localized orbital from its per-atom Mulliken populations `pop` (sums
    to ~1) and Fock-diagonal `energy` (Ha). Returns an rb.bonding_orbital dict."""
    import numpy as np

    order = list(np.argsort(pop)[::-1])
    a0 = int(order[0])
    w0 = float(pop[a0])
    a1 = int(order[1]) if len(order) > 1 else -1
    w1 = float(pop[a1]) if a1 >= 0 else 0.0

    centers = [{"atom": int(a), "weight": float(pop[a])} for a in order if pop[a] >= 0.05]

    if w0 >= 0.85 and energy < -5.0:
        # A deep, single-atom orbital — a core (1s-like) pair.
        kind, atoms = "core", [a0]
    elif w0 >= 0.85:
        # Single-atom valence orbital — a lone pair.
        kind, atoms = "lone_pair", [a0]
    elif (w0 + w1) >= 0.70 and w1 >= 0.20:
        # Shared between two atoms — a 2-centre bond.
        kind, atoms = "bond", sorted([a0, a1])
    else:
        kind = "delocalized"
        atoms = [int(a) for a in order[:3] if pop[a] >= 0.10]
    return rb.bonding_orbital(kind, atoms, 2.0, float(energy), centers)


def _compute_nbo_block(spec: dict[str, Any], request: dict[str, Any], mol, mf, result) -> None:
    """Fill result["bonding"] with the localized-bonding (NBO-style) Lewis picture off an
    already-converged mean-field `mf`: natural (meta-Löwdin) charges + IBO/Pipek–Mezey
    localized occupied orbitals classified core / lone pair / 2-centre bond, with an optional
    per-orbital .cube export (gated by the same compute_cubes flag as the energy path).
    Restricted closed-shell only — open-shell degrades to natural charges + a warning. Mutates
    `result`; never raises (every failure degrades to a warning).

    Shared by action_nbo (the standalone calc type, kept for reproduced specs) and action_energy
    (the Method "Bonding (NBO)" property add-on), so both paths yield an identical result["bonding"]."""
    import numpy as np

    # Natural (meta-Löwdin / NAO) charges — the natural-population-analysis proxy.
    natural_charges: list[float] = []
    try:
        _mp, nao = mf.mulliken_meta(mol, mf.make_rdm1(), verbose=0)
        natural_charges = [float(c) for c in np.asarray(nao).ravel()]
    except Exception as exc:  # noqa: BLE001
        _warn(result, f"Natural (meta-Löwdin) charges unavailable: {exc}")

    # Restricted closed-shell only: one set of doubly-occupied spatial orbitals to
    # localize. ndim != 1 catches UHF/UKS; the partial-occupancy test catches ROHF/ROKS,
    # whose mo_occ is 1-D with a SOMO at 1.0 — localizing that alongside the closed
    # pairs would emit a Lewis table with more electrons than the molecule has.
    mo_occ = np.asarray(mf.mo_occ)
    partial = mo_occ.ndim == 1 and bool(
        np.any((mo_occ > 1e-6) & (mo_occ < 2.0 - 1e-6))
    )
    if mo_occ.ndim != 1 or partial:
        _warn(result, "Localized-bonding analysis needs a restricted closed-shell reference "
                      "(one set of doubly-occupied orbitals); open-shell localization is not "
                      "offered — reporting natural charges only")
        result["bonding"] = rb.bonding_block(
            method="", natural_charges=natural_charges, orbitals=[])
        return

    occ_idx = [i for i in range(mo_occ.shape[0]) if mo_occ[i] > 1e-6]
    if not occ_idx:
        _warn(result, "Localized-bonding analysis: no occupied orbitals to localize")
        result["bonding"] = rb.bonding_block(
            method="", natural_charges=natural_charges, orbitals=[])
        return

    c_occ = np.asarray(mf.mo_coeff)[:, occ_idx]  # (nao, nocc)
    _emit_phase("localize")
    method_label, c_loc = _localize_occupied(mol, c_occ, result)

    s = mol.intor_symmetric("int1e_ovlp")
    fock = np.asarray(mf.get_fock())
    if fock.ndim != 2:
        fock = fock[0]
    ao_atom = _ao_atom_map(mol)
    natom = mol.natm
    sc = s @ c_loc  # column k = S·c_k

    # Optional .cube export — one volumetric file per localized orbital so Analyze can draw
    # the lone pairs / bonds as 3D isosurfaces (gated by the same compute_cubes flag as the
    # energy path). Written BEFORE the sort so each cube_path travels with its orbital. The
    # cubegen import + every write is best-effort: a cube failure degrades to a warning and
    # the Lewis table still stands (never fails the job).
    cube_out_dir = ""
    cube_stem = "job"
    want_cubes = _wants_cubes(spec)
    cubegen = None
    if want_cubes:
        op = str(request.get("output_path", ""))
        cube_out_dir = os.path.dirname(op) or "."
        cube_stem = os.path.splitext(os.path.basename(op))[0] or "job"
        try:
            from pyscf.tools import cubegen as _cubegen
            cubegen = _cubegen
        except Exception as exc:  # noqa: BLE001
            want_cubes = False
            _warn(result, f"NBO orbital cubes unavailable (cubegen import failed): {exc}")

    orbitals: list[dict[str, Any]] = []
    for k in range(c_loc.shape[1]):
        ck = c_loc[:, k]
        contrib = ck * sc[:, k]  # per-AO Mulliken contribution, sums to ~1
        pop = np.zeros(natom)
        np.add.at(pop, ao_atom, contrib)
        e_loc = float(ck @ (fock @ ck))  # Fock-diagonal energy of the localized orbital
        orb = _classify_localized(pop, e_loc)
        if want_cubes and cubegen is not None:
            try:
                cube_path = os.path.join(cube_out_dir, f"{cube_stem}_nbo_{k}.cube")
                cubegen.orbital(mol, cube_path, ck)
                orb["cube_path"] = cube_path
            except Exception as exc:  # noqa: BLE001 — one bad cube drops, the table stands
                _warn(result, f"NBO cube for localized orbital {k} unavailable: {exc}")
        orbitals.append(orb)

    # Stable Lewis listing: cores first, then by energy ascending (cube_path travels along).
    orbitals.sort(key=lambda o: (0 if o["kind"] == "core" else 1, o["energy"]))
    result["bonding"] = rb.bonding_block(
        method=method_label, natural_charges=natural_charges, orbitals=orbitals)
    if method_label in ("IBO", "Pipek-Mezey"):
        _warn(result, "Bonding orbitals from %s localization (a chemically equivalent Lewis "
                      "picture) — not Weinhold NBO7, which requires the external NBO program."
                      % method_label)


def action_nbo(request: dict[str, Any]) -> dict[str, Any]:
    """Localized-bonding (NBO-style) analysis -> JobResult.

    Runs the SCF, localizes the occupied orbitals (Intrinsic Bond Orbitals, Knizia 2013,
    via pyscf.lo.ibo — Pipek–Mezey fallback) and reads the Lewis picture off them: each
    localized orbital is classified core / lone pair / 2-centre bond by its Mulliken atomic
    populations, with composition, occupancy and Fock-diagonal energy. Natural (meta-Löwdin /
    NAO) atomic charges round out result["bonding"].

    Honest scope: this is IBO/Pipek–Mezey localization, NOT Weinhold NBO7 (which needs the
    external NBO program) — the result stamps the method used and says so in a warning.
    Restricted closed-shell references only; open-shell degrades to natural charges + a warning."""
    import pyscf

    spec = request.get("spec", {})
    molecule = request["molecule"]
    seed = int(spec.get("rng_seed", 0) or 0)
    _reject_casscf(spec, "nbo")

    t0 = time.perf_counter()
    mol, mf, is_dft = _build_mol(spec, molecule, progress=True)
    wall = time.perf_counter() - t0

    result = rb.blank_result()
    _fill_overview(result, spec, molecule, seed=seed)
    result["method"] = "DFT" if is_dft else "HF"
    result["engine"] = "pyscf"
    result["engine_version"] = str(pyscf.__version__)
    result["wall_clock_s"] = float(wall)
    _fill_scf(result, mol, mf, is_dft, spec)
    result["total_energy"] = result["scf_energy"]
    result["calc_type"] = "nbo"
    _compute_nbo_block(spec, request, mol, mf, result)
    result["success"] = True
    return result


# ─────────────────────────── NEB reaction path (chain of states) ───────────────────────────


def _neb_tangent(r_prev, r_cur, r_next, e_prev, e_cur, e_next):
    """Improved upwind tangent — moved to quchemy.paths.neb_tangent (shared with user
    input scripts); this forwarder keeps the old sidecar-internal name working."""
    from quchemy.paths import neb_tangent

    return neb_tangent(r_prev, r_cur, r_next, e_prev, e_cur, e_next)


def action_neb(request: dict[str, Any]) -> dict[str, Any]:
    """Nudged-elastic-band (NEB) reaction path from reactant to product -> JobResult.

    The reactant is request["molecule"]; the product geometry is spec.params.neb_product_coords
    (a list of [x,y,z] in Å, SAME atom count + order). A band of `neb_images` images is linearly
    interpolated between the two endpoints and relaxed with the improved-tangent NEB (Henkelman
    2000): each interior image feels the PERPENDICULAR true force plus a PARALLEL spring force, so
    it slides onto the minimum-energy path without sliding down it. With the climbing image
    (default on) the highest image inverts its parallel force to climb onto the saddle — a
    transition-state estimate. Fills result["neb_path"] (the optimized band + energies) and mirrors
    it into trajectory (kind "neb") for the 3D scrubber.

    A real but lightweight chain-of-states minimum-energy path: Cartesian (not mass-weighted)
    steepest-descent image moves — enough to map the path and estimate the barrier, not a tight
    saddle optimization (use a Transition state search + IRC to refine)."""
    import numpy as np
    import pyscf

    spec = request.get("spec", {})
    molecule = request["molecule"]
    seed = int(spec.get("rng_seed", 0) or 0)
    params = spec.get("params", {})
    params = params if isinstance(params, dict) else {}
    _reject_casscf(spec, "neb")

    atoms = molecule.get("atoms", [])
    natom = len(atoms)
    r0 = np.asarray([[a["x"], a["y"], a["z"]] for a in atoms], dtype=float)  # reactant (Å)

    # Product geometry — required, same atom count/order. Fail loud (a band needs two ends).
    prod_raw = params.get("neb_product_coords")
    if not isinstance(prod_raw, list) or len(prod_raw) != natom:
        raise ValueError(
            "NEB needs a product geometry (params.neb_product_coords) with the same atom "
            "count/order as the reactant (%d atoms); got %r"
            % (natom, None if prod_raw is None else "%d entries" % len(prod_raw)))
    try:
        rp = np.asarray([[float(p[0]), float(p[1]), float(p[2])] for p in prod_raw], dtype=float)
    except Exception as exc:  # noqa: BLE001
        raise ValueError("NEB product geometry is malformed (need [[x,y,z],…] in Å): %s" % exc)

    n_images = int(np.clip(int(params.get("neb_images", 7)), 3, 15))
    # Clamps used to swallow a larger request silently: asking for 200 iterations got 40
    # with nothing said, so a user who tried to fix a non-converged band had no way to know
    # their instruction was discarded. Honour the cap, but say it was applied.
    _req_iter = int(params.get("neb_max_iter", 10))
    max_iter = int(np.clip(_req_iter, 1, 40))
    spring_k = max(1e-4, float(params.get("neb_spring_k", 0.5)))      # Ha/Å²
    step = max(1e-3, float(params.get("neb_step", 0.5)))              # SD learning rate (Å²/Ha)
    max_move = 0.2                                                    # per-coord move cap (Å)
    climbing = bool(params.get("neb_climbing", True))

    is_mace = _is_mace(spec)
    t0 = time.perf_counter()
    result = rb.blank_result()
    if _req_iter != max_iter:
        _warn(result,
              "neb_max_iter = %d was clamped to %d (the engine's cap) — the larger request "
              "was NOT honoured. If the band does not relax within that, a chain-of-states "
              "run is the wrong tool for this reaction: locate the saddle with a "
              "transition_state run and confirm it with an IRC."
              % (_req_iter, max_iter))
    _fill_overview(result, spec, molecule, seed=seed)
    result["calc_type"] = "neb"
    if is_mace:
        # ML potential: the reactant energy anchors the band; no mean-field / electronic
        # structure (the band + barrier are the whole story for an ML reaction path).
        e_react, _conv = _mace_point_energy(spec, molecule, r0)
        result["engine"] = "mace"
        result["method"] = _mace_model_id(spec)
        _warn(result, "MACE is an ML interatomic potential (%s): energies/forces only — no "
                      "orbitals/charges/dipole on the band." % result["method"])
    else:
        # Reactant SCF — overview/charges/orbitals come from it; its energy anchors the band.
        mol0, mf0, is_dft = _build_mol(spec, molecule, progress=True)
        e_react = float(mf0.e_tot)
        result["method"] = "DFT" if is_dft else "HF"
        result["engine"] = "pyscf"
        result["engine_version"] = str(pyscf.__version__)
        _fill_scf(result, mol0, mf0, is_dft, spec)

    # Linear-interpolated initial band (endpoints fixed throughout).
    # Endpoint energy (fixed): the product, a single point (the reactant was reused above).
    e_prod, _gp, conv_p = _energy_grad_at(spec, molecule, rp)
    if not conv_p:
        _warn(result, "NEB: the product-geometry SCF did not converge — the band end is unreliable")

    # The band itself is quchemy.paths.neb_relax — the SAME function the Method screen's
    # generated input scripts import — driven through the engine's energy/gradient seam.
    from quchemy.paths import neb_relax

    band, energies, band_converged, band_max_force = neb_relax(
        lambda x: _energy_grad_at(spec, molecule, x),
        r0, rp,
        n_images=n_images, max_iter=max_iter, spring_k=spring_k, step=step,
        max_move=max_move, climbing=climbing,
        e_react=float(e_react), e_prod=float(e_prod),
        on_warn=lambda m: _warn(result, m),
        on_iter=lambda it, emax: _emit_progress({"t": "neb", "iter": it, "emax": emax}),
    )
    # A NEB result used to report the REACTANT SCF's convergence while its band could be
    # arbitrarily far from a minimum-energy path — the loop was a bare counter with no
    # force test. Now the band's own verdict decides, and the barrier read off it is
    # labelled a lower bound when the band never relaxed (same policy as a truncated IRC).
    result["irc_reached_minimum"] = bool(band_converged)
    if not band_converged:
        _warn(result,
              "The NEB band did NOT relax: after %d iterations the largest image force is "
              "still %.2e Hartree/Å (tolerance 5e-03). The images are not on the "
              "minimum-energy path, so the barrier below is a LOWER BOUND and the "
              "saddle-image geometry is not a transition-state estimate. Raise "
              "params.neb_max_iter (capped at 40 — for a real reaction, locate the TS "
              "directly with a transition_state run and confirm it with an IRC instead)."
              % (max_iter, band_max_force))

    # Cumulative path length (Å) and the result band + a "neb" trajectory for the scrubber.
    neb_path: list[dict[str, Any]] = []
    frames: list[dict[str, Any]] = []
    s_arc = 0.0
    for i in range(n_images):
        if i > 0:
            s_arc += float(np.linalg.norm(band[i] - band[i - 1]))
        coords = [rb.vec3(band[i][k, 0], band[i][k, 1], band[i][k, 2]) for k in range(natom)]
        neb_path.append(rb.neb_point(i, s_arc, energies[i], coords))
        frames.append(rb.trajectory_frame(s_arc, coords, energies[i], 0.0))
    result["neb_path"] = neb_path
    result["trajectory"] = frames
    result["trajectory_kind"] = "neb"

    # Headline geometry = the highest image (the transition-state estimate); the headline
    # energy stays the reactant reference (= scf_energy) — the barrier lives in neb_path.
    i_ts = int(np.argmax(energies))
    result["final_coords"] = [
        rb.vec3(band[i_ts][k, 0], band[i_ts][k, 1], band[i_ts][k, 2]) for k in range(natom)
    ]
    result["total_energy"] = result["scf_energy"]
    barrier_ev = (max(energies) - e_react) * 27.211386245988
    _warn(result, "NEB barrier ≈ %.2f eV (forward), image %d of %d is the saddle estimate — "
                  "a chain-of-states minimum-energy path (Cartesian steepest descent, %d "
                  "iterations); refine with a Transition state search + IRC."
                  % (barrier_ev, i_ts, n_images, max_iter))
    result["wall_clock_s"] = float(time.perf_counter() - t0)
    result["success"] = True
    return result


# ─────────────────────────── MACE ML interatomic potential ───────────────────────────

# eV → Hartree (MACE foundation models emit eV / eV·Å⁻¹; the result contract is Hartree).
_EV_TO_HARTREE: float = 1.0 / 27.211386245988
# Calc types action_mace serves directly (energy + forces only — the gradient-driven family).
# Wavefunction types are never MACE.
_MACE_CALC_TYPES: frozenset[str] = frozenset(
    {"energy", "optimize", "opt+freq", "frequencies", "md"}
)
# Reaction-path calc types the MACE backend serves through their own actions + the shared
# energy/gradient seam: NEB + PES scan (Phase 2), plus IRC (numerical Hessian for the
# imaginary mode) + relaxed_scan (ASE FixInternals constrained opt) (Phase 2b).
_MACE_MECHANISM_CALC_TYPES: frozenset[str] = frozenset(
    {"neb", "pes_scan", "irc", "relaxed_scan"}
)
# Built MACE calculators, keyed (model, device, dtype). A model load is expensive (checkpoint
# + torch graph), so a NEB/scan that calls the gradient seam hundreds of times — or a committee
# that loads several models — reuses each one.
_MACE_CALC_CACHE: dict[tuple[str, str, str], Any] = {}
# Compute devices + precisions the backend accepts (Phase 3). cuda = NVIDIA GPU, mps = Apple
# Silicon GPU; float32 is faster, float64 keeps finite-difference Hessians/tight opts clean.
_MACE_DEVICES: frozenset[str] = frozenset({"cpu", "cuda", "mps"})
_MACE_DTYPES: frozenset[str] = frozenset({"float32", "float64"})


def _is_mace(spec: dict[str, Any]) -> bool:
    """True when the run targets the MACE ML-potential engine (spec.backend == 'mace')."""
    return str(spec.get("backend", "")).strip().lower() == "mace"


def _mace_model_id(spec: dict[str, Any]) -> str:
    """The MACE foundation-model id for this run (params.mace_model, default OFF-medium)."""
    return str((spec.get("params", {}) or {}).get("mace_model", "mace-off-medium"))


def _mace_device(spec: dict[str, Any]) -> str:
    """The validated compute device (params.mace_device, default cpu). Fails loud on an
    unknown device rather than silently running on the CPU."""
    device = str((spec.get("params", {}) or {}).get("mace_device", "cpu")).strip().lower()
    if device not in _MACE_DEVICES:
        raise ValueError("Unknown MACE device %r — use one of %s."
                         % (device, ", ".join(sorted(_MACE_DEVICES))))
    return device


def _mace_dtype(spec: dict[str, Any]) -> str:
    """The validated float precision (params.mace_dtype, default float64). Fails loud on an
    unknown precision."""
    dtype = str((spec.get("params", {}) or {}).get("mace_dtype", "float64")).strip().lower()
    if dtype not in _MACE_DTYPES:
        raise ValueError("Unknown MACE precision %r — use float32 or float64." % dtype)
    return dtype


def _mace_committee(spec: dict[str, Any]) -> list[str]:
    """The committee model ids (params.mace_committee) — the spread of an energy across them
    is a rough epistemic-uncertainty proxy. [] (no committee) unless ≥2 distinct ids given."""
    raw = (spec.get("params", {}) or {}).get("mace_committee", [])
    if not isinstance(raw, list):
        return []
    models = [str(m) for m in raw if str(m)]
    # De-dup but keep order; a committee needs ≥2 genuinely-different models to mean anything.
    seen: list[str] = []
    for m in models:
        if m not in seen:
            seen.append(m)
    return seen if len(seen) >= 2 else []


def _ensure_matscipy_shim() -> None:
    """Make `import matscipy.neighbours` resolve even where matscipy has no wheel (Python 3.14).

    MACE hard-imports matscipy's neighbour-list, but matscipy fails to build on 3.14 while
    everything else in the stack installs. When the real matscipy is absent, prepend the
    sidecar's ASE-backed shim (quchemy/compat/matscipy_shim) to sys.path — the same load-shim
    pattern the dispersion backend uses. A real matscipy install always wins (checked first)."""
    try:
        import matscipy  # noqa: F401 — real matscipy present; nothing to do
        return
    except Exception:  # noqa: BLE001
        pass
    shim = os.path.join(os.path.dirname(os.path.abspath(__file__)),
                        "quchemy", "compat", "matscipy_shim")
    if os.path.isdir(shim) and shim not in sys.path:
        sys.path.insert(0, shim)


def _require_mace() -> None:
    """Import-guard for the ML stack: fail loud with an actionable install hint when torch /
    ase / mace are missing (the Method screen greys the card, but the sidecar is the contract).
    Activates the matscipy shim first so MACE's neighbour-list import resolves on Python 3.14."""
    _ensure_matscipy_shim()
    try:
        import ase  # noqa: F401
        import mace  # noqa: F401
        import torch  # noqa: F401
    except Exception as exc:  # noqa: BLE001 — the whole point is a readable install hint
        raise RuntimeError(
            "MACE backend unavailable: %s. Install it from Config → Engines (or "
            "`pip install torch ase e3nn ... && pip install --no-deps mace-torch` — the "
            "sidecar ships an ASE-backed matscipy shim, so matscipy itself is not needed)." % exc
        )


def _mace_is_custom_model(model: str) -> bool:
    """True when `model` is a fine-tuned/custom checkpoint PATH rather than a foundation id.

    Fine-tuning a MACE model is an offline, data + GPU-heavy step that lives outside the
    sidecar (the `mace_run_train` CLI); the sidecar's job is to USE the resulting checkpoint.
    A model string that is a filesystem path (has a separator, or a .model/.pt/.pth suffix) is
    treated as such a checkpoint; a bare id like "mace-off-medium" is a foundation model."""
    m = (model or "").strip()
    if any(m.lower().endswith(ext) for ext in (".model", ".pt", ".pth")):
        return True
    return ("/" in m or os.path.sep in m) and not m.startswith("mace-")


def _mace_build_calc(spec: dict[str, Any], model: str | None = None):
    """Return a cached ASE MACE calculator for `model` (default this run's model) on the run's
    device + precision. Built once per (model, device, dtype). A foundation id loads via the
    mace.calculators loader; a checkpoint PATH (a fine-tuned model trained offline) loads via
    MACECalculator(model_paths=[...])."""
    _require_mace()
    model = model or _mace_model_id(spec)
    device = _mace_device(spec)
    dtype = _mace_dtype(spec)
    key = (model, device, dtype)
    if key not in _MACE_CALC_CACHE:
        if _mace_is_custom_model(model):
            if not os.path.isfile(model):
                raise FileNotFoundError(
                    "MACE model checkpoint not found: %r. Point params.mace_model at a "
                    "fine-tuned .model file, or use a foundation id (mace-off-medium / "
                    "mace-mp-medium)." % model)
            from mace.calculators import MACECalculator
            _MACE_CALC_CACHE[key] = MACECalculator(
                model_paths=[model], device=device, default_dtype=dtype)
        else:
            loader, size = _mace_model_loader(model)
            _MACE_CALC_CACHE[key] = loader(model=size, device=device, default_dtype=dtype)
    return _MACE_CALC_CACHE[key]


def _mace_committee_uncertainty(spec: dict[str, Any], molecule: dict[str, Any], coords_ang):
    """Energy/force spread across the committee models (params.mace_committee) at `coords_ang`.

    Evaluates each committee model once and returns an rb.mace_uncertainty dict (energy std in
    Hartree, max per-component force std in eV/Å, committee size). {} when no committee was
    requested. A rough, uncalibrated epistemic signal — a large spread flags a geometry off the
    models' shared training distribution (the active-learning candidate)."""
    import numpy as np

    models = _mace_committee(spec)
    if not models:
        return {}
    energies: list[float] = []
    forces: list[Any] = []
    for m in models:
        calc = _mace_build_calc(spec, model=m)
        atoms_ase = _ase_atoms(molecule, coords_ang)
        atoms_ase.calc = calc
        energies.append(float(atoms_ase.get_potential_energy()))      # eV
        forces.append(np.asarray(atoms_ase.get_forces()))             # eV/Å
    e_std_ha = float(np.std(energies)) * _EV_TO_HARTREE
    f_std = float(np.max(np.std(np.stack(forces), axis=0))) if forces else 0.0
    return rb.mace_uncertainty(
        energy_std_ha=e_std_ha, max_force_std_ev_ang=f_std, n_models=len(models),
        source="committee of %d MACE models (%s)" % (len(models), ", ".join(models)))


def _mace_energy_grad(spec: dict[str, Any], molecule: dict[str, Any], coords_ang):
    """MACE counterpart of [func]_energy_grad_at[/func]: (energy Hartree, nuclear gradient
    Hartree/Bohr, converged=True) at `coords_ang`. Forces (eV/Å) → gradient (Ha/Bohr):
    g = −F · eV→Ha · (Å/Bohr). The gradient seam that lights up NEB on the MACE engine."""
    import numpy as np

    calc = _mace_build_calc(spec)
    atoms_ase = _ase_atoms(molecule, coords_ang)
    atoms_ase.calc = calc
    e_ha = float(atoms_ase.get_potential_energy()) * _EV_TO_HARTREE
    forces = np.asarray(atoms_ase.get_forces())  # eV/Å
    grad = -forces * _EV_TO_HARTREE * _BOHR_TO_ANG  # Hartree/Bohr
    return e_ha, grad, True


def _mace_point_energy(spec: dict[str, Any], molecule: dict[str, Any], coords_ang):
    """MACE single-point energy (Hartree, converged=True) at `coords_ang` — the energy-only
    seam for the rigid PES scan."""
    calc = _mace_build_calc(spec)
    atoms_ase = _ase_atoms(molecule, coords_ang)
    atoms_ase.calc = calc
    return float(atoms_ase.get_potential_energy()) * _EV_TO_HARTREE, True


def _mace_normal_modes(spec: dict[str, Any], molecule: dict[str, Any]):
    """Numerical (finite-difference) normal-mode analysis on the MACE forces at the input
    geometry. Returns (signed_wavenumbers cm⁻¹ as a real array — imaginary modes negative,
    modes list of (natoms, 3) Cartesian displacements). The IRC path reads the most-negative
    mode (the reaction coordinate at a transition state) off this."""
    _require_mace()  # friendly install hint before the bare `from ase...` import
    import os
    import tempfile

    import numpy as np
    from ase.vibrations import Vibrations

    calc = _mace_build_calc(spec)
    atoms_ase = _ase_atoms(molecule)
    atoms_ase.calc = calc
    with tempfile.TemporaryDirectory() as tmp:
        vib = Vibrations(atoms_ase, name=os.path.join(tmp, "vib"))
        vib.run()
        freqs = np.asarray(vib.get_frequencies())  # cm⁻¹, imaginary modes as complex
        modes = [np.asarray(vib.get_mode(i)) for i in range(len(freqs))]
        vib.clean()
    signed = np.where(np.abs(freqs.imag) > np.abs(freqs.real), -np.abs(freqs.imag), freqs.real)
    return np.real(signed).astype(float), modes


def _mace_constrained_opt_to_value(
    spec: dict[str, Any], molecule: dict[str, Any], kind: str, atoms: list[int],
    value: float, *, fmax: float = 0.03, steps: int = 200,
):
    """One relaxed-scan step on MACE: optimize `molecule` while holding the (kind, atoms)
    coordinate at `value` (distance Å / angle·dihedral degrees) with an ASE FixInternals
    constraint, relaxing everything else. Returns (energy_Ha, coords_ang, converged) — the
    MACE counterpart of [func]_constrained_opt_to_value[/func]."""
    _require_mace()  # friendly install hint before the bare `from ase...` import
    from ase.constraints import FixInternals
    from ase.optimize import LBFGS

    calc = _mace_build_calc(spec)
    atoms_ase = _ase_atoms(molecule)
    atoms_ase.calc = calc
    idx = [int(a) for a in atoms]
    # Pre-set the scanned coordinate to the target BEFORE constraining. ASE FixInternals only
    # *holds* a coordinate — it does not *drive* it to the target. When the start geometry
    # already satisfies a different value (e.g. the previous chained scan point) and the rest
    # is relaxed, LBFGS converges at step 0 and the bond never reaches `value` — every later
    # scan point then collapses onto the first. Seeding the geometry at the target fixes that.
    if kind == "distance":
        atoms_ase.set_distance(idx[0], idx[1], float(value), fix=0)
        cons = FixInternals(bonds=[[float(value), idx]])
    elif kind == "angle":
        atoms_ase.set_angle(idx[0], idx[1], idx[2], float(value))
        cons = FixInternals(angles_deg=[[float(value), idx]])
    else:  # dihedral
        atoms_ase.set_dihedral(idx[0], idx[1], idx[2], idx[3], float(value))
        cons = FixInternals(dihedrals_deg=[[float(value), idx]])
    atoms_ase.set_constraint(cons)
    converged = bool(LBFGS(atoms_ase, logfile=None).run(fmax=fmax, steps=steps))
    e_ha = float(atoms_ase.get_potential_energy()) * _EV_TO_HARTREE
    return e_ha, atoms_ase.get_positions(), converged


def _mace_model_loader(model: str):
    """Resolve a MACE foundation-model id → (loader, size) for mace.calculators.

    `model` is "mace-off-<size>" (MACE-OFF, organic molecules) or "mace-mp-<size>"
    (MACE-MP-0, ~89 elements / materials), size ∈ {small, medium, large}. Returns the
    (callable, size_str) used to build the calculator. Defaults to MACE-OFF medium."""
    from mace.calculators import mace_mp, mace_off

    m = (model or "mace-off-medium").strip().lower()
    size = "medium"
    for s in ("small", "medium", "large"):
        if m.endswith(s):
            size = s
            break
    loader = mace_mp if "mp" in m else mace_off
    return loader, size


def _mace_calculator(spec: dict[str, Any], result: dict[str, Any]):
    """The ASE-attached MACE calculator for this run (cached), stamping result["method"]
    with the model id. Fails loud with an install hint when the ML stack is absent."""
    calc = _mace_build_calc(spec)
    result["method"] = _mace_model_id(spec)
    return calc


def _ase_atoms(molecule: dict[str, Any], coords=None):
    """Build an ase.Atoms for `molecule` (optionally at replacement `coords`, an
    (natoms, 3) Å array). Charge/spin are NOT set — the foundation models are neutral
    closed-shell; the caller warns when a non-trivial charge/multiplicity was requested."""
    from ase import Atoms

    atoms = molecule.get("atoms", [])
    symbols = [str(a.get("element", "")) for a in atoms]
    if coords is None:
        positions = [[float(a["x"]), float(a["y"]), float(a["z"])] for a in atoms]
    else:
        positions = [[float(c[0]), float(c[1]), float(c[2])] for c in coords]
    return Atoms(symbols=symbols, positions=positions)


def _mace_fill_geometry(result: dict[str, Any], atoms_ase) -> None:
    """Stamp final_coords (Å) + atom_symbols from an ase.Atoms onto the result."""
    pos = atoms_ase.get_positions()
    result["final_coords"] = [rb.vec3(p[0], p[1], p[2]) for p in pos]
    result["atom_symbols"] = [str(s) for s in atoms_ase.get_chemical_symbols()]


def action_mace(request: dict[str, Any]) -> dict[str, Any]:
    """MACE ML-interatomic-potential run -> JobResult.

    A fast DFT surrogate (MACE-OFF organics / MACE-MP-0 materials) via mace-torch + ASE:
    serves the gradient-driven calc types — energy, optimize, opt+freq, frequencies, md.
    Energies/forces only: there is NO wavefunction, so orbitals, charges, dipole, IR
    intensities and every spectroscopy/Fukui/NBO tab stay empty (stated in a warning, never
    a silent blank). Honest provenance: engine "mace", method = the model id.

    Reaction-path types (irc/neb/scan) ride the shared gradient seam in Phase 2; here an
    unsupported calc type fails loud BEFORE any heavy import."""
    spec = request.get("spec", {})
    molecule = request["molecule"]
    seed = int(spec.get("rng_seed", 0) or 0)
    calc_type = str(spec.get("calc_type", "energy")).lower()
    if calc_type not in _MACE_CALC_TYPES:
        raise NotImplementedError(
            "MACE backend does not support calc_type %r — it is an ML interatomic "
            "potential (energy/optimize/opt+freq/frequencies/md only). Reaction-path types "
            "(IRC/NEB/scan) ride a classical engine here." % calc_type
        )

    t0 = time.perf_counter()
    result = rb.blank_result()
    _fill_overview(result, spec, molecule, seed=seed)
    result["engine"] = "mace"
    result["calc_type"] = spec.get("calc_type", "energy")

    calc = _mace_calculator(spec, result)  # fail-loud import + model label
    try:
        import mace
        result["engine_version"] = str(getattr(mace, "__version__", "unknown"))
    except Exception:  # noqa: BLE001
        pass

    # The base foundation models are neutral closed-shell — be honest if asked otherwise.
    if int(molecule.get("charge", 0)) != 0 or int(molecule.get("multiplicity", 1)) != 1:
        _warn(result, "MACE foundation models are trained on neutral closed-shell systems; "
                      "the requested charge/multiplicity is ignored by the potential.")

    atoms_ase = _ase_atoms(molecule)
    atoms_ase.calc = calc

    if calc_type in ("optimize", "opt+freq"):
        _mace_optimize(spec, atoms_ase, result)
    if calc_type == "md":
        _mace_md(spec, atoms_ase, result)
    elif calc_type in ("frequencies", "opt+freq"):
        _mace_frequencies(atoms_ase, result, spec)
        _mace_single_point(atoms_ase, result)
        _mace_thermochemistry(spec, result, atoms_ase, float(result.get("total_energy", 0.0)))
    else:
        # energy (and the post-optimize energy for "optimize")
        _mace_single_point(atoms_ase, result)

    if calc_type != "md":
        _mace_fill_geometry(result, atoms_ase)

    # Committee uncertainty at the final geometry (opt-in via params.mace_committee): the
    # prediction spread across the committee — a rough confidence signal for the ML result.
    if _mace_committee(spec) and calc_type != "md":
        unc = _mace_committee_uncertainty(spec, molecule, atoms_ase.get_positions())
        if unc:
            result["mace_uncertainty"] = unc
            _warn(result, "MACE committee uncertainty: energy ±%.4f eV, max force ±%.3f eV/Å "
                          "across %d models — a rough (uncalibrated) confidence signal; a large "
                          "spread means this geometry is off the models' training distribution."
                          % (unc["energy_std_ha"] / _EV_TO_HARTREE,
                             unc["max_force_std_ev_ang"], unc["n_models"]))

    # The honest "no electronic structure" note (orbitals/charges/dipole/spectra stay empty).
    _warn(result, "MACE is an ML interatomic potential (%s): energies and forces only — no "
                  "electronic structure, so orbitals, charges, dipole and spectra "
                  "(IR intensities / UV-Vis / NMR) and Fukui/NBO are unavailable."
                  % result.get("method", "model"))
    result["wall_clock_s"] = float(time.perf_counter() - t0)
    result["success"] = True
    return result


def _mace_single_point(atoms_ase, result: dict[str, Any]) -> None:
    """Fill total_energy/scf_energy (Ha) from the potential energy at the current geometry."""
    e_ev = float(atoms_ase.get_potential_energy())
    e_ha = e_ev * _EV_TO_HARTREE
    result["total_energy"] = e_ha
    result["scf_energy"] = e_ha
    # An ML potential has no SCF to converge, so this flag carries the GEOMETRY's verdict —
    # and this runs AFTER _mace_optimize, so forcing True here silently undid a failed
    # optimization's honest False. A plain single point never optimized anything, and
    # geometry_converged defaults True, so it still reports converged.
    result["converged"] = bool(result.get("geometry_converged", True))


def _mace_optimize(spec: dict[str, Any], atoms_ase, result: dict[str, Any]) -> None:
    """Relax the geometry with ASE LBFGS on MACE forces; record the per-step energy trace."""
    from ase.optimize import LBFGS

    params = spec.get("params", {}) or {}
    fmax = float(params.get("mace_fmax", 0.03))          # eV/Å convergence
    steps = int(params.get("mace_opt_steps", 200))
    energies: list[float] = []

    def _observe() -> None:
        e = float(atoms_ase.get_potential_energy()) * _EV_TO_HARTREE
        energies.append(e)
        _emit_progress({"t": "opt", "step": len(energies), "e": e})

    dyn = LBFGS(atoms_ase, logfile=None)
    dyn.attach(_observe, interval=1)
    dyn.run(fmax=fmax, steps=steps)
    result["opt_steps"] = [rb.opt_step(e) for e in energies]

    # The classical path got this in the 08-03 review (_warn_unconverged_geometry) and the
    # MACE path never did: the return value and dyn.converged() were both discarded, so an
    # optimization that merely ran out of steps reported converged=true. Measured on a
    # distorted water with mace_opt_steps=2: converged=true, 185.2 kcal/mol above the real
    # minimum on the same surface, no warning. ASE hands the flag over for free.
    _converged = bool(dyn.converged())
    _warn_unconverged_geometry(result, _converged, steps)
    # Record the force that decides it, in the same units as every other max_gradient
    # (Eh/Bohr) — it was left at the blank_result default of 0.0 on every MACE optimize.
    try:
        import numpy as _np

        gmax_ev_ang = float(_np.abs(atoms_ase.get_forces()).max())
        result["max_gradient"] = gmax_ev_ang * _EV_TO_HARTREE * _BOHR_TO_ANG
    except Exception:  # noqa: BLE001 — a diagnostic must never fail the job
        pass


def _is_linear_ase(atoms_ase) -> bool:
    """True when the molecule is linear (one vanishing principal moment of inertia).

    Decides whether 5 or 6 degrees of freedom are translation/rotation — CO2 has 4 real
    vibrations, not 3, so getting this wrong drops a genuine mode.
    """
    import numpy as np

    if len(atoms_ase) < 3:
        return True
    try:
        moments = np.sort(np.abs(atoms_ase.get_moments_of_inertia()))
        return bool(moments[0] < 1e-3 * max(moments[-1], 1e-12))
    except Exception:  # noqa: BLE001 — fall back to the safe non-linear assumption
        return False


def _mace_frequencies(atoms_ase, result: dict[str, Any], spec: dict[str, Any]) -> None:
    """Numerical (finite-difference) Hessian via ase.vibrations.Vibrations on MACE forces.

    Fills result["vibrations"] (wavenumbers; IR intensities are 0 — an ML potential has no
    dipole derivatives) and n_imaginary / stationary_point. Cache files go to a temp dir."""
    import tempfile

    import numpy as np
    from ase.vibrations import Vibrations

    with tempfile.TemporaryDirectory() as tmp:
        vib = Vibrations(atoms_ase, name=os.path.join(tmp, "vib"))
        vib.run()
        freqs = np.asarray(vib.get_frequencies())  # cm⁻¹, imaginary modes as complex
        vib.clean()

    # ASE diagonalizes the raw 3N x 3N finite-difference Hessian: it does NOT project out
    # the translational/rotational subspace the way pyscf's thermo.harmonic_analysis does on
    # the classical path, so all 3N eigenvalues come back. Water returned nine "modes"
    # (-42.31, -0.46, -0.01, 0.13, 40.47, 45.87, 1627, 3855, 3941) — six of them trans/rot —
    # and the thermochemistry filter (wn > 1.0) then fed 40.47 and 45.87 to thermo.thermo as
    # genuine vibrations. A ~40 cm^-1 mode carries ~5 cal/mol/K of entropy, so water's S came
    # out 55.29 against a correct 45.07 (experiment 45.10) and G was 1.86 kcal/mol low.
    #
    # Drop the 3N-6 (3N-5 if linear) modes closest to zero. This is selection by magnitude
    # rather than a true projection, which is the honest tool available on top of ASE's
    # eigenvalues: an imaginary mode has large |w| and therefore survives, so a transition
    # state is still classified correctly.
    signed_all = []
    for f in freqs:
        wn = float(np.real(f))
        if abs(np.imag(f)) > abs(np.real(f)):
            wn = -float(np.imag(f))  # signed-negative for an imaginary mode
        signed_all.append(wn)
    n_atoms = len(atoms_ase)
    n_trans_rot = 5 if _is_linear_ase(atoms_ase) else 6
    n_vib = max(0, 3 * n_atoms - n_trans_rot)
    if n_atoms > 1 and 0 < n_vib < len(signed_all):
        # Keep the n_vib largest by magnitude, restored to ascending order.
        keep = sorted(sorted(range(len(signed_all)),
                             key=lambda i: abs(signed_all[i]), reverse=True)[:n_vib])
        dropped = [signed_all[i] for i in range(len(signed_all)) if i not in set(keep)]
        signed = [signed_all[i] for i in keep]
        if any(abs(d) > 100.0 for d in dropped):
            _warn(result,
                  "MACE frequencies: the %d translational/rotational modes were removed by "
                  "magnitude, and the largest removed was %.1f cm^-1 — high enough that it "
                  "may be a real low-frequency vibration rather than a rotation. Treat the "
                  "vibrational entropy with caution."
                  % (n_trans_rot, max(abs(d) for d in dropped)))
    else:
        signed = signed_all

    modes: list[dict[str, Any]] = []
    n_imag = 0
    for wn in signed:
        if wn < -50.0:
            n_imag += 1
        modes.append(rb.vibration_mode(wn, ir_intensity=0.0))
    result["vibrations"] = modes
    result["n_imaginary"] = n_imag
    result["stationary_point"] = rb.stationary_label(n_imag)
    # Same guard as the PySCF path (_check_stationary_point): a Hessian classifies a
    # stationary point, it never establishes you are at one. The ML forces ARE the
    # gradient here, so this costs nothing — one already-computed force call.
    try:
        import numpy as _np
        gmax_ev_ang = float(_np.abs(atoms_ase.get_forces()).max())
        # ase forces are eV/Å and are -dE/dx; convert the magnitude to Eh/Bohr.
        gmax = gmax_ev_ang * _EV_TO_HARTREE * _BOHR_TO_ANG
        result["max_gradient"] = gmax
        if gmax > _GMAX_TOL_HA_BOHR:
            result["stationary_point"] = "not_stationary"
            _warn(result,
                  "This geometry is NOT a stationary point on the MACE surface: the largest "
                  "force component is %.2e Eh/Bohr, %.0fx the %.1e threshold. Frequencies and "
                  "thermochemistry from it are not usable — optimize with MACE first."
                  % (gmax, gmax / _GMAX_TOL_HA_BOHR, _GMAX_TOL_HA_BOHR))
    except Exception as exc:  # noqa: BLE001 — never fail the job over the check itself
        _warn(result, "could not verify that this geometry is a stationary point (%s)." % exc)
    _warn(result, "MACE frequencies are from a finite-difference Hessian on the ML forces; "
                  "IR/Raman intensities are unavailable (no dipole/polarizability derivatives).")


def _mace_thermochemistry(
    spec: dict[str, Any], result: dict[str, Any], atoms_ase, electronic_energy_ha: float
) -> None:
    """Fill result['thermochemistry'] + ['thermo_scan'] for a MACE frequency run.

    Reuses pyscf's harmonic-thermo machinery (thermo.thermo) on the MACE wavenumbers so the
    block is unit-identical to the classical path (energies Eh, S/Cv Eh/K) and carries Cv +
    the G/H/S-vs-T scan. The MACE wavenumbers are converted back to pyscf's atomic-unit
    frequencies; imaginary / near-zero (translation/rotation) modes are dropped — the standard
    transition-state / non-stationary-geometry treatment. Never raises: on any failure the
    vibrations still stand and a warning explains the empty thermo block."""
    try:
        import numpy as np
        from pyscf import gto
        from pyscf.hessian import thermo
        from pyscf.data import nist

        wn = np.asarray([float(m.get("wavenumber", 0.0)) for m in result.get("vibrations", [])])
        real_cm = wn[wn > 1.0]  # drop imaginary (signed-negative) + ~zero trans/rot modes
        if real_cm.size == 0:
            _warn(result, "thermochemistry unavailable: no real vibrational modes "
                          "(is this geometry optimized? use opt+freq).")
            return
        # Invert pyscf's freq_au → cm⁻¹ map so thermo.thermo sees its own atomic-unit input.
        au2hz = (nist.HARTREE2J / (nist.ATOMIC_MASS * nist.BOHR_SI ** 2)) ** 0.5 / (2 * np.pi)
        cm_per_au = au2hz / nist.LIGHT_SPEED_SI * 1e-2
        freq_au = real_cm / cm_per_au

        # Minimal pyscf Mole from the FINAL geometry (basis irrelevant to thermo — it only
        # reads masses / coords / symmetry). Charge & spin from the molecule so an open-shell
        # request doesn't trip gto's parity check (the foundation model itself stays neutral).
        syms = result.get("atom_symbols") or [str(a.symbol) for a in atoms_ase]
        pos = atoms_ase.get_positions()
        atom = [[str(syms[i]), (float(pos[i][0]), float(pos[i][1]), float(pos[i][2]))]
                for i in range(len(syms))]
        charge = int((result.get("charge", 0) or 0))
        spin = max(0, int((result.get("multiplicity", 1) or 1)) - 1)
        with _quiet():
            mol = gto.M(atom=atom, basis="sto-3g", charge=charge, spin=spin,
                        unit="Angstrom", verbose=0)
        model = type("_MaceThermoModel", (), {"mol": mol, "e_tot": float(electronic_energy_ha)})()

        temperature_k, pressure_pa = _thermo_conditions(spec)
        with _quiet():
            th = thermo.thermo(model, freq_au, float(temperature_k), float(pressure_pa))
        result["thermochemistry"] = rb.thermochemistry(
            temperature_k=float(temperature_k),
            electronic_energy=float(electronic_energy_ha),
            zpe=float(th["ZPE"][0]),
            internal_energy=float(th["E_tot"][0]),
            enthalpy=float(th["H_tot"][0]),
            gibbs=float(th["G_tot"][0]),
            entropy=float(th["S_tot"][0]),
            heat_capacity_cv=float(th["Cv_tot"][0]),
        )
        scan: list[dict[str, float]] = []
        for t in _thermo_scan_temperatures(float(temperature_k)):
            try:
                with _quiet():
                    th_t = thermo.thermo(model, freq_au, float(t), float(pressure_pa))
                scan.append(rb.thermo_point(
                    temperature_k=float(t),
                    gibbs=float(th_t["G_tot"][0]),
                    enthalpy=float(th_t["H_tot"][0]),
                    entropy=float(th_t["S_tot"][0]),
                    zpe=float(th_t["ZPE"][0]),
                ))
            except Exception as exc:  # noqa: BLE001 — one bad T drops, scan stands
                _warn(result, f"thermo scan point at {t:g} K unavailable: {exc}")
        result["thermo_scan"] = scan
    except Exception as exc:  # noqa: BLE001 — vibrations stand; thermo block says why
        _warn(result, f"thermochemistry unavailable: {exc}")


# MD is expensive (a force eval + a trajectory frame per step) — cap the requested step
# count so a hand-built / reproduced request with a huge md_steps can't run unbounded and
# accumulate frames without limit. Shared by both MD paths (pyscf BOMD and MACE Langevin).
_MAX_MD_STEPS: int = 200


def _clamp_md_steps(requested: Any) -> int:
    """Clamp a requested MD step count to [1, _MAX_MD_STEPS]."""
    return max(1, min(int(requested), _MAX_MD_STEPS))


def _mace_md(spec: dict[str, Any], atoms_ase, result: dict[str, Any]) -> None:
    """NVT Langevin molecular dynamics on MACE forces; fills the trajectory (kind "md")."""
    from ase import units
    from ase.md.langevin import Langevin
    from ase.md.velocitydistribution import MaxwellBoltzmannDistribution

    params = spec.get("params", {}) or {}
    n_steps = _clamp_md_steps(params.get("md_steps", 20))
    temp_k = float(params.get("md_temp_k", 300.0))
    dt_fs = float(params.get("md_dt_fs", 0.5))

    MaxwellBoltzmannDistribution(atoms_ase, temperature_K=temp_k)
    dyn = Langevin(atoms_ase, timestep=dt_fs * units.fs, temperature_K=temp_k, friction=0.01)
    frames: list[dict[str, Any]] = []

    def _frame() -> None:
        pos = atoms_ase.get_positions()
        coords = [rb.vec3(p[0], p[1], p[2]) for p in pos]
        e = float(atoms_ase.get_potential_energy()) * _EV_TO_HARTREE
        t_now = float(atoms_ase.get_temperature())
        frames.append(rb.trajectory_frame(len(frames) * dt_fs, coords, e, t_now))
        _emit_progress({"t": "md", "step": len(frames), "e": e})

    _frame()  # initial frame
    dyn.attach(_frame, interval=1)
    dyn.run(n_steps)
    result["trajectory"] = frames
    result["trajectory_kind"] = "md"
    last = atoms_ase.get_positions()
    result["final_coords"] = [rb.vec3(p[0], p[1], p[2]) for p in last]
    result["atom_symbols"] = [str(s) for s in atoms_ase.get_chemical_symbols()]
    if frames:
        result["total_energy"] = float(frames[-1]["energy"])
        result["scf_energy"] = float(frames[-1]["energy"])
    result["converged"] = True


def _spec_flag(spec: dict[str, Any], name: str) -> bool:
    params = spec.get("params", {})
    if isinstance(params, dict) and bool(params.get(name, False)):
        return True
    return bool(spec.get(name, False))


def _nmr_class(mf):
    """Return the pyscf-properties NMR class matching the (possibly solvent-wrapped)
    mean-field — restricted or unrestricted. ROHF/ROKS has no NMR driver in
    pyscf.prop, so it is refused with a clear message (caught → warning)."""
    import warnings

    if _is_rohf(mf):
        raise NotImplementedError(
            "NMR shieldings are not available for an ROHF/ROKS reference in "
            "pyscf-properties — use UHF/UKS (params.reference) instead"
        )
    with warnings.catch_warnings():
        warnings.simplefilter("ignore")  # pyscf.prop prints "Module X is under testing"
        from pyscf.prop import nmr as nmr_mod
    is_ks = hasattr(mf, "xc")
    if _is_unrestricted(mf):
        return nmr_mod.UKS if is_ks else nmr_mod.UHF
    return nmr_mod.RKS if is_ks else nmr_mod.RHF


def _polarizability_class(mf):
    """Return the pyscf-properties Polarizability class matching the mean-field
    (R/U × HF/KS). ROHF/ROKS is refused — no RO response driver exists in
    pyscf.prop; callers catch and warn."""
    import warnings

    if _is_rohf(mf):
        raise NotImplementedError(
            "polarizability is not available for an ROHF/ROKS reference in "
            "pyscf-properties — use UHF/UKS (params.reference) instead"
        )
    with warnings.catch_warnings():
        warnings.simplefilter("ignore")
        if _is_unrestricted(mf):
            if hasattr(mf, "xc"):
                from pyscf.prop.polarizability.uks import Polarizability
            else:
                from pyscf.prop.polarizability.uhf import Polarizability
        else:
            if hasattr(mf, "xc"):
                from pyscf.prop.polarizability.rks import Polarizability
            else:
                from pyscf.prop.polarizability.rhf import Polarizability
    return Polarizability


def _try_nmr_kernel(cls, mf, *, cphf: bool):
    """Run a pyscf-properties NMR kernel, returning the shielding tensors or None.

    `cphf=False` selects the UNCOUPLED (no coupled-perturbed response) shieldings —
    the route that sidesteps the addon's response-solver version skew with this PySCF
    (a hardcoded `reshape(3, nmo, nocc)` in the CPHF `vind`)."""
    import warnings

    try:
        with warnings.catch_warnings():
            warnings.simplefilter("ignore")  # "Module X is under testing" noise
            obj = cls(mf)
        obj.verbose = 0
        obj.cphf = cphf
        with _quiet():
            return obj.kernel()
    except Exception:  # noqa: BLE001 — caller tries the next fallback / warns
        return None


def _hf_reference_for_nmr(mf):
    """Build an HF mean-field (matching R/U) on `mf`'s molecule plus the matching
    pyscf-properties NMR class, for the DFT-GIAO fallback. Returns (hf_mf, cls) or
    (None, None)."""
    import warnings

    from pyscf import scf

    try:
        hf = scf.UHF(mf.mol) if _is_unrestricted(mf) else scf.RHF(mf.mol)
        hf.verbose = 0
        with _quiet():
            hf.kernel()
        with warnings.catch_warnings():
            warnings.simplefilter("ignore")
            from pyscf.prop import nmr as nmr_mod
        cls = nmr_mod.UHF if _is_unrestricted(mf) else nmr_mod.RHF
        return hf, cls
    except Exception:  # noqa: BLE001
        return None, None


def _compute_nmr_shieldings(mol, mf, result: dict[str, Any]) -> None:
    """Fill result["nmr_shieldings"] with per-atom GIAO shielding records
    ({atom_index, isotropic, anisotropy, symbol}, ppm).

    The pinned pyscf-properties GIAO response is incompatible with this PySCF build in
    two ways (a hardcoded CPHF `reshape(3, nmo, nocc)` and a DFT numint `block_loop`
    blksize assertion), so we degrade through real-number fallbacks rather than return
    nothing: coupled GIAO → UNCOUPLED GIAO (works for HF) → for a DFT reference whose
    GIAO numint is unusable, HF/GIAO on the same geometry, labeled as such. Each
    fallback says out loud what it did; only a total failure leaves the tab empty."""
    import numpy as np

    _emit_phase("nmr")
    try:
        cls = _nmr_class(mf)
    except Exception as exc:  # noqa: BLE001 — capability gap (missing addon / RO ref)
        _warn(result, f"NMR shieldings unavailable: {exc}")
        return

    note = ""
    # 1) coupled GIAO (most accurate when the addon's response matches PySCF core).
    tensors = _try_nmr_kernel(cls, mf, cphf=True)
    # 2) uncoupled GIAO — sidesteps the addon/PySCF CPHF version skew.
    if tensors is None:
        tensors = _try_nmr_kernel(cls, mf, cphf=False)
        if tensors is not None:
            note = ("uncoupled (CPHF disabled — the pyscf-properties response solver is "
                    "incompatible with this PySCF build); GIAO shieldings that neglect the "
                    "self-consistent response")
    # 3) DFT GIAO numint is unusable here — fall back to HF/GIAO on the same geometry so
    #    the tab shows real numbers, clearly labeled as an HF approximation.
    if tensors is None and hasattr(mf, "xc"):
        hf_mf, hf_cls = _hf_reference_for_nmr(mf)
        if hf_mf is not None:
            level = "coupled"
            tensors = _try_nmr_kernel(hf_cls, hf_mf, cphf=True)
            if tensors is None:
                level = "uncoupled"
                tensors = _try_nmr_kernel(hf_cls, hf_mf, cphf=False)
            if tensors is not None:
                note = ("DFT GIAO is unavailable in this PySCF build — shieldings computed "
                        "at the HF/GIAO (%s) level on the DFT geometry" % level)
    if tensors is None:
        _warn(result, "NMR shieldings unavailable: the pyscf-properties GIAO response is "
                      "incompatible with this PySCF build (CPHF reshape / DFT numint "
                      "blksize). Pin a pyscf-properties matching PySCF core to enable it.")
        return
    if note:
        _warn(result, "NMR shieldings: " + note)

    shieldings: list[dict[str, Any]] = []
    for i, tensor in enumerate(np.asarray(tensors)):
        sym_part = 0.5 * (tensor + tensor.T)
        eigs = np.sort(np.linalg.eigvalsh(sym_part))  # σ11 ≤ σ22 ≤ σ33
        iso = float(eigs.mean())  # = trace/3
        aniso = float(eigs[2] - 0.5 * (eigs[0] + eigs[1]))
        shieldings.append(rb.nmr_shielding(i, iso, aniso, symbol=str(mol.atom_symbol(i))))
    result["nmr_shieldings"] = shieldings


def _compute_polarizability(mf, result: dict[str, Any]) -> None:
    """Fill result["polarizability"] with the static dipole polarizability tensor α
    (3×3 nested list, atomic units) via the analytic CPHF/CPKS response from the
    pyscf-properties addon. Missing addon or a response failure degrades to the empty
    contract default WITH a warning — fail visible, not silent."""
    import numpy as np

    _emit_phase("polarizability")
    try:
        pol_cls = _polarizability_class(mf)
    except Exception as exc:  # noqa: BLE001
        _warn(result, f"polarizability unavailable: {exc}")
        return
    try:
        with _quiet():
            alpha = np.asarray(pol_cls(mf).polarizability(), dtype=float)
        result["polarizability"] = [[float(x) for x in row] for row in alpha]
    except Exception as exc:  # noqa: BLE001
        _warn(result, f"polarizability unavailable: {exc}")


def _mulliken_charges(mol, mf, dm) -> list[float]:
    """Per-atom Mulliken charges for a built (mol, mf) pair from the AO density `dm`,
    same atom order as `mol`. The condensed-Fukui standard population scheme. Raises on
    failure (the Fukui driver catches and degrades to [] + a warning)."""
    import numpy as np

    _pop, charges = mf.mulliken_pop(mol, dm, verbose=0)
    return [float(c) for c in np.asarray(charges).ravel()]


def _compute_fukui(spec: dict[str, Any], molecule: dict[str, Any],
                   q0: list[float], result: dict[str, Any],
                   *, e_neutral: float | None = None) -> None:
    """Fill result["fukui"] with condensed Fukui reactivity indices (Yang–Mortier,
    Mulliken-based) — predict WHERE a molecule reacts. Opt-in (compute_fukui), and the
    two extra SCFs cost is why. When `e_neutral` (the neutral total energy, Ha) is given,
    ALSO fill result["reactivity"] with the global conceptual-DFT descriptors (IP/EA/μ/η/
    S/ω/ΔN_max) — free, since the same two ion SCFs already give the vertical ΔSCF IP/EA.

    SCOPE: only a closed-shell-singlet NEUTRAL. `q0` is the neutral's Mulliken charges
    (already computed). At the SAME geometry, build the cation (charge+1) and anion
    (charge−1) — both doublets (spin=1 → UHF via the same _build_mol/_make_mf path) —
    with the IDENTICAL recipe as the neutral (same basis/functional/solvent/dispersion,
    via the same `spec`), so the per-atom charge response is consistent. Then:
        f_plus[i]  = q0[i] − q_anion[i]    (nucleophilic site — added electron)
        f_minus[i] = q_cation[i] − q0[i]   (electrophilic site — removed electron)
        dual[i]    = f_plus[i] − f_minus[i]
    BOTH ion SCFs must converge, else degrade to [] + a warning (no partial). Any
    failure → [] + warning; never fatal."""
    charge = int(molecule.get("charge", spec.get("charge", 0)))
    multiplicity = int(molecule.get("multiplicity", spec.get("multiplicity", 1)))
    # Scope guard: ambiguous ion spin states for an open-shell or charged neutral.
    if multiplicity != 1 or charge != 0:
        _warn(result,
              "Fukui indices need a closed-shell neutral (multiplicity 1, charge 0) — "
              "the N±1 ion spin states are ambiguous otherwise; skipped")
        return
    if not q0:
        _warn(result, "Fukui unavailable: the neutral has no Mulliken charges to "
                      "difference against")
        return

    _emit_phase("fukui")
    # The cation/anion are doublets (one unpaired electron) → multiplicity 2, spin 1 →
    # UHF through the shared mean-field factory. Same recipe as the neutral (same spec).
    cation = {**molecule, "charge": charge + 1, "multiplicity": 2}
    anion = {**molecule, "charge": charge - 1, "multiplicity": 2}
    try:
        _mol_c, mf_c, _ = _build_mol(spec, cation)
        _mol_a, mf_a, _ = _build_mol(spec, anion)
    except Exception as exc:  # noqa: BLE001 — degrade, but say so
        _warn(result, f"Fukui unavailable: cation/anion build failed: {exc}")
        return

    if not (bool(getattr(mf_c, "converged", False))
            and bool(getattr(mf_a, "converged", False))):
        _warn(result, "Fukui unavailable: cation/anion SCF did not converge")
        return

    try:
        q_cation = _mulliken_charges(_mol_c, mf_c, mf_c.make_rdm1())
        q_anion = _mulliken_charges(_mol_a, mf_a, mf_a.make_rdm1())
    except Exception as exc:  # noqa: BLE001
        _warn(result, f"Fukui unavailable: ion Mulliken charges failed: {exc}")
        return

    natom = len(q0)
    if len(q_cation) != natom or len(q_anion) != natom:
        _warn(result, "Fukui unavailable: ion charge arrays disagree with the neutral's "
                      "atom count")
        return

    rows: list[dict[str, Any]] = []
    for i in range(natom):
        f_plus = q0[i] - q_anion[i]
        f_minus = q_cation[i] - q0[i]
        rows.append(rb.fukui_index(i, f_plus, f_minus, f_plus - f_minus))
    result["fukui"] = rows

    # Global conceptual-DFT descriptors from the SAME two ion SCFs (no extra cost): the
    # vertical ΔSCF IP/EA are the cation/anion total energies relative to the neutral.
    if e_neutral is None:
        return
    try:
        e_cation = float(mf_c.e_tot)
        e_anion = float(mf_a.e_tot)
    except Exception as exc:  # noqa: BLE001
        _warn(result, f"Reactivity descriptors unavailable: ion energies missing: {exc}")
        return
    eh_ev = 27.211386245988
    ip = (e_cation - float(e_neutral)) * eh_ev  # ionization potential (eV)
    ea = (float(e_neutral) - e_anion) * eh_ev   # electron affinity (eV)
    eta = ip - ea                                # chemical hardness η
    chi = 0.5 * (ip + ea)                        # electronegativity χ
    mu = -chi                                    # chemical potential μ
    if abs(eta) < 1e-6:
        _warn(result, "Reactivity descriptors: chemical hardness η ≈ 0 — softness, "
                      "electrophilicity and ΔN_max are undefined; reporting IP/EA/χ/μ only")
        result["reactivity"] = rb.reactivity_block(
            ip_ev=ip, ea_ev=ea, electronegativity_ev=chi, chemical_potential_ev=mu,
            hardness_ev=eta, softness=0.0, electrophilicity_ev=0.0,
            max_electron_flow=0.0)
        return
    softness = 1.0 / eta                         # global softness S = 1/η
    omega = mu * mu / (2.0 * eta)                # electrophilicity index ω
    dn_max = -mu / eta                           # maximal electron flow ΔN_max
    result["reactivity"] = rb.reactivity_block(
        ip_ev=ip, ea_ev=ea, electronegativity_ev=chi, chemical_potential_ev=mu,
        hardness_ev=eta, softness=softness, electrophilicity_ev=omega,
        max_electron_flow=dn_max)


def _frontier_label(mo_index: int, nocc: int) -> str:
    """Frontier-relative MO name: HOMO / HOMO-1 / LUMO / LUMO+1 …"""
    homo = nocc - 1
    if mo_index <= homo:
        d = homo - mo_index
        return "HOMO" if d == 0 else "HOMO-%d" % d
    d = mo_index - (homo + 1)
    return "LUMO" if d == 0 else "LUMO+%d" % d


def _excited_transitions(xy, nocc: int, top: int = 3, threshold: float = 0.10) -> list[dict[str, Any]]:
    """Dominant occupied→virtual contributions for one excited state from its (X, Y)
    amplitudes. Weight(i,a) = 2·X_ia² (restricted; X dominates — exact for TDA, the leading
    term for TDDFT/RPA). Returns up to `top` contributions ≥ `threshold`, as rb.transition
    dicts with absolute MO indices and frontier-relative labels."""
    import numpy as np

    x = np.asarray(xy[0])
    weights = 2.0 * (x ** 2)
    found: list[tuple[float, int, int]] = []
    for i in range(weights.shape[0]):          # occupied index 0..nocc-1 → MO index i
        for a in range(weights.shape[1]):      # virtual index → MO index nocc+a
            w = float(weights[i, a])
            if w >= threshold:
                found.append((w, i, nocc + a))
    found.sort(reverse=True)
    return [
        rb.transition(frm, to, w, _frontier_label(frm, nocc), _frontier_label(to, nocc))
        for (w, frm, to) in found[:top]
    ]


def _excited_transitions_u(
    xy, nocc_a: int, nocc_b: int, top: int = 3, threshold: float = 0.10
) -> list[dict[str, Any]]:
    """Dominant occupied→virtual contributions for one UNRESTRICTED excited state.
    xy[0] is the (X_alpha, X_beta) amplitude pair; weight = X_ia² (no spin-degeneracy
    factor of 2 — the channels are explicit). Labels carry an α/β suffix."""
    import numpy as np

    found: list[tuple[float, int, int, int, str]] = []
    for x, nocc, tag in zip(xy[0], (nocc_a, nocc_b), ("α", "β")):
        w = np.asarray(x) ** 2
        for i in range(w.shape[0]):
            for a in range(w.shape[1]):
                if float(w[i, a]) >= threshold:
                    found.append((float(w[i, a]), i, nocc + a, nocc, tag))
    found.sort(reverse=True)
    return [
        rb.transition(frm, to, w,
                      _frontier_label(frm, nocc) + tag,
                      _frontier_label(to, nocc) + tag)
        for (w, frm, to, nocc, tag) in found[:top]
    ]


def _build_td(mf, td_method: str, triplet: bool, nstates: int):
    """Build a TD object: TDDFT (full RPA) or TDA (Tamm-Dancoff), singlet or triplet.

    For an unrestricted (UHF/UKS) reference the singlet/triplet selector does not
    apply — the excitations are computed in the spin-orbital basis and are in
    general spin-mixed — so `singlet` is left alone (callers warn)."""
    # PySCF sets ROHF.TDA / ROKS.TDDFT to None — calling them raises a meaningless
    # "'NoneType' object is not callable". Refuse with the actionable message instead
    # (mirrors the NMR/polarizability refusals).
    if _is_rohf(mf):
        raise ValueError(
            "TDDFT/TDA is not available for an ROHF/ROKS reference in PySCF — use "
            "UHF/UKS (params.reference) for open-shell excited states."
        )
    method = "TDDFT" if str(td_method).upper() == "TDDFT" else "TDA"
    td = mf.TDDFT() if method == "TDDFT" else mf.TDA()
    if not _is_unrestricted(mf):
        td.singlet = not triplet
    td.nstates = int(nstates)
    return td, method


def _warn_td_unconverged(result: dict[str, Any], td, where: str = "") -> None:
    """td.converged is a PER-STATE array — name the unconverged roots instead of
    hiding them (their energies/oscillator strengths are not trustworthy)."""
    import numpy as np

    conv = np.atleast_1d(np.asarray(getattr(td, "converged", True))).ravel()
    bad = [str(i + 1) for i, ok in enumerate(conv) if not bool(ok)]
    if bad:
        _warn(result, "TDDFT/TDA state(s) %s not converged%s" % (", ".join(bad), where))


# Length-gauge rotatory strength → 10⁻⁴⁰ cgs. R = μ·m where μ is the electric and m the
# magnetic transition dipole (both in atomic units); pyscf returns m already including the
# imaginary i prefactor, so R is real. The conversion 471.44 = (a.u. dipole × a.u. magnetic
# dipole) in esu·cm·erg/G ×10⁴⁰ (Bohr magneton + e·a0 factors). NOTE: the LENGTH gauge is
# origin-dependent for non-exact (finite-basis) wavefunctions — fine for the qualitative
# bisignate ECD shape we display; the velocity gauge would be origin-independent but is not
# uniformly exposed across pyscf TD methods, so we take the simpler length gauge here.
_ROT_AU_TO_CGS = 471.44


def _rotatory_strengths(td, n: int, result: dict[str, Any]):
    """Length-gauge rotatory strengths R = μ·m per excited state, in 10⁻⁴⁰ cgs — the ECD
    (electronic circular dichroism) intensities. Chiral → nonzero/bisignate (±); achiral →
    ≈0. Returns a length-`n` array (zeros if unavailable).

    `transition_magnetic_dipole` is not exposed by every TD path (e.g. some TDA builds, and
    unrestricted UHF/UKS TD): when it is missing or raises, R is set to 0.0 for all states
    and a single warning is emitted — never a fabricated value, never a job failure."""
    import numpy as np

    zeros = np.zeros(int(n))
    if not hasattr(td, "transition_magnetic_dipole"):
        _warn(result, "rotatory strengths (ECD) unavailable for this method/reference")
        return zeros
    try:
        mu = np.asarray(td.transition_dipole())          # electric, length gauge (a.u.)
        m = np.asarray(td.transition_magnetic_dipole())  # magnetic (a.u.)
    except Exception:  # noqa: BLE001 — TDA / unrestricted may lack the magnetic dipole
        _warn(result, "rotatory strengths (ECD) unavailable for this method/reference")
        return zeros
    if mu.ndim < 2 or m.ndim < 2 or len(mu) != len(m):
        _warn(result, "rotatory strengths (ECD) unavailable for this method/reference")
        return zeros
    r = np.einsum("sx,sx->s", mu[:, :3], m[:, :3]) * _ROT_AU_TO_CGS
    out = zeros.copy()
    out[: len(r)] = np.real(r)
    return out


def _compute_excited_states(
    mf, result: dict[str, Any], *, nstates: int = 5, td_method: str = "TDA",
    triplet: bool = False, mol=None, out_dir: str | None = None, stem: str = "job",
    compute_nto: bool = False, spec: dict[str, Any] | None = None,
) -> None:
    """Excited states for the Analyze UV-Vis tab: vertical energies, oscillator strengths,
    dominant MO→MO character, transition dipoles, and the multiplicity. Honors TDA vs full
    TDDFT (recording which actually ran in `excited_method`). On an unrestricted (UHF/UKS)
    reference the states are spin-mixed: the triplet selector is ignored WITH a warning and
    the per-state multiplicity is recorded as 0 (unknown), never a pure-spin lie.

    When `compute_nto` is set (with `mol`/`out_dir` provided), ALSO writes the dominant
    hole/particle natural-transition-orbital .cube pair per state into result["nto_cubes"]
    — the proper "what does this excitation look like" picture. Failure there degrades to
    a warning and never fails the job.

    Never fails the job."""
    _emit_phase("tddft")
    try:
        import numpy as np
        unrestricted = _is_unrestricted(mf)
        if unrestricted and triplet:
            _warn(result, "triplet selection ignored for an unrestricted (UHF/UKS) "
                          "reference — excitations are computed in the spin-orbital "
                          "basis and are in general spin-mixed")
        td, method = _build_td(mf, td_method, triplet, nstates)
        with _quiet():
            td.kernel()
        _warn_td_unconverged(result, td)
        ev = np.asarray(td.e).ravel() * 27.211386245988
        osc = np.asarray(td.oscillator_strength()).ravel()
        try:
            tdip = np.asarray(td.transition_dipole())
        except Exception as exc:  # noqa: BLE001 — states still useful without dipoles
            tdip = None
            _warn(result, f"transition dipoles unavailable: {exc}")
        rot = _rotatory_strengths(td, len(ev), result)
        if unrestricted:
            occ_a, occ_b = (np.asarray(o) for o in mf.mo_occ)
            nocc_a = int((occ_a > 0).sum())
            nocc_b = int((occ_b > 0).sum())
        else:
            nocc = int((np.asarray(mf.mo_occ) > 0).sum())
    except Exception as exc:  # noqa: BLE001 — UV-Vis tab stays empty, but says why
        _warn(result, f"excited states unavailable: {exc}")
        return
    # 0 = unknown/spin-mixed (unrestricted); the UV-Vis tab renders it as "?".
    mult = 0 if unrestricted else (3 if triplet else 1)
    states: list[dict[str, Any]] = []
    for i in range(len(ev)):
        e = float(ev[i])
        wl = (1239.841984 / e) if e > 1e-6 else 0.0
        o = float(osc[i]) if i < len(osc) else 0.0
        trans: list[dict[str, Any]] = []
        try:
            if unrestricted:
                trans = _excited_transitions_u(td.xy[i], nocc_a, nocc_b)
            else:
                trans = _excited_transitions(td.xy[i], nocc)
        except Exception as exc:  # noqa: BLE001 — state stands; character says why
            trans = []
            _warn(result, f"transition character unavailable for state {i + 1}: {exc}")
        tvec = rb.vec3(0.0, 0.0, 0.0)
        if tdip is not None and i < len(tdip) and len(tdip[i]) >= 3:
            tvec = rb.vec3(float(tdip[i][0]), float(tdip[i][1]), float(tdip[i][2]))
        r_state = float(rot[i]) if i < len(rot) else 0.0
        states.append(rb.excited_state(
            e, wl, o, "", multiplicity=mult, transitions=trans, transition_dipole=tvec,
            rotatory_strength=r_state))
    result["excited_states"] = states
    result["excited_method"] = method
    # These arrive with oscillator strengths and wavelengths, ready to be plotted — so the
    # basis has to be competent to produce them, and states above the ionization threshold
    # have to be named as what they are.
    _check_excited_state_basis(
        result, mf, spec or {}, [float(s.get("energy_ev", 0.0)) for s in states])

    # Natural transition orbitals (opt-in): the dominant hole/particle pair per state.
    # td/mf are the converged objects above; mol + out_dir come from the caller.
    if compute_nto and mol is not None and out_dir is not None:
        _generate_nto_cubes(mol, mf, td, len(states), result, out_dir, stem)


# NTO weights below this are not worth a cube pair — a near-zero dominant pair means
# the state has no single dominant hole→particle picture (multi-configurational), so a
# single pair would misrepresent it. Cap below ~0.10 (same order as the MO→MO
# transition-character threshold) and skip with a per-state warning.
_NTO_WEIGHT_FLOOR: float = 0.10


def _generate_nto_cubes(
    mol, mf, td, n_states: int, result: dict[str, Any], out_dir: str, stem: str = "job"
) -> None:
    """Write the dominant hole/particle natural-transition-orbital .cube pair for each
    computed excited state and fill result["nto_cubes"] (GaussView/Multiwfn parity).

    For each state k (1-based) `td.get_nto(state=k)` returns (weights, nto_coeff): the
    occupied block of nto_coeff (first nocc columns) holds the hole NTOs, the virtual
    block (the rest) the particle NTOs, both SVD-sorted in descending weight order. The
    DOMINANT hole is therefore column 0 (the largest-weight occupied NTO) and the
    dominant particle is column nocc (the largest-weight virtual NTO); the pair weight is
    weights[0]. Each is rendered with cubegen.orbital, exactly the machinery the frontier
    MO cubes use, so the UV-Vis tab renders the pair through the same isosurface path.

    Unrestricted (UHF/UKS) references are not supported by pyscf's get_nto (the X
    amplitudes are an α/β pair) — probed up front and warn-skipped. Every other failure
    degrades to a warning, never fatal: an empty/partial nto_cubes plus a stated reason."""
    if _is_unrestricted(mf):
        _warn(result, "natural transition orbitals are not available for an "
                      "unrestricted (UHF/UKS) reference — pyscf's get_nto needs a "
                      "single (restricted) orbital set; skipping NTO cubes")
        return
    try:
        from pyscf.tools import cubegen
        import numpy as np
    except Exception as exc:  # noqa: BLE001
        _warn(result, f"NTO cubes unavailable: {exc}")
        return
    try:
        nocc = int((np.asarray(mf.mo_occ) > 0).sum())
    except Exception as exc:  # noqa: BLE001
        _warn(result, f"NTO cubes unavailable: {exc}")
        return

    cubes: list[dict[str, Any]] = []
    for k in range(1, int(n_states) + 1):  # td.get_nto is 1-based
        try:
            weights, nto_coeff = td.get_nto(state=k)
            weights = np.asarray(weights).ravel()
            nto = np.asarray(nto_coeff)
            if nto.ndim != 2 or nto.shape[1] <= nocc or weights.size == 0:
                _warn(result, "NTO cubes skipped for state %d: unexpected NTO shape" % k)
                continue
            weight = float(weights[0])
            if weight < _NTO_WEIGHT_FLOOR:
                _warn(result, "NTO cubes skipped for state %d: dominant pair weight "
                              "%.3f is below %.2f (no single dominant hole→particle "
                              "picture)" % (k, weight, _NTO_WEIGHT_FLOOR))
                continue
            # Dominant hole = column 0 of the occupied block; dominant particle =
            # column nocc (column 0 of the virtual block). See the docstring.
            hole = nto[:, 0]
            particle = nto[:, nocc]
            hole_path = os.path.join(out_dir, f"{stem}_nto_{k}_hole.cube")
            particle_path = os.path.join(out_dir, f"{stem}_nto_{k}_particle.cube")
            cubegen.orbital(mol, hole_path, hole)
            cubegen.orbital(mol, particle_path, particle)
            cubes.append(rb.nto_cube(k, weight, hole_path, particle_path))
        except Exception as exc:  # noqa: BLE001 — degrade per state, but say why
            _warn(result, f"NTO cubes unavailable for state {k}: {exc}")
            continue
    result["nto_cubes"] = cubes


def _run_md(mol, mf, result: dict[str, Any], spec: dict[str, Any], *, seed: int = 0,
            nsteps: int = 20, dt_fs: float = 0.5, temp_k: float = 300.0) -> None:
    """Born-Oppenheimer molecular dynamics (NVE, velocity Verlet) for the Analyze MD tab.
    Maxwell-Boltzmann initial velocities (seeded → reproducible), then SCF + analytic
    gradient each step — rebuilt through `_make_mf`, so a PCM/dispersion recipe keeps
    its forces solvated/corrected (previously the rebuild was a bare RKS/RHF: PCM MD
    silently propagated on gas-phase forces). Emits result.trajectory frames (time fs,
    coords Å, energy Ha, instantaneous temperature K) — the initial geometry plus one
    frame per step, closing with the final propagated state (its SCF energy is already
    paid for by the last Verlet half-kick), and surfaces that final geometry as
    result.final_coords so the Geometry tab reflects where the dynamics ended. Never
    fails the job, but failures and unconverged steps land in result.warnings.
    Expensive (an SCF+gradient per step) → step count is capped."""
    try:
        import numpy as np
        AMU_TO_AU = 1822.888486
        FS_TO_AU = 41.341374575751
        KB_AU = 3.166811563e-6  # Hartree / K
        BOHR_TO_ANG = 0.529177210903

        m = np.asarray(mol.atom_mass_list()) * AMU_TO_AU  # (natoms,) au
        x = np.asarray(mol.atom_coords()).copy()          # Bohr
        rng = np.random.default_rng(int(seed))
        v = rng.standard_normal((len(m), 3)) * np.sqrt(KB_AU * float(temp_k) / m)[:, None]
        # Remove centre-of-mass drift — MASS-WEIGHTED. Subtracting the plain mean of the
        # velocity vectors does not zero the momentum unless every atom has the same mass:
        # P = Σ mᵢ(vᵢ − v̄) = Σ mᵢvᵢ − v̄ Σ mᵢ ≠ 0. Worse, the light atoms carry the largest
        # Maxwell-Boltzmann speeds, so v̄ is dominated by them and subtracting it GIVES the
        # heavy atom a velocity it never had, adding kinetic energy. Measured on water over
        # 200 seeds: residual |P| = 10.3 au, 57% of the initial kinetic energy was rigid
        # translation, and a 300 K request started the run at a mean 507 K.
        v -= (m[:, None] * v).sum(axis=0) / m.sum()
        # Three translational degrees of freedom have just been removed, so the instantaneous
        # temperature must divide by 3N−3, not 3N — otherwise the reported temperature is
        # systematically low by that ratio even once the momentum is right.
        ndof = max(1, 3 * len(m) - 3)
        dt = float(dt_fs) * FS_TO_AU
        energy = float(mf.e_tot)
        g = np.asarray(mf.nuc_grad_method().kernel())  # Hartree/Bohr at x0
        a = -g / m[:, None]

        frames: list[dict[str, Any]] = []
        nsteps = _clamp_md_steps(nsteps)
        for step in range(nsteps):
            ke = 0.5 * float(np.sum(m[:, None] * v * v))
            t_inst = (2.0 * ke / (ndof * KB_AU)) if ndof > 0 else 0.0
            coords = [
                rb.vec3(float(x[i, 0] * BOHR_TO_ANG), float(x[i, 1] * BOHR_TO_ANG),
                        float(x[i, 2] * BOHR_TO_ANG))
                for i in range(len(m))
            ]
            frames.append(rb.trajectory_frame(step * float(dt_fs), coords, energy, t_inst))
            # Live telemetry: one md record per recorded frame (step 0 = initial state).
            _emit_progress({"t": "md", "step": step, "e": energy, "temp": t_inst})
            # velocity Verlet
            v += 0.5 * a * dt
            x += v * dt
            m2 = mol.set_geom_(x, unit="Bohr", inplace=False)
            mf2, _ = _make_mf(m2, spec)  # same recipe as step 0: solvent + dispersion
            mf2.kernel()
            if not getattr(mf2, "converged", False):
                _warn(result, "SCF not converged at MD step %d" % (step + 1))
            g = np.asarray(mf2.nuc_grad_method().kernel())
            a_new = -g / m[:, None]
            v += 0.5 * a_new * dt
            a = a_new
            energy = float(mf2.e_tot)
        # Closing frame: the post-propagation state. The loop already computed its
        # SCF energy (and the velocities carry the final half-kick), so this is free.
        ke = 0.5 * float(np.sum(m[:, None] * v * v))
        t_inst = (2.0 * ke / (ndof * KB_AU)) if ndof > 0 else 0.0
        final_coords = [
            rb.vec3(float(x[i, 0] * BOHR_TO_ANG), float(x[i, 1] * BOHR_TO_ANG),
                    float(x[i, 2] * BOHR_TO_ANG))
            for i in range(len(m))
        ]
        frames.append(rb.trajectory_frame(nsteps * float(dt_fs), final_coords,
                                          energy, t_inst))
        _emit_progress({"t": "md", "step": nsteps, "e": energy, "temp": t_inst})
        result["trajectory"] = frames
        result["trajectory_kind"] = "md"
        # The MD result's geometry of record is where the dynamics ended, not the input.
        result["final_coords"] = list(final_coords)

        # Energy-conservation check. `converged` on an MD result describes the t=0 reference
        # SCF and never the trajectory, and nothing measured drift at all — a run with
        # dt = 6 fs flew apart (Etot drift +2464 kcal/mol, T reaching 103,000 K, atoms 80 A
        # from the origin) and still reported converged/success. The frames already carry
        # potential energy and temperature, so E_tot = E_pot + (ndof/2)kT costs nothing.
        etots = [float(f["energy"]) + 0.5 * ndof * KB_AU * float(f.get("temperature", 0.0))
                 for f in frames]
        if len(etots) > 1:
            drift = max(etots) - min(etots)
            drift_kcal = drift * 627.5094740631
            per_atom = drift_kcal / max(1, len(m))
            # ~1 kcal/mol/atom over a short run is already a broken integrator; 0.1 is the
            # threshold at which a chemist would shorten the timestep.
            if per_atom > 1.0:
                result["converged"] = False
                _warn(result,
                      "MD did NOT conserve energy: total energy drifted %.2f kcal/mol "
                      "(%.2f per atom) over %d fs, and the temperature reached %.0f K. The "
                      "integration is unstable — this trajectory is not physical. Reduce "
                      "md_dt_fs (try 0.5 fs or less)."
                      % (drift_kcal, per_atom, int(nsteps * float(dt_fs)),
                         max(float(f.get("temperature", 0.0)) for f in frames)))
            elif per_atom > 0.1:
                _warn(result,
                      "MD total-energy drift is %.3f kcal/mol (%.3f per atom) over %d fs — "
                      "larger than a well-integrated run should show. Halve md_dt_fs if you "
                      "intend to quote anything from this trajectory."
                      % (drift_kcal, per_atom, int(nsteps * float(dt_fs))))
    except Exception as exc:  # noqa: BLE001 — MD tab stays empty, but says why
        _warn(result, f"MD trajectory unavailable: {exc}")
        return


# Wavenumber magnitude (cm^-1) below which a mode is treated as a residual
# translation/rotation rather than a genuine imaginary mode — keeps numerical noise
# from being miscounted as a saddle direction.
_IMAG_TOL_CM: float = 10.0


# Thermochemistry conditions: clamp the user-requested temperature / pressure to a sane
# physical window so a stray Method entry never feeds thermo.thermo a nonsensical value.
_THERMO_T_MIN_K: float = 1.0
_THERMO_T_MAX_K: float = 5000.0
_THERMO_P_MIN_PA: float = 1.0e3
_THERMO_P_MAX_PA: float = 1.0e8
# Standard reference temperatures always shown in the G/H/S-vs-T scan alongside the
# chosen one: freezing/standard/body temperature plus a useful high-T spread. The chosen
# T is unioned in, the set is sorted, de-duplicated, and capped at ~8 points.
_THERMO_SCAN_STANDARD_K: tuple[float, ...] = (
    200.0, 250.0, 273.15, 298.15, 310.15, 350.0, 400.0, 500.0,
)
_THERMO_SCAN_MAX_POINTS: int = 8


def _thermo_conditions(spec: dict[str, Any]) -> tuple[float, float]:
    """Read params.temperature_k / params.pressure_pa (clamped to a physical window).
    Defaults: 298.15 K, 101325 Pa (1 atm) — the standard state. The clamp keeps a bad
    Method entry from feeding thermo.thermo a non-physical T/P."""
    params = spec.get("params", {})
    params = params if isinstance(params, dict) else {}
    try:
        t = float(params.get("temperature_k", 298.15))
    except (TypeError, ValueError):
        t = 298.15
    try:
        p = float(params.get("pressure_pa", 101325.0))
    except (TypeError, ValueError):
        p = 101325.0
    t = min(max(t, _THERMO_T_MIN_K), _THERMO_T_MAX_K)
    p = min(max(p, _THERMO_P_MIN_PA), _THERMO_P_MAX_PA)
    return t, p


def _thermo_scan_temperatures(chosen_t: float) -> list[float]:
    """The temperature set for the G/H/S-vs-T scan: the chosen T unioned with the standard
    reference points, sorted, de-duplicated (to 2 dp so 298.15 isn't doubled), only
    physical (>0), capped at _THERMO_SCAN_MAX_POINTS. Always includes the chosen T."""
    wanted: dict[float, None] = {}
    for t in (chosen_t, *_THERMO_SCAN_STANDARD_K):
        if t > 0.0:
            wanted[round(float(t), 2)] = None
    points = sorted(wanted)
    if len(points) <= _THERMO_SCAN_MAX_POINTS:
        return points
    # Over the cap: keep the chosen T plus an evenly-spaced subset of the rest so the
    # spread still spans low→high T (never drop the user's own temperature).
    chosen = round(float(chosen_t), 2)
    others = [t for t in points if t != chosen]
    keep = _THERMO_SCAN_MAX_POINTS - 1
    step = max(1, len(others) // keep)
    trimmed = others[::step][:keep]
    return sorted({chosen, *trimmed})


# Largest nuclear-gradient component still counted as "at a stationary point", in
# Hartree/Bohr. This is geomeTRIC's own `convergence_gmax` default — the same bar an
# optimization must clear to call itself converged, so the frequency job and the optimizer
# agree on what "converged geometry" means.
_GMAX_TOL_HA_BOHR: float = 4.5e-4


def _check_stationary_point(mol, mf, result: dict[str, Any]) -> None:
    """Verify the geometry actually IS a stationary point, and say so when it is not.

    A harmonic analysis is only meaningful where the gradient vanishes: the imaginary-mode
    count classifies a stationary point, it never establishes that you are at one. Nothing
    checked this, so `frequencies` at ANY geometry returned `stationary_point: "minimum"`,
    `n_imaginary: 0` and a full ZPE/H/G block with an empty warnings channel — measured on a
    distorted water at max|grad| = 0.108 Eh/Bohr, 240x this threshold. Thermochemistry from
    such a structure is meaningless: the harmonic partition functions assume a minimum.

    Records `max_gradient` either way (provenance: the reader can see the number), and on
    failure relabels the point and warns rather than deleting the block — the frequencies
    themselves are still what the Hessian said, they just do not mean what the label claims.
    """
    import numpy as np

    try:
        with _quiet():
            grad = mf.nuc_grad_method().kernel()
        gmax = float(np.abs(np.asarray(grad)).max())
    except Exception as exc:  # noqa: BLE001 — an unavailable gradient must not fail the job
        _warn(result,
              "could not verify that this geometry is a stationary point (no analytic "
              "gradient available here: %s) — if it was not optimized at this exact level "
              "of theory, treat the frequencies and thermochemistry with caution." % exc)
        return

    result["max_gradient"] = gmax
    if gmax <= _GMAX_TOL_HA_BOHR:
        return

    result["stationary_point"] = "not_stationary"
    _warn(result,
          "This geometry is NOT a stationary point: the largest nuclear gradient component "
          "is %.2e Eh/Bohr, %.0fx the %.1e convergence threshold. Harmonic frequencies and "
          "every thermochemical quantity derived from them (ZPE, enthalpy, entropy, Gibbs "
          "energy) assume a vanishing gradient and are not usable here — optimize the "
          "structure at this level of theory first, then run frequencies on the result."
          % (gmax, gmax / _GMAX_TOL_HA_BOHR, _GMAX_TOL_HA_BOHR))


def _compute_frequencies(
    mol, mf, result: dict[str, Any], spec: dict[str, Any]
) -> None:
    """Harmonic vibrational analysis (pyscf Hessian → wavenumbers + per-atom normal-mode
    displacements) plus IR / Raman intensities for the IR/Raman tab, the stationary-point
    character (imaginary-mode count), and thermochemistry. Never fails the job, but every
    degradation lands in result.warnings.

    PySCF returns an imaginary mode as a pure-imaginary wavenumber (0 + |ω|·j). We map it
    to a NEGATIVE real wavenumber to match the JobResult convention (VibrationMode:
    "negative = imaginary mode"), so the IR/Raman tab tags it `im` and the count is honest.

    Solvated Hessians: PySCF can differentiate some reaction fields twice (PCM) but not
    all (ddCOSMO). When the solvated Hessian raises, the modes are recomputed GAS-PHASE
    at the same geometry and the fallback is named in a warning — never silent.
    """
    _emit_phase("hessian")
    try:
        import numpy as np
        from pyscf.hessian import thermo
        with _quiet():
            try:
                hess = mf.Hessian().kernel()
            except Exception as hess_exc:  # noqa: BLE001
                model, name = _solvent_request(spec)
                if not model:
                    raise  # gas-phase Hessian failed for real — outer except warns
                mf_gas, _ = _make_mf(mol, _gas_phase_spec(spec))
                mf_gas.kernel()
                if not getattr(mf_gas, "converged", False):
                    _warn(result, "gas-phase fallback SCF not converged — the "
                                  "fallback frequencies/thermochemistry are "
                                  "unreliable")
                hess = mf_gas.Hessian().kernel()
                _warn(result,
                      "%s(%s) Hessian unavailable (%s) — frequencies/thermochemistry "
                      "are a GAS-PHASE fallback at the solvated geometry"
                      % (model, name, hess_exc))
            info = thermo.harmonic_analysis(mol, hess)
        raw = np.asarray(info["freq_wavenumber"]).ravel()
        # Signed wavenumbers: imaginary modes (|imag| dominates) become negative.
        signed = np.where(np.abs(raw.imag) > np.abs(raw.real), -np.abs(raw.imag), raw.real)
        modes = np.asarray(info["norm_mode"])  # (nmodes, natoms, 3)
    except Exception as exc:  # noqa: BLE001 — IR/Raman tab stays empty, but says why
        hint = (" — ROHF/ROKS has no analytic Hessian in PySCF; use UHF/UKS "
                "(params.reference)") if _is_rohf(mf) else ""
        _warn(result, f"frequencies unavailable: {exc}{hint}")
        return
    ir, raman = _vib_intensities(mol, mf, modes, spec, result)
    vibs: list[dict[str, Any]] = []
    for k in range(len(signed)):
        disp = [
            rb.vec3(float(modes[k, a, 0]), float(modes[k, a, 1]), float(modes[k, a, 2]))
            for a in range(modes.shape[1])
        ]
        vibs.append(rb.vibration_mode(float(signed[k]), float(ir[k]), float(raman[k]), disp))
    result["vibrations"] = vibs

    # Stationary-point character: how many genuine imaginary modes? 0 = minimum,
    # 1 = transition state (first-order saddle), ≥2 = higher-order saddle.
    n_imag = int(np.sum(signed < -_IMAG_TOL_CM))
    result["n_imaginary"] = n_imag
    result["stationary_point"] = rb.stationary_label(n_imag)
    # ...but the imaginary-mode count only CLASSIFIES a stationary point; it cannot tell
    # you that you are at one. Check the gradient before the label is believed.
    _check_stationary_point(mol, mf, result)

    # Thermochemistry at the user-chosen temperature / pressure (defaults: 298.15 K,
    # 1 atm — the standard state). Imaginary modes have no real vibrational partition
    # function, so they are dropped (standard TS treatment) — the reported G/H/S of a
    # saddle then omit the reaction-coordinate mode. A second cheap pass over the same
    # real frequencies fills the G/H/S-vs-T scan (re-evaluating thermo.thermo at a
    # handful of temperatures is ~free once the Hessian is in hand).
    temperature_k, pressure_pa = _thermo_conditions(spec)
    # Thermochemistry off a non-converged SCF is not a number with error bars — it is a
    # number off a garbage wavefunction. The warnings channel already said so per displaced
    # geometry, but the block still shipped a Gibbs energy and a stationary-point label that
    # read as results. Withhold it instead of decorating it.
    if not bool(result.get("converged", False)):
        _warn(result,
              "Thermochemistry withheld: the SCF did not converge, so the Hessian and every "
              "quantity derived from it (ZPE, enthalpy, entropy, Gibbs energy) would come "
              "from an unconverged wavefunction. The frequencies above are shown for "
              "diagnosis only — fix the SCF, then re-run.")
        return
    try:
        freq_au = np.asarray(info["freq_au"]).ravel()
        real_au = freq_au.real[(np.abs(freq_au.imag) < 1e-9) & (freq_au.real > 1e-6)]
        with _quiet():
            th = thermo.thermo(mf, real_au, float(temperature_k), float(pressure_pa))
        # Grimme quasi-RRHO alongside the harmonic numbers: the low-frequency modes that
        # dominate vibrational entropy are hindered rotations, not oscillators, and pure
        # RRHO over-rewards floppy structures. Swap the vibrational term only — translation,
        # rotation and the electronic term are unchanged — then G = H - T*S with the new S.
        s_vib_qrrho = rb.qrrho_entropy(
            [float(w) for w in signed if float(w) > 0.0], float(temperature_k))
        gibbs_qrrho = None
        entropy_qrrho = None
        if s_vib_qrrho is not None and "S_vib" in th:
            entropy_qrrho = float(th["S_tot"][0]) - float(th["S_vib"][0]) + s_vib_qrrho
            gibbs_qrrho = float(th["H_tot"][0]) - float(temperature_k) * entropy_qrrho
        result["thermochemistry"] = rb.thermochemistry(
            temperature_k=float(temperature_k),
            electronic_energy=float(mf.e_tot),
            zpe=float(th["ZPE"][0]),
            internal_energy=float(th["E_tot"][0]),
            enthalpy=float(th["H_tot"][0]),
            gibbs=float(th["G_tot"][0]),
            entropy=float(th["S_tot"][0]),
            heat_capacity_cv=float(th["Cv_tot"][0]),
            gibbs_qrrho=gibbs_qrrho,
            entropy_qrrho=entropy_qrrho,
        )
        # Thermochemistry-vs-temperature table at the SAME (constant) pressure: from the
        # one Hessian, evaluate G/H/S/ZPE across the chosen + standard temperatures so the
        # user sees how the free energy drops (and entropy rises) with T. Empty when there
        # are no real frequencies (e.g. a single atom) — the loop simply records nothing.
        scan: list[dict[str, float]] = []
        if real_au.size > 0:
            for t in _thermo_scan_temperatures(float(temperature_k)):
                try:
                    with _quiet():
                        th_t = thermo.thermo(mf, real_au, float(t), float(pressure_pa))
                    scan.append(rb.thermo_point(
                        temperature_k=float(t),
                        gibbs=float(th_t["G_tot"][0]),
                        enthalpy=float(th_t["H_tot"][0]),
                        entropy=float(th_t["S_tot"][0]),
                        zpe=float(th_t["ZPE"][0]),
                    ))
                except Exception as exc:  # noqa: BLE001 — one bad T drops, scan stands
                    _warn(result, f"thermo scan point at {t:g} K unavailable: {exc}")
        result["thermo_scan"] = scan
    except Exception as exc:  # noqa: BLE001 — vibrations stand; thermo block says why
        _warn(result, f"thermochemistry unavailable: {exc}")


def _vib_intensities(
    mol, mf, modes, spec: dict[str, Any], result: dict[str, Any]
) -> tuple[list[float], list[float]]:
    """Return (ir, raman) intensity lists per mode by central finite difference along
    each Cartesian normal mode, sharing the ± displaced SCF runs. IR ∝ |dμ/dQ|² (dipole,
    no addon needed). Raman ∝ 45·ᾱ'² + 7·γ'² from dα/dQ (needs the pyscf-properties
    polarizability module; degrades to 0 WITH a warning if absent or on error).

    The displaced mean-fields are rebuilt through `_make_mf`, so a PCM recipe gets
    PCM dipole derivatives (previously the rebuild was a bare RKS/RHF — a PCM freq
    job silently got gas-phase IR intensities)."""
    import numpy as np

    n: int = int(modes.shape[0])
    ir: list[float] = [0.0] * n
    raman: list[float] = [0.0] * n
    # Polarizability (Raman) is optional; IR works without it.
    pol_cls = None
    try:
        pol_cls = _polarizability_class(mf)
    except Exception as exc:  # noqa: BLE001
        pol_cls = None
        _warn(result, f"Raman activities unavailable (polarizability module): {exc}")
    raman_warned = False
    try:
        base = mol.atom_coords()  # Bohr
        delta = 0.01
        for k in range(n):
            d = np.asarray(modes[k])  # (natoms, 3)
            dips: list = []
            pols: list = []
            for sign in (1.0, -1.0):
                m2 = mol.set_geom_(base + sign * delta * d, unit="Bohr", inplace=False)
                mf2, _ = _make_mf(m2, spec)  # same recipe: solvent + dispersion
                mf2.kernel()
                if not getattr(mf2, "converged", False):
                    _warn(result,
                          "SCF not converged at displaced geometry (mode %d)" % k)
                dips.append(np.asarray(mf2.dip_moment(verbose=0)))
                if pol_cls is not None:
                    try:
                        pols.append(np.asarray(pol_cls(mf2).polarizability()))
                    except Exception as pol_exc:  # noqa: BLE001
                        pols = []
                        if not raman_warned:
                            raman_warned = True
                            _warn(result, f"Raman activities unavailable: {pol_exc}")
            dmu = (dips[0] - dips[1]) / (2.0 * delta)
            ir[k] = float(np.dot(dmu, dmu))
            if len(pols) == 2:
                da = (pols[0] - pols[1]) / (2.0 * delta)  # dα/dQ (3×3)
                a_mean = float(np.trace(da)) / 3.0
                g2 = 0.5 * (
                    (da[0, 0] - da[1, 1]) ** 2
                    + (da[1, 1] - da[2, 2]) ** 2
                    + (da[2, 2] - da[0, 0]) ** 2
                    + 6.0 * (da[0, 1] ** 2 + da[1, 2] ** 2 + da[0, 2] ** 2)
                )
                # Convert Bohr^4/amu -> Angstrom^4/amu. da = dalpha/dQ comes from pyscf's
                # polarizability (atomic units, Bohr^3) differentiated along a displacement
                # taken in BOHR, so the invariant lands in Bohr^4/amu — while every code a
                # chemist compares against (Gaussian, ORCA, Q-Chem, Psi4) and this app's own
                # tooltip report Angstrom^4/amu. The activities were 1/0.529177^4 = 12.75x
                # too large under a label claiming the smaller unit.
                raman[k] = float(45.0 * a_mean ** 2 + 7.0 * g2) * (_BOHR_TO_ANG ** 4)
        return ir, raman
    except Exception as exc:  # noqa: BLE001 — modes stand; intensities say why
        _warn(result, f"IR/Raman intensities unavailable: {exc}")
        return ir, raman


def _wants_cubes(spec: dict[str, Any]) -> bool:
    params = spec.get("params", {})
    if isinstance(params, dict) and bool(params.get("compute_cubes", False)):
        return True
    return bool(spec.get("compute_cubes", False))


def _cube_window(spec: dict[str, Any]) -> tuple[int, int]:
    """How many (occupied, virtual) orbital cubes to write — the Method screen's
    Surfaces counts (params.cube_occupied / cube_virtual). Defaults preserve the
    legacy frontier window (HOMO-1..HOMO / LUMO..LUMO+1). Clamped to [0, 50];
    a malformed value falls back to the default rather than failing the job."""
    params = spec.get("params", {})
    if not isinstance(params, dict):
        params = {}

    def _count(key: str, default: int) -> int:
        try:
            return max(0, min(int(params.get(key, default)), 50))
        except (TypeError, ValueError):
            return default

    return _count("cube_occupied", 2), _count("cube_virtual", 2)


def _generate_orbital_cubes(
    mol, mf, result: dict[str, Any], out_dir: str, stem: str = "job",
    n_occ: int = 2, n_virt: int = 2,
) -> list[dict[str, Any]]:
    """Write Gaussian .cube files for a window of MOs around the frontier — n_occ
    occupied (HOMO, HOMO-1, …) and n_virt virtual (LUMO, LUMO+1, …), the Method
    screen's Surfaces counts (defaults = the legacy HOMO-1..LUMO+1 window) — and
    return their {index, spin, path} records. Files are named
    <stem>_orbital_<idx>.cube so jobs don't collide in a shared dir. Unrestricted
    (UHF/UKS) mean-fields get BOTH channels — each channel's own frontier window,
    beta files suffixed `_b` — previously the 3-D coefficient array fell through
    the `ndim != 2` guard and the viewer's empty state was a silent mystery. Never
    fails the job — a cube error is skipped WITH a warning."""
    cubes: list[dict[str, Any]] = []
    mo = getattr(mf, "mo_coeff", None)
    if mo is None:
        return cubes
    try:
        from pyscf.tools import cubegen
        import numpy as np
    except Exception as exc:  # noqa: BLE001
        _warn(result, f"orbital cubes unavailable: {exc}")
        return cubes
    mo = np.asarray(mo)
    if mo.ndim == 3 and mo.shape[0] == 2:
        occs = np.asarray(mf.mo_occ)
        # (spin tag, coefficients, channel frontier from its own occupations)
        channels = [("a", mo[0], occs[0]), ("b", mo[1], occs[1])]
    elif mo.ndim == 2:
        channels = [("a", mo, None)]  # restricted: keep the legacy "a" tag + filename
    else:
        return cubes
    for spin, coeff, occ in channels:
        nmo = int(coeff.shape[1])
        if occ is None:
            homo = int(result.get("homo_index", -1))
            lumo = int(result.get("lumo_index", -1))
            suffix = ""
        else:
            occupied = [i for i, o in enumerate(np.asarray(occ).ravel()) if float(o) > 1e-9]
            homo = occupied[-1] if occupied else -1
            # homo == -1 (a channel with zero occupied orbitals, e.g. the H-atom beta
            # channel) still has virtuals from index 0 — its LUMO is 0, not absent.
            lumo = homo + 1 if homo + 1 < nmo else -1
            suffix = f"_{spin}"
        want: list[int] = []
        if homo >= 0:
            for k in range(n_occ):
                idx = homo - k
                if 0 <= idx < nmo and idx not in want:
                    want.append(idx)
        if lumo >= 0:
            for k in range(n_virt):
                idx = lumo + k
                if 0 <= idx < nmo and idx not in want:
                    want.append(idx)
        want.sort()
        for idx in want:
            path = os.path.join(out_dir, f"{stem}_orbital_{idx}{suffix}.cube")
            try:
                cubegen.orbital(mol, path, coeff[:, idx])
                cubes.append({"index": int(idx), "spin": spin, "path": path})
            except Exception as exc:  # noqa: BLE001
                _warn(result, f"orbital cube {idx}{suffix} unavailable: {exc}")
                continue
    return cubes


def _generate_casscf_orbital_cubes(
    mol, mc, result: dict[str, Any], out_dir: str, stem: str = "job"
) -> list[dict[str, Any]]:
    """Write .cube files for the CASSCF NATURAL orbitals (mc.mo_coeff, natorb=True)
    and return their {index, spin, path} records (same shape/naming as the HF path,
    spin "a" — the CASSCF reference is restricted(-open), one spatial set).

    Frontier-window choice: natural occupations are fractional and ~never exactly
    0 or 2, so a HOMO/LUMO edge is ill-defined — the frontier IS the active space.
    The window is therefore every ACTIVE natural orbital plus its immediate
    neighbors (one core below, one virtual above: active window ± 1), which is
    exactly the set the user picked to inspect, kept consistent with the
    natural-occupation ladder the result's orbitals array carries (column i of
    mo_coeff ↔ mo_occ[i], guaranteed by natorb=True in _run_casscf). Never fails
    the job — a cube error is skipped WITH a warning."""
    cubes: list[dict[str, Any]] = []
    try:
        from pyscf.tools import cubegen
        import numpy as np
    except Exception as exc:  # noqa: BLE001
        _warn(result, f"orbital cubes unavailable: {exc}")
        return cubes
    coeff = np.asarray(getattr(mc, "mo_coeff", None))
    if coeff.ndim != 2:
        _warn(result, "orbital cubes unavailable: unexpected CASSCF mo_coeff shape "
                      f"{coeff.shape}")
        return cubes
    nmo = int(coeff.shape[1])
    ncore = int(mc.ncore)
    ncas = int(mc.ncas)
    want = [i for i in range(ncore - 1, ncore + ncas + 1) if 0 <= i < nmo]
    for idx in want:
        path = os.path.join(out_dir, f"{stem}_orbital_{idx}.cube")
        try:
            cubegen.orbital(mol, path, coeff[:, idx])
            cubes.append({"index": int(idx), "spin": "a", "path": path})
        except Exception as exc:  # noqa: BLE001
            _warn(result, f"orbital cube {idx} unavailable: {exc}")
            continue
    return cubes


# Density / MEP cube grid resolution (samples per axis). Pinned so the density cube and
# the molecular-electrostatic-potential cube share the EXACT same grid — the ESP surface
# colors each density-isosurface vertex by sampling the MEP cube at that vertex.
# CubeFile.sample interpolates in WORLD space from the MEP cube's own origin/cell, so
# the two cubes only need a shared EXTENT (cubegen derives that from the molecule +
# default margin — identical for both), NOT a shared resolution. The MEP grid is
# therefore decoupled and much coarser: MEP cost is O(ngrid · nao²) and 80³ is brutal
# (benzene/6-31G ≈ 104 s), while the coloring field is smooth and trilinear-sampled
# onto the fine density surface, so 48³ (≈ 22 s benzene) is visually indistinguishable.
_DENSITY_CUBE_NX = 80
_MEP_CUBE_NX = 48


def _generate_density_cubes(
    mol, mf, result: dict[str, Any], out_dir: str, stem: str = "job"
) -> list[dict[str, Any]]:
    """Write density .cube files (GaussView parity, P-UI-25 A3/A4) and return their
    {kind, path} records: the TOTAL electron density always, plus the SPIN density
    (alpha−beta) when the reference is spin-separated (UHF/UKS/ROHF — make_rdm1
    returns the (2, nao, nao) channel pair; restricted refs return one matrix and
    get total only). Files are named <stem>_density_<kind>.cube — the same per-job
    stem as the orbital cubes, so concurrent jobs never collide in a shared dir.

    When the total density cube is written, ALSO writes a molecular-electrostatic-
    potential (MEP) cube on the SAME grid (kind "mep"): the GaussView signature ESP
    surface colors the density isosurface by this potential field (red = negative /
    electron-rich, blue = positive). "mep" is NOT an isosurface to march — it is the
    coloring field — so the UI treats that record specially.

    Never fails the job — a cube error is skipped WITH a warning."""
    cubes: list[dict[str, Any]] = []
    try:
        from pyscf.tools import cubegen
        import numpy as np

        dm = np.asarray(mf.make_rdm1())
    except Exception as exc:  # noqa: BLE001
        _warn(result, f"density cubes unavailable: {exc}")
        return cubes
    if dm.ndim == 3 and dm.shape[0] == 2:
        # (kind, AO density matrix) — total always, spin only for open shell.
        wanted = [("total", dm[0] + dm[1]), ("spin", dm[0] - dm[1])]
    elif dm.ndim == 2:
        wanted = [("total", dm)]
    else:
        _warn(result, f"density cubes unavailable: unexpected rdm1 shape {dm.shape}")
        return cubes
    nx = _DENSITY_CUBE_NX
    total_dm = None  # the spin-traced total AO density, for the shared-grid MEP cube
    for kind, matrix in wanted:
        path = os.path.join(out_dir, f"{stem}_density_{kind}.cube")
        try:
            cubegen.density(mol, path, matrix, nx=nx, ny=nx, nz=nx)
            cubes.append({"kind": kind, "path": path})
            if kind == "total":
                total_dm = matrix
        except Exception as exc:  # noqa: BLE001
            _warn(result, f"{kind} density cube unavailable: {exc}")
            continue
    # MEP coloring field on the SAME grid as the total density cube (GaussView ESP
    # surface). Only when the total density cube succeeded — the ESP surface marches
    # that density and colors it by this potential, so a MEP without its density is
    # useless. A failure degrades to a warning and just omits the ESP-surface option.
    if total_dm is not None:
        mep_path = os.path.join(out_dir, f"{stem}_density_mep.cube")
        try:
            mnx = _MEP_CUBE_NX
            cubegen.mep(mol, mep_path, total_dm, nx=mnx, ny=mnx, nz=mnx)
            cubes.append({"kind": "mep", "path": mep_path})
        except Exception as exc:  # noqa: BLE001
            _warn(result, f"electrostatic-potential cube unavailable: {exc}")
    return cubes


# Qubit mappings the local statevector simulator supports end-to-end (Hamiltonian +
# HF-state prep + ansatz). Parity is intentionally absent — it has no ansatz/HF-state
# path here, so a parity request fails loud rather than silently mis-mapping (§6).
_VALID_QUBIT_MAPPINGS = ("jordan_wigner", "bravyi_kitaev")


def _quantum_mapping(params: dict[str, Any]) -> str:
    """Read + validate the fermion→qubit mapping from spec.params (default Jordan-Wigner)."""
    mapping = str(params.get("mapping", "jordan_wigner")).lower()
    if mapping not in _VALID_QUBIT_MAPPINGS:
        raise ValueError(
            f"Unknown qubit mapping {mapping!r}. Supported: jordan_wigner, bravyi_kitaev "
            "(parity is not available in the local quantum simulator)."
        )
    return mapping


# Local statevector-simulator feasibility ceilings (mirrored in the GDScript QuantumCostModel
# so the Method screen blocks and the engine fails loud at the same size). VQE/ADAPT simulate a
# 2^N statevector; QPE additionally builds a DENSE 2^n_sys × 2^n_sys unitary, whose memory is
# the tighter limit — so QPE is gated on the SYSTEM qubit count, VQE on the total.
_MAX_VQE_QUBITS = 20
_MAX_QPE_SYSTEM_QUBITS = 12
# Open-system dynamics builds the DENSE Liouvillian superoperator (2^n × 2^n acting on the
# vectorized density matrix → a (4^n) × (4^n) matrix), far heavier than a statevector or even
# QPE's dense unitary, so it has its own much tighter ceiling.
_MAX_OPEN_SYSTEM_QUBITS = 5
# Exact gate synthesis (Quantum Shannon Decomposition) of an arbitrary unitary is O(4^n) gates, so
# the gate-circuit paths that compile a dilation (QAAE, open-system) cap the SYNTHESIZED register.
# 8 qubits ≈ 1.5e5 gates synthesized + applied in ~1-2 s — the practical ceiling for these demos.
_MAX_SYNTHESIS_QUBITS = 8


def _validate_quantum_recipe(spec: dict[str, Any], molecule: dict[str, Any]) -> None:
    """Fail loud (pyscf-free) on quantum recipes the local path can't honor.

    Open shell IS supported (ROHF reference, one set of spatial orbitals; unequal
    alpha/beta counts flow through the Hamiltonian, HF state prep, and the
    unrestricted UCCSD / per-spin ADAPT pool / spin-unbalanced LUCJ ansätze). What
    must still hold: an explicit active space is physical, contains every unpaired
    electron (they cannot sit in the frozen/doubly-occupied region), and pairs the
    rest. Mirrors the Method-screen validation so a hand-built or reproduced request
    is caught here too, never run as the wrong wavefunction.
    """
    mult = int(molecule.get("multiplicity", spec.get("multiplicity", 1)))
    unpaired = abs(mult - 1)
    params = dict(spec.get("params", {}) or {})
    ao = int(params["active_orbitals"]) if params.get("active_orbitals") else None
    ae = int(params["active_electrons"]) if params.get("active_electrons") else None
    if (ao is None) != (ae is None):
        raise ValueError(
            "Quantum active space: set BOTH active_orbitals and active_electrons "
            "(or neither, for the full space)."
        )
    if ao is not None and ae is not None:
        if ao < 1:
            raise ValueError(f"Quantum active_orbitals must be >= 1 (got {ao}).")
        if ae < 0 or ae > 2 * ao:
            raise ValueError(
                f"Quantum active space is impossible: {ae} active electrons cannot fit in "
                f"{ao} active orbitals (max {2 * ao})."
            )
        if ae < unpaired:
            raise ValueError(
                f"Quantum active space must contain every unpaired electron: multiplicity "
                f"{mult} means {unpaired} unpaired, but only {ae} active electrons were "
                f"requested."
            )
        if (ae - unpaired) % 2 != 0:
            raise ValueError(
                f"Quantum active space: after placing {unpaired} unpaired electron(s) "
                f"(multiplicity {mult}), the remaining active electrons must pair up — "
                f"{ae} total leaves an odd remainder."
            )
        if (ae + unpaired) > 2 * ao:
            raise ValueError(
                f"Quantum active space is impossible for multiplicity {mult}: "
                f"{(ae + unpaired) // 2} alpha electrons cannot fit in {ao} active "
                f"orbitals."
            )


def _guard_quantum_size(method: str, num_system_qubits: int) -> None:
    """Fail loud before the LOCAL simulator would OOM / hang. `num_system_qubits` is the
    system register (2 × active spatial orbitals); QPE's dense unitary makes it the binding
    limit there, while VQE/ADAPT are bounded by the same count as the statevector width."""
    if str(method).upper() == "QPE":
        if num_system_qubits > _MAX_QPE_SYSTEM_QUBITS:
            raise ValueError(
                f"QPE builds a dense 2^{num_system_qubits} time-evolution unitary — too large "
                f"for the local simulator (max {_MAX_QPE_SYSTEM_QUBITS} system qubits ≈ "
                f"{_MAX_QPE_SYSTEM_QUBITS // 2} spatial orbitals). Use a smaller basis, frozen "
                f"core, or an explicit active space."
            )
    elif num_system_qubits > _MAX_VQE_QUBITS:
        raise ValueError(
            f"This recipe needs {num_system_qubits} qubits, over the local statevector "
            f"simulator limit ({_MAX_VQE_QUBITS}). Use a smaller basis, enable frozen core, "
            f"or set a smaller active space."
        )


def _run_quantum_common(spec: dict[str, Any], molecule: dict[str, Any], seed: int):
    """Shared setup for VQE/QPE: build SCF, Hamiltonian, qubit operator, info, mapping.

    Honors the Method screen's quantum-Hamiltonian options from spec.params:
      - mapping: 'jordan_wigner' (default) | 'bravyi_kitaev'
      - frozen_core: freeze atomic-core orbitals out of the active space
      - active_orbitals / active_electrons: explicit active-space window (0/absent = full)
    Defaults reproduce the pre-options behavior so the pinned VQE/QPE anchors are unchanged.
    """
    import numpy as np

    np.random.seed(seed if seed else 42)

    from quchemy import get_molecular_hamiltonian, map_to_qubits

    # Fail loud BEFORE the SCF on a recipe the closed-shell-singlet path can't honor
    # (open shell / impossible active space) — cheap, pyscf-free.
    _validate_quantum_recipe(spec, molecule)

    params = dict(spec.get("params", {}) or {})
    mapping = _quantum_mapping(params)
    frozen_core = bool(params.get("frozen_core", False))
    # 0 / absent → None (let the bridge take the full active space).
    active_orbitals = int(params["active_orbitals"]) if params.get("active_orbitals") else None
    active_electrons = int(params["active_electrons"]) if params.get("active_electrons") else None

    # The qubit Hamiltonian is extracted from bare integrals; an implicit-solvent
    # reaction field (and a classical -D dispersion add-on) is not supported here,
    # so force gas phase / no dispersion rather than silently alter the reference.
    quantum_spec = {**spec, "functional": "", "method": "HF", "solvent": ""}
    quantum_params = dict(quantum_spec.get("params", {}) or {})
    quantum_params.pop("solvent_model", None)
    quantum_params.pop("dispersion", None)
    # The quchemy Hamiltonian extraction expects ONE set of spatial orbitals, so the
    # open-shell UHF default does not apply here: pin the pre-UHF behavior (ROHF for
    # open shell — what scf.RHF auto-dispatched to — RHF otherwise). A user-forced
    # params.reference cannot be honored — refuse rather than silently overwrite.
    open_shell = int(molecule.get("multiplicity", spec.get("multiplicity", 1))) != 1
    forced_ref = "ROHF" if open_shell else "RHF"
    user_ref = str(params.get("reference", "")).strip().upper()
    if user_ref and user_ref not in ("AUTO", forced_ref):
        raise ValueError(
            "quantum methods extract the Hamiltonian from a restricted(-open) "
            "reference — params.reference %r is not honored here (this run uses %s). "
            "Remove the override, or use a classical method for that reference."
            % (user_ref, forced_ref)
        )
    quantum_params["reference"] = forced_ref
    quantum_spec["params"] = quantum_params
    mol, mf, _ = _build_mol(quantum_spec, molecule)
    ham, info = get_molecular_hamiltonian(
        mol, mf,
        frozen_core=frozen_core,
        active_electrons=active_electrons,
        active_orbitals=active_orbitals,
    )
    qop = map_to_qubits(ham, mapping)
    return mol, mf, ham, qop, info, mapping


def _statevector_measurements(state, num_qubits: int, *, register: str) -> dict[str, Any]:
    """The computational-basis readout distribution of a simulated statevector.

    |amplitude|^2 per basis state, normalized, top-N kept (rb.measurement_block's cap) — what a
    perfect infinite-shot measurement of the prepared state would give, so `source` is
    "statevector", never "sampled". Bit order follows the quchemy simulator: qubit 0 is the
    LEFTMOST character (MSB), and under OpenFermion interleaved spin ordering qubit 2i is
    spatial orbital i alpha, 2i+1 is i beta.

    The top-N selection runs in numpy (argpartition) so a wide register never materializes a
    2^n-entry Python dict; the discarded mass rides as the block's "other_probability".
    """
    import numpy as np

    probs = np.abs(np.asarray(state).ravel()) ** 2
    total = float(probs.sum())
    if total > 0.0:
        probs = probs / total
    keep = min(int(rb.MAX_MEASUREMENT_OUTCOMES), int(probs.size))
    if keep < probs.size:
        top = np.argpartition(probs, -keep)[-keep:]
    else:
        top = np.arange(probs.size)
    fmt = "0%db" % max(1, num_qubits)
    kept_map = {format(int(i), fmt): float(probs[i]) for i in top}
    return rb.measurement_block(
        probabilities=kept_map,
        num_qubits=num_qubits,
        source="statevector",
        register=register,
        total_unique=int((probs > rb.MIN_MEASUREMENT_PROBABILITY).sum()),
        other_probability=float(max(0.0, 1.0 - sum(kept_map.values()))),
    )


def action_vqe(request: dict[str, Any]) -> dict[str, Any]:
    """VQE via quchemy -> JobResult (total_energy = VQE energy).

    Honors spec.params.algorithm: 'uccsd' (default — the fixed UCCSD ansatz), 'adapt'
    (ADAPT-VQE: build the ansatz iteratively from the UCCSD operator pool), 'cqe' (CQE/ACSE),
    or 'qaae' (amplitude-amplification eigensolver — a non-variational spectral-filter amplify-learn
    loop). All use the qubit mapping resolved in _run_quantum_common (Jordan-Wigner default).
    """
    import quchemy
    from quchemy import VQE, make_uccsd_ansatz
    from quchemy.solver.expectation import statevector_simulate

    spec = request.get("spec", {})
    molecule = request["molecule"]
    seed = int(spec.get("rng_seed", 0) or 0)
    params = spec.get("params", {}) or {}
    algorithm = str(params.get("algorithm", "uccsd")).lower()
    # The converged ansatz state, when the algorithm ends on a prepared circuit (UCCSD/ADAPT) —
    # its basis-state probabilities become the Analyze Quantum tab's readout histogram. The
    # dense CQE/QAAE paths do not return a state, so they simply carry no measurement block.
    final_state = None

    t0 = time.perf_counter()
    mol, mf, _ham, qop, info, mapping = _run_quantum_common(spec, molecule, seed)
    num_qubits = int(info["num_qubits"])
    # Backstop the statevector size before VQE.run allocates the 2^N state (the Method screen
    # already blocks this; a hand-built/reproduced request is caught here).
    _guard_quantum_size("VQE", num_qubits)

    if algorithm == "adapt":
        from quchemy import AdaptVQE, build_uccsd_pool, make_hf_state_circuit

        # Tuple, not the summed count: unequal alpha/beta switches the pool to
        # per-spin occupied windows (a shared window would sideline the SOMO).
        pool = build_uccsd_pool(info["num_spatial_orbitals"], info["num_particles"], mapping)
        hf_circuit = make_hf_state_circuit(info["num_particles"], num_qubits, mapping)
        adapt_res = AdaptVQE(
            qop,
            pool,
            num_qubits,
            initial_state=hf_circuit,
            optimizer=str(params.get("optimizer", "COBYLA")),
            max_iterations=int(params.get("adapt_max_iterations", 50)),
            gradient_threshold=float(params.get("adapt_gradient_threshold", 1e-5)),
            max_vqe_iterations=int(params.get("adapt_vqe_iterations", 500)),
        ).run()
        energy = float(adapt_res["energy"])
        converged = bool(adapt_res["converged"])
        algorithm_label = "ADAPT-VQE"
        ansatz_label = "ADAPT"
        circuit = adapt_res["circuit"]
        circuit_depth = int(circuit.depth())
        num_parameters = int(len(adapt_res["parameters"]))
        iterations = int(adapt_res["iterations"])
        energy_history = list(adapt_res["history"])
        final_state = statevector_simulate(circuit, adapt_res["parameters"])
    elif algorithm == "cqe":
        from quchemy import CQE, build_generalized_pool, get_hf_state

        # The CQE/ACSE needs the FULL generalized two-body pool to reach FCI — the UCCSD subset
        # (occupied→virtual only) has ACSE stationary points well above the ground state.
        pool = build_generalized_pool(num_qubits, mapping)
        hf_state = get_hf_state(info["num_particles"], num_qubits, mapping=mapping)
        cqe_circuit = bool(params.get("use_gate_circuit", False))
        cqe_res = CQE(
            qop,
            pool,
            num_qubits,
            hf_state,
            epsilon=float(params.get("cqe_epsilon", 0.1)),
            max_iterations=int(params.get("cqe_max_iterations", 300)),
            residual_tol=float(params.get("cqe_residual_tol", 1e-6)),
            use_gate_circuit=cqe_circuit,
            trotter_steps=int(params.get("trotter_steps", 1)),
        ).run()
        energy = float(cqe_res.energy)
        converged = bool(cqe_res.converged)
        algorithm_label = "CQE-gate-circuit" if cqe_circuit else "CQE"
        ansatz_label = "2-body-ACSE"
        circuit_depth = int(cqe_res.iterations)  # one exp(eps A) layer per iteration
        num_parameters = int(len(pool))
        iterations = int(cqe_res.iterations)
        energy_history = list(cqe_res.energy_history)
    elif algorithm == "qaae":
        from quchemy import QAAE, get_hf_state

        # QAAE builds the dense spectral-filter contraction (and dilates it) — gate like QPE.
        _guard_quantum_size("QPE", num_qubits)
        qaae_circuit = bool(params.get("use_gate_circuit", False))
        if qaae_circuit and (num_qubits + 1) > _MAX_SYNTHESIS_QUBITS:
            raise ValueError(
                "QAAE on the gate circuit compiles the Sz.-Nagy dilation (a %d-qubit unitary) via the "
                "Quantum Shannon Decomposition — O(4^n) gates, capped at %d qubits. Use a smaller "
                "basis, frozen core, or an active space; the dense path has no such limit."
                % (num_qubits + 1, _MAX_SYNTHESIS_QUBITS)
            )
        hf_state = get_hf_state(info["num_particles"], num_qubits, mapping=mapping)
        qaae_res = QAAE(
            qop, hf_state,
            rounds=int(params.get("qaae_rounds", 40)),
            tol=float(params.get("qaae_tol", 1e-9)),
            use_gate_circuit=qaae_circuit,
        ).run()
        energy = float(qaae_res.energy)
        converged = bool(qaae_res.converged)
        algorithm_label = "QAAE-gate-circuit" if qaae_circuit else "QAAE"
        ansatz_label = "filter-amplify"
        circuit_depth = int(qaae_res.rounds)         # one filter-dilation round per layer
        num_parameters = 0                           # not variational — no parameters to optimize
        iterations = int(qaae_res.rounds)
        energy_history = list(qaae_res.energy_history)
    else:
        ansatz = make_uccsd_ansatz(
            info["num_spatial_orbitals"], info["num_particles"], mapping=mapping)
        vqe_res = VQE(
            ansatz,
            qop,
            optimizer=str(params.get("optimizer", "COBYLA")),
            max_iterations=int(params.get("max_iterations", 2000)),
            tol=float(params.get("tol", 1e-10)),
        ).run()
        energy = float(vqe_res.energy)
        converged = bool(vqe_res.converged)
        algorithm_label = "UCCSD-VQE"
        ansatz_label = "UCCSD"
        circuit_depth = int(ansatz.depth())
        num_parameters = int(ansatz.num_parameters)
        iterations = int(vqe_res.num_iterations)
        energy_history = list(vqe_res.history)
        final_state = statevector_simulate(ansatz, vqe_res.optimal_parameters)
    wall = time.perf_counter() - t0

    result = rb.blank_result()
    _fill_overview(result, spec, molecule, seed=seed if seed else 42)
    result["method"] = "VQE"
    result["engine"] = "quchemy"
    result["engine_version"] = str(quchemy.__version__)
    result["wall_clock_s"] = float(wall)
    # The ACTUAL circuit + run metrics (Analyze shows them against the Method estimate;
    # Reproduce reads mapping/algorithm back). {} for classical methods.
    result["quantum"] = rb.quantum_block(
        num_qubits=num_qubits, mapping=mapping, algorithm=algorithm_label, ansatz=ansatz_label,
        num_parameters=num_parameters, iterations=iterations, circuit_depth=circuit_depth,
        energy_history=energy_history,
    )
    if final_state is not None:
        result["quantum"]["measurements"] = _statevector_measurements(
            final_state, num_qubits,
            register="computational basis (spin-orbital occupations)")
    # HF orbitals as the reference picture for the Orbitals tab.
    _fill_scf(result, mol, mf, False)
    result["total_energy"] = energy
    result["converged"] = converged
    if algorithm_label == "CQE-gate-circuit":
        _warn(result, "CQE prepared its ACSE state with a real gate circuit (Trotterized "
                      "exp(-eps A) Pauli-exponential layers, hardware-exportable) — Trotter-"
                      "approximate; the exact sparse path is the default.")
    elif algorithm_label == "QAAE-gate-circuit":
        _warn(result, "QAAE applied its spectral filter as the Sz.-Nagy dilation compiled to gates "
                      "(exact Quantum Shannon Decomposition, +1 ancilla, hardware-exportable); the "
                      "dense path is the default.")
    if _spec_flag(spec, "compute_fukui"):
        _warn(result, "Fukui indices are not offered for VQE — the condensed scheme "
                      "differences classical N±1 ion Mulliken charges")
    result["success"] = True
    return result


def action_qpe(request: dict[str, Any]) -> dict[str, Any]:
    """QPE with HF initial state via quchemy -> JobResult (total_energy = QPE energy).

    params.use_gate_circuit routes QPE through the REAL universal-gate circuit (QFT + Trotterized
    controlled-e^{-iHt} powers, hardware-exportable) instead of the dense matrix-exponential
    simulator — Trotter-approximate but the genuine on-hardware algorithm.
    """
    import numpy as np
    import quchemy
    from quchemy import QPE, get_hf_state, get_num_qubits

    spec = request.get("spec", {})
    molecule = request["molecule"]
    seed = int(spec.get("rng_seed", 0) or 0)
    params = spec.get("params", {}) or {}
    n_ancilla = int(params.get("num_ancilla", 6))
    use_circuit = bool(params.get("use_gate_circuit", False))
    # Ancilla-register readout distribution (the QPE "peak picking" picture) — filled from the
    # dense path's phase probabilities; the gate path returns only the estimate.
    phase_probs: dict[int, float] = {}

    t0 = time.perf_counter()
    mol, mf, _ham, qop, info, mapping = _run_quantum_common(spec, molecule, seed)
    num_system_qubits = get_num_qubits(qop)
    # QPE builds a dense 2^n_sys × 2^n_sys unitary — backstop the size before that allocation.
    _guard_quantum_size("QPE", num_system_qubits)
    hf_state = get_hf_state(info["num_particles"], num_system_qubits, mapping=mapping)
    if use_circuit:
        from quchemy.solver.qpe_circuit import qpe_gate_estimate

        gate_res = qpe_gate_estimate(qop, np.asarray(hf_state).astype(int), n_ancilla=n_ancilla,
                                     num_trotter_steps=int(params.get("num_trotter_steps", 1)))
        qpe_energy = gate_res["energy"]
        total_qubits = n_ancilla + num_system_qubits
        circuit_depth = 0
    else:
        qpe_res = QPE(
            qop,
            num_ancilla=n_ancilla,
            num_trotter_steps=int(params.get("num_trotter_steps", 1)),
            initial_state=hf_state,
        ).run()
        qpe_energy = float(qpe_res.energy)
        total_qubits = int(qpe_res.total_qubits)
        circuit_depth = int(qpe_res.circuit_depth)
        phase_probs = dict(qpe_res.phase_probabilities)
    wall = time.perf_counter() - t0

    result = rb.blank_result()
    _fill_overview(result, spec, molecule, seed=seed if seed else 42)
    result["method"] = "QPE"
    result["engine"] = "quchemy"
    result["engine_version"] = str(quchemy.__version__)
    result["wall_clock_s"] = float(wall)
    # The ACTUAL circuit metrics (system + ancilla qubits, approximate depth, mapping).
    result["quantum"] = rb.quantum_block(
        num_qubits=total_qubits, mapping=mapping,
        algorithm="QPE-gate-circuit" if use_circuit else "QPE",
        circuit_depth=circuit_depth, num_ancilla=n_ancilla,
    )
    if phase_probs:
        # The phase register IS the QPE measurement: bin k (MSB-first over n_ancilla bits) means
        # phase k/2^n, which _phase_to_energy maps to the reported energy. The tallest bar is the
        # estimate; a spread-out distribution is the honest picture of ancilla-limited resolution.
        fmt = "0%db" % max(1, n_ancilla)
        result["quantum"]["measurements"] = rb.measurement_block(
            probabilities={format(int(k), fmt): float(v) for k, v in phase_probs.items()},
            num_qubits=n_ancilla, source="statevector",
            register="phase (ancilla) register",
        )
    _fill_scf(result, mol, mf, False)
    result["total_energy"] = float(qpe_energy)
    if use_circuit:
        _warn(result, "QPE ran as the real gate circuit (QFT + Trotterized controlled-e^{-iHt} "
                      "powers, hardware-exportable) — Trotter-approximate; the exact dense "
                      "matrix-exponential path is the default.")
    # QPE is a discretized estimate; treat as "converged" when it ran — but SAY what that
    # word is worth here. The phase register has 2^n_ancilla bins, and the estimator takes
    # the tallest one, so the answer is quantized with a bin width of 2*pi/(t * 2^n) in
    # energy. The true phase generally falls between bins, and the reported energy can land
    # BELOW the exact ground state — a variational-principle violation on its face, which
    # looked like a converged result with no stated uncertainty (H2/STO-3G, n=6: -1.14546 Ha
    # against an exact -1.13728, i.e. 5.1 kcal/mol low). The repo's own regression tolerance
    # already admits this (QPE_TOL = 2e-2, "NOT chemical accuracy"); now the user sees it.
    result["converged"] = True
    _qpe_resolution = None
    try:
        import math as _math

        _t_evo = float(getattr(qpe_res, "evolution_time", 0.0)) if not use_circuit \
            else float(gate_res.get("evolution_time", 0.0))
        if _t_evo > 0.0:
            _qpe_resolution = 2.0 * _math.pi / (_t_evo * (2 ** n_ancilla))
    except Exception:  # noqa: BLE001 — the estimate is a courtesy, never a failure
        _qpe_resolution = None
    if _qpe_resolution:
        _warn(result,
              "QPE energy is quantized by the %d-bit phase register: its resolution is "
              "+/-%.2e Ha (%.2f kcal/mol), far coarser than chemical accuracy. The estimate "
              "is the tallest phase bin, so it can fall either side of the true eigenvalue "
              "— including BELOW it. Add ancilla qubits to refine it; do not quote this "
              "number to more precision than the bin width."
              % (n_ancilla, _qpe_resolution, _qpe_resolution * 627.5094740631))
    else:
        _warn(result,
              "QPE energy is quantized by the %d-bit phase register and is the tallest "
              "phase bin, so it carries a resolution-limited error that can place it either "
              "side of the true eigenvalue. It is not a variational upper bound."
              % n_ancilla)
    if _spec_flag(spec, "compute_fukui"):
        _warn(result, "Fukui indices are not offered for QPE — the condensed scheme "
                      "differences classical N±1 ion Mulliken charges")
    result["success"] = True
    return result


def _ancilla_z_from_bitarray(bit_array) -> float:
    """<Z> on the Hadamard-test ancilla from a SamplerV2 measurement BitArray.

    The ancilla is circuit qubit 0; under Qiskit's little-endian bitstrings that is the RIGHTMOST
    character. <Z> = P(anc=0) − P(anc=1) over the shots. (Per-qubit <Z> is convention-independent,
    so the quchemy-simulator MSB ordering vs Qiskit LSB ordering does not matter here.)
    """
    counts = bit_array.get_counts()
    total = sum(counts.values())
    if not total:
        return 0.0
    z = 0.0
    for bits, c in counts.items():
        z += c if str(bits)[-1] == "0" else -c
    return z / total


def _hadamard_signal_via_sampler(qop, ref_bits, times, sampler, *, trotter_dt=0.2,
                                 max_steps=4000, pass_manager=None):
    """g(t) = <phi0|e^{-iHt}|phi0> for each t, sampled from the Hadamard-test gate circuits run on a
    SamplerV2-like `sampler` (IBM Quantum hardware, or a local reference sampler for verification).

    Builds the real + imaginary Hadamard-test circuit per time (ancilla = qubit 0, measured),
    optionally transpiles them with `pass_manager` (ISA for a real device), batches ALL of them
    into one `sampler.run`, and reads <Z> on the ancilla per circuit. Returns the complex g(t).
    """
    import math as _math

    import numpy as np
    from quchemy.solver.hadamard_test import hadamard_test_circuit
    from quchemy.export.qiskit_export import to_qiskit_circuit

    ref_bits = np.asarray(ref_bits).astype(int)
    times = np.asarray(times)
    circuits = []
    meta: list[tuple[int, str]] = []
    for k, t in enumerate(times):
        tt = float(t)
        steps = 1 if tt == 0.0 else min(max_steps, max(1, _math.ceil(abs(tt) / trotter_dt)))
        for part in ("re", "im"):
            qc = to_qiskit_circuit(hadamard_test_circuit(qop, ref_bits, tt, steps, part))
            qc.measure_all()
            circuits.append(qc)
            meta.append((k, part))
    if pass_manager is not None:
        circuits = [pass_manager.run(c) for c in circuits]

    result = sampler.run(circuits).result()
    g_re = np.zeros(len(times))
    g_im = np.zeros(len(times))
    for idx, (k, part) in enumerate(meta):
        z = _ancilla_z_from_bitarray(result[idx].data.meas)
        if part == "re":
            g_re[k] = z
        else:
            g_im[k] = z
    return g_re + 1j * g_im


def _signal_pe_signal_ibmq(qop, ref_bits, times, request, token, trotter_dt, shots, notes, label):
    """Sample a signal-PE method's g(t) on IBM Quantum hardware (SamplerV2). Returns (g, device).

    Shared by the IBM path of QCELS / RPE / QMEGS — they all consume the same time-domain signal
    g(t) = <HF|e^{-iHt}|HF>, so one Hadamard-test sampler serves them all. Auths like action_ibmq
    (channel ibm_quantum_platform + instance CRN), picks the device (or the least-busy real one),
    transpiles the Hadamard-test circuits to the device, and batches them in one job. Untested
    on live hardware here (0-QPU budget by design); the circuit path is validated against the dense
    signal on a local reference sampler in the test suite.
    """
    from qiskit_ibm_runtime import QiskitRuntimeService, SamplerV2
    from qiskit.transpiler.preset_passmanagers import generate_preset_pass_manager

    instance = str(request.get("ibmq_instance", "")).strip()
    kw: dict[str, Any] = {"channel": "ibm_quantum_platform", "token": token}
    if instance:
        kw["instance"] = instance
    service = QiskitRuntimeService(**kw)
    device = str(request.get("ibmq_backend", "")).strip()
    backend = (
        service.backend(device) if device
        else service.least_busy(operational=True, simulator=False))
    pm = generate_preset_pass_manager(target=backend.target, optimization_level=1)
    name = str(getattr(backend, "name", device) or device)
    # Job mode (SamplerV2(mode=backend)): the whole g(t) batches into ONE sampler.run, so a
    # device-reserving Session adds nothing — and Session is forbidden on the free IBM Quantum
    # Open plan (API error 1352). Job mode runs on every plan.
    sampler = SamplerV2(mode=backend)
    sampler.options.default_shots = shots
    g = _hadamard_signal_via_sampler(qop, ref_bits, times, sampler,
                                     trotter_dt=trotter_dt, pass_manager=pm)
    notes.append("%s sampled g(t) at %d times (×2 Hadamard-test circuits) on IBM device %s"
                 % (label, len(times), name))
    return g, name


def action_signal_pe(request: dict[str, Any]) -> dict[str, Any]:
    """Signal-based phase estimation -> JobResult (total_energy = ground-state estimate).

    One action for the signal-PE family; spec.params.algorithm selects:
      'qcels' (default) — Quantum Complex Exponential Least Squares (dominant-frequency fit),
      'rpe'             — Robust Phase Estimation (Heisenberg-limited phase unwrapping),
      'qmegs'           — multi-eigenvalue Gaussian-filter search (excited-state spectrum),
      'bpe'             — Bayesian Phase Estimation (single-ancilla, posterior-tracking),
      'bpde'            — Bayesian Phase-Difference Estimation (the ground→S1 energy GAP directly;
                          gets its two references from VQD).
    All build g(t) = <HF|exp(-iHt)|HF> on the statevector (one dense diagonalization), so they
    share QPE's memory footprint and are gated on the SYSTEM qubit count.
    """
    import quchemy
    from quchemy import (QCELS, RobustPE, QMEGS, BPE, BPDE,
                         get_hf_state, get_num_qubits)

    spec = request.get("spec", {})
    molecule = request["molecule"]
    seed = int(spec.get("rng_seed", 0) or 0)
    params = spec.get("params", {}) or {}
    algorithm = str(params.get("algorithm", "qcels")).lower()

    # IBM Quantum routing: IbmqStrategy injects a token when the Run target is IBM Quantum. The
    # signal-PE methods whose g(t) = <HF|e^{-iHt}|HF> is sampled from one batch of Hadamard-test
    # circuits run on SamplerV2 (QCELS/RPE/QMEGS); BPE (adaptive, one time per round → many jobs),
    # QKD (Krylov overlap matrices) and BPDE (arbitrary excited-state prep) have no hardware path
    # here and are rejected loud rather than silently run local. Drop the credential when read.
    ibmq_token = str(request.get("ibmq_token", "")).strip()
    request.pop("ibmq_token", None)
    _IBM_SIGNAL_ALGOS = ("qcels", "rpe", "qmegs")
    if ibmq_token and algorithm not in _IBM_SIGNAL_ALGOS:
        raise ValueError(
            "IBM Quantum runs QCELS/RPE/QMEGS from the signal-PE family (their Hadamard-test g(t) "
            "is sampled on SamplerV2); %r has no IBM-hardware path. Run it on the Local backend."
            % algorithm.upper())
    ibmq_device = ""
    ibmq_notes: list[str] = []

    t0 = time.perf_counter()
    mol, mf, _ham, qop, info, mapping = _run_quantum_common(spec, molecule, seed)
    num_system_qubits = get_num_qubits(qop)
    # The signal primitive diagonalizes the dense 2^n_sys × 2^n_sys Hamiltonian — QPE's ceiling.
    _guard_quantum_size("QPE", num_system_qubits)
    hf_state = get_hf_state(info["num_particles"], num_system_qubits, mapping=mapping)

    spectrum_energies: list[float] = []
    # The reliable signal-PE family (QCELS/RPE/QMEGS/BPE) can sample g(t) from the real Hadamard-test
    # gate circuit (Trotterized controlled-e^{-iHt}, +1 ancilla, hardware-exportable) instead of the
    # exact dense signal. EXCLUDED from the gate path: BPDE (its excited reference is a statevector,
    # not a basis string, so the gate state-prep can't build it). Default stays the exact dense path.
    requested_circuit = bool(params.get("use_hadamard_test", False))
    use_circuit = requested_circuit and algorithm not in ("bpde",)
    trotter_dt = float(params.get("trotter_dt", 0.2))
    signal_circuit = False    # set when g(t) came from the Hadamard-test gate circuit

    # One Hadamard-test g(t) sampler shared by the IBM path of QCELS/RPE/QMEGS (None → local run).
    # Each solver calls signal_fn(times) once with its own time grid; the closure batches those
    # circuits to SamplerV2 and records the device. When None the solver takes its normal path.
    ibm_signal_fn = None
    if ibmq_token:
        _ibm_shots = max(1, int(params.get("shots", 4096)))
        _ibm_label = algorithm.upper()

        def ibm_signal_fn(times):
            g, dev = _signal_pe_signal_ibmq(
                qop, hf_state, times, request, ibmq_token, trotter_dt, _ibm_shots,
                ibmq_notes, _ibm_label)
            nonlocal ibmq_device
            ibmq_device = dev
            return g

    if algorithm == "rpe":
        res = RobustPE(qop, hf_state,
                       num_generations=int(params.get("num_generations", 12)),
                       use_hadamard_test=use_circuit, trotter_dt=trotter_dt,
                       signal_fn=ibm_signal_fn).run()
        method_label = "RPE"
        signal_circuit = use_circuit or ibm_signal_fn is not None
    elif algorithm == "qmegs":
        res = QMEGS(qop, hf_state,
                    num_samples=int(params.get("num_samples", 400)),
                    resolution=params.get("qmegs_resolution"),
                    max_eigenvalues=int(params.get("max_eigenvalues", 8)),
                    use_hadamard_test=use_circuit, trotter_dt=trotter_dt,
                    signal_fn=ibm_signal_fn).run()
        method_label = "QMEGS"
        spectrum_energies = list(res.energies)
        signal_circuit = use_circuit or ibm_signal_fn is not None
    elif algorithm == "bpe":
        res = BPE(qop, hf_state,
                  num_rounds=int(params.get("num_rounds", 24)),
                  shots=int(params.get("shots", 200)),
                  seed=seed if seed else 42,
                  use_hadamard_test=use_circuit, trotter_dt=trotter_dt).run()
        method_label = "BPE"
        signal_circuit = use_circuit
    elif algorithm == "bpde":
        # The ground→S1 GAP. References from VQD (the two lowest states it overlaps); total_energy
        # stays the GROUND energy (honest), and the gap is surfaced in the spectrum + a warning.
        from quchemy import VQD, make_uccsd_ansatz
        ansatz = make_uccsd_ansatz(info["num_spatial_orbitals"], info["num_particles"], mapping=mapping)
        vqd = VQD(ansatz, qop, k=2).run()
        if len(vqd.states) < 2:
            raise ValueError("BPDE needs a ground and an excited reference — VQD returned <2 states.")
        # Gate-circuit path: prepare BOTH references with the VQD ansatz bound to its optimal
        # parameters (a real gate circuit), and sample g_g(t)/g_e(t) from the Hadamard test.
        bpde_kwargs = {}
        if requested_circuit:
            bpde_kwargs = {
                "prep_ground": ansatz.bind_parameters(vqd.parameters[0]).gates,
                "prep_excited": ansatz.bind_parameters(vqd.parameters[1]).gates,
                "trotter_dt": trotter_dt,
            }
        bpde = BPDE(qop, vqd.states[0], vqd.states[1],
                    num_rounds=int(params.get("num_rounds", 24)),
                    shots=int(params.get("shots", 200)),
                    seed=seed if seed else 42, **bpde_kwargs).run()
        signal_circuit = requested_circuit
        ground = float(vqd.energies[0])
        spectrum_energies = [ground, ground + bpde.gap]   # S0 and the BPDE-estimated S1
        bpde_gap = float(bpde.gap)
        res = type("_BPDERes", (), {"energy": ground})()
        method_label = "BPDE"
    else:
        # QCELS (default). Honors the shared Hadamard-test gate-circuit signal path, AND — when a
        # token rode in (IBM Quantum target) — samples g(t) on real hardware via SamplerV2.
        res = QCELS(qop, hf_state,
                    num_samples=int(params.get("num_samples", 200)),
                    dt=params.get("qcels_dt"),
                    use_hadamard_test=use_circuit, trotter_dt=trotter_dt,
                    signal_fn=ibm_signal_fn).run()
        method_label = "QCELS"
        signal_circuit = use_circuit or ibm_signal_fn is not None
    wall = time.perf_counter() - t0

    result = rb.blank_result()
    _fill_overview(result, spec, molecule, seed=seed if seed else 42)
    result["method"] = method_label
    # On the IBM path g(t) came from real hardware (SamplerV2); stamp the engine honestly.
    on_ibmq = bool(ibmq_device)
    result["engine"] = (
        "qiskit-ibm-runtime (%s/SamplerV2)" % method_label if on_ibmq else "quchemy")
    result["engine_version"] = str(quchemy.__version__)
    result["wall_clock_s"] = float(wall)
    # QMEGS resolves several eigenvalues — carry them (ascending) in the quantum block's
    # energy_history so Analyze can render the spectrum; the others leave it empty.
    # The Hadamard-test gate path adds one ancilla (the test qubit) over the bare system register.
    qblock = rb.quantum_block(
        num_qubits=num_system_qubits, mapping=mapping, algorithm=method_label,
        num_ancilla=(1 if (algorithm in ("rpe", "bpe") or signal_circuit) else 0),
        energy_history=spectrum_energies, energy_history_kind="spectrum",
        # Report the count this algorithm actually has, rather than letting depth /
        # parameters / iterations default to 0 — the Circuit & run panel was printing a
        # 0-depth, 0-iteration circuit for a method that evaluated a signal at hundreds of
        # time points or ran two dozen Bayesian rounds. Absent numbers shown as zeros.
        iterations=(int(params.get("num_rounds", 24)) if algorithm in ("bpe", "bpde")
                    else int(params.get("num_samples", 400 if algorithm == "qcels" else 200))),
    )
    if on_ibmq:
        qblock["ibmq_backend"] = ibmq_device
        qblock["shots"] = max(1, int(params.get("shots", 4096)))
    result["quantum"] = qblock
    _fill_scf(result, mol, mf, False)
    result["total_energy"] = float(res.energy)
    for note in ibmq_notes:
        _warn(result, str(note))
    if algorithm == "bpde":
        # NOT "S0→S1". The excited reference is whatever VQD's second root converges to
        # inside the UCCSD manifold, which conserves particle number and Sz — for H2/STO-3G
        # that is the doubly-excited ¹Σg⁺ (44.1 eV by FCI), not the first excited singlet
        # (26.4 eV). Calling it S1 turned an ansatz artifact into a named spectroscopic
        # observable that was 71% too large, quoted to six decimals, with converged=true.
        # Two honest changes: name what it actually is, and check that it IS an eigenvalue
        # — VQD's second root came back 1.13 eV ABOVE the highest exact root, i.e. not
        # stationary at all, and no residual was ever read.
        _warn(result,
              "BPDE energy difference between the two VQD references = %.4f Ha (%.2f eV). "
              "This is NOT the S0→S1 excitation energy: the excited reference is the lowest "
              "VQD root orthogonal to the ground state WITHIN the UCCSD manifold, which "
              "conserves particle number and Sz — it may be a doubly-excited or "
              "different-spin state, and the true first excited state may be unreachable by "
              "this ansatz entirely. Do not quote it as a spectroscopic gap; use TD-DFT or "
              "an explicit excited-state method for that. total_energy is the ground state."
              % (bpde_gap, bpde_gap * 27.211386))
        # A reference above the ansatz's own variational reach is not a converged state.
        _bpde_excited = float(spectrum_energies[-1]) if spectrum_energies else float("nan")
        if _bpde_excited == _bpde_excited and _bpde_excited > 0.0:
            _warn(result,
                  "The BPDE excited reference converged to a POSITIVE total energy "
                  "(%+.4f Ha). For a bound molecule that is not a physical eigenvalue — VQD "
                  "did not reach a stationary excited state, so the difference above is not "
                  "an excitation energy of anything. Treat this run as failed."
                  % _bpde_excited)
    if signal_circuit:
        _warn(result, "%s sampled g(t) from the Hadamard-test gate circuit (Trotterized "
                      "controlled-e^{-iHt}, +1 ancilla) — a hardware-exportable but Trotter-"
                      "approximate path; the exact dense signal is the default." % method_label)
    elif requested_circuit and not signal_circuit:
        _warn(result, "the Hadamard-test gate circuit was requested but is not offered for %s (its "
                      "deep doubling evolutions make the Trotterized bit-feedback unreliable); ran "
                      "the exact dense signal instead." % method_label)
    # Discretized / least-squares / Bayesian estimate from a finite signal; converged when it ran.
    # QPE got this honesty and the rest of the family did not: every algorithm here fits a
    # phase to a FINITE signal, so none is variational and none carries an error bound.
    # Measured on H2/STO-3G against exact FCI: QCELS and RPE both landed BELOW the true
    # eigenvalue — the same variational-violation signature that made the QPE finding
    # matter — while reporting converged=true with an empty warnings channel.
    result["converged"] = True
    _warn_estimator_uncertainty(result, method_label, params, stochastic=algorithm in ("bpe", "bpde"))
    result["success"] = True
    return result


def action_krylov(request: dict[str, Any]) -> dict[str, Any]:
    """Quantum Krylov diagonalization (VQPE) -> JobResult (total_energy = ground Ritz value).

    Projects H into a real-time Krylov space built from the HF reference and solves the
    regularized generalized eigenproblem. Builds the dense time-evolution operator, so it
    is gated on the SYSTEM qubit count like QPE. The Ritz spectrum rides in the quantum
    block's energy_history (ascending) for the Analyze convergence view.
    """
    import quchemy
    from quchemy import QuantumKrylov, get_hf_state, get_num_qubits

    spec = request.get("spec", {})
    molecule = request["molecule"]
    seed = int(spec.get("rng_seed", 0) or 0)
    params = spec.get("params", {}) or {}
    # IBM Quantum routing: IbmqStrategy injects a token when the Run target is IBM Quantum. QKD
    # samples its Krylov g(t)/g'(t) on SamplerV2 (the 3 time grids batched into one job). Drop the
    # credential the instant it is read.
    ibmq_token = str(request.get("ibmq_token", "")).strip()
    request.pop("ibmq_token", None)
    ibmq_device = ""
    ibmq_notes: list[str] = []

    t0 = time.perf_counter()
    mol, mf, _ham, qop, info, mapping = _run_quantum_common(spec, molecule, seed)
    num_system_qubits = get_num_qubits(qop)
    # Krylov builds a dense 2^n_sys × 2^n_sys propagator — same memory ceiling as QPE.
    _guard_quantum_size("QPE", num_system_qubits)
    hf_state = get_hf_state(info["num_particles"], num_system_qubits, mapping=mapping)
    # params.use_hadamard_test builds the Krylov S/H matrix elements from the real Hadamard-test
    # gate circuit (S_jk = g((k-j)dt), H_jk = i g'((k-j)dt)) instead of the exact basis.
    use_circuit = bool(params.get("use_hadamard_test", False))
    krylov_trotter_dt = float(params.get("trotter_dt", 0.1))

    # One Hadamard-test g(t) sampler for the IBM path (None → local). QKD batches its 3 time grids
    # into a single signal_fn call, so one SamplerV2 job serves the whole Krylov subspace build.
    # QKD's H_jk uses a finite-difference derivative of g(t) that AMPLIFIES shot noise (∝1/delta),
    # so the hardware path needs (a) a wider delta (dt/8, set below) and (b) many shots — with a
    # raised floor and a loud honesty warning. Fewer shots give unreliable Ritz energies.
    ibm_signal_fn = None
    delta_frac = 1.0 / 20.0
    qkd_ibm_shots = max(1, int(params.get("shots", 4096)))
    if ibmq_token:
        delta_frac = 1.0 / 8.0
        qkd_ibm_shots = max(32768, int(params.get("shots", 32768)))

        def ibm_signal_fn(times):
            g, dev = _signal_pe_signal_ibmq(
                qop, hf_state, times, request, ibmq_token, krylov_trotter_dt, qkd_ibm_shots,
                ibmq_notes, "QKD")
            nonlocal ibmq_device
            ibmq_device = dev
            return g

    krylov_res = QuantumKrylov(
        qop,
        hf_state,
        krylov_dim=int(params.get("krylov_dim", 6)),
        dt=params.get("krylov_dt"),
        regularization=float(params.get("krylov_regularization", 1e-8)),
        use_hadamard_test=use_circuit,
        trotter_dt=krylov_trotter_dt,
        signal_fn=ibm_signal_fn,
        signal_delta_frac=delta_frac,
    ).run()
    wall = time.perf_counter() - t0
    on_ibmq = bool(ibmq_device)

    result = rb.blank_result()
    _fill_overview(result, spec, molecule, seed=seed if seed else 42)
    result["method"] = "QKD"
    result["engine"] = "qiskit-ibm-runtime (QKD/SamplerV2)" if on_ibmq else "quchemy"
    result["engine_version"] = str(quchemy.__version__)
    result["wall_clock_s"] = float(wall)
    qblock = rb.quantum_block(
        num_qubits=num_system_qubits, mapping=mapping,
        algorithm="QKD-gate-circuit" if (use_circuit or on_ibmq) else "QKD",
        num_ancilla=1 if (use_circuit or on_ibmq) else 0,
        iterations=int(krylov_res.effective_dim), energy_history=list(krylov_res.energies),
        energy_history_kind="spectrum",
    )
    if on_ibmq:
        qblock["ibmq_backend"] = ibmq_device
        qblock["shots"] = qkd_ibm_shots
    result["quantum"] = qblock
    _fill_scf(result, mol, mf, False)
    result["total_energy"] = float(krylov_res.ground_energy)
    for note in ibmq_notes:
        _warn(result, str(note))
    if on_ibmq:
        _warn(result, "QKD's Krylov H matrix uses a finite-difference derivative of the sampled "
                      "g(t), which amplifies shot noise — it needs many shots (floor %d here) and a "
                      "widened step for a reliable Ritz energy; fewer shots give an unstable result. "
                      "QCELS/RPE on IBM (no derivative) are more shot-efficient." % qkd_ibm_shots)
    if use_circuit and not on_ibmq:
        _warn(result, "QKD built its Krylov overlap/Hamiltonian matrices from the Hadamard-test gate "
                      "circuit (S_jk from g(t), H_jk from i·g'(t); +1 ancilla) — hardware-exportable "
                      "but Trotter-approximate; the exact dense path is the default.")
    result["converged"] = True
    # Same family, same honesty: a Ritz value from a finite, regularized Krylov space is not
    # a variational bound on the exact eigenvalue either.
    _warn_estimator_uncertainty(result, "QKD", params, stochastic=on_ibmq,
                                extra="its Krylov space is regularized (krylov_regularization "
                                      "= %s), which sets a floor on the resolvable splitting"
                                      % params.get("krylov_regularization", 1e-8))
    result["success"] = True
    return result


def action_vibrational_vqe(request: dict[str, Any]) -> dict[str, Any]:
    """Vibrational structure on the quantum path -> JobResult.

    Computes the molecule's harmonic frequencies (pyscf Hessian, same path as a frequency job),
    then builds a truncated harmonic-oscillator vibrational Hamiltonian for a SELECTED subset of the
    lowest real modes (params.num_modes, gated so the boson-to-qubit encoding fits the local
    simulator), optionally adds a per-mode quartic anharmonicity, and reports the vibrational levels
    — exactly (vibrational CI in the Fock truncation) or variationally (VQE on the encoded
    Hamiltonian). The full harmonic spectrum still rides in `vibrations` for the IR tab.

    params: num_modes (modes to treat quantumly, default 3), fock_levels (per-mode truncation d,
    default 4), encoding (binary|gray|unary, default binary), anharmonicity (per-mode quartic,
    default 0), use_vqe (bool, default false → exact).
    """
    import pyscf
    from quchemy import vibrational as vib
    from quchemy.vibrational import encoding as venc

    spec = request.get("spec", {})
    molecule = request["molecule"]
    seed = int(spec.get("rng_seed", 0) or 0)
    params = spec.get("params", {}) or {}

    fock_levels = max(2, int(params.get("fock_levels", 4)))
    encoding = str(params.get("encoding", "binary")).lower()
    if encoding not in venc.ENCODINGS:
        encoding = "binary"
    anharmonicity = float(params.get("anharmonicity", 0.0) or 0.0)
    use_vqe = bool(params.get("use_vqe", False))

    t0 = time.perf_counter()
    result = rb.blank_result()
    _fill_overview(result, spec, molecule, seed=seed if seed else 42)

    # 1. Harmonic frequencies (fills result["vibrations"] with signed wavenumbers, cm^-1).
    #
    # _fill_scf FIRST — it is what writes result["converged"], and _compute_frequencies
    # withholds thermochemistry when that flag is false. Every other action already ordered
    # it this way; this one did not, so the guard read blank_result()'s default False and
    # every vibrational-VQE run lost its thermochemistry to a "the SCF did not converge"
    # claim about an SCF that had converged perfectly well.
    mol, mf, is_dft = _build_mol(spec, molecule, progress=True)
    _fill_scf(result, mol, mf, is_dft, spec)
    _compute_frequencies(mol, mf, result, spec)

    # 2. Real (positive) vibrational wavenumbers, lowest-first.
    real_freqs = sorted(
        float(v["wavenumber"]) for v in result.get("vibrations", [])
        if float(v["wavenumber"]) > _IMAG_TOL_CM
    )
    if not real_freqs:
        _warn(result, "no real vibrational modes were found — the vibrational quantum analysis "
                      "needs a minimum (run on an optimized geometry).")
        result["method"] = "VibVQE"
        result["engine"] = "quchemy"
        result["wall_clock_s"] = float(time.perf_counter() - t0)
        result["success"] = True
        return result

    # 3. Select the lowest modes, gated so the boson-to-qubit encoding fits the local simulator.
    num_modes = max(1, int(params.get("num_modes", 3)))
    selected = real_freqs[:num_modes]
    # Shrink the selection until the qubit count is within the Pauli-decomposition ceiling.
    while len(selected) > 1 and venc.qubit_count(
            [fock_levels] * len(selected), encoding) > venc.MAX_PAULI_QUBITS:
        selected = selected[:-1]
    n_qubits = venc.qubit_count([fock_levels] * len(selected), encoding)
    if len(selected) < min(num_modes, len(real_freqs)):
        _warn(result, "vibrational quantum analysis reduced to the %d lowest modes so the %s "
                      "encoding (d=%d) fits the local simulator's %d-qubit limit."
                      % (len(selected), encoding, fock_levels, venc.MAX_PAULI_QUBITS))

    # 4. Vibrational levels — exact (vibrational CI) or VQE on the encoded Hamiltonian.
    import numpy as np
    np.random.seed(seed if seed else 42)
    if use_vqe:
        vres = vib.vibrational_vqe(selected, levels=fock_levels, anharmonicity=anharmonicity,
                                   encoding=encoding)
        method_label = "VibVQE"
    else:
        vres = vib.vibrational_energies(selected, levels=fock_levels, anharmonicity=anharmonicity,
                                        num_levels=min(8, fock_levels * len(selected)))
        method_label = "VibCI"

    result["vibrational"] = rb.vibrational_block(
        mode_frequencies=selected,
        zero_point_energy=vres.zero_point_energy,
        levels=vres.energies,
        fundamentals=vres.fundamentals,
        encoding=encoding,
        fock_levels=fock_levels,
        num_qubits=int(vres.num_qubits or n_qubits),
        anharmonicity=anharmonicity,
        method=vres.method,
    )
    result["quantum"] = rb.quantum_block(
        num_qubits=int(vres.num_qubits or n_qubits), mapping=encoding, algorithm=method_label,
    )
    result["method"] = method_label
    result["engine"] = "quchemy"
    result["engine_version"] = str(pyscf.__version__)
    result["wall_clock_s"] = float(time.perf_counter() - t0)
    result["total_energy"] = result.get("scf_energy", 0.0)
    result["calc_type"] = "vibrational_vqe"
    result["converged"] = True
    result["success"] = True
    return result


def action_open_dynamics(request: dict[str, Any]) -> dict[str, Any]:
    """Open-quantum-system dissipative dynamics -> JobResult (roadmap §6).

    Builds the molecule's qubit Hamiltonian (same `_run_quantum_common` setup as VQE/QPE), then
    evolves the density matrix under the Lindblad master equation with an environment coupling and
    reports the relaxation/decoherence trajectory plus the steady state.

    The system starts in the Hartree-Fock state |HF><HF| (a superposition of energy eigenstates, so
    the dynamics are non-trivial) and the dissipator is chosen via spec.params.dissipator:
      'relaxation' (default) — each excited energy eigenstate decays to the ground state
                               (jump |E0><E_k|); the steady state is the molecular GROUND state, so
                               total_energy is the relaxed energy <H>_ss (≈ FCI in the active space).
      'dephasing'            — pure dephasing in the energy eigenbasis (jump ∝ H); coherences die,
                               populations are frozen, the steady state is the decohered ρ0.
    params: gamma (rate, default 0.1), evolution_time (total, default 5/gamma), time_steps
    (default 40), max_levels (eigenstate populations to record, default 8). Gated at
    _MAX_OPEN_SYSTEM_QUBITS because the dense Liouvillian is 4^n.
    """
    import numpy as np
    import quchemy
    from quchemy import get_num_qubits, get_hf_state
    from quchemy.open_system import liouvillian, purity as _purity
    from quchemy.solver.signal_pe import dense_hamiltonian_matrix, bitstring_to_statevector

    spec = request.get("spec", {})
    molecule = request["molecule"]
    seed = int(spec.get("rng_seed", 0) or 0)
    params = spec.get("params", {}) or {}
    dissipator = str(params.get("dissipator", "relaxation")).lower()
    if dissipator not in ("relaxation", "dephasing"):
        dissipator = "relaxation"
    gamma = float(params.get("gamma", 0.1) or 0.1)
    if gamma <= 0.0:
        raise ValueError(f"Open-system coupling rate gamma must be > 0 (got {gamma}).")

    t0 = time.perf_counter()
    mol, mf, _ham, qop, info, mapping = _run_quantum_common(spec, molecule, seed)
    n_sys = get_num_qubits(qop)
    if n_sys > _MAX_OPEN_SYSTEM_QUBITS:
        raise ValueError(
            f"Open-system dynamics builds the dense Liouvillian (a 4^{n_sys} superoperator) — too "
            f"large for the local simulator (max {_MAX_OPEN_SYSTEM_QUBITS} system qubits). Use a "
            f"smaller basis, frozen core, or an explicit active space."
        )

    # Dense Hamiltonian + its eigenbasis (the natural frame for relaxation/dephasing + populations).
    H = dense_hamiltonian_matrix(qop, n_sys)
    evals, U = np.linalg.eigh(H)                     # ascending; columns are |E_k>
    d = H.shape[0]
    hf_bits = np.asarray(get_hf_state(info["num_particles"], n_sys, mapping=mapping)).astype(int)
    psi0 = bitstring_to_statevector(hf_bits, n_sys)
    rho0 = np.outer(psi0, psi0.conj())

    # Jump operators (in the computational basis the propagator uses).
    jumps: list[np.ndarray] = []
    if dissipator == "relaxation":
        g0 = U[:, 0]
        for k in range(1, d):
            jumps.append(np.sqrt(gamma) * np.outer(g0, U[:, k].conj()))   # |E0><E_k|
        jump_desc = [f"relaxation to ground (gamma={gamma:g}, {d - 1} channels)"]
    else:
        shift = float(np.mean(evals))
        jumps.append(np.sqrt(gamma) * (H - shift * np.eye(d)))            # pure dephasing ∝ H
        jump_desc = [f"pure dephasing in the energy eigenbasis (gamma={gamma:g})"]

    # Time grid + an eig-once propagation of the (non-Hermitian) Liouvillian.
    total_time = float(params.get("evolution_time", 5.0 / gamma))
    steps = max(2, int(params.get("time_steps", 40)))
    times = [total_time * i / (steps - 1) for i in range(steps)]
    L = liouvillian(H, jumps)
    lw, lV = np.linalg.eig(L)
    lVinv = np.linalg.inv(lV)
    v0 = rho0.reshape(-1, order="F")
    coeff = lVinv @ v0

    def _l1_coherence(rho_eig: np.ndarray) -> float:
        # Off-diagonal l1-norm in the energy eigenbasis: total electronic coherence (0 = a
        # classical mixture of eigenstates). Decays to 0 under relaxation, to the same-energy
        # block under dephasing.
        return float(np.sum(np.abs(rho_eig)) - np.sum(np.abs(np.diag(rho_eig))))

    max_levels = max(1, min(int(params.get("max_levels", 8)), d))
    populations: list[list[float]] = []
    coherence: list[float] = []
    purity_trace: list[float] = []
    for t in times:
        rho_t = (lV @ (np.exp(lw * t) * coeff)).reshape((d, d), order="F")
        rho_t = 0.5 * (rho_t + rho_t.conj().T)
        rho_eig = U.conj().T @ rho_t @ U                          # eigenbasis populations
        populations.append([float(np.real(rho_eig[k, k])) for k in range(max_levels)])
        coherence.append(_l1_coherence(rho_eig))
        purity_trace.append(_purity(rho_t))

    # Physical steady state = long-time limit of THIS initial condition: project rho0 onto the
    # non-decaying (Re λ ≈ 0) Liouvillian modes. Robust where the kernel is degenerate (dephasing
    # leaves every diagonal-in-eigenbasis state steady, so the bare null-vector is ambiguous).
    tol = 1e-9 * (1.0 + float(np.max(np.abs(lw))))
    persistent = np.abs(np.real(lw)) < tol
    rho_ss = (lV @ (persistent * coeff)).reshape((d, d), order="F")
    rho_ss = 0.5 * (rho_ss + rho_ss.conj().T)
    tr = np.trace(rho_ss)
    if abs(tr) > 1e-12:
        rho_ss = rho_ss / tr
    ss_energy = float(np.real(np.trace(rho_ss @ H)))
    ss_eig = U.conj().T @ rho_ss @ U
    steady_pops = [float(np.real(ss_eig[k, k])) for k in range(max_levels)]

    n_ancilla = 1 if dissipator == "relaxation" else 0          # Sz.-Nagy dilation overhead on HW
    # Gate-circuit realization: dilate the open-system CHANNEL (Kraus map of e^{L*total_time}) into a
    # Stinespring unitary on system+ancilla, compiled EXACTLY to gates, and run it on |HF> — the real
    # hardware way to execute the non-unitary step. Gated by the synthesis ceiling (O(4^n) gates).
    gate_circuit = bool(params.get("use_gate_circuit", False))
    gate_algorithm = "OpenSys-Lindblad"
    gate_warning = ""
    if gate_circuit:
        from quchemy.open_system import superop_to_kraus
        from quchemy.open_system.stinespring import apply_channel_gates

        P = lV @ (np.exp(lw * total_time)[:, None] * lVinv)     # channel superoperator to total_time
        kraus = superop_to_kraus(P, d)
        n_anc = max(1, int(np.ceil(np.log2(len(kraus))))) if len(kraus) > 1 else 1
        if n_sys + n_anc > _MAX_SYNTHESIS_QUBITS:
            raise ValueError(
                "Open-system gate circuit: dilating the channel (Kraus rank %d) needs %d ancilla "
                "qubits, %d total — over the exact-synthesis ceiling of %d. The dilation is the "
                "fault-tolerant regime; use a smaller system or run the dense (default) path."
                % (len(kraus), n_anc, n_sys + n_anc, _MAX_SYNTHESIS_QUBITS)
            )
        rho_gate = apply_channel_gates(psi0, kraus, n_sys)
        rho_T = (lV @ (np.exp(lw * total_time) * coeff)).reshape((d, d), order="F")
        gate_err = float(np.linalg.norm(rho_gate - 0.5 * (rho_T + rho_T.conj().T)))
        n_ancilla = n_anc
        gate_algorithm = "OpenSys-Stinespring-gate"
        gate_warning = ("open-system step run as a Stinespring dilation compiled to gates (channel "
                        "Kraus rank %d → %d ancilla, %d total qubits, exact synthesis); reproduces "
                        "the dense rho(T) to %.1e." % (len(kraus), n_anc, n_sys + n_anc, gate_err))

    result = rb.blank_result()
    _fill_overview(result, spec, molecule, seed=seed if seed else 42)
    _fill_scf(result, mol, mf, False)
    result["method"] = "OpenSys"
    result["engine"] = "quchemy"
    result["engine_version"] = str(quchemy.__version__)
    result["wall_clock_s"] = float(time.perf_counter() - t0)
    result["calc_type"] = "open_dynamics"
    result["open_system"] = rb.open_system_block(
        algorithm="lindblad",
        dimension=d,
        num_qubits=n_sys,
        num_ancilla=n_ancilla,
        times=times,
        populations=populations,
        coherence=coherence,
        purity_trace=purity_trace,
        steady_state_real=[[float(x) for x in row] for row in np.real(rho_ss)],
        steady_state_imag=[[float(x) for x in row] for row in np.imag(rho_ss)],
        steady_populations=steady_pops,
        steady_purity=_purity(rho_ss),
        jump_operators=jump_desc,
        residual=0.0,
    )
    result["quantum"] = rb.quantum_block(
        num_qubits=n_sys, mapping=mapping, algorithm=gate_algorithm, num_ancilla=n_ancilla,
        energy_history=[float(e) for e in evals[:max_levels]], energy_history_kind="spectrum",
    )
    result["total_energy"] = ss_energy
    if gate_warning:
        _warn(result, gate_warning)
    if dissipator == "relaxation":
        _warn(result, "open-system relaxation: the dissipator drives the molecule to its ground "
                      "state; total_energy = <H> of the steady state (%.6f Ha)." % ss_energy)
    else:
        _warn(result, "open-system dephasing: coherences decay while eigenstate populations are "
                      "preserved; total_energy = <H> of the decohered steady state (%.6f Ha)."
                      % ss_energy)
    result["converged"] = True
    result["success"] = True
    return result


def _qubitop_to_sparsepauliop(qop, num_qubits: int):
    """Convert an OpenFermion QubitOperator into a qiskit SparsePauliOp on `num_qubits`.

    OpenFermion terms are tuples of (qubit_index, pauli_char); qiskit Pauli labels are
    little-endian (rightmost char is qubit 0), so each acting qubit `i` lands at label
    position `num_qubits - 1 - i`, identity elsewhere. The Hamiltonian's constant
    (nuclear repulsion + core) rides in as the all-identity term, so the expectation value
    is the TOTAL energy — no separate offset to add back.
    """
    from qiskit.quantum_info import SparsePauliOp

    terms: list[tuple[str, complex]] = []
    for term, coeff in qop.terms.items():
        label = ["I"] * num_qubits
        for qubit_index, pauli in term:
            label[num_qubits - 1 - qubit_index] = pauli
        terms.append(("".join(label), complex(coeff)))
    if not terms:
        terms = [("I" * num_qubits, 0.0)]
    return SparsePauliOp.from_list(terms, num_qubits=num_qubits)


def _ibmq_backend_with_options(service, device: str, want_fractional: bool, notes: list):
    """Resolve the IBM Quantum backend, enabling fractional gates when asked + supported.

    IBM Heron processors expose direct fractional RZZ(θ)/RX(θ) gates (`use_fractional_gates=
    True`), which cut depth for rotation-heavy ansätze (EfficientSU2). Other processor
    families ignore the flag, so the request is honored best-effort: if enabling it raises, we
    fall back to the standard decomposition and record a note. Returns the backend object.
    """
    def _named(name: str, frac: bool):
        return service.backend(name, use_fractional_gates=True) if frac else service.backend(name)

    if not want_fractional:
        return _named(device, False) if device else service.least_busy(
            operational=True, simulator=False)
    try:
        if device:
            be = _named(device, True)
        else:
            lb = service.least_busy(operational=True, simulator=False)
            be = _named(str(getattr(lb, "name", lb)), True)
        notes.append("fractional gates (RZZ/RX) enabled on %s" % str(getattr(be, "name", "device")))
        return be
    except Exception as exc:  # noqa: BLE001 — fall back to standard gates, never fail the run
        notes.append(
            "fractional gates requested but unavailable on this device (%s); using the standard "
            "gate decomposition" % exc)
        return _named(device, False) if device else service.least_busy(
            operational=True, simulator=False)


def _apply_estimator_options(estimator, params: dict, shots: int, notes: list) -> dict:
    """Apply shots + error mitigation/suppression to an EstimatorV2 (qiskit-ibm-runtime ≥0.40).

    Honors spec.params (all optional, hardware-sane defaults learned from the IBM docs):
      resilience_level: 0|1|2    (default 1 — TREX measurement-error mitigation)
      zne: bool                  (opt-in — forces resilience_level 2 + zne_mitigation)
      dynamical_decoupling: bool (default True — cheap idle-qubit suppression)
      twirling: bool             (default True — Pauli gate twirling)
    Each option is set defensively; one renamed across runtime versions is skipped with a note
    rather than crashing the run. Returns the settings actually requested (for provenance).
    """
    opts = estimator.options
    opts.default_shots = shots
    resilience_level = min(2, max(0, int(params.get("resilience_level", 1))))
    use_zne = bool(params.get("zne", False))
    use_dd = bool(params.get("dynamical_decoupling", True))
    use_twirl = bool(params.get("twirling", True))
    applied: list[str] = []

    try:
        opts.resilience_level = resilience_level
        applied.append("resilience_level=%d" % resilience_level)
    except Exception:  # noqa: BLE001
        notes.append("could not set resilience_level on this runtime version")
    if use_zne:
        try:
            opts.resilience_level = 2
            opts.resilience.zne_mitigation = True
            applied.append("ZNE")
        except Exception:  # noqa: BLE001
            notes.append("ZNE unavailable on this runtime version")
    if use_dd:
        try:
            opts.dynamical_decoupling.enable = True
            applied.append("dynamical decoupling")
        except Exception:  # noqa: BLE001
            notes.append("dynamical decoupling unavailable on this runtime version")
    if use_twirl:
        try:
            opts.twirling.enable_gates = True
            applied.append("gate twirling")
        except Exception:  # noqa: BLE001
            notes.append("gate twirling unavailable on this runtime version")

    notes.append("error mitigation: " + (", ".join(applied) if applied else "none"))
    return {
        "resilience_level": resilience_level, "zne": use_zne,
        "dynamical_decoupling": use_dd, "twirling": use_twirl,
    }


def action_ibmq(request: dict[str, Any]) -> dict[str, Any]:
    """VQE on IBM Quantum hardware (qiskit-ibm-runtime) -> JobResult (overhaul §13.4 / P4.1).

    Capability-gated + fail-loud (§6): a missing qiskit-ibm-runtime install, a non-VQE/QPE
    method, QPE (deep controlled-time-evolution circuits beyond current hardware), or a
    missing token each RAISE an actionable error rather than silently degrading to a local
    run. The local statevector VQE/QPE path (actions "vqe"/"qpe") needs none of this and is
    unaffected — this action only runs when the Run-screen backend picker chose IBM Quantum.

    The circuit is a hardware-efficient EfficientSU2 ansatz; the qubit Hamiltonian (from the
    same `_run_quantum_common` setup the local VQE uses) becomes the SparsePauliOp observable.
    The optimizer (default COBYLA) drives an EstimatorV2 primitive inside a runtime Session,
    streaming each evaluation as a "vqe" QPROG record so the Run-screen live chart updates.
    """
    # Cheap input validation first (no heavy imports): a useful error even in an env that
    # lacks qiskit, and it keeps the capability gate from masking a method/token mistake.
    spec = request.get("spec", {})
    molecule = request["molecule"]
    method = str(spec.get("method", "")).upper()
    if method not in ("VQE", "QPE"):
        raise ValueError(
            f"IBM Quantum runs the quantum methods VQE/QPE; got classical method {method!r}. "
            "Pick the Local or SSH backend, or switch the method in Method."
        )
    if method == "QPE":
        raise ValueError(
            "QPE on IBM Quantum needs deep controlled-time-evolution circuits beyond current "
            "hardware coherence. Run QPE on the Local backend, or use VQE on IBM Quantum."
        )
    token = str(request.get("ibmq_token", "")).strip()
    if not token:
        raise ValueError(
            "No IBM Quantum API token in the request. Add it in Config -> Keys (IBMQ token) "
            "before running on IBM Quantum."
        )

    # Capability gate (fail loud): the deep hardware path needs qiskit + qiskit-ibm-runtime.
    try:
        from qiskit_ibm_runtime import QiskitRuntimeService, EstimatorV2, Session, Batch
        # EfficientSU2: the class is deprecated in Qiskit 2.1 and removed in 3.0 — prefer the
        # `efficient_su2` builder function, falling back to the class on older qiskit.
        try:
            from qiskit.circuit.library import efficient_su2 as _make_efficient_su2
        except ImportError:
            from qiskit.circuit.library import EfficientSU2 as _ESU2Class

            def _make_efficient_su2(n: int, reps: int = 3):
                return _ESU2Class(n, reps=reps)
        from qiskit.transpiler.preset_passmanagers import generate_preset_pass_manager
        import qiskit_ibm_runtime
    except ImportError as exc:
        raise RuntimeError(
            "IBM Quantum execution needs qiskit + qiskit-ibm-runtime, which are not "
            "installed in this sidecar env. Install the optional extra: "
            "pip install 'quchemy[ibmq]'  (or: pip install qiskit qiskit-ibm-runtime). "
            "The local statevector VQE/QPE backend (backend = Local) does not require them."
        ) from exc

    import numpy as np
    from quchemy import get_num_qubits
    from scipy.optimize import minimize

    # Drop the credential from the request dict as soon as it is captured — it is not
    # needed past the service handshake and must not linger in any result/provenance copy.
    request.pop("ibmq_token", None)

    seed = int(spec.get("rng_seed", 0) or 0)
    params = spec.get("params", {}) or {}
    # Clamp the knobs to sane ranges so a degenerate request (shots=0, reps=0) cannot reach
    # the primitive: at least 1 shot, a non-trivial ansatz, and a bounded optimizer budget.
    shots = max(1, int(params.get("shots", 4096)))
    reps = max(1, int(params.get("ansatz_reps", 2)))
    maxiter = max(1, int(params.get("max_iterations", 100)))
    optimizer = str(params.get("optimizer", "COBYLA"))
    # Current-hardware knobs (IBM docs): opt-in fractional gates + execution mode. "job" runs
    # each evaluation as an independent job (the only mode the IBM Quantum Open/free plan
    # authorizes); "session"/"batch" reserve the device and need a paid plan (a session on the
    # open plan returns API error 1352 "not authorized to run a session when using the open plan").
    want_fractional = bool(params.get("fractional_gates", False))
    # Default "job": works on every IBM Quantum plan (including the free Open plan). Session/batch
    # reserve the device for lower latency but need a paid plan, so they are opt-in, not default.
    exec_mode = str(params.get("exec_mode", "job")).lower()
    if exec_mode not in ("session", "batch", "job"):
        exec_mode = "job"
    # Human-readable provenance notes (surfaced via the result warnings channel, §"no silent").
    hw_notes: list[str] = []

    t0 = time.perf_counter()
    mol, mf, _ham, qop, _info, mapping = _run_quantum_common(spec, molecule, seed)
    num_qubits = get_num_qubits(qop)
    observable = _qubitop_to_sparsepauliop(qop, num_qubits)

    # IBM retired the legacy "ibm_quantum" channel (IBM Quantum Platform Classic sunset
    # 2025-07-01); the upgraded platform uses "ibm_quantum_platform" (the qiskit-ibm-runtime
    # 0.40+ default; "ibm_quantum" is removed). An instance CRN selects the account/instance
    # on the new platform — pass it when supplied; a saved default instance works without it.
    instance = str(request.get("ibmq_instance", "")).strip()
    service_kwargs: dict[str, Any] = {"channel": "ibm_quantum_platform", "token": token}
    if instance:
        service_kwargs["instance"] = instance
    service = QiskitRuntimeService(**service_kwargs)
    device = str(request.get("ibmq_backend", "")).strip()
    backend = _ibmq_backend_with_options(service, device, want_fractional, hw_notes)

    ansatz = _make_efficient_su2(num_qubits, reps=reps)
    pass_manager = generate_preset_pass_manager(target=backend.target, optimization_level=1)
    isa_ansatz = pass_manager.run(ansatz)
    isa_observable = observable.apply_layout(isa_ansatz.layout)

    rng = np.random.default_rng(seed if seed else 42)
    x0 = rng.uniform(-0.1, 0.1, ansatz.num_parameters)
    history: list[float] = []

    mitigation: dict[str, Any] = {}

    def _run_optimization(estimator) -> Any:
        """Drive COBYLA over the chosen estimator (job- or session/batch-bound)."""
        nonlocal mitigation
        mitigation = _apply_estimator_options(estimator, params, shots, hw_notes)

        def cost(x):
            job = estimator.run([(isa_ansatz, isa_observable, x)])
            # EstimatorV2 returns evs as a (possibly 0-d / 1-element) array for the single
            # PUB; flatten + take the first element so a scalar OR array shape both work.
            evs = np.asarray(job.result()[0].data.evs).reshape(-1)
            energy = float(np.real(evs[0]))
            history.append(energy)
            _emit_progress({"t": "vqe", "cycle": len(history), "e": energy})
            return energy

        return minimize(cost, x0, method=optimizer, options={"maxiter": maxiter})

    if exec_mode == "job":
        # Job mode: each estimator.run() is an independent job — no reserved context. This is
        # the execution mode the IBM Quantum Open (free) plan allows; pass the backend as the
        # estimator's mode directly (no Session/Batch wrapper).
        opt = _run_optimization(EstimatorV2(mode=backend))
    else:
        # Session reserves the device between evaluations (lowest latency); Batch is offered for
        # completeness. Both need a paid plan — on the open plan use exec_mode "job".
        mode_ctx = Batch(backend=backend) if exec_mode == "batch" else Session(backend=backend)
        with mode_ctx as session:
            opt = _run_optimization(EstimatorV2(mode=session))

    wall = time.perf_counter() - t0
    energy = float(opt.fun) if history else float(min(history) if history else 0.0)

    result = rb.blank_result()
    _fill_overview(result, spec, molecule, seed=seed if seed else 42)
    result["method"] = "VQE"
    result["engine"] = "qiskit-ibm-runtime"
    result["engine_version"] = str(qiskit_ibm_runtime.__version__)
    result["wall_clock_s"] = float(wall)
    # Circuit + run metrics + hardware-execution provenance live in the `quantum` block (the
    # Analyze Overview reads it); the shots/backend/mitigation knobs ride as extra keys the
    # validator ignores. This is also the ACTUAL counterpart to the Method pre-run estimate.
    qblock = rb.quantum_block(
        num_qubits=num_qubits, mapping=mapping, algorithm="VQE", ansatz="EfficientSU2",
        num_parameters=int(getattr(ansatz, "num_parameters", 0)),
        iterations=len(history), circuit_depth=int(isa_ansatz.depth()),
        energy_history=history)
    qblock["shots"] = shots
    qblock["ibmq_backend"] = str(getattr(backend, "name", device) or device)
    qblock["exec_mode"] = exec_mode
    qblock["fractional_gates"] = bool(want_fractional)
    qblock["mitigation"] = mitigation
    result["quantum"] = qblock
    # HF orbitals as the reference picture for the Orbitals tab (matches the local VQE).
    _fill_scf(result, mol, mf, False)
    result["total_energy"] = energy
    result["converged"] = bool(getattr(opt, "success", False))
    result["success"] = True
    # Honesty channel: record exactly what mitigation/suppression + gate set actually applied
    # (so a degraded/unsupported option is surfaced, never silently dropped — §"no silent failures").
    for note in hw_notes:
        _warn(result, str(note))
    return result


def action_ibmq_check(request: dict[str, Any]) -> dict[str, Any]:
    """Lightweight IBM Quantum connection probe (Config → Quantum "Test connection").

    Authenticates the runtime service with the saved token + instance CRN and lists the
    visible backends + the least-busy real device. It submits NO circuit, so it spends ZERO
    QPU credit — it only exercises the credential/handshake path. A SIMPLE action (returns a
    plain doc, not a JobResult); never raises — a bad token / missing runtime / network error
    is reported as {ok:false, error}. The token is dropped from the request the instant it is
    read and is never placed in the returned doc.

    Returns {ok, runtime_version, instance_used, backends:[names], least_busy, message}.
    """
    token = str(request.get("ibmq_token", "")).strip()
    instance = str(request.get("ibmq_instance", "")).strip()
    # Drop the credential from the request dict as soon as it is captured — it must not
    # linger in any copy and must never reach the written doc.
    request.pop("ibmq_token", None)

    if not token:
        return _write_doc(request, {
            "ok": False,
            "error": "No IBM Quantum API token. Add it in Config → Keys (IBMQ token) first.",
        })

    try:
        from qiskit_ibm_runtime import QiskitRuntimeService
        import qiskit_ibm_runtime
    except ImportError as exc:
        return _write_doc(request, {
            "ok": False,
            "error": (
                "qiskit-ibm-runtime is not installed in this sidecar env. Install it from the "
                "Engines tab (or: pip install qiskit-ibm-runtime). Details: %s" % exc),
        })

    try:
        # IBM Quantum Platform (Classic sunset 2025-07-01): channel "ibm_quantum_platform",
        # token + optional instance CRN. An empty instance lets a saved default apply.
        service_kwargs: dict[str, Any] = {"channel": "ibm_quantum_platform", "token": token}
        if instance:
            service_kwargs["instance"] = instance
        service = QiskitRuntimeService(**service_kwargs)

        backends = [str(getattr(b, "name", b)) for b in service.backends()]
        # least_busy can raise when the instance exposes no operational real device — that is
        # not an auth failure, so report the device list with least_busy=None + a note.
        least_busy = ""
        note = ""
        try:
            lb = service.least_busy(operational=True, simulator=False)
            least_busy = str(getattr(lb, "name", lb))
        except Exception as exc:  # noqa: BLE001 — auth worked; just no real device handy
            note = "Authenticated, but no least-busy real device: %s" % exc

        msg = "Connected — %d backend(s) visible." % len(backends)
        if least_busy:
            msg += " Least busy: %s." % least_busy
        return _write_doc(request, {
            "ok": True,
            "runtime_version": str(qiskit_ibm_runtime.__version__),
            "instance_used": instance or "(account default)",
            "backends": backends,
            "least_busy": least_busy,
            "message": msg + ((" " + note) if note else ""),
        })
    except Exception as exc:  # noqa: BLE001 — surface the handshake failure, never crash
        return _write_doc(request, {
            "ok": False,
            "error": "IBM Quantum connection failed: %s: %s" % (type(exc).__name__, exc),
        })


def _lucj_op_from_mf(mf, n_reps: int, notes: list, frozen: list | None = None):
    """Build the LUCJ (Local Unitary Cluster Jastrow) operator for the SQD ansatz from CCSD
    amplitudes (the IBM SQD workflow). Falls back to MP2, then to None (sample the bare
    Hartree-Fock reference) — each degradation is recorded so it is never silent.

    Open shell (ROHF reference): pyscf's CCSD/MP2 emit spin-tuple amplitudes
    (t2aa, t2ab, t2bb) which the spin-balanced constructor rejects — use ffsim's
    UCJOpSpinUnbalanced there (the caller picks the matching circuit gate).

    `frozen` (spatial orbital indices OUTSIDE the active window) restricts the
    amplitude calculation to the active space — the LUCJ operator's orbital count
    must match the SQD circuit's active register, so full-space amplitudes on a
    reduced window would build a gate wider than the circuit."""
    import ffsim

    open_shell = _is_rohf(mf) or int(getattr(mf.mol, "spin", 0)) != 0
    op_cls = ffsim.UCJOpSpinUnbalanced if open_shell else ffsim.UCJOpSpinBalanced
    if open_shell:
        notes.append("open-shell reference: spin-unbalanced LUCJ ansatz")
    try:
        from pyscf import cc
        ccsd = cc.CCSD(mf, frozen=frozen)
        ccsd.kernel()
        return op_cls.from_t_amplitudes(ccsd.t2, t1=ccsd.t1, n_reps=n_reps)
    except Exception as exc:  # noqa: BLE001
        notes.append("CCSD amplitudes unavailable (%s); LUCJ ansatz falls back to MP2" % exc)
    try:
        from pyscf import mp
        mp2 = mp.MP2(mf, frozen=frozen)
        mp2.kernel()
        return op_cls.from_t_amplitudes(mp2.t2, n_reps=n_reps)
    except Exception as exc:  # noqa: BLE001
        notes.append(
            "MP2 amplitudes also unavailable (%s); sampling the Hartree-Fock reference only "
            "(SQD reduces to the HF determinant's CI subspace)" % exc)
    return None


def _sqd_bit_array(data):
    """Extract the measurement BitArray from a SamplerV2/FfsimSampler PUB result DataBin.
    `measure_all` names the register "meas"; fall back to the sole register if renamed."""
    ba = getattr(data, "meas", None)
    if ba is not None:
        return ba
    # DataBin exposes its fields; take the first bit register present.
    for key in getattr(data, "_FIELDS", []) or []:
        val = getattr(data, key, None)
        if val is not None:
            return val
    raise RuntimeError("sampler returned no measurement register")


def _sqd_sample_local(qc, shots: int, seed: int):
    """Sample configurations from the ansatz with ffsim's fast statevector sampler (no QPU)."""
    from ffsim.qiskit import FfsimSampler
    sampler = FfsimSampler(default_shots=shots, seed=seed)
    res = sampler.run([qc]).result()
    return _sqd_bit_array(res[0].data)


def _sqd_sample_ibmq(qc, request: dict, token: str, shots: int, notes: list):
    """Sample configurations on IBM Quantum hardware (SamplerV2). Returns (bit_array, device).

    Mirrors action_ibmq's auth (channel ibm_quantum_platform + instance CRN). Untested on live
    hardware here (the connection probe spends 0 QPU by design); structurally follows the IBM
    SQD tutorial. Any failure propagates as a loud error rather than a silent local fallback.
    """
    from qiskit_ibm_runtime import QiskitRuntimeService, SamplerV2
    from qiskit.transpiler.preset_passmanagers import generate_preset_pass_manager

    instance = str(request.get("ibmq_instance", "")).strip()
    kw: dict[str, Any] = {"channel": "ibm_quantum_platform", "token": token}
    if instance:
        kw["instance"] = instance
    service = QiskitRuntimeService(**kw)
    device = str(request.get("ibmq_backend", "")).strip()
    backend = (
        service.backend(device) if device
        else service.least_busy(operational=True, simulator=False))
    pm = generate_preset_pass_manager(target=backend.target, optimization_level=1)
    isa = pm.run(qc)
    # Job mode: a single batched sampler.run needs no device-reserving Session (which the free
    # IBM Quantum Open plan forbids — API error 1352). SamplerV2(mode=backend) runs on every plan.
    sampler = SamplerV2(mode=backend)
    sampler.options.default_shots = shots
    res = sampler.run([isa]).result()
    name = str(getattr(backend, "name", device) or device)
    notes.append("sampled %d shots on IBM Quantum device %s" % (shots, name))
    return _sqd_bit_array(res[0].data), name


def _cas_determinant_count(norb: int, nelec) -> int:
    """Determinant count of a CAS(nelec, norb) space = C(norb, na) * C(norb, nb).

    The denominator for "how much of the active space did SQD actually sample?" — without it
    a subspace dimension is a number with no scale.
    """
    from math import comb

    try:
        na, nb = (int(nelec[0]), int(nelec[1])) if isinstance(nelec, (tuple, list)) \
            else (int(nelec) // 2, int(nelec) - int(nelec) // 2)
        return int(comb(int(norb), na) * comb(int(norb), nb))
    except Exception:  # noqa: BLE001 — a diagnostic must never fail the job
        return 0


def action_sqd(request: dict[str, Any]) -> dict[str, Any]:
    """SQD — Sample-based Quantum Diagonalization -> JobResult (IBM first-party quantum-chem).

    Samples electronic configurations from a LUCJ ansatz (ffsim) prepared on the Hartree-Fock
    reference, then runs qiskit-addon-sqd's self-consistent configuration recovery + selected-CI
    diagonalization of the molecular Hamiltonian to approximate the ground state. Classical-heavy,
    hardware-light: the Local path samples with ffsim's statevector sampler (no QPU); the IBM
    Quantum target samples with SamplerV2 on hardware.

    Capability-gated + fail-loud (§6): a missing qiskit-addon-sqd / ffsim install RAISES an
    actionable error rather than degrading. The active-space reduction is shared with the VQE/QPE
    qubit Hamiltonian (get_active_space_integrals), so SQD sees the identical active space.
    """
    try:
        import ffsim  # noqa: F401
        from ffsim.qiskit import (
            PrepareHartreeFockJW,
            UCJOpSpinBalancedJW,
            UCJOpSpinUnbalancedJW,
        )
        from qiskit import QuantumCircuit
        from qiskit_addon_sqd.fermion import diagonalize_fermionic_hamiltonian
        import qiskit_addon_sqd
    except ImportError as exc:
        raise RuntimeError(
            "SQD needs qiskit-addon-sqd + ffsim, which are not installed in this sidecar env. "
            "Install them from Config → Engines (or: pip install qiskit-addon-sqd ffsim). "
            "The other quantum methods (VQE/QPE on Local) do not require them."
        ) from exc

    from quchemy.integral.pyscf_bridge import _active_space_integrals

    spec = request.get("spec", {})
    molecule = request["molecule"]
    seed = int(spec.get("rng_seed", 0) or 0) or 42
    params = dict(spec.get("params", {}) or {})
    # Knobs (clamped): sampling shots, LUCJ depth, and the SQD recovery loop sizing.
    shots = max(256, int(params.get("shots", 4096)))
    lucj_reps = max(1, int(params.get("lucj_reps", params.get("ansatz_reps", 1))))
    samples_per_batch = max(10, int(params.get("samples_per_batch", 100)))
    num_batches = max(1, int(params.get("num_batches", 1)))
    max_iterations = max(1, int(params.get("max_recovery_iterations", 5)))
    frozen_core = bool(params.get("frozen_core", False))
    active_orbitals = int(params["active_orbitals"]) if params.get("active_orbitals") else None
    active_electrons = int(params["active_electrons"]) if params.get("active_electrons") else None
    notes: list[str] = []

    t0 = time.perf_counter()
    # Reuse the VQE/QPE common setup for the gas-phase HF reference + recipe validation, then
    # take the SPATIAL active-space integrals SQD needs (chemist-notation h1/eri + core energy).
    mol, mf, _ham, _qop, _info, _mapping = _run_quantum_common(spec, molecule, seed)
    parts = _active_space_integrals(
        mol, mf, frozen_core, active_electrons, active_orbitals)
    h1, eri, ecore = parts["h1"], parts["eri"], parts["ecore"]
    nelec = (parts["n_alpha"], parts["n_beta"])
    norb = int(parts["n_active"])
    num_qubits = 2 * norb

    # LUCJ ansatz (CCSD→MP2→HF-only) prepared on the HF reference; measured in the comp.
    # basis. Orbitals OUTSIDE the active window are frozen out of the amplitude
    # calculation — full-space amplitudes would build a LUCJ gate wider than the
    # active-register circuit (CircuitError, or silently wrong orbital count).
    n_orbs_total = int(mf.mo_coeff.shape[-1])
    frozen = list(range(int(parts["active_start"]))) + list(
        range(int(parts["active_end"]), n_orbs_total))
    ucj = _lucj_op_from_mf(mf, lucj_reps, notes, frozen=frozen or None)
    qc = QuantumCircuit(num_qubits)
    qc.append(PrepareHartreeFockJW(norb, nelec), range(num_qubits))
    if ucj is not None:
        # Gate class must match the operator flavor (_lucj_op_from_mf picks
        # spin-unbalanced for an open-shell/ROHF reference).
        if isinstance(ucj, ffsim.UCJOpSpinUnbalanced):
            qc.append(UCJOpSpinUnbalancedJW(ucj), range(num_qubits))
        else:
            qc.append(UCJOpSpinBalancedJW(ucj), range(num_qubits))
    qc.measure_all()

    # Sample configurations: IBM SamplerV2 if a token rode in (target=ibmq), else ffsim local.
    # Drop the credential the instant it is captured (never linger in a result/provenance copy).
    token = str(request.get("ibmq_token", "")).strip()
    request.pop("ibmq_token", None)
    device_name = ""
    if token:
        bit_array, device_name = _sqd_sample_ibmq(qc, request, token, shots, notes)
        engine = "qiskit-ibm-runtime (SQD/SamplerV2)"
    else:
        bit_array = _sqd_sample_local(qc, shots, seed)
        engine = "qiskit-addon-sqd (local ffsim sampler)"

    # Self-consistent configuration recovery + selected-CI diagonalization. The solver energy is
    # the active-space ELECTRONIC energy (h1/eri only); add the core constant for the total.
    # Record what the recovery loop actually did. SQD diagonalizes a SELECTED subspace of the
    # CAS, so its energy is a variational upper bound over however many determinants the
    # sampling happened to find — and none of that reached the result: `converged` was set
    # unconditionally, iterations were 0 and energy_history empty. The library hands the
    # subspace dimension and per-iteration energy to a callback for free.
    sqd_history: list[float] = []
    sqd_dims: list[int] = []

    def _sqd_callback(results) -> None:
        # The library passes a LIST of SCIResult objects — one per batch — after every
        # recovery iteration. (Its docstring calls them "(energy, sci_state, occupancies)
        # triplets", but they are dataclasses, not tuples; subscripting them raised and the
        # diagnostic silently produced nothing.) Take the best batch, and read the subspace
        # size off the SCI state's determinant strings: amplitudes is
        # (len(ci_strs_a), len(ci_strs_b)), so the diagonalized space is their product.
        try:
            best = min(results, key=lambda r: float(r.energy))
        except Exception:  # noqa: BLE001 — a diagnostic must never fail the job
            return
        try:
            sqd_history.append(float(best.energy) + float(ecore))
        except Exception:  # noqa: BLE001
            pass
        # Kept separate: a failure reading the subspace size must not also cost the energy
        # history (they diverged exactly that way — 2 iterations recorded, 0 dimensions).
        try:
            state = best.sci_state
            # NOTE: ci_strs_a/ci_strs_b are numpy arrays. `arr or []` raises
            # "truth value of an array ... is ambiguous", so never use `or` to default them
            # — that swallowed the dimension on every run with more than one determinant
            # (and only appeared to work in the 1-determinant collapse case).
            n_a = int(len(state.ci_strs_a))
            n_b = int(len(state.ci_strs_b))
            if n_a > 0 and n_b > 0:
                sqd_dims.append(n_a * n_b)
        except Exception:  # noqa: BLE001 — a diagnostic must never fail the job
            pass

    sci = diagonalize_fermionic_hamiltonian(
        h1, eri, bit_array, samples_per_batch=samples_per_batch, norb=norb, nelec=nelec,
        num_batches=num_batches, max_iterations=max_iterations, seed=seed,
        callback=_sqd_callback)
    total_energy = float(sci.energy) + float(ecore)
    wall = time.perf_counter() - t0

    result = rb.blank_result()
    _fill_overview(result, spec, molecule, seed=seed)
    result["method"] = "SQD"
    result["engine"] = engine
    # qiskit-addon-sqd does not define __version__, so getattr always fell through to
    # "unknown" — a provenance hole in the method whose reproducibility depends most on the
    # library revision. importlib.metadata reads it from the installed distribution.
    try:
        from importlib.metadata import version as _dist_version

        result["engine_version"] = str(_dist_version("qiskit-addon-sqd"))
    except Exception:  # noqa: BLE001
        result["engine_version"] = str(getattr(qiskit_addon_sqd, "__version__", "unknown"))
    result["wall_clock_s"] = float(wall)
    # Circuit + run metrics live in the `quantum` block (Analyze Overview reads it); the SQD
    # sampling knobs + any IBM device ride along as extra keys the validator ignores.
    qblock = rb.quantum_block(
        num_qubits=num_qubits, mapping="jordan_wigner", algorithm="SQD",
        ansatz="LUCJ" if ucj is not None else "Hartree-Fock",
        circuit_depth=int(qc.decompose().depth()),
        iterations=len(sqd_history), energy_history=sqd_history)
    qblock["shots"] = shots
    if sqd_dims:
        qblock["sci_subspace_dim"] = int(sqd_dims[-1])
    qblock["samples_per_batch"] = samples_per_batch
    qblock["num_batches"] = num_batches
    qblock["recovery_iterations"] = max_iterations
    if device_name:
        qblock["ibmq_backend"] = device_name
    # The GENUINELY sampled configuration histogram (ffsim locally, the QPU on IBM) that SQD
    # diagonalized over — source "sampled", Qiskit's little-endian bitstrings (qubit 0 rightmost).
    get_counts = getattr(bit_array, "get_counts", None)
    if callable(get_counts):
        qblock["measurements"] = rb.measurement_block(
            counts={str(b): int(c) for b, c in get_counts().items()},
            num_qubits=num_qubits, shots=shots, source="sampled",
            register="computational basis (Qiskit little-endian)",
        )
    result["quantum"] = qblock
    # HF orbitals as the reference picture for the Orbitals tab (matches the local VQE/QPE).
    _fill_scf(result, mol, mf, False)
    result["total_energy"] = float(total_energy)
    result["converged"] = True
    # SQD diagonalizes a SELECTED subspace of the active space, so its energy is a
    # variational upper bound over however many determinants the sampling found — not a
    # converged diagonalization of the CAS. That was reported as a bare converged=true with
    # no subspace diagnostic at all. Two things now ride out: the size of the subspace
    # against the full CAS, and a loud warning when the sampling collapsed.
    _full_dim = _cas_determinant_count(norb, nelec)
    _dim = int(sqd_dims[-1]) if sqd_dims else 0
    if _dim > 0 and _full_dim > 0:
        _frac = 100.0 * _dim / _full_dim
        _warn(result,
              "SQD diagonalized a SELECTED subspace of %d determinants out of the active "
              "space's %d (%.1f%%). The energy is a variational upper bound over that "
              "subspace, not a converged CAS diagonalization — a small fraction means a "
              "correspondingly incomplete correlation energy. Raise shots, "
              "samples_per_batch or max_recovery_iterations to enlarge it."
              % (_dim, _full_dim, _frac))
    # The pathological case: the sampled histogram collapsed onto a single configuration, so
    # the "diagonalization" was of a 1x1 matrix and the answer is the reference determinant's
    # energy — Hartree-Fock, returned under the name SQD with converged=true.
    _unique = int(((qblock.get("measurements") or {}).get("total_unique") or 0))
    if _dim == 1 or _unique == 1:
        result["converged"] = False
        _warn(result,
              "SQD sampling collapsed to a SINGLE configuration (the Hartree-Fock "
              "determinant), so no correlation was recovered at all — this energy is the "
              "mean-field reference, not a correlated result. Raise shots and "
              "samples_per_batch, or widen the active space.")
    result["success"] = True
    for note in notes:
        _warn(result, str(note))
    return result


def action_parse(request: dict[str, Any]) -> dict[str, Any]:
    """Parse an external-engine output file via cclib -> JobResult (overhaul §3, §13.4)."""
    import cclib

    parse_path = request.get("parse_path", "")
    if not parse_path or not os.path.isfile(parse_path):
        raise FileNotFoundError(f"parse_path does not exist: {parse_path!r}")

    data = cclib.io.ccread(parse_path)
    # cclib does NOT raise on an unparseable file (empty / binary / non-chemistry text):
    # depending on version it returns None or a bare ccData with no attributes set. Either
    # way `jobresult_from_cclib` would otherwise hand back a success=true result with no
    # data and no warning — a silent import of "nothing". Fail loud instead so the Godot
    # side surfaces a real error the user can act on.
    if not _cclib_has_data(data):
        raise ValueError(
            "cclib could not extract any chemistry from %r — the file is empty, not a "
            "supported engine output, or truncated before any parseable section "
            "(no geometry, energies, or orbitals were found)." % parse_path
        )
    return jobresult_from_cclib(data, request.get("spec", {}))


def _nonempty(value: Any) -> bool:
    """True when a cclib array-like attribute actually holds data. Guards the trap that
    this cclib version sets `atomcoords` to a shape-(1, 0, 3) array on a garbage file —
    `len(atomcoords) == 1` (one EMPTY frame), so a bare `len() > 0` lies. We flatten via
    numpy size so an all-empty nesting reads as no data."""
    if value is None:
        return False
    try:
        import numpy as np

        return int(np.asarray(value, dtype=object).size) > 0
    except Exception:  # noqa: BLE001 — non-array (dict/scalar): fall back to truthiness
        try:
            return len(value) > 0
        except TypeError:
            return bool(value)


def _cclib_has_data(data: Any) -> bool:
    """True when a cclib parse carries at least one NON-EMPTY recognizable chemistry
    attribute (geometry / energies / orbitals / vibrations / excited states / charges).

    cclib signals an unparseable file (empty / binary / non-chemistry text) by returning
    None or a bare ccData whose array attributes are all empty (rather than raising), so
    this is the explicit "did we actually parse anything?" check the `parse` action gates
    on — checking real content, not mere attribute presence (this cclib pre-creates empty
    `atomnos`/`atomcoords` and a `natom = 0` even for total garbage)."""
    if data is None:
        return False
    # natom is the one scalar signal — a real molecule has at least one atom.
    natom = getattr(data, "natom", None)
    if isinstance(natom, int) and natom > 0:
        return True
    for attr in (
        "atomnos", "scfenergies", "moenergies", "vibfreqs",
        "etenergies", "atomcharges", "moments",
    ):
        if _nonempty(getattr(data, attr, None)):
            return True
    # atomcoords is checked last and via content: a garbage parse leaves a
    # shape-(1, 0, 3) array (one empty frame) that _nonempty correctly rejects.
    return _nonempty(getattr(data, "atomcoords", None))


def action_parse_trajectory(request: dict[str, Any]) -> dict[str, Any]:
    """Parse a multi-frame .xyz trajectory file -> JobResult (overhaul §3).

    The complement to `action_parse` (cclib): a concatenated-XYZ trajectory (xmol/MD)
    becomes a result whose `trajectory`/`trajectory_kind` ("xyz") the Analyze MD tab
    scrubs. Per-frame energies come from the comment lines (assumed Hartree — see
    `parse_xyz_trajectory`). cclib already owns geometry-optimization trajectories
    coming through `action_parse`, so this path is XYZ-only; any other extension is
    rejected loudly (it would never be a multi-frame XYZ)."""
    from quchemy.cheminformatics import parse_xyz_trajectory

    parse_path = request.get("parse_path", "")
    if not parse_path or not os.path.isfile(parse_path):
        raise FileNotFoundError(f"parse_path does not exist: {parse_path!r}")

    ext = os.path.splitext(parse_path)[1].lower()
    if ext != ".xyz":
        raise ValueError(
            f"parse_trajectory only reads multi-frame .xyz files (got {ext!r}); "
            "geometry-optimization trajectories from engine output come through the "
            "'parse' action (cclib)."
        )

    traj = parse_xyz_trajectory(parse_path)

    result = rb.blank_result()
    result["success"] = True
    result["energy_unit"] = rb.ENERGY_UNIT_HARTREE
    result["engine"] = "imported"
    result["method"] = "imported"
    result["host"] = rb.host()
    result["library_versions"] = rb.library_versions()
    symbols = traj["atom_symbols"]
    result["atom_symbols"] = list(symbols)
    result["formula"] = rb.formula_from_atoms([{"element": s} for s in symbols])
    result["final_coords"] = traj["final_coords"]
    result["trajectory"] = traj["trajectory"]
    result["trajectory_kind"] = traj["trajectory_kind"]
    # Honest provenance: the energy-unit assumption + any per-format degradation note.
    for w in traj.get("warnings", []):
        _warn(result, str(w))
    return result


# ─────────────────────────── cclib mapping ───────────────────────────

# cclib returns energies in eV; convert to Hartree for the JobResult contract.
_EV_PER_HARTREE = 27.211386245988


def _ev_to_hartree(value_ev: float) -> float:
    """Convert an energy from eV (cclib convention) to Hartree."""
    try:
        from cclib.parser.utils import convertor

        return float(convertor(value_ev, "eV", "hartree"))
    except Exception:
        return float(value_ev) / _EV_PER_HARTREE


def _cclib_converged(data: Any) -> bool | None:
    """Best-available convergence verdict from a parsed cclib `ccData`.

    Checked in order of trustworthiness; returns None when the parse carries no
    signal at all (the caller then reports converged=false WITH a warning):

    1. `optdone` — present only for geometry optimizations; cclib sets it True/
       a non-empty index list exactly when the optimization converged.
    2. `metadata["success"]` — the engine's own "terminated normally" stamp
       (ORCA / Gaussian / Psi4 abort on an unconverged SCF, so a normal
       termination of a single point implies SCF convergence).
    3. `scfvalues` vs `scftargets` — final SCF cycle errors against the engine's
       own thresholds. Engines declare convergence on engine-specific criterion
       combinations, so ALL-met is taken as converged and anything else falls
       through to "no signal" rather than asserting failure.
    """
    optdone = getattr(data, "optdone", None)
    if optdone is not None:
        if isinstance(optdone, (list, tuple)):
            return len(optdone) > 0
        return bool(optdone)

    metadata = getattr(data, "metadata", None)
    if isinstance(metadata, dict) and isinstance(metadata.get("success"), bool):
        return bool(metadata["success"])

    scfvalues = getattr(data, "scfvalues", None)
    scftargets = getattr(data, "scftargets", None)
    try:
        if (scfvalues is not None and len(scfvalues) > 0
                and scftargets is not None and len(scftargets) > 0):
            import numpy as np

            last_cycle = np.abs(np.asarray(scfvalues[-1][-1], dtype=float).ravel())
            targets = np.asarray(scftargets[-1], dtype=float).ravel()
            if last_cycle.size and last_cycle.size == targets.size:
                if bool(np.all(last_cycle <= targets)):
                    return True
    except Exception:  # noqa: BLE001 — malformed arrays = no signal, not a verdict
        return None
    return None


def jobresult_from_cclib(data: Any, spec: dict[str, Any] | None = None) -> dict[str, Any]:
    """Map a parsed cclib `ccData` object into the JobResult schema.

    Only fields cclib actually parsed are filled; tab-specific arrays stay empty
    otherwise. Energies coming from cclib in eV are converted to Hartree.
    """
    import cclib
    import numpy as np

    spec = spec or {}
    result = rb.blank_result()
    result["energy_unit"] = rb.ENERGY_UNIT_HARTREE
    result["engine"] = "external"
    result["engine_version"] = str(getattr(cclib, "__version__", ""))
    # Honest provenance: name the originating engine when cclib identified it
    # (metadata "package" / "package_version", e.g. ORCA 5.0.2) instead of the
    # anonymous "external". cclib's own version stays in library_versions.
    metadata = getattr(data, "metadata", None)
    if isinstance(metadata, dict) and metadata.get("package"):
        result["engine"] = f"external:{metadata['package']}"
        if metadata.get("package_version"):
            result["engine_version"] = str(metadata["package_version"])
    result["method"] = str(spec.get("method", ""))
    result["basis"] = str(spec.get("basis_set", ""))
    result["functional"] = str(spec.get("functional", ""))
    # The level of theory printed IN THE FILE, when the submitting spec did not name one.
    # An import has no Method screen behind it, so reading these from the spec alone left an
    # imported ORCA MP2/STO-3G job recording method "" and basis "" while cclib had both in
    # metadata — provenance thrown away for a result whose methods section depends on it.
    # The spec still wins when it says something: the user's declaration beats the parse.
    if isinstance(metadata, dict):
        if not result["method"]:
            methods = metadata.get("methods") or []
            if len(methods) > 0:
                # cclib lists them in ascending order of theory (["HF", "MP2"]) — the last
                # is the one the file's final energy belongs to.
                result["method"] = str(methods[-1])
        if not result["basis"] and metadata.get("basis_set"):
            result["basis"] = str(metadata["basis_set"])
        if not result["functional"] and metadata.get("functional"):
            result["functional"] = str(metadata["functional"])
    result["host"] = rb.host()
    result["library_versions"] = rb.library_versions()

    # Charge / multiplicity.
    if getattr(data, "charge", None) is not None:
        result["charge"] = int(data.charge)
    if getattr(data, "mult", None) is not None:
        result["multiplicity"] = int(data.mult)

    # Final geometry (last atomcoords frame), formula from atomnos.
    atomnos = getattr(data, "atomnos", None)
    atomcoords = getattr(data, "atomcoords", None)
    if atomcoords is not None and len(atomcoords) > 0:
        last = atomcoords[-1]
        result["final_coords"] = [rb.vec3(c[0], c[1], c[2]) for c in last]
    if atomnos is not None:
        symbols = [_element_symbol(int(z)) for z in atomnos]
        result["atom_symbols"] = symbols
        result["formula"] = rb.formula_from_atoms([{"element": s} for s in symbols])

    # SCF energy (cclib `scfenergies` are in eV).
    scfenergies = getattr(data, "scfenergies", None)
    if scfenergies is not None and len(scfenergies) > 0:
        scf_ha = _ev_to_hartree(float(scfenergies[-1]))
        result["scf_energy"] = scf_ha
        result["total_energy"] = scf_ha

    # ...but for a CORRELATED calculation the SCF energy is not the total energy. cclib
    # parses the post-HF totals into `mpenergies` (MP2/MP3/MP4, one row per step, columns
    # ascending in order) and `ccenergies` (CCSD, CCSD(T)); both were being discarded, so an
    # imported MP2 or coupled-cluster job reported its HARTREE-FOCK energy as the total with
    # no warning. On the repo's own orca5_water_mp2.out fixture that is -74.9635741 against
    # the file's own FINAL SINGLE POINT ENERGY of -74.9993738 — 22.46 kcal/mol, which is
    # larger than most of the effects people run MP2 to capture.
    #
    # Coupled cluster wins over MP when both are present: a CCSD job's output carries the MP2
    # energy too (it is the starting guess), and the CC total is the one the file's own
    # summary line reports.
    corr_ha: float | None = None
    corr_label = ""
    mpenergies = getattr(data, "mpenergies", None)
    if _nonempty(mpenergies):
        # Last step, highest order computed.
        corr_ha = _ev_to_hartree(float(np.asarray(mpenergies)[-1][-1]))
        corr_label = "MP"
    ccenergies = getattr(data, "ccenergies", None)
    if _nonempty(ccenergies):
        corr_ha = _ev_to_hartree(float(np.asarray(ccenergies).ravel()[-1]))
        corr_label = "coupled-cluster"
    if corr_ha is not None:
        result["total_energy"] = corr_ha
        if result["scf_energy"] != 0.0:
            result["correlation_energy"] = corr_ha - float(result["scf_energy"])
        _warn(result,
              "Imported a correlated (%s) calculation: total_energy is the correlated total "
              "energy from the file, and scf_energy is its Hartree-Fock reference. The "
              "correlation energy between them is %.6f Hartree (%.2f kcal/mol)."
              % (corr_label, result["correlation_energy"],
                 result["correlation_energy"] * 627.5094740631))
    # Honest convergence: previously the mere presence of scfenergies set
    # converged=True — an aborted optimization or unconverged SCF still has
    # energies in the file. Use cclib's actual signals; with no signal, stay
    # False and SAY SO instead of guessing.
    converged = _cclib_converged(data)
    if converged is None:
        result["converged"] = False
        _warn(result,
              "convergence could not be determined from the output file "
              "(cclib parsed no optdone / metadata.success / scfvalues "
              "signal) — reporting converged=false")
    else:
        result["converged"] = bool(converged)
        if not converged:
            _warn(result, "the output file reports an UNCONVERGED calculation")

    # Optimization steps (energy per geometry step).
    if scfenergies is not None and len(scfenergies) > 1:
        result["opt_steps"] = [
            rb.opt_step(_ev_to_hartree(float(e))) for e in scfenergies
        ]

    # Optimization TRAJECTORY (GaussView/Chemcraft parity): every intermediate
    # geometry, not just the converged one, so the MD/Trajectory tab can scrub the
    # whole path. cclib `atomcoords` is [nsteps][natom][3] in Å (no conversion).
    # The "time" axis is a STEP INDEX, not fs — the tab labels it honestly. Energy
    # comes from scfenergies[i] (eV→Ha) per frame, aligned on the common prefix.
    # Single-frame parses (a single point) leave trajectory empty / kind "".
    if atomcoords is not None and len(atomcoords) > 1:
        # Real Gaussian/ORCA opt logs routinely emit N geometries with N±1 energies
        # (a post-HF correction step, a dropped initial SCF, a trailing freq point).
        # Align the COMMON PREFIX rather than all-or-nothing: frames up to the shorter
        # of the two series get their real per-step energy (eV→Ha); any remainder gets
        # 0.0 and a warning that those frames carry no energy. Only the perfectly
        # aligned case is silent. With no scfenergies at all, every frame is 0.0 (the
        # genuine no-energy-data case — left silent here; opt_steps already absent).
        energies_ha: list[float] = []
        if scfenergies is not None and len(scfenergies) > 0:
            aligned = min(len(scfenergies), len(atomcoords))
            energies_ha = [_ev_to_hartree(float(e)) for e in scfenergies[:aligned]]
            if len(scfenergies) != len(atomcoords):
                unfilled = len(atomcoords) - aligned
                if unfilled > 0:
                    _warn(
                        result,
                        f"{unfilled} trajectory frame(s) beyond the aligned "
                        f"prefix carry no energy ({len(scfenergies)} energies vs "
                        f"{len(atomcoords)} geometries) — shown as 0.0 Hartree",
                    )
        frames: list[dict[str, Any]] = []
        for i, frame_coords in enumerate(atomcoords):
            coords = [rb.vec3(c[0], c[1], c[2]) for c in frame_coords]
            energy = energies_ha[i] if i < len(energies_ha) else 0.0
            frames.append(rb.trajectory_frame(float(i), coords, energy, 0.0))
        result["trajectory"] = frames
        result["trajectory_kind"] = "optimization"

    # Orbital energies (cclib `moenergies` in eV, per spin). An unrestricted output
    # carries TWO spin channels — render both with spin tags and occ 1.0/0.0, exactly
    # like _fill_scf; collapsing to an alpha-only occ-2.0 ladder would show a
    # closed-shell picture for an open-shell log (silent-failure class).
    moenergies = getattr(data, "moenergies", None)
    homos = getattr(data, "homos", None)
    # Orbital symmetry labels (a1, b2, eg …) when the package printed them — the Orbitals
    # tab shows them beside each level, and rb.orbitals_from_mo takes them directly.
    mosyms = getattr(data, "mosyms", None)

    def _syms(channel: int, count: int) -> list[str] | None:
        if not _nonempty(mosyms) or channel >= len(mosyms):
            return None
        labels = [str(x) for x in mosyms[channel]]
        return labels if len(labels) == count else None

    if moenergies is not None and len(moenergies) > 0:
        unrestricted = len(moenergies) > 1
        if unrestricted:
            mo_ha_a = [_ev_to_hartree(float(e)) for e in moenergies[0]]
            mo_ha_b = [_ev_to_hartree(float(e)) for e in moenergies[1]]
            homo_a = int(homos[0]) if homos is not None and len(homos) > 0 else -1
            homo_b = int(homos[1]) if homos is not None and len(homos) > 1 else -1
            occ_a = [1.0 if i <= homo_a else 0.0 for i in range(len(mo_ha_a))]
            occ_b = [1.0 if i <= homo_b else 0.0 for i in range(len(mo_ha_b))]
            orbs_a, _h, _l = rb.orbitals_from_mo(mo_ha_a, occ_a, _syms(0, len(mo_ha_a)), spin="a")
            orbs_b, _hb, _lb = rb.orbitals_from_mo(mo_ha_b, occ_b, _syms(1, len(mo_ha_b)), spin="b")
            result["orbitals"] = orbs_a + orbs_b
            # Alpha frontier, matching the _fill_scf convention (the Orbitals tab
            # resolves per-channel frontiers from occupations when spin tags exist).
            result["homo_index"] = homo_a
            result["lumo_index"] = (
                homo_a + 1 if 0 <= homo_a + 1 < len(orbs_a) else -1
            )
        else:
            mo_ha = [_ev_to_hartree(float(e)) for e in moenergies[0]]
            homo_idx = int(homos[0]) if homos is not None and len(homos) > 0 else -1
            occ = [2.0 if i <= homo_idx else 0.0 for i in range(len(mo_ha))]
            orbs, homo, lumo = rb.orbitals_from_mo(mo_ha, occ, _syms(0, len(mo_ha)))
            result["orbitals"] = orbs
            result["homo_index"] = homo if homo_idx < 0 else homo_idx
            result["lumo_index"] = (
                result["homo_index"] + 1 if result["homo_index"] + 1 < len(orbs) else -1
            )

    # Vibrations (cm^-1) + IR intensities.
    vibfreqs = getattr(data, "vibfreqs", None)
    if vibfreqs is not None and len(vibfreqs) > 0:
        vibirs = getattr(data, "vibirs", None)
        vibramans = getattr(data, "vibramans", None)
        # Cartesian displacement vectors per mode (cclib `vibdisps`, [nmodes][natom][3] in
        # delta-Angstrom, the same convention rb.vibration_mode wants). Without them an
        # imported frequency job lists its modes but the IR/Raman tab cannot animate any of
        # them and draws no displacement arrows — the file had the vectors all along.
        vibdisps = getattr(data, "vibdisps", None)
        modes = []
        for i, wn in enumerate(vibfreqs):
            ir = float(vibirs[i]) if vibirs is not None and i < len(vibirs) else 0.0
            rm = float(vibramans[i]) if vibramans is not None and i < len(vibramans) else 0.0
            disp = None
            if vibdisps is not None and i < len(vibdisps):
                disp = [rb.vec3(float(v[0]), float(v[1]), float(v[2])) for v in vibdisps[i]]
            modes.append(rb.vibration_mode(float(wn), ir, rm, disp))
        result["vibrations"] = modes

    # Excited states (TD-DFT): cclib `etenergies` in cm^-1 -> eV + nm.
    etenergies = getattr(data, "etenergies", None)
    if etenergies is not None and len(etenergies) > 0:
        etoscs = getattr(data, "etoscs", None)
        etsyms = getattr(data, "etsyms", None)
        # Rotatory strengths — the per-state ECD intensity. Dropping them meant an imported
        # TD-DFT job with a full CD spectrum in the file rendered as UV-Vis only.
        etrotats = getattr(data, "etrotats", None)
        states = []
        for i, e_cm in enumerate(etenergies):
            e_ev = float(e_cm) / 8065.54429  # cm^-1 -> eV
            wl_nm = (1.0e7 / float(e_cm)) if float(e_cm) != 0 else 0.0
            osc = float(etoscs[i]) if etoscs is not None and i < len(etoscs) else 0.0
            sym = str(etsyms[i]) if etsyms is not None and i < len(etsyms) else ""
            rot = float(etrotats[i]) if etrotats is not None and i < len(etrotats) else 0.0
            states.append(rb.excited_state(e_ev, wl_nm, osc, sym, rotatory_strength=rot))
        result["excited_states"] = states

    # Atomic charges (Mulliken if available; Löwdin alongside when the engine printed it).
    atomcharges = getattr(data, "atomcharges", None)
    if isinstance(atomcharges, dict) and "mulliken" in atomcharges:
        result["charges"] = [float(c) for c in atomcharges["mulliken"]]
    if isinstance(atomcharges, dict) and "lowdin" in atomcharges:
        result["charges_lowdin"] = [float(c) for c in atomcharges["lowdin"]]

    # Dipole moment (Debye).
    moments = getattr(data, "moments", None)
    if moments is not None and len(moments) > 1:
        dip = moments[1]
        if len(dip) >= 3:
            result["dipole"] = rb.vec3(float(dip[0]), float(dip[1]), float(dip[2]))

    # Thermochemistry. cclib reports these already in Hartree (entropy in Hartree/K), so no
    # conversion — unlike its eV energies. A Gaussian/ORCA `freq` job carries every one of
    # them and the Analyze Thermochemistry section was rendering empty for imports, which is
    # the "empty tab, unexplained" pattern with the numbers sitting in the file.
    enthalpy = getattr(data, "enthalpy", None)
    freeenergy = getattr(data, "freeenergy", None)
    entropy = getattr(data, "entropy", None)
    zpve = getattr(data, "zpve", None)
    if enthalpy is not None or freeenergy is not None:
        temp_k = float(getattr(data, "temperature", None) or 298.15)
        h_ha = float(enthalpy) if enthalpy is not None else 0.0
        # U = H - kT for an ideal gas; cclib parses no internal energy of its own.
        u_ha = (h_ha - _KB_HARTREE_PER_K * temp_k) if enthalpy is not None else 0.0
        result["thermochemistry"] = rb.thermochemistry(
            temperature_k=temp_k,
            electronic_energy=float(result["total_energy"]),
            zpe=float(zpve) if zpve is not None else 0.0,
            internal_energy=u_ha,
            enthalpy=h_ha,
            gibbs=float(freeenergy) if freeenergy is not None else 0.0,
            entropy=float(entropy) if entropy is not None else 0.0,
            # cclib parses no heat capacity from any package — 0.0 means "not in the file",
            # and the warning below says so rather than letting a bare 0 read as a value.
            heat_capacity_cv=0.0,
        )
        _warn(result,
              "Thermochemistry was imported from the output file (T = %.2f K). Heat capacity "
              "Cv is 0 because cclib does not parse it, the internal energy is derived as "
              "H - kT, and no quasi-RRHO correction is available for an imported result."
              % temp_k)

    # Static polarizability tensor (cclib `polarizabilities`: a list of 3x3 arrays in atomic
    # units — the same units and shape the contract's `polarizability` wants).
    polarizabilities = getattr(data, "polarizabilities", None)
    if _nonempty(polarizabilities):
        tensor = np.asarray(polarizabilities[-1], dtype=float)
        if tensor.shape == (3, 3):
            result["polarizability"] = [[float(x) for x in row] for row in tensor]

    # NMR shielding tensors (cclib `nmrtensors`: {atom_index: {component: 3x3}} in ppm).
    # The isotropic shielding is the trace/3 of the total tensor and the anisotropy is
    # sigma_33 - (sigma_11 + sigma_22)/2 over the eigenvalues of its symmetric part — the
    # standard Haeberlen-ordered definition, computed here because cclib hands over the
    # tensor, not the scalars.
    nmrtensors = getattr(data, "nmrtensors", None)
    if isinstance(nmrtensors, dict) and nmrtensors:
        symbols_for_nmr = result.get("atom_symbols") or []
        shieldings = []
        for atom_index in sorted(nmrtensors.keys()):
            block = nmrtensors[atom_index]
            total = block.get("total") if isinstance(block, dict) else None
            if total is None:
                continue
            t = np.asarray(total, dtype=float)
            if t.shape != (3, 3):
                continue
            iso = float(np.trace(t)) / 3.0
            eig = np.sort(np.linalg.eigvalsh(0.5 * (t + t.T)))
            aniso = float(eig[2] - 0.5 * (eig[0] + eig[1]))
            idx = int(atom_index)
            sym = str(symbols_for_nmr[idx]) if 0 <= idx < len(symbols_for_nmr) else ""
            shieldings.append(rb.nmr_shielding(idx, iso, aniso, sym))
        if shieldings:
            result["nmr_shieldings"] = shieldings
            result["calc_type"] = result["calc_type"] or "nmr"

    # Relaxed/rigid PES scan (cclib `scanenergies` in eV alongside `scanparm`, the scanned
    # parameter values — one tuple per scanned variable).
    scanenergies = getattr(data, "scanenergies", None)
    if _nonempty(scanenergies):
        scanparm = getattr(data, "scanparm", None)
        coords_axis: list[float] = []
        if _nonempty(scanparm):
            try:
                coords_axis = [float(v) for v in scanparm[0]]
            except (TypeError, ValueError):
                coords_axis = []
        points = []
        for i, e in enumerate(scanenergies):
            coordinate = coords_axis[i] if i < len(coords_axis) else float(i)
            points.append(rb.scan_point(coordinate, _ev_to_hartree(float(e))))
        result["scan_points"] = points
        if not coords_axis:
            _warn(result,
                  "The imported scan carries energies but no scanned-parameter values — the "
                  "scan axis is the STEP INDEX, not the coordinate.")
        else:
            names = getattr(data, "scannames", None)
            if _nonempty(names):
                _warn(result, "Imported a PES scan over %s." % str(names[0]))

    # Per-atom spin densities (open-shell outputs; cclib `atomspins` is keyed by scheme).
    atomspins = getattr(data, "atomspins", None)
    if isinstance(atomspins, dict) and atomspins:
        for scheme in ("mulliken", "lowdin"):
            if scheme in atomspins and _nonempty(atomspins[scheme]):
                result["spin_populations"] = [float(x) for x in atomspins[scheme]]
                break

    # Rotational constants (cclib `rotconsts`, GHz) have no home in the result contract, so
    # they are reported in the warnings channel rather than dropped.
    rotconsts = getattr(data, "rotconsts", None)
    if _nonempty(rotconsts):
        try:
            abc = np.asarray(rotconsts, dtype=float).ravel()[-3:]
            _warn(result, "Rotational constants from the file: %s GHz."
                  % ", ".join("%.5f" % float(v) for v in abc))
        except (TypeError, ValueError):
            pass

    # The catch-all. Everything above maps a specific cclib attribute; anything else the
    # parser found is data the user's file contained and this import does NOT show. Naming it
    # is the difference between a feature gap and a silent one — the whole class of finding
    # this block exists to close.
    _warn_unmapped_cclib_attributes(data, result)

    result["success"] = True
    return result


## Boltzmann constant in Hartree/K — for the ideal-gas U = H - kT of an imported enthalpy.
_KB_HARTREE_PER_K: float = 3.166811563e-6

## cclib attributes `jobresult_from_cclib` reads, or deliberately does not need. Anything a
## parse produces outside this set is reported to the user instead of vanishing.
_CCLIB_MAPPED: frozenset[str] = frozenset({
    # consumed above
    "metadata", "charge", "mult", "atomnos", "atomcoords", "scfenergies", "mpenergies",
    "ccenergies", "optdone", "optstatus", "scfvalues", "scftargets", "moenergies", "homos",
    "vibfreqs", "vibirs", "vibramans", "vibdisps", "mosyms", "etenergies", "etoscs", "etsyms",
    "etrotats", "atomcharges", "moments", "enthalpy", "freeenergy", "entropy", "zpve",
    "temperature", "polarizabilities", "nmrtensors", "scanenergies", "scanparm", "scannames",
    "atomspins", "rotconsts",
    # structural / bookkeeping attributes with nothing to display
    "natom", "atommasses", "nbasis", "nmo", "coreelectrons", "aonames", "atombasis",
    "gbasis", "aooverlaps", "mocoeffs", "nelectrons", "pressure", "scancoords",
})


def _warn_unmapped_cclib_attributes(data: Any, result: dict[str, Any]) -> None:
    """Name every attribute cclib parsed that this import does not carry into the result."""
    parsed = [a for a in getattr(data, "_attrlist", []) if hasattr(data, a)]
    unmapped = sorted(
        a for a in parsed
        if a not in _CCLIB_MAPPED and _nonempty(getattr(data, a, None))
    )
    if not unmapped:
        return
    _warn(result,
          "The output file also contained %s, which Qemica's importer does not read — "
          "%s not shown anywhere in Analyze."
          % (", ".join(unmapped), "they are" if len(unmapped) > 1 else "it is"))


# Z -> element symbol, complete through Og (Z=118) — the table used to stop at Xe,
# so Cs+, lanthanides, Pt/Au complexes etc. parsed into formula "X". Falls back to
# "X" only for out-of-range Z so formula building never crashes.
_PERIODIC = (
    "X H He Li Be B C N O F Ne Na Mg Al Si P S Cl Ar K Ca Sc Ti V Cr Mn Fe Co Ni "
    "Cu Zn Ga Ge As Se Br Kr Rb Sr Y Zr Nb Mo Tc Ru Rh Pd Ag Cd In Sn Sb Te I Xe "
    "Cs Ba La Ce Pr Nd Pm Sm Eu Gd Tb Dy Ho Er Tm Yb Lu Hf Ta W Re Os Ir Pt Au Hg "
    "Tl Pb Bi Po At Rn Fr Ra Ac Th Pa U Np Pu Am Cm Bk Cf Es Fm Md No Lr Rf Db Sg "
    "Bh Hs Mt Ds Rg Cn Nh Fl Mc Lv Ts Og"
).split()


def _element_symbol(z: int) -> str:
    return _PERIODIC[z] if 0 < z < len(_PERIODIC) else "X"


def action_custom_script(request: dict[str, Any]) -> dict[str, Any]:
    """Run the user's hand-edited Script-preview text verbatim -> JobResult.

    The Method screen's input preview is editable; a dirty preview submits its text as
    spec.params.custom_script and this action executes it in the sidecar's own
    interpreter/venv — the same environment the generated recipe would use; the user is
    running their own code on their own machine by explicit request. The namespace is
    seeded with:

      GEOMETRY               pyscf atom string of the submitted molecule
      CHARGE / MULTIPLICITY  from the molecule
      OUTPUT_PATH            where run() writes the JobResult
      result                 an empty dict the script may fill with JobResult fields

    After exec, a filled `result` dict wins; otherwise a finite `energy` variable is
    harvested as total_energy (the generated previews leave one behind). A raising
    script fails the job LOUD (run()'s error path carries the exception text); prints
    land in the engine log (Analyze → Raw).
    """
    import math

    spec = request.get("spec", {})
    molecule = request["molecule"]
    params = spec.get("params", {})
    if not isinstance(params, dict):
        params = {}
    script = str(params.get("custom_script", ""))
    if not script.strip():
        raise ValueError("custom_script was empty — nothing to run.")

    result = rb.blank_result()
    result["method"] = str(spec.get("method", ""))
    result["basis"] = str(spec.get("basis_set", ""))
    result["calc_type"] = str(spec.get("calc_type", "energy"))
    _emit_phase("custom script")

    ns: dict[str, Any] = {
        "__name__": "__qemica_custom_script__",
        "GEOMETRY": _atom_string(molecule),
        "CHARGE": int(molecule.get("charge", 0)),
        "MULTIPLICITY": int(molecule.get("multiplicity", 1)),
        "OUTPUT_PATH": str(request.get("output_path", "")),
        "result": {},
    }
    exec(compile(script, "<qemica-custom-script>", "exec"), ns)  # noqa: S102

    doc = ns.get("result")
    if isinstance(doc, dict) and doc:
        for key, value in doc.items():
            result[key] = value
    else:
        harvested = False
        try:
            energy = float(ns.get("energy"))  # type: ignore[arg-type]
            if math.isfinite(energy):
                result["total_energy"] = energy
                harvested = True
        except (TypeError, ValueError):
            pass
        if not harvested:
            _warn(result, "custom script filled no `result` dict and left no finite "
                          "`energy` variable — the job ran, but there is nothing to display.")
    _warn(result, "produced by a hand-edited custom script — the Method recipe may not "
                  "describe what actually ran.")
    result["success"] = True
    return result


# ─────────────────────────── dispatch ───────────────────────────

_ACTIONS = {
    "custom_script": action_custom_script,
    "energy": action_energy,
    "transition_state": action_transition_state,
    "irc": action_irc,
    "pes_scan": action_pes_scan,
    "relaxed_scan": action_relaxed_scan,
    "es_opt": action_es_opt,
    "nbo": action_nbo,
    "neb": action_neb,
    "mace": action_mace,
    "vqe": action_vqe,
    "qpe": action_qpe,
    "signal_pe": action_signal_pe,
    "krylov": action_krylov,
    "vibrational_vqe": action_vibrational_vqe,
    "open_dynamics": action_open_dynamics,
    "ibmq": action_ibmq,
    "sqd": action_sqd,
    "parse": action_parse,
    "parse_trajectory": action_parse_trajectory,
}

# Cheminformatics actions emit a SIMPLE {"ok":...} document, not a JobResult.
# They write output_path themselves; run() must not call rb.validate/rb.write_result
# for them (overhaul §12.2). Keyed the same way the capabilities probe is.
_SIMPLE_ACTIONS = {
    "depict": action_depict,
    "embed": action_embed,
    "generate_conformers": action_generate_conformers,
    "smiles": action_smiles,
    "inchikey": action_inchikey,
    "parse_smiles": action_parse_smiles,
    "parse_structure": action_parse_structure,
    "fetch_pubchem": action_fetch_pubchem,
    "write_structure": action_write_structure,
    # Quick-install a missing capability's pip package(s), arch-aware (Config → Engines).
    "install_capability": action_install_capability,
    # IBM Quantum connection probe (Config → Quantum "Test connection"); spends ZERO QPU.
    "ibmq_check": action_ibmq_check,
}


def run(request: dict[str, Any]) -> dict[str, Any]:
    """Dispatch a request. For JobResult actions, validate + write output_path.

    Returns the document written (a JobResult, or the capabilities doc).
    """
    action = str(request.get("action", "")).strip()
    output_path = request.get("output_path", "")

    if action == "capabilities":
        return action_capabilities(request)

    if action in _SIMPLE_ACTIONS:
        if not output_path:
            raise ValueError("request.output_path is required")
        return _SIMPLE_ACTIONS[action](request)

    if action not in _ACTIONS:
        raise ValueError(f"Unknown action: {action!r}")

    if not output_path:
        raise ValueError("request.output_path is required")

    # Capture the verbose engine log (pyscf SCF at verbose=5 + IBM/qiskit runtime logs + any
    # prints) for the Analyze "Raw" tab. Diagnostics only — science stays in the structured
    # result fields (§3). The full text rides in result["engine_log"]; the persistence layer
    # peels it off into a separate engine_log_<id>.txt file-of-record (the DB stays lean).
    with _engine_log_capture(True) as log_buf:
        result = _ACTIONS[action](request)
    if log_buf is not None:
        text = log_buf.getvalue()
        if text:
            result["engine_log"] = text
    rb.write_result(result, output_path)
    return result


def _run_one_serve_request(request_path: str) -> str:
    """Run ONE request whose envelope is at `request_path`; return the framed status
    line ('OK <output_path>' / 'ERR <msg>', no trailing newline).

    Byte-for-byte the same per-request semantics as the one-shot [main] body — delete
    the envelope the moment it is read (credential hygiene, §13.4), dispatch through the
    identical [run] action map, and on failure still write an error `result.json` so the
    client always has a file to read. The ONLY difference from one-shot is that this is
    called in a loop by [serve_loop] instead of once per process; the heavy imports
    (pyscf/RDKit) are therefore paid once and reused across every request.
    """
    request: dict[str, Any] = {}
    output_path = ""
    try:
        with open(request_path, "r", encoding="utf-8") as fh:
            request = json.load(fh)
        try:
            os.remove(request_path)
        except OSError:
            pass
        output_path = request.get("output_path", "")
        run(request)
        return f"OK {output_path}"
    except Exception as exc:  # noqa: BLE001 — a resident worker must never die on one bad job
        message = f"{type(exc).__name__}: {exc}"
        if output_path and request.get("action") != "capabilities":
            try:
                err = rb.error_result(message, spec=request.get("spec", {}))
                rb.write_result(err, output_path)
            except Exception:
                pass
        traceback.print_exc(file=sys.stderr)
        return f"ERR {message}"


def serve_loop(stream: Any = None) -> int:
    """Resident 'serve' mode (batch / conformer-ensemble / scan amortization, §6).

    Reads successive request-envelope FILE PATHS — one per line — from stdin and runs
    each through the SAME [run] dispatch as the one-shot path, staying resident so the
    heavy scientific imports are paid ONCE for the whole group instead of per job. For
    each request it writes `result.json` to that request's own `output_path` and prints
    exactly one framed status line ('OK <path>' / 'ERR <msg>') to stdout, flushed, so
    the client can frame per-request completion. QPROG live telemetry streams per request
    exactly as in one-shot mode (the client drains it between status lines). EOF on stdin
    ends the loop cleanly (return 0).

    This is a pure OUTER LOOP around the unchanged one-shot action dispatch — one-shot
    invocation (`sidecar.py <request.json>`) is byte-identical and never enters here.
    """
    stream = sys.stdin if stream is None else stream
    # readline() one line at a time — NOT `for line in stream`, whose read-ahead buffer
    # can deadlock an interactive line protocol (the child would block waiting to fill the
    # buffer while the client waits for output). readline returns "" only at real EOF.
    while True:
        raw = stream.readline()
        if raw == "":
            break
        line = raw.strip()
        if not line:
            continue
        status = _run_one_serve_request(line)
        sys.stdout.write(status + "\n")
        sys.stdout.flush()
    return 0


def main(argv: list[str] | None = None) -> int:
    """CLI entrypoint. Prints 'OK <path>' or 'ERR <msg>'; returns process exit code."""
    argv = list(sys.argv[1:] if argv is None else argv)
    if not argv:
        print("ERR usage: sidecar.py <request.json>", file=sys.stdout)
        return 2

    # Resident serve mode (opt-in, §6): an outer loop over stdin request paths. Guarded
    # so the one-shot path below is entered for every ordinary `sidecar.py <request.json>`
    # invocation exactly as before.
    if argv[0] == "--serve":
        return serve_loop()

    request_path = argv[0]
    request: dict[str, Any] = {}
    output_path = ""
    try:
        with open(request_path, "r", encoding="utf-8") as fh:
            request = json.load(fh)
        # Delete the request envelope from disk as soon as it is read into memory. The
        # envelope can carry a credential (the IBM Quantum token, §13.4), so it must not
        # linger on disk for the (possibly long) lifetime of the run — nor be orphaned if
        # the run later fails. The caller also cleans up, but doing it here bounds the
        # on-disk window to interpreter startup regardless of how the job ends.
        try:
            os.remove(request_path)
        except OSError:
            pass
        output_path = request.get("output_path", "")
        run(request)
        print(f"OK {output_path}")
        return 0
    except Exception as exc:  # noqa: BLE001 — sidecar must never crash silently
        message = f"{type(exc).__name__}: {exc}"
        # Always leave a readable result file for the Godot side when possible.
        if output_path and request.get("action") != "capabilities":
            try:
                err = rb.error_result(message, spec=request.get("spec", {}))
                rb.write_result(err, output_path)
            except Exception:
                pass
        # Full traceback to stderr (logs only — never parsed for science, §3).
        traceback.print_exc(file=sys.stderr)
        print(f"ERR {message}")
        return 1


if __name__ == "__main__":
    raise SystemExit(main())
