"""Structure-file import/export (Chemcraft/Avogadro parity — overhaul §12.2).

Parses .xyz / .mol / .sdf / .pdb files into the same MoleculeGraph JSON contract
that ``parse_smiles`` emits, plus 3D coordinates and the net formal charge, so
the Godot side reuses the SMILES-import handoff verbatim.

RDKit is the PRIMARY reader (better bond/charge perception for its formats).
OpenBabel (pybel) is the fallback ONLY for its exclusive formats
(.mol2 / .cif / .cml / .gro / .pdbqt) — an RDKit failure on a .mol/.sdf is
never silently retried with OpenBabel (different perception would be
confusing); the RDKit error stands. When OpenBabel is absent its formats are
rejected loudly with a message naming the gap, never half-parsed.

``write_structure`` is the export mirror: mol/sdf/pdb/xyz via RDKit, mol2 via
pybel (RDKit cannot write mol2). All RDKit/OpenBabel imports are local
(sidecar capability probing, §15.4).
"""

from __future__ import annotations

import os
import re
from typing import Any

from .rdkit_ops import graph_to_rdkit, rdkit_to_graph

#: Formats this importer genuinely supports (RDKit-native readers).
SUPPORTED_EXTENSIONS = (".xyz", ".mol", ".sdf", ".pdb")

#: Formats read via OpenBabel (pybel) when it is installed — its exclusive set.
OPENBABEL_EXTENSIONS = (".mol2", ".cif", ".cml", ".gro", ".pdbqt")

#: Gaussian CARTESIAN input decks — parsed natively (this OpenBabel build has no
#: Gaussian cartesian-input reader). The most common migration on-ramp for Gaussian
#: users: import the geometry (+ charge/multiplicity) straight from a .gjf/.com deck.
GAUSSIAN_INPUT_EXTENSIONS = (".gjf", ".com", ".gau")

#: Other engine INPUT decks OpenBabel reads, mapped extension -> OB read-format code
#: (the extension is not always the format name, e.g. Jaguar ".in" -> "jin"). Serves
#: migrating Jaguar/GAMESS/MOPAC users. A Gaussian Z-matrix deck (.gzmat) rides here;
#: cartesian Gaussian decks take the native path above.
OPENBABEL_INPUT_DECKS = {
    ".jin": "jin",      # Jaguar input (Schrödinger Jaguar)
    ".in": "jin",       # Jaguar's common input extension
    ".gzmat": "gzmat",  # Gaussian Z-matrix input
    ".gamin": "gamin",  # GAMESS input
    ".mopin": "mopin",  # MOPAC internal coordinates
}

#: Formats write_structure can emit (mol2 needs OpenBabel; the rest are RDKit).
WRITE_FORMATS = ("mol", "sdf", "mol2", "pdb", "xyz")


def _openbabel_available() -> bool:
    """True when the ``openbabel`` package (pybel) is importable (§15.4)."""
    import importlib.util

    try:
        return importlib.util.find_spec("openbabel") is not None
    except Exception:
        return False


def parse_structure(file_path: str) -> dict[str, Any]:
    """Parse a structure file into a molecule document.

    Returns::

        {
          "graph":    MoleculeGraph dict (atoms incl. formal_charge, bonds),
          "coords_3d": [{"x","y","z"}, ...]  (one per graph atom, Angstrom),
          "coords_2d": [{"x","y"}, ...]  (native MDL 2D depiction; empty unless
                        a .mol/.sdf carried a 2D layout — see coords_2d note),
          "charge":   int   (net formal charge),
          "multiplicity": int (1, or 2 + warning for an odd electron count),
          "name":     str   (file stem),
          "format":   str   ("xyz" | "mol" | "sdf" | "pdb" | "mol2" | ...),
          "warnings": [str, ...],
        }

    Raises ``FileNotFoundError`` for a missing file and ``ValueError`` (naming
    the format) for unsupported formats or unparseable content.
    """
    if not file_path or not os.path.isfile(file_path):
        raise FileNotFoundError(f"structure file does not exist: {file_path!r}")

    ext = os.path.splitext(file_path)[1].lower()
    warnings: list[str] = []

    if ext == ".xyz":
        mol = _mol_from_xyz(file_path, warnings)
    elif ext == ".mol":
        mol = _mol_from_molfile(file_path)
    elif ext == ".sdf":
        mol = _mol_from_sdf(file_path, warnings)
    elif ext == ".pdb":
        mol = _mol_from_pdb(file_path)
    elif ext in GAUSSIAN_INPUT_EXTENSIONS:
        return _doc_from_gaussian_input(file_path, ext, warnings)
    elif ext in OPENBABEL_EXTENSIONS or ext in OPENBABEL_INPUT_DECKS:
        if not _openbabel_available():
            raise ValueError(
                f"unsupported structure format {ext!r} — reading it requires "
                "OpenBabel, which is not installed. Supported: "
                + " ".join(SUPPORTED_EXTENSIONS)
            )
        deck_fmt = OPENBABEL_INPUT_DECKS.get(ext)
        return _doc_from_pybel(
            file_path, ext, warnings, fmt=deck_fmt, single=deck_fmt is not None
        )
    else:
        supported = SUPPORTED_EXTENSIONS + GAUSSIAN_INPUT_EXTENSIONS + (
            OPENBABEL_EXTENSIONS + tuple(OPENBABEL_INPUT_DECKS)
            if _openbabel_available() else ()
        )
        raise ValueError(
            f"unsupported structure format {ext!r} — supported: "
            + " ".join(supported)
        )

    return _molecule_doc(mol, file_path, ext, warnings)


# ─────────────────────────── multi-frame XYZ trajectory ───────────────────────────

#: A single floating-point number (decimal point or exponent required — a bare integer
#: is a frame index/atom count, never an energy).
_FLOAT = r"[-+]?\d+\.\d+(?:[eEdD][-+]?\d+)?|[-+]?\d+[eEdD][-+]?\d+"

#: The xmol/MD convention carries the frame energy on the comment line. We accept it
#: ONLY in two unambiguous shapes, so a decimal buried in descriptive prose
#: ("geometry at 1.5 angstrom", "MD step=5 t=2.5fs", "frame10 -12.5") is NOT mistaken
#: for an energy:
#:   1. a BARE number — the whole comment is just the float (optional whitespace), the
#:      most common xmol convention "the comment line is the energy";
#:   2. an ENERGY-KEYWORD prefix — `E` / `energy` (case-insensitive) optionally followed
#:      by `=` or `:`, then the number ("E = -76.42", "energy: -76.42", "Energy -76.4").
_BARE_ENERGY = re.compile(rf"^\s*(?P<num>{_FLOAT})\s*$")
_KEYWORD_ENERGY = re.compile(
    rf"\b(?:e|energy)\b\s*[=:]?\s*(?P<num>{_FLOAT})", re.IGNORECASE
)


def _parse_comment_energy(comment: str) -> float | None:
    """The frame energy from an XYZ comment line (Hartree), or None when the comment
    carries no recognizable energy.

    Only two shapes count as an energy: a comment that is JUST a bare float, or a float
    introduced by an energy keyword (`E`/`energy`, optionally with `=`/`:`). A decimal
    embedded in descriptive text ("1.5 angstrom") is intentionally ignored — grabbing
    the first float anywhere produced false positives. A bare integer (no decimal point
    or exponent) is never an energy — those are frame indices/atom counts."""
    text = comment or ""
    match = _BARE_ENERGY.match(text) or _KEYWORD_ENERGY.search(text)
    if not match:
        return None
    token = match.group("num").replace("d", "e").replace("D", "e")
    try:
        return float(token)
    except ValueError:
        return None


def count_xyz_frames(file_path: str) -> int:
    """Cheap frame count of an XYZ file (number of "<natom>\\n<comment>\\n<atoms>"
    blocks) without an RDKit parse — the modeler uses it to nudge a multi-frame import
    toward the Analyze trajectory scrubber. 0 for a missing/empty/unparseable file."""
    if not file_path or not os.path.isfile(file_path):
        return 0
    frames = 0
    try:
        with open(file_path, "r", encoding="utf-8", errors="replace") as fh:
            lines = fh.read().splitlines()
    except OSError:
        # Per this helper's contract, an unreadable file yields 0 (no trajectory nudge).
        # Narrowed from bare Exception so a non-IO bug surfaces rather than reading as "0".
        return 0
    i = 0
    n = len(lines)
    while i < n:
        head = lines[i].strip()
        if not head:
            i += 1
            continue
        try:
            natom = int(head)
        except ValueError:
            break  # not a frame header — stop counting rather than miscount
        if natom <= 0:
            break
        frames += 1
        i += 2 + natom  # header + comment + natom coordinate lines
    return frames


def parse_xyz_trajectory(file_path: str) -> dict[str, Any]:
    """Parse a multi-frame (concatenated) XYZ file into a trajectory document.

    Each frame is "<natom>\\n<comment>\\n<elem x y z>×natom"; the comment line
    conventionally carries the frame energy (xmol/MD). Returns::

        {
          "atom_symbols": [str, ...],          # element order (constant across frames)
          "final_coords": [{"x","y","z"}, ...],# last frame's geometry
          "trajectory":   [trajectory_frame(step, coords, energy, 0.0), ...],
          "trajectory_kind": "xyz",
          "frame_count":  int,
          "warnings":     [str, ...],
        }

    Energy honesty: XYZ comment energies are assumed Hartree already (the QM-trajectory
    convention) — NOT converted (unlike cclib's eV). A warning says so IFF any frame
    energy was actually read. Validates a consistent atom count across frames (raises
    ValueError naming the offending frame on a mismatch); element order is assumed
    constant. Raises FileNotFoundError for a missing file, ValueError for empty/garbage.
    """
    from ..sidecar import result_builder as rb

    if not file_path or not os.path.isfile(file_path):
        raise FileNotFoundError(f"trajectory file does not exist: {file_path!r}")

    with open(file_path, "r", encoding="utf-8", errors="replace") as fh:
        lines = fh.read().splitlines()

    warnings: list[str] = []
    frames: list[dict[str, Any]] = []
    symbols: list[str] = []
    any_energy = False

    i = 0
    n = len(lines)
    frame_index = 0
    while i < n:
        # Skip blank padding between blocks.
        while i < n and not lines[i].strip():
            i += 1
        if i >= n:
            break
        head = lines[i].strip()
        try:
            natom = int(head)
        except ValueError as exc:
            raise ValueError(
                f"malformed XYZ trajectory: expected an atom count at line {i + 1}, "
                f"got {head!r}"
            ) from exc
        if natom <= 0:
            raise ValueError(
                f"malformed XYZ trajectory: non-positive atom count {natom} in frame "
                f"{frame_index + 1}"
            )
        comment = lines[i + 1] if i + 1 < n else ""
        atom_start = i + 2
        if atom_start + natom > n:
            raise ValueError(
                f"truncated XYZ trajectory: frame {frame_index + 1} declares {natom} "
                f"atoms but the file ends early"
            )

        frame_symbols: list[str] = []
        coords: list[dict[str, float]] = []
        for k in range(natom):
            parts = lines[atom_start + k].split()
            if len(parts) < 4:
                raise ValueError(
                    f"malformed XYZ trajectory: atom line {atom_start + k + 1} in frame "
                    f"{frame_index + 1} has fewer than 4 fields ({lines[atom_start + k]!r})"
                )
            frame_symbols.append(parts[0])
            try:
                coords.append(rb.vec3(float(parts[1]), float(parts[2]), float(parts[3])))
            except ValueError:
                raise ValueError(
                    f"malformed XYZ trajectory: non-numeric coordinate on atom line "
                    f"{atom_start + k + 1} in frame {frame_index + 1} "
                    f"({lines[atom_start + k]!r})"
                )

        if not symbols:
            symbols = frame_symbols
        elif len(frame_symbols) != len(symbols):
            raise ValueError(
                f"inconsistent atom count in XYZ trajectory: frame {frame_index + 1} has "
                f"{len(frame_symbols)} atoms, frame 1 has {len(symbols)} — frames must "
                "describe the same system"
            )

        energy = _parse_comment_energy(comment)
        if energy is not None:
            any_energy = True
        frames.append(rb.trajectory_frame(float(frame_index), coords, energy or 0.0, 0.0))
        frame_index += 1
        i = atom_start + natom

    if not frames:
        raise ValueError(f"no XYZ frames found in file: {file_path!r}")

    if any_energy:
        warnings.append(
            "frame energies read from XYZ comments, assumed Hartree (XYZ trajectories "
            "carry no unit — not converted)"
        )

    return {
        "atom_symbols": symbols,
        "final_coords": frames[-1]["coords"],
        "trajectory": frames,
        "trajectory_kind": "xyz",
        "frame_count": len(frames),
        "warnings": warnings,
    }


# ─────────────────────────── per-format readers ───────────────────────────


def _mol_from_xyz(file_path: str, warnings: list[str]) -> Any:
    """XYZ: coordinates only — bonds are inferred (rdDetermineBonds), honestly
    degrading to connectivity-only, then to a bondless import, with a warning."""
    from rdkit import Chem

    with open(file_path, "r", encoding="utf-8", errors="replace") as fh:
        block = fh.read()
    mol = Chem.MolFromXYZBlock(block)
    if mol is None or mol.GetNumAtoms() == 0:
        raise ValueError(f"could not parse XYZ file: {file_path!r}")

    # XYZ carries no bonds or charge; infer bonds, assuming a neutral system.
    try:
        from rdkit.Chem import rdDetermineBonds

        try:
            rdDetermineBonds.DetermineBonds(mol, charge=0)
        except Exception:
            # Bond *orders* failed (radicals/charged species/odd valences) —
            # fall back to connectivity only (all single bonds), and say so.
            rdDetermineBonds.DetermineConnectivity(mol)
            # Everything is a single bond now, and any per-atom formal charge left on that
            # model is arithmetic on a wrong bonding pattern rather than chemistry. Taking
            # Chem.GetFormalCharge of it produced real, silent errors: acetate (true -1)
            # imported as -3 with a carbon carrying -1, and 1,3-dimethylimidazolium (true
            # +1) as -1 — the SIGN inverted, a two-electron mistake that flows straight into
            # the job spec. An XYZ file carries no charge at all, so the only honest answer
            # is neutral-with-a-warning; guessing is worse than asking.
            for atom in mol.GetAtoms():
                atom.SetFormalCharge(0)
            warnings.append(
                "bond orders could not be perceived from the XYZ geometry — "
                "connectivity imported as single bonds"
            )
            warnings.append(
                "XYZ files carry no charge or spin information, and the bonding here could "
                "not be perceived, so the charge could not be inferred either — imported as "
                "NEUTRAL. If this is an ion or a radical, set the charge and multiplicity "
                "before running: an incorrect charge changes the electron count and every "
                "number that follows from it."
            )
    except Exception:
        warnings.append(
            "no bonds could be inferred from the XYZ geometry — "
            "atoms imported without bonds"
        )
    mol.UpdatePropertyCache(strict=False)
    return mol


def _mol_from_molfile(file_path: str) -> Any:
    """MDL molfile: bonds + formal charges (M  CHG) come from the file."""
    from rdkit import Chem

    mol = Chem.MolFromMolFile(file_path, removeHs=False)
    if mol is None:
        raise ValueError(f"RDKit could not parse MDL molfile: {file_path!r}")
    return mol


def _mol_from_sdf(file_path: str, warnings: list[str]) -> Any:
    """SDF: may hold many records — load the first parseable one + a warning."""
    supplier_mols = _read_sdf_records(file_path)
    total = len(supplier_mols)
    if total == 0:
        raise ValueError(f"RDKit could not parse SDF file: {file_path!r}")
    first = next((m for m in supplier_mols if m is not None), None)
    if first is None:
        raise ValueError(
            f"RDKit could not parse any structure in SDF file: {file_path!r}"
        )
    if total > 1:
        warnings.append(f"{total} structures in SDF file — loaded the first")
    return first


def _read_sdf_records(file_path: str) -> list[Any]:
    from rdkit import Chem

    supplier = Chem.SDMolSupplier(file_path, removeHs=False)
    return list(supplier)


def _mol_from_pdb(file_path: str) -> Any:
    """PDB: CONECT records + RDKit proximity bonding supply the bonds."""
    from rdkit import Chem

    mol = Chem.MolFromPDBFile(file_path, removeHs=False)
    if mol is None:
        raise ValueError(f"RDKit could not parse PDB file: {file_path!r}")
    return mol


# ─────────────────────────── Gaussian input decks ───────────────────────────

#: A Gaussian charge/multiplicity line: one or more "charge mult" integer pairs
#: (fragmented systems write several). We take the FIRST pair as the overall spec.
_GAUSSIAN_CM = re.compile(r"^\s*(-?\d+)\s+(\d+)(?:\s+-?\d+\s+\d+)*\s*$")
#: A Gaussian cartesian atom line: an element token (symbol, optionally suffixed like
#: "O1"/"C(Iso=13)", or a bare atomic number) followed by three coordinates.
_GAUSSIAN_ATOM = re.compile(
    r"^\s*([A-Za-z]{1,2}[A-Za-z0-9()=,.\-]*|\d{1,3})\s+"
    r"(-?\d+\.\d+|-?\d+)\s+(-?\d+\.\d+|-?\d+)\s+(-?\d+\.\d+|-?\d+)\s*$"
)


def _element_from_token(tok: str) -> str:
    """Resolve a Gaussian atom token to an element symbol. Accepts a bare atomic
    number ("8"), a plain symbol ("Cl"), or a labelled/suffixed symbol ("O1",
    "C(Iso=13)"). Returns "" when nothing element-like can be read."""
    from rdkit.Chem import GetPeriodicTable

    pt = GetPeriodicTable()
    t = tok.strip()
    if t[:1].isdigit():
        try:
            return pt.GetElementSymbol(int(float(t)))
        except Exception:
            return ""
    letters = ""
    for ch in t:
        if ch.isalpha():
            letters += ch
        else:
            break
    for cand in ((letters[:2].capitalize(),) if len(letters) >= 2 else ()) + (
        (letters[:1].upper(),) if letters else ()
    ):
        try:
            if pt.GetAtomicNumber(cand) > 0:
                return cand
        except Exception:
            continue
    return ""


def _parse_gaussian_geometry(
    lines: list[str],
) -> tuple[int, int, list[tuple[str, float, float, float]]]:
    """Extract (charge, multiplicity, [(element, x, y, z), ...]) from a Gaussian
    input deck's cartesian block. `atoms` is empty when no cartesian block is found
    (e.g. a Z-matrix deck) — the caller then falls back to OpenBabel."""
    for i, line in enumerate(lines):
        cm = _GAUSSIAN_CM.match(line)
        if not cm:
            continue
        atoms: list[tuple[str, float, float, float]] = []
        for follow in lines[i + 1 :]:
            am = _GAUSSIAN_ATOM.match(follow)
            if not am:
                break
            el = _element_from_token(am.group(1))
            if el:
                atoms.append(
                    (el, float(am.group(2)), float(am.group(3)), float(am.group(4)))
                )
        if atoms:
            return int(cm.group(1)), int(cm.group(2)), atoms
    return 0, 1, []


def _doc_from_gaussian_input(
    file_path: str, ext: str, warnings: list[str]
) -> dict[str, Any]:
    """Gaussian cartesian input deck (.gjf/.com/.gau) -> molecule doc.

    The migration on-ramp for a Gaussian user: import the geometry AND the deck's
    explicit (charge, multiplicity) straight from an input file. Only CARTESIAN
    geometries are read natively (this OpenBabel build has no Gaussian cartesian
    reader); a Z-matrix deck falls back to OpenBabel's gzmat reader when present.
    """
    from rdkit import Chem

    with open(file_path, "r", encoding="utf-8", errors="replace") as fh:
        lines = fh.read().splitlines()
    charge, multiplicity, atoms = _parse_gaussian_geometry(lines)
    if not atoms:
        if _openbabel_available():
            return _doc_from_pybel(
                file_path, ext, warnings, fmt="gzmat", single=True
            )
        raise ValueError(
            f"no cartesian geometry found in Gaussian input deck {file_path!r} — a "
            "Z-matrix deck needs OpenBabel, which is not installed"
        )

    block = "%d\n\n" % len(atoms) + "\n".join(
        "%s %.10f %.10f %.10f" % a for a in atoms
    )
    mol = Chem.MolFromXYZBlock(block)
    if mol is None or mol.GetNumAtoms() == 0:
        raise ValueError(
            f"could not parse the geometry in Gaussian input deck {file_path!r}"
        )
    try:
        from rdkit.Chem import rdDetermineBonds

        try:
            rdDetermineBonds.DetermineBonds(mol, charge=charge)
        except Exception:
            rdDetermineBonds.DetermineConnectivity(mol)
            warnings.append(
                "bond orders could not be perceived from the Gaussian geometry — "
                "connectivity imported as single bonds"
            )
    except Exception:
        warnings.append(
            "no bonds could be inferred from the Gaussian geometry — "
            "atoms imported without bonds"
        )
    mol.UpdatePropertyCache(strict=False)

    doc = _molecule_doc(mol, file_path, ext, warnings)
    # The deck states (charge, multiplicity) explicitly; those are authoritative over
    # RDKit's perceived formal charge / electron-count guess (which differ for radicals
    # and ions the bond-perception could not fully resolve).
    doc["charge"] = int(charge)
    doc["multiplicity"] = int(multiplicity)
    return doc


# ─────────────────────────── OpenBabel readers ───────────────────────────


def _doc_from_pybel(
    file_path: str,
    ext: str,
    warnings: list[str],
    fmt: str | None = None,
    single: bool = False,
) -> dict[str, Any]:
    """OpenBabel-read formats -> molecule doc.

    Covers the OpenBabel-exclusive structure set (.mol2/.cif/.cml/.gro/.pdbqt,
    where the extension IS the format code) and the input decks whose extension
    differs from the OB format name (passed via `fmt`, e.g. ".in" -> "jin").

    Builds the SAME molecule document `_molecule_doc` produces from RDKit —
    graph contract atoms/bonds, coords_3d, net charge, multiplicity guess —
    but straight from the pybel/OBMol perception (no RDKit round-trip, so
    sanitization can never reject what OpenBabel legitimately read).

    `single` skips the multi-structure probe: an INPUT DECK holds exactly one
    molecule, and some OB deck readers (notably `jin`) never signal EOF when
    iterated past the first record — draining the reader would spin forever.
    """
    from openbabel import openbabel as ob
    from openbabel import pybel

    fmt = fmt if fmt else ext.lstrip(".")
    reader = pybel.readfile(fmt, file_path)
    try:
        first = next(reader, None)
    except Exception as exc:
        raise ValueError(
            f"OpenBabel could not parse {fmt} file: {file_path!r} ({exc})"
        ) from exc
    if first is None or len(first.atoms) == 0:
        raise ValueError(f"OpenBabel could not parse {fmt} file: {file_path!r}")
    if not single:
        extra = sum(1 for _ in reader)
        if extra:
            warnings.append(
                f"{extra + 1} structures in {fmt} file — loaded the first"
            )

    obmol = first.OBMol
    atoms: list[dict[str, Any]] = []
    for a in first.atoms:
        oba = a.OBAtom
        atoms.append(
            {
                "element": ob.GetSymbol(a.atomicnum),
                "formal_charge": int(a.formalcharge),
                "implicit_h": int(oba.GetImplicitHCount()),
                "aromatic": bool(oba.IsAromatic()),
                "isotope": int(a.isotope),
            }
        )
    bonds: list[dict[str, Any]] = []
    for b in ob.OBMolBondIter(obmol):
        # OBMol atom indices are 1-based; the graph contract is 0-based.
        order = 4 if b.IsAromatic() else max(1, min(3, int(b.GetBondOrder())))
        bonds.append(
            {
                "a": int(b.GetBeginAtomIdx()) - 1,
                "b": int(b.GetEndAtomIdx()) - 1,
                "order": order,
                "stereo": "none",
            }
        )
    if fmt in ("cif", "gro") and bonds:
        # These formats carry no bond table — OpenBabel perceived the bonds
        # from interatomic distances. Say so (honest degradation, §15.4).
        warnings.append(
            "bonds perceived from interatomic distances (OpenBabel) — "
            "verify the connectivity"
        )

    coords: list[dict[str, float]] = []
    coords_2d: list[dict[str, float]] = []
    dim = int(obmol.GetDimension())
    if dim == 0:
        warnings.append("file carries no coordinates — only the graph was imported")
    else:
        for a in first.atoms:
            x, y, z = a.coords
            coords.append({"x": float(x), "y": float(y), "z": float(z)})
        if dim == 2:
            # Native 2D depiction — hand the x/y through so the sketch honors it.
            coords_2d = [{"x": c["x"], "y": c["y"]} for c in coords]
            warnings.append("file carries 2D coordinates (all z = 0)")

    charge = int(first.charge)
    # Same honest multiplicity guess as the RDKit path: an odd electron count
    # cannot be a singlet — default to a doublet and say so.
    electrons = sum(a.atomicnum for a in first.atoms) - charge
    electrons += sum(a["implicit_h"] for a in atoms)
    multiplicity = 1
    if electrons % 2 == 1:
        multiplicity = 2
        warnings.append(
            "odd electron count — multiplicity defaulted to 2 (doublet); "
            "adjust it before running a calculation"
        )

    stem = os.path.splitext(os.path.basename(file_path))[0]
    doc: dict[str, Any] = {
        "graph": {"atoms": atoms, "bonds": bonds},
        "coords_3d": coords,
        "coords_2d": coords_2d,
        "charge": charge,
        "multiplicity": multiplicity,
        "name": stem,
        "format": fmt,
        "warnings": warnings,
    }
    # A CIF (or any OB format carrying a cell) describes a CRYSTAL, not a molecule. Importing
    # only its asymmetric unit turned rock-salt NaCl into a neutral two-atom "molecule" with
    # one covalent bond — a gas-phase fragment, silently. The app HAS a periodic path
    # (_pbc_energy runs pyscf.pbc KRHF/KRKS from exactly this a/b/c block) and the Builder
    # has a lattice overlay, so the cell rides along; `use_pbc` stays False because turning
    # periodicity on is the user's decision, and the warning says what was and was not read.
    lattice = _unit_cell(obmol)
    if lattice is not None:
        doc["lattice"] = lattice
        group = str(lattice.get("space_group") or "").strip()
        # "crystal" only when the file actually named a space group — a .gro box is a
        # periodic MD cell, not a crystal, and calling it one would be its own small lie.
        kind = "crystal (space group %s)" % group if group else "periodic cell"
        warnings.append(
            "%s describes a PERIODIC %s: a=%.4f b=%.4f c=%.4f Angstrom, "
            "alpha=%.2f beta=%.2f gamma=%.2f deg. Only the %d atom(s) written in the file "
            "were imported — NO symmetry expansion was applied, so this is a fragment of the "
            "cell, not the full structure. The cell came with it: turn on periodic boundary "
            "conditions in the Builder to compute with it, or the calculation is gas-phase."
            % (fmt.upper(), kind,
               lattice["lengths"][0], lattice["lengths"][1], lattice["lengths"][2],
               lattice["angles"][0], lattice["angles"][1], lattice["angles"][2], len(atoms))
        )
    return doc


def _unit_cell(obmol: Any) -> dict[str, Any] | None:
    """The OBMol's unit cell as the `lattice` block, or None when the file carried none.

    Vectors are Angstrom rows a/b/c — the shape `_pbc_energy` and the Godot `Lattice` class
    both already speak. `lengths`/`angles`/`space_group` ride along for the warning text and
    for a crystallographic readout that does not have to re-derive them.
    """
    from openbabel import openbabel as ob

    try:
        data = obmol.GetData(ob.UnitCell)
        if data is None:
            return None
        cell = ob.toUnitCell(data)
        vecs = [
            [float(v.GetX()), float(v.GetY()), float(v.GetZ())]
            for v in cell.GetCellVectors()
        ]
        if len(vecs) != 3:
            return None
        group = cell.GetSpaceGroupName() or ""
        return {
            "a": vecs[0],
            "b": vecs[1],
            "c": vecs[2],
            "use_pbc": False,
            "lengths": [float(cell.GetA()), float(cell.GetB()), float(cell.GetC())],
            "angles": [float(cell.GetAlpha()), float(cell.GetBeta()), float(cell.GetGamma())],
            "space_group": str(group),
        }
    except Exception:  # noqa: BLE001 — no cell, or an OB build without one: import as before
        return None


# ─────────────────────────── document assembly ───────────────────────────


def _molecule_doc(
    mol: Any, file_path: str, ext: str, warnings: list[str]
) -> dict[str, Any]:
    """RDKit Mol (+ conformer) -> the molecule document (see parse_structure)."""
    from rdkit import Chem

    graph = rdkit_to_graph(mol)

    coords: list[dict[str, float]] = []
    coords_2d: list[dict[str, float]] = []
    if mol.GetNumConformers() > 0:
        conf = mol.GetConformer()
        for i in range(mol.GetNumAtoms()):
            p = conf.GetAtomPosition(i)
            coords.append({"x": float(p.x), "y": float(p.y), "z": float(p.z)})
        # An MDL 2D depiction flags itself via the conformer's dimensional code
        # (Is3D() is False) AND has all-zero z. Require BOTH: a genuine 3D geometry of a
        # planar molecule aligned to the z=0 plane (dimensional code "3D") must not be
        # demoted to a sketch depiction, and a file claiming "2D" with real z is treated
        # as 3D. Hand the native x/y through as `coords_2d` so the sketch honors the
        # file's own layout instead of PCA-projecting from the flat geometry.
        is_2d = not conf.Is3D() and not any(c["z"] for c in coords)
        if is_2d and ext in (".mol", ".sdf"):
            coords_2d = [{"x": c["x"], "y": c["y"]} for c in coords]
            warnings.append("file carries 2D coordinates (all z = 0)")
    else:
        warnings.append("file carries no coordinates — only the graph was imported")

    charge = int(Chem.GetFormalCharge(mol))

    # Honest multiplicity: an odd electron count cannot be a singlet. Default to a
    # doublet and warn, rather than handing back an impossible (charge, mult) pair.
    electrons = sum(a.GetAtomicNum() for a in mol.GetAtoms()) - charge
    electrons += sum(a.GetTotalNumHs() for a in mol.GetAtoms())
    multiplicity = 1
    if electrons % 2 == 1:
        multiplicity = 2
        warnings.append(
            "odd electron count — multiplicity defaulted to 2 (doublet); "
            "adjust it before running a calculation"
        )

    stem = os.path.splitext(os.path.basename(file_path))[0]
    return {
        "graph": graph,
        "coords_3d": coords,
        "coords_2d": coords_2d,
        "charge": charge,
        "multiplicity": multiplicity,
        "name": stem,
        "format": ext.lstrip("."),
        "warnings": warnings,
    }


# ─────────────────────────── structure export ───────────────────────────


def write_structure(
    file_path: str, fmt: str, molecule: dict[str, Any]
) -> dict[str, Any]:
    """Write a molecule document to a structure file (Avogadro-parity export).

    ``molecule`` is the same dict contract `parse_structure` returns / the Godot
    side holds: ``{"graph": {...}, "coords_3d": [{x,y,z},...] | None,
    "coords_2d": [{x,y},...] | None, "name": str, ...}``. ``fmt`` is one of
    ``WRITE_FORMATS`` ("" infers it from the file extension).

    mol/sdf/pdb/xyz are written via RDKit; mol2 via pybel (RDKit cannot write
    mol2 — requires OpenBabel). Honesty rules: 3D coords are used when present,
    a 2D layout is written flat (z = 0) with a warning, a coordinate-free
    molecule gets all-zero positions with a warning, and bondless / implicit-H
    losses are warned, never hidden.

    Returns ``{"path": ..., "format": ..., "warnings": [...]}``; raises
    ``ValueError`` for unsupported formats or an unwritable molecule.
    """
    fmt = (fmt or "").lower().lstrip(".")
    if not fmt:
        fmt = os.path.splitext(file_path)[1].lower().lstrip(".")
    if fmt not in WRITE_FORMATS:
        raise ValueError(
            f"unsupported export format {fmt!r} — supported: "
            + " ".join(WRITE_FORMATS)
        )
    if not file_path:
        raise ValueError("file_path is required")
    if fmt == "mol2" and not _openbabel_available():
        raise ValueError(
            "writing .mol2 requires OpenBabel, which is not installed"
        )

    graph = molecule.get("graph") or {}
    graph_atoms = graph.get("atoms") or []
    graph_bonds = graph.get("bonds") or []
    if not graph_atoms:
        raise ValueError("molecule has no atoms — nothing to write")

    from rdkit import Chem
    from rdkit.Geometry import Point3D

    warnings: list[str] = []
    mol = graph_to_rdkit(graph)
    name = str(molecule.get("name", "") or "molecule")
    mol.SetProp("_Name", name)

    # XYZ is elements + coordinates and nothing else: it cannot carry charge or spin. Writing
    # an ion to .xyz silently drops the one property that decides the electron count, and the
    # reader on the far side (ours included) has no way to recover it. Say so at the point of
    # loss rather than leaving the user to discover it on re-import.
    _q = int(molecule.get("charge", 0) or 0)
    _mult = int(molecule.get("multiplicity", 1) or 1)
    if fmt == "xyz" and (_q != 0 or _mult != 1):
        warnings.append(
            "XYZ cannot store charge or multiplicity — this molecule's charge %+d / "
            "multiplicity %d are NOT written to the file. Anything reading it back will "
            "assume a neutral singlet; use .mol/.sdf, or set them by hand on import."
            % (_q, _mult)
        )

    if len(graph_atoms) > 1 and not graph_bonds:
        warnings.append(
            "molecule has no bonds — the file carries atoms without connectivity"
        )
    # Implicit hydrogens exist only in the valence model (mol/sdf keep them);
    # coordinate formats write the explicit atoms only — say what is lost.
    declared_implicit_h = sum(int(a.get("implicit_h", 0)) for a in graph_atoms)
    if declared_implicit_h and fmt in ("xyz", "pdb", "mol2"):
        warnings.append(
            f"{declared_implicit_h} implicit hydrogens are not written — "
            f"embed 3D to make hydrogens explicit before exporting {fmt}"
        )

    # Conformer: 3D when given, 2D-as-flat with a warning, else all-zero + warning.
    coords = molecule.get("coords_3d")
    flat = False
    if isinstance(coords, list) and coords and len(coords) != mol.GetNumAtoms():
        warnings.append(
            f"coords_3d count ({len(coords)}) does not match the atom count "
            f"({mol.GetNumAtoms()}) — coordinates ignored"
        )
        coords = None
    if not (isinstance(coords, list) and coords):
        coords_2d = molecule.get("coords_2d")
        if isinstance(coords_2d, list) and len(coords_2d) == mol.GetNumAtoms():
            coords = [
                {"x": c.get("x", 0.0), "y": c.get("y", 0.0), "z": 0.0}
                for c in coords_2d
            ]
            flat = True
            warnings.append("no 3D coordinates — wrote the 2D layout flat (z = 0)")
        else:
            coords = [{"x": 0.0, "y": 0.0, "z": 0.0}] * mol.GetNumAtoms()
            flat = True
            warnings.append(
                "molecule has no coordinates — atom positions written as zeros; "
                "embed 3D for a real geometry"
            )
    conf = Chem.Conformer(mol.GetNumAtoms())
    for i, c in enumerate(coords):
        conf.SetAtomPosition(
            i, Point3D(float(c["x"]), float(c["y"]), float(c["z"]))
        )
    conf.Set3D(not flat)
    mol.AddConformer(conf, assignId=True)

    if fmt == "mol":
        with open(file_path, "w", encoding="utf-8") as fh:
            fh.write(Chem.MolToMolBlock(mol))
    elif fmt == "sdf":
        writer = Chem.SDWriter(file_path)
        try:
            writer.write(mol)
        finally:
            writer.close()
    elif fmt == "pdb":
        Chem.MolToPDBFile(mol, file_path)
    elif fmt == "xyz":
        with open(file_path, "w", encoding="utf-8") as fh:
            fh.write(Chem.MolToXYZBlock(mol))
    else:  # mol2 — RDKit cannot write it; route the molblock through pybel.
        from openbabel import pybel

        obmol = pybel.readstring("mol", Chem.MolToMolBlock(mol))
        obmol.title = name
        obmol.write("mol2", file_path, overwrite=True)

    return {"path": file_path, "format": fmt, "warnings": warnings}
