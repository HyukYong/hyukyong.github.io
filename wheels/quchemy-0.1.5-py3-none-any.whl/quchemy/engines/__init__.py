"""quchemy.engines — drivers for external quantum-chemistry programs.

Qemica computes chemistry on its own PySCF/quchemy stack by default. This package holds
the drivers for programs the USER installed and licensed themselves: Qemica writes an
input file, runs their binary, and parses the output back into the `JobResult` contract.

Nothing here ships, mirrors, downloads or embeds a third-party program — an external
engine is only ever invoked at a path the user configured (Config → Engines), and their
use of it is governed by that program's own license, not Qemica's.
"""

from __future__ import annotations

__all__ = ["orca"]
