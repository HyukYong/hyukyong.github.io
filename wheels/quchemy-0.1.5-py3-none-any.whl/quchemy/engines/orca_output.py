"""Readers for ORCA's own machine-readable output files.

**Why this exists instead of cclib.** cclib is the right tool for an output file someone
ELSE produced and handed us (`action_parse`), and it stays that way. But for a job Qemica
itself ran, cclib is both fragile and lossy against current ORCA: version 1.8.1 raises on
ORCA 6.x output in four separate places (the SCF-convergence block, the orbital-energies
block, a population-analysis assertion, and an early EOF), so a job that succeeded fails at
the parse step — and even with those errors suppressed it never recovers thermochemistry.

ORCA already publishes what we need in stable, structured, versioned files. Reading those
is what FACCTs' own Python interface does, and it gives us MORE than cclib did:
thermochemistry, Mayer bond orders, and ORCA's own termination verdict.

Division of labour between the files:

* `<job>.property.txt` — status, geometry, energies, charges, dipole, bond orders,
  thermochemistry. A block/key format with declared types.
* `<job>.hess` — frequencies, IR intensities, Raman activities, normal-mode displacements.
  A block format with plain numeric rows.
* `<job>.out` — the human-readable log. Only orbital energies are read from here, because
  they appear in no structured file.

Every reader returns partial data rather than raising: a job whose physics completed must
not be lost to a missing optional block.
"""

from __future__ import annotations

import os
import re
from typing import Any

# ── <job>.property.txt ────────────────────────────────────────────────────────
#
# Shape (ORCA 5 and 6 alike):
#
#     $Calculation_Status
#        &GeometryIndex 5
#        &version [&Type "String"] "6.1.1"
#        &Status [&Type "String"] "NORMAL TERMINATION"
#     $End
#     $Geometry
#        &CartesianCoordinates [&Type "Coordinates", &Dim(3,4), &Units "Bohr"]
#                   O      0.000000    0.000000    0.224877
#     $End
#
# A block may repeat, once per geometry step of an optimization; the LAST occurrence is
# the converged one. Array values are followed by indented `<index> <value>` rows.

## `&keyName [&Type "Double", &Units "a.u."]   -76.32` — the scalar form. The trailing
## value is optional: an array declaration has its values on the following lines.
_PROP_KEY_RE = re.compile(
    r'^\s*&(?P<key>\w+)\s*(?:\[(?P<meta>[^\]]*)\])?\s*(?P<value>.*?)\s*$'
)
## `<row index> <value> [<value> …]` inside an array block. A 2-D array (e.g. Mayer's
## `components`, Dim (2,4)) puts a whole ROW on one line, so more than one value must be
## accepted — matching a single value silently dropped every multi-column array. Values
## are flattened row-major, which is the order the declared Dim implies.
##
## NO LEADING WHITESPACE, deliberately. Each array is preceded by a right-aligned COLUMN
## HEADER line (`        0        1        2        3`) that is otherwise indistinguishable
## from a data row — and parsing it as one shifts every subsequent value by a column,
## which turned water's Mayer bonds into "atom 1–atom 3". Data rows start their index at
## column 0; the header never does.
_PROP_ROW_RE = re.compile(
    r'^(\d+)((?:\s+-?\d+\.?\d*(?:[eEdD][+-]?\d+)?)+)\s*$'
)
## A coordinate row: `O   0.000000  0.000000  0.224877`.
_PROP_COORD_RE = re.compile(
    r'^\s*([A-Za-z][A-Za-z]?)\s+(-?\d+\.\d+)\s+(-?\d+\.\d+)\s+(-?\d+\.\d+)\s*$'
)

## ORCA reports geometry in the property file in BOHR; the JobResult contract is Ångström.
BOHR_TO_ANGSTROM = 0.529177210903
## ORCA reports the dipole in atomic units; the JobResult contract is Debye.
AU_TO_DEBYE = 2.541746473

## The status string ORCA writes for a run that completed.
NORMAL_TERMINATION = "NORMAL TERMINATION"


def parse_property_file(path: str) -> dict[str, list[dict[str, Any]]]:
    """Parse `<job>.property.txt` into `{block_name: [occurrence, …]}`.

    Blocks REPEAT — once per geometry of an optimization — and both ends matter: the last
    occurrence is the converged result, while the sequence of `Single_Point_Data`
    occurrences IS the optimization energy profile. So every occurrence is kept and
    callers pick with [last_block] or read the whole list.

    Scalars are typed from their `&Type` declaration (Double/Integer/String/Boolean);
    arrays become lists of floats; `CartesianCoordinates` becomes
    `[{"element", "x", "y", "z"}]` CONVERTED TO ÅNGSTRÖM (the file is in Bohr, and a
    silent unit mismatch here would put every geometry out by a factor of 1.89).

    Returns {} for a missing or unreadable file; never raises.
    """
    if not path or not os.path.isfile(path):
        return {}
    try:
        with open(path, "r", encoding="utf-8", errors="replace") as fh:
            lines = fh.read().splitlines()
    except OSError:
        return {}

    blocks: dict[str, list[dict[str, Any]]] = {}
    current: dict[str, Any] | None = None
    pending_key: str | None = None
    # row index → its values. A WIDE 2-D array is printed in COLUMN GROUPS (rows 0..n for
    # columns 0-7, then a fresh header and rows 0..n for columns 8-10), so values must be
    # accumulated per row across groups. Flattening as encountered would interleave the
    # groups and scramble every wide matrix.
    pending_matrix: dict[int, list[float]] = {}
    pending_coords: list[dict[str, Any]] = []

    def flush() -> None:
        nonlocal pending_key, pending_matrix, pending_coords
        if pending_key is not None and current is not None:
            if pending_coords:
                _store(current, pending_key, pending_coords)
            elif pending_matrix:
                rows = [pending_matrix[i] for i in sorted(pending_matrix)]
                # A 1-D array (one value per row) collapses to a flat list; a genuine
                # matrix stays a list of rows so callers can index [row][column].
                flat = [r[0] for r in rows] if all(len(r) == 1 for r in rows) else rows
                _store(current, pending_key, flat)
        pending_key, pending_matrix, pending_coords = None, {}, []

    for raw in lines:
        stripped = raw.strip()
        if stripped.startswith("$"):
            flush()
            name = stripped[1:].strip()
            if name.lower() == "end":
                current = None
            else:
                current = {}
                blocks.setdefault(name, []).append(current)
            continue
        if current is None:
            continue

        if stripped.startswith("&"):
            flush()
            match = _PROP_KEY_RE.match(raw)
            if not match:
                continue
            key = match.group("key")
            meta = match.group("meta") or ""
            value = match.group("value").strip()
            # An ARRAY declaration often carries a trailing description string
            # (`&dipoleTotal [&Type "ArrayOfDoubles", …] "Total"`). Reading that as the
            # value would store the word "Total" where a 3-vector belongs, so the declared
            # type decides, not the presence of trailing text.
            if value and not _declares_array(meta):
                _store(current, key, _coerce_property_value(value, meta))
            else:
                pending_key = key  # its values are on the following lines
            continue

        # Inside an array declaration: collect indexed rows / coordinate rows.
        if pending_key is not None:
            coord = _PROP_COORD_RE.match(raw)
            if coord:
                pending_coords.append({
                    "element": coord.group(1),
                    "x": float(coord.group(2)) * BOHR_TO_ANGSTROM,
                    "y": float(coord.group(3)) * BOHR_TO_ANGSTROM,
                    "z": float(coord.group(4)) * BOHR_TO_ANGSTROM,
                })
                continue
            row = _PROP_ROW_RE.match(raw)
            if row:
                index = int(row.group(1))
                values = [float(t.replace("d", "e").replace("D", "e"))
                          for t in row.group(2).split()]
                pending_matrix.setdefault(index, []).extend(values)
    flush()
    return blocks


def _store(block: dict[str, Any], key: str, value: Any) -> None:
    """Set `key`, accumulating into a list when it REPEATS within one block.

    ORCA uses a repeated key as a per-item list — `&NUC` once per nucleus in the NMR
    block, `&SDSO` once per shielding tensor. Overwriting would keep only the last
    nucleus and silently report a three-atom molecule's shieldings as one atom's.
    """
    if key not in block:
        block[key] = value
        return
    existing = block[key]
    if isinstance(existing, _Repeated):
        existing.append(value)
    else:
        block[key] = _Repeated([existing, value])


class _Repeated(list):
    """Marker for a key that appeared more than once in a block (see [_store]).

    A plain list would be ambiguous against a key whose single value IS a list.
    """


def repeated(block: dict[str, Any], key: str) -> list[Any]:
    """Every occurrence of `key` in a block, as a list — one element when it appeared
    once, [] when absent. The uniform accessor for ORCA's repeated-key convention."""
    if key not in block:
        return []
    value = block[key]
    return list(value) if isinstance(value, _Repeated) else [value]


def _declares_array(meta: str) -> bool:
    """True when a `&Type` declaration names an array/coordinate type, whose values live
    on the FOLLOWING lines rather than on the declaration line."""
    lowered = meta.lower()
    return "arrayof" in lowered or "coordinates" in lowered


def last_block(blocks: dict[str, list[dict[str, Any]]], name: str) -> dict[str, Any]:
    """The final occurrence of `name` — the converged step of an optimization, and the
    only occurrence of a single-point block. {} when the block is absent."""
    occurrences = blocks.get(name) or []
    return occurrences[-1] if occurrences else {}


def _coerce_property_value(value: str, meta: str) -> Any:
    """Type a scalar property value from its `&Type "..."` declaration.

    A scalar line may carry a trailing human description that is NOT part of the value::

        &FinalEnergy [&Type "Double"]   -7.632e+01  "Final single point energy"
        &Status      [&Type "String"]   "NORMAL TERMINATION"

    So a String takes the quoted text (that IS the value) while a number takes the leading
    token and discards the description — coercing the whole line would have stored the
    sentence "Final single point energy" where an energy belongs.
    """
    declared = ""
    type_match = re.search(r'&Type\s+"([^"]+)"', meta)
    if type_match:
        declared = type_match.group(1).lower()

    if declared == "string":
        quoted = re.match(r'\s*"([^"]*)"', value)
        return quoted.group(1) if quoted else value.strip().strip('"')

    # Numeric/boolean: the value is the FIRST token; anything after it is commentary.
    tokens = value.strip().split()
    token = tokens[0].strip('"') if tokens else ""
    if declared == "integer":
        try:
            return int(float(token))
        except ValueError:
            return token
    if declared == "boolean":
        return token.lower() == "true"
    if declared == "double":
        try:
            return float(token.replace("d", "e").replace("D", "e"))
        except ValueError:
            return token
    # Undeclared: a number if it reads as one, else the raw text.
    try:
        return float(token)
    except ValueError:
        return value.strip().strip('"')


def property_terminated_normally(blocks: dict[str, list[dict[str, Any]]]) -> bool | None:
    """ORCA's OWN verdict on the run, or None when it did not record one.

    More trustworthy than grepping the log: it is a declared field rather than a banner,
    and it survives whatever formatting the human-readable output adopts next release.
    """
    status = last_block(blocks, "Calculation_Status")
    if "Status" not in status:
        return None
    return NORMAL_TERMINATION in str(status["Status"]).upper()


# ── <job>.hess ────────────────────────────────────────────────────────────────
#
#     $vibrational_frequencies
#     9
#         0        0.0000000000
#         6     1637.6261492051
#     $ir_spectrum
#     9
#        1637.63   0.01094220  55.29739880   -0.000000  0.000000  0.045663
#
# Rows cover ALL 3N modes, including the six ~zero translations/rotations.

## `$ir_spectrum` column holding the intensity in km/mol (after the wavenumber and T²).
_IR_INTENSITY_COLUMN = 2
## `$raman_spectrum` column holding the activity (after the wavenumber).
_RAMAN_ACTIVITY_COLUMN = 1


def parse_hessian_file(path: str) -> dict[str, Any]:
    """Parse the vibrational blocks of `<job>.hess`.

    Returns `{"frequencies": [cm⁻¹ …], "ir_intensities": [km/mol …],
    "raman_activities": [… ]}` with only the blocks present. All three lists cover the
    same 3N modes in the same order, so they align by index with each other (but NOT with
    a 3N−6 list from elsewhere — see [vibrations_from_hessian]).

    Returns {} for a missing or unreadable file; never raises.
    """
    if not path or not os.path.isfile(path):
        return {}
    try:
        with open(path, "r", encoding="utf-8", errors="replace") as fh:
            lines = fh.read().splitlines()
    except OSError:
        return {}

    out: dict[str, Any] = {}
    freqs = _hess_indexed_values(lines, "$vibrational_frequencies")
    if freqs:
        out["frequencies"] = freqs
    ir = _hess_columns(lines, "$ir_spectrum", _IR_INTENSITY_COLUMN)
    if ir:
        out["ir_intensities"] = ir
    raman = _hess_columns(lines, "$raman_spectrum", _RAMAN_ACTIVITY_COLUMN)
    if raman:
        out["raman_activities"] = raman
    return out


def _hess_block(lines: list[str], tag: str) -> list[str]:
    """The rows of a `.hess` block, excluding its tag and trailing blank/next tag."""
    try:
        start = next(i for i, line in enumerate(lines) if line.strip() == tag)
    except StopIteration:
        return []
    rows: list[str] = []
    for line in lines[start + 1:]:
        if line.strip().startswith("$"):
            break
        rows.append(line)
    return rows


def _hess_indexed_values(lines: list[str], tag: str) -> list[float]:
    """`<index> <value>` rows from a `.hess` block, in index order."""
    values: list[float] = []
    for row in _hess_block(lines, tag):
        parts = row.split()
        if len(parts) != 2:
            continue  # the count line, or a blank
        try:
            values.append(float(parts[1]))
        except ValueError:
            continue
    return values


def _hess_columns(lines: list[str], tag: str, column: int) -> list[float]:
    """One column of a multi-column `.hess` spectrum block, in row order."""
    values: list[float] = []
    for row in _hess_block(lines, tag):
        parts = row.split()
        if len(parts) <= column:
            continue  # the count line
        try:
            values.append(float(parts[column]))
        except ValueError:
            continue
    return values


# ── <job> MD trajectory ───────────────────────────────────────────────────────
#
# ORCA's AIMD trajectory is an XYZ whose comment carries both the simulation clock and
# the potential energy:
#
#   # ORCA AIMD Position Step 0, t=0.00 fs, E_Pot=-196818.91017926 kJ mol^-1, ...
#
# The shared XYZ reader cannot use either: its energy pattern does not match `E_Pot=`
# (the underscore breaks the word boundary), and it assumes Hartree — which for a value
# in kJ/mol would be wrong by a factor of 2625 if it ever did match. So the MD path reads
# this format itself.

## `t=12.50 fs` — the simulation clock.
_AIMD_TIME_RE = re.compile(r"\bt\s*=\s*(-?\d+\.?\d*(?:[eE][+-]?\d+)?)\s*fs", re.IGNORECASE)
## `E_Pot=-196818.91017926 kJ mol^-1` — the potential energy AND its unit.
_AIMD_ENERGY_RE = re.compile(
    r"E_Pot\s*=\s*(-?\d+\.?\d*(?:[eE][+-]?\d+)?)\s*(kJ|kcal|Eh|Hartree)?", re.IGNORECASE)

## ORCA reports AIMD energies in kJ/mol; the JobResult contract is Hartree.
KJ_PER_MOL_TO_HARTREE = 1.0 / 2625.499639479
KCAL_PER_MOL_TO_HARTREE = 1.0 / 627.5094740631


def parse_aimd_comment(comment: str) -> dict[str, float]:
    """`{"time_fs", "energy_ha"}` from an ORCA AIMD trajectory comment; {} when absent.

    The energy is converted to Hartree from whatever unit the comment names (ORCA writes
    kJ/mol). Reporting -196818 as a Hartree energy would be off by a factor of 2625 and
    would look, at a glance, like a plausible number.
    """
    out: dict[str, float] = {}
    time_match = _AIMD_TIME_RE.search(comment)
    if time_match:
        out["time_fs"] = float(time_match.group(1))
    energy_match = _AIMD_ENERGY_RE.search(comment)
    if energy_match:
        value = float(energy_match.group(1))
        unit = (energy_match.group(2) or "kJ").lower()
        if unit == "kj":
            value *= KJ_PER_MOL_TO_HARTREE
        elif unit == "kcal":
            value *= KCAL_PER_MOL_TO_HARTREE
        out["energy_ha"] = value
    return out


def read_md_trajectory(path: str) -> list[dict[str, Any]]:
    """ORCA's AIMD trajectory as `[{"time_fs", "energy_ha", "coords"}]`, or [].

    `coords` is `[{"x","y","z"}]` in Ångström, which is what the file already uses.
    """
    if not path or not os.path.isfile(path):
        return []
    try:
        with open(path, "r", encoding="utf-8", errors="replace") as fh:
            lines = fh.read().splitlines()
    except OSError:
        return []

    frames: list[dict[str, Any]] = []
    i = 0
    while i < len(lines):
        head = lines[i].strip()
        if not head:
            i += 1
            continue
        try:
            natom = int(head)
        except ValueError:
            i += 1
            continue
        if natom <= 0 or i + 1 + natom >= len(lines) + 1:
            break
        meta = parse_aimd_comment(lines[i + 1] if i + 1 < len(lines) else "")
        coords: list[dict[str, float]] = []
        for k in range(natom):
            row = i + 2 + k
            if row >= len(lines):
                break
            parts = lines[row].split()
            if len(parts) < 4:
                break
            try:
                coords.append({"x": float(parts[1]), "y": float(parts[2]),
                               "z": float(parts[3])})
            except ValueError:
                break
        if len(coords) == natom:
            # `parsed` records whether the AIMD comment actually yielded a clock and an
            # energy. Without it the fallbacks below are indistinguishable from real data:
            # a frame index looks like a time in fs, and 0.0 looks like an energy.
            frames.append({
                "time_fs": float(meta.get("time_fs", len(frames))),
                "energy_ha": float(meta.get("energy_ha", 0.0)),
                "coords": coords,
                "parsed": "time_fs" in meta and "energy_ha" in meta,
            })
        i += 2 + natom
    return frames


def read_md_energies(path: str) -> list[dict[str, float]]:
    """Per-step MD energetics from ORCA's `<job>-md-ener.csv`.

    Returns `[{"time_fs", "temperature_k", "e_kin", "e_pot", "e_tot"}]`, or [] when the
    file is absent. Semicolon-separated with a `#`-prefixed header; blank cells are normal
    (the first step has no gradient time or drift).

    The TEMPERATURE lives only here — the trajectory file's comment carries the clock and
    the potential energy but no temperature at all.
    """
    if not path or not os.path.isfile(path):
        return []
    try:
        with open(path, "r", encoding="utf-8", errors="replace") as fh:
            lines = fh.read().splitlines()
    except OSError:
        return []
    rows: list[dict[str, float]] = []
    header: list[str] = []
    for line in lines:
        cells = [c.strip() for c in line.split(";")]
        if not header:
            if line.lstrip().startswith("#"):
                header = [c.lstrip("#").strip().lower() for c in cells]
            continue
        if len(cells) < len(header) or not cells[0]:
            continue
        row = dict(zip(header, cells))
        def num(key: str) -> float:
            try:
                return float(row.get(key, "") or 0.0)
            except ValueError:
                return 0.0
        rows.append({
            "time_fs": num("sim. time"),
            "temperature_k": num("temp"),
            "e_kin": num("e_kin"),
            "e_pot": num("e_pot"),
            "e_tot": num("e_tot"),
        })
    return rows


## The spin tags the JobResult contract uses for an unrestricted run. NOT "alpha"/"beta":
## the contract and the Analyze Orbitals tab both key on these single letters, and the
## long forms made every open-shell comparison fail — the ladder rendered zero levels
## while the alpha/beta toggle sat there live and inert.
SPIN_ALPHA = "a"
SPIN_BETA = "b"


def _hess_matrix(lines: list[str], tag: str) -> list[list[float]]:
    """A `.hess` matrix block as `rows[row][column]`.

    Wide matrices are printed in COLUMN GROUPS — a header of column indices, then one line
    per row — so values are accumulated per row across groups. Flattening as encountered
    would interleave the groups and scramble the matrix.
    """
    rows: dict[int, list[float]] = {}
    for line in _hess_block(lines, tag):
        parts = line.split()
        if len(parts) < 2:
            continue
        # A column-header line is bare integers; a data row starts with its index and
        # continues with floats.
        if all(("." not in p and "E" not in p and "e" not in p) for p in parts):
            continue
        try:
            index = int(parts[0])
            values = [float(p) for p in parts[1:]]
        except ValueError:
            continue
        rows.setdefault(index, []).extend(values)
    return [rows[i] for i in sorted(rows)]


def normal_modes_from_hessian(path: str) -> list[list[dict[str, float]]]:
    """Per-mode atom displacements from `<job>.hess`'s `$normal_modes`.

    Returns `modes[mode][atom] = {"x","y","z"}` for all 3N modes, or [] when the block is
    absent. The matrix is indexed `[3*atom + axis][mode]`, so a mode is a COLUMN.

    Without these the IR/Raman tab's Vectors overlay and Play animation have nothing to
    move — the controls are there, and would silently do nothing.
    """
    if not path or not os.path.isfile(path):
        return []
    try:
        with open(path, "r", encoding="utf-8", errors="replace") as fh:
            lines = fh.read().splitlines()
    except OSError:
        return []
    matrix = _hess_matrix(lines, "$normal_modes")
    if not matrix:
        return []
    n_coords = len(matrix)
    n_modes = min(len(row) for row in matrix)
    n_atoms = n_coords // 3
    modes: list[list[dict[str, float]]] = []
    for mode in range(n_modes):
        atoms: list[dict[str, float]] = []
        for atom in range(n_atoms):
            atoms.append({
                "x": float(matrix[3 * atom][mode]),
                "y": float(matrix[3 * atom + 1][mode]),
                "z": float(matrix[3 * atom + 2][mode]),
            })
        modes.append(atoms)
    return modes


def vibrations_from_hessian(hess: dict[str, Any], *, zero_tol_cm: float = 1.0) -> list[dict]:
    """Real vibrational modes as `{"wavenumber", "ir_intensity", "raman_activity"}`.

    The Hessian lists all 3N modes; the six ~zero translations and rotations are dropped
    here so the result matches the 3N−6 convention every other engine path reports (and so
    a spectrum is not padded with six meaningless zero-frequency lines). An IMAGINARY mode
    is kept — it is negative, not near-zero, and is the whole point of a saddle search.

    Because the three lists are dropped together by index, the alignment between a
    frequency and its intensity is preserved exactly.
    """
    freqs = hess.get("frequencies") or []
    ir = hess.get("ir_intensities") or []
    raman = hess.get("raman_activities") or []
    modes: list[dict] = []
    for i, freq in enumerate(freqs):
        if abs(freq) <= zero_tol_cm:
            continue
        modes.append({
            # The ORIGINAL row index: the displacement matrix still holds all 3N modes,
            # so a caller matching by position after this drop would be six columns out.
            "index": i,
            "wavenumber": float(freq),
            "ir_intensity": float(ir[i]) if i < len(ir) else 0.0,
            "raman_activity": float(raman[i]) if i < len(raman) else 0.0,
        })
    return modes


# ── <job>.out (only what no structured file carries) ──────────────────────────

## `   0   2.0000     -19.116108      -520.1757` under an "ORBITAL ENERGIES" heading.
_ORBITAL_ROW_RE = re.compile(
    r"^\s*(\d+)\s+(-?\d+\.\d+)\s+(-?\d+\.\d+)\s+(-?\d+\.\d+)\s*$"
)
_ORBITAL_HEADER = "ORBITAL ENERGIES"
## Bytes of the log tail to scan for the final orbital table. An optimization prints one
## per step and only the last matters, so reading the whole (possibly huge) file is waste.
_ORBITAL_TAIL_BYTES = 2_000_000


## Sub-headers ORCA prints inside ONE `ORBITAL ENERGIES` section for an unrestricted run.
_SPIN_UP_HEADER = "SPIN UP ORBITALS"
_SPIN_DOWN_HEADER = "SPIN DOWN ORBITALS"


def parse_orbital_energies(out_path: str) -> list[dict[str, Any]]:
    """Orbital occupations and energies from the LAST `ORBITAL ENERGIES` section.

    Read from the log because ORCA publishes them in no structured file. Returns
    `[{"index", "occupancy", "energy_ha"}]` in orbital order — plus a `"spin"` tag of
    `"a"`/`"b"` for an unrestricted run — or [] when absent.

    An optimization prints one section PER STEP, so only the last is the converged one.
    Within that section, an unrestricted run prints `SPIN UP ORBITALS` then `SPIN DOWN
    ORBITALS`; both are returned, because reporting one channel as if it were the whole
    picture is exactly the closed-shell-looking lie the contract's spin tags exist to
    prevent.
    """
    text = _tail_text(out_path, _ORBITAL_TAIL_BYTES)
    if not text:
        return []
    lines = text.splitlines()
    starts = [i for i, line in enumerate(lines) if line.strip() == _ORBITAL_HEADER]
    if not starts:
        return []

    rows: list[dict[str, Any]] = []
    spin = ""
    started = False
    for line in lines[starts[-1] + 1:]:
        stripped = line.strip()
        if stripped == _SPIN_UP_HEADER:
            spin, started = SPIN_ALPHA, False
            continue
        if stripped == _SPIN_DOWN_HEADER:
            spin, started = SPIN_BETA, False
            continue
        match = _ORBITAL_ROW_RE.match(line)
        if match:
            row: dict[str, Any] = {
                "index": int(match.group(1)),
                "occupancy": float(match.group(2)),
                "energy_ha": float(match.group(3)),
            }
            if spin:
                row["spin"] = spin
            rows.append(row)
            started = True
            continue
        # A non-row line ends the CURRENT table. Keep scanning for a following spin
        # header (the alpha/beta pair is separated by exactly such lines); stop only at
        # the next major section, which is flagged by a run of text after both tables.
        if started and stripped and not stripped.startswith(("-", "NO", "*")):
            if spin != SPIN_ALPHA:
                break
            started = False
    return rows


## `   0 O :   -0.176801    1.026670` — atom, Mulliken charge, then SPIN population. The
## spin column exists only for an unrestricted run and appears in no structured file.
_MULLIKEN_SPIN_HEADER = "MULLIKEN ATOMIC CHARGES AND SPIN POPULATIONS"
_MULLIKEN_SPIN_ROW_RE = re.compile(
    r"^\s*\d+\s+[A-Za-z]{1,2}\s*:\s*(-?\d+\.\d+)\s+(-?\d+\.\d+)\s*$"
)
## ORCA prints only a handful of virtual orbitals by default and says so with this line.
ORBITAL_TRUNCATION_MARKER = "virtual orbitals were printed"


def parse_spin_populations(out_path: str) -> list[float]:
    """Per-atom Mulliken SPIN populations (α−β) from the log, or [] for a closed shell.

    Only an unrestricted run prints the spin column, and it appears in no structured file,
    so this is read from the log's Mulliken block. Same atom order as the charges.
    """
    text = _tail_text(out_path, _ORBITAL_TAIL_BYTES)
    if not text or _MULLIKEN_SPIN_HEADER not in text:
        return []
    lines = text.splitlines()
    starts = [i for i, line in enumerate(lines) if line.strip() == _MULLIKEN_SPIN_HEADER]
    spins: list[float] = []
    for line in lines[starts[-1] + 1:]:
        match = _MULLIKEN_SPIN_ROW_RE.match(line)
        if match:
            spins.append(float(match.group(2)))
        elif spins:
            break
    return spins


def orbitals_were_truncated(out_path: str) -> bool:
    """True when ORCA printed only a subset of the virtual orbitals.

    Its default output lists just the first few virtuals, so an orbital ladder read from
    the log is genuinely incomplete above the frontier. The frontier itself (and therefore
    HOMO/LUMO and the gap) is always present — but a consumer counting orbitals against
    the basis size deserves to be told.
    """
    return ORBITAL_TRUNCATION_MARKER in _tail_text(out_path, _ORBITAL_TAIL_BYTES)


def _tail_text(path: str, limit: int) -> str:
    """The last `limit` bytes of a file as text (binary IO — see orca._head_and_tail)."""
    if not path or not os.path.isfile(path):
        return ""
    try:
        size = os.path.getsize(path)
        with open(path, "rb") as fh:
            if size > limit:
                fh.seek(size - limit)
            return fh.read().decode("utf-8", errors="replace")
    except OSError:
        return ""
