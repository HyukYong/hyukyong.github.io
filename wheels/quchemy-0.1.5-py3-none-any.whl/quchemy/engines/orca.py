"""ORCA driver: run the user's own ORCA install and parse its output.

Qemica NEVER ships, mirrors, downloads or hosts ORCA. Its EULA forbids transferring the
software to third parties, while generating an input file and reading the output text is
the interop pattern ORCA's own Python interface (OPI) uses. The user installs a copy they
registered for and points Config → Engines at the executable; this module spawns exactly
that path and nothing else.

Division of labour (deliberate, see the app-side ScriptGenerator ORCA section):

* The Godot domain layer renders the `.inp` — ONE rendering of an ORCA recipe, so there is
  no preview-vs-execution drift to keep in sync. This module never composes chemistry.
* This module owns everything the app cannot do: resolving and spawning the binary,
  re-stamping geometry, streaming progress, killing the process group on cancel, and
  mapping the output back onto the `JobResult` contract.

Fail-loud policy (overhaul §15.4): a missing binary, a non-zero exit, or an output that
never reached `ORCA TERMINATED NORMALLY` raises with the tail of the log attached. A run
never returns success with an empty result and no explanation.
"""

from __future__ import annotations

import os
import re
import shutil
import signal
import subprocess
from typing import Any, Callable

# ORCA prints this exactly once, at the very end of a run that completed. Its ABSENCE is
# the only reliable failure signal: ORCA exits 0 on several kinds of aborted job.
TERMINATION_MARKER = "ORCA TERMINATED NORMALLY"

# Banner line carrying the version, e.g. "Program Version 6.0.1  -   RELEASE  -".
_VERSION_RE = re.compile(r"Program\s+Version\s+([0-9][0-9.]*)")

# Progress lines worth streaming to the job tray. ORCA is verbose; these two are the ones
# that actually mark forward motion in a long run.
_SCF_ITER_RE = re.compile(r"^\s*(\d+)\s+(-?\d+\.\d+)\s+.*(?:DIIS|SOSCF)", re.IGNORECASE)
_OPT_CYCLE_RE = re.compile(r"GEOMETRY OPTIMIZATION CYCLE\s+(\d+)")

# How much of the log to quote when a run fails. Enough to carry ORCA's own diagnosis
# (which it prints right before dying), short enough to read in a toast.
_ERROR_TAIL_LINES = 40

# The input's own filename inside the per-job scratch directory. ORCA derives every
# output name from this stem, which is what makes the aux files predictable.
INPUT_NAME = "job.inp"
OUTPUT_NAME = "job.out"
BASENAME = "job"


class OrcaNotConfigured(RuntimeError):
    """No usable ORCA executable — the app should send the user to Config → Engines."""


class OrcaFailed(RuntimeError):
    """ORCA ran but did not complete. Carries the tail of its own log."""


def resolve_executable(exe: str) -> str:
    """The absolute ORCA executable to spawn, or raise [OrcaNotConfigured].

    ORCA's MPI launcher re-execs itself BY PATH, so a bare `orca` resolved through PATH
    silently breaks every parallel run (and on macOS collides with the unrelated `orca`
    screen-reader binary). An absolute path is therefore a correctness requirement, not a
    style preference — resolve one here or refuse.
    """
    candidate = (exe or "").strip()
    if not candidate:
        raise OrcaNotConfigured(
            "No ORCA executable is configured. Qemica does not include ORCA — install "
            "your own licensed copy (orcaforum.kofo.mpg.de) and set its full path in "
            "Config → Engines → External engines."
        )
    if os.path.isdir(candidate):
        raise OrcaNotConfigured(
            "The configured ORCA path is a directory (%r). Point it at the `orca` "
            "EXECUTABLE inside it — ORCA's parallel launcher needs the binary's own "
            "absolute path." % candidate
        )
    if not os.path.isabs(candidate):
        found = shutil.which(candidate)
        if not found:
            raise OrcaNotConfigured(
                "ORCA executable %r was not found on PATH. Set its full absolute path "
                "in Config → Engines → External engines." % candidate
            )
        candidate = found
    if not os.path.isfile(candidate):
        raise OrcaNotConfigured(
            "The configured ORCA executable does not exist: %r. Check the path in "
            "Config → Engines → External engines." % candidate
        )
    if not os.access(candidate, os.X_OK):
        raise OrcaNotConfigured(
            "The configured ORCA path is not executable: %r (try `chmod +x`)." % candidate
        )
    return candidate


# ── parallel execution ────────────────────────────────────────────────────────
#
# ORCA does not implement parallelism itself: it re-execs through `mpirun` against the
# OpenMPI version it was BUILT for. Two things therefore go wrong on a normal machine —
# no MPI at all, or an MPI whose major version does not match ORCA's build. Both end the
# same way: ORCA prints "error termination in Startup" and EXITS 0, which without the
# termination-marker check would read as a successful calculation.
#
# A missing launcher is detectable up front and worth degrading for; a version mismatch is
# not reliably detectable without running something, so it is left to fail loud with
# ORCA's own diagnosis attached.

## `%pal nprocs N end` (or a multi-line `%pal … end`) — the block that requests MPI ranks.
_PAL_BLOCK_RE = re.compile(
    r"^[ \t]*%pal\b.*?(?:\bend\b).*?$", re.IGNORECASE | re.MULTILINE | re.DOTALL
)
## `%pal nprocs 4 end` on one line — the form the app renders.
_PAL_INLINE_RE = re.compile(
    r"^[ \t]*%pal\s+nprocs\s+(\d+)\s+end[ \t]*$", re.IGNORECASE | re.MULTILINE
)
## ORCA's MPI launcher.
MPI_LAUNCHER = "mpirun"


def mpirun_available() -> bool:
    """Whether ORCA's MPI launcher is on PATH at all.

    A cheap necessary condition, not a sufficient one: an `mpirun` from the wrong OpenMPI
    line still fails, but only at run time and with a message worth surfacing verbatim.
    """
    return shutil.which(MPI_LAUNCHER) is not None


def requested_ranks(inp: str) -> int:
    """The rank count an input asks for, or 1 when it requests no parallelism."""
    match = _PAL_INLINE_RE.search(inp)
    return int(match.group(1)) if match else 1


def strip_parallel_block(inp: str) -> str:
    """Remove the `%pal` block so the input runs serially.

    Used only when the machine has no MPI launcher: the alternative is a job that dies in
    startup. The caller MUST record a warning — a calculation that quietly ran on one core
    when the user asked for eight is a surprise at best and a wrong benchmark at worst.
    """
    return _PAL_BLOCK_RE.sub("", inp)


def stamp_geometry(inp: str, molecule: dict[str, Any]) -> str:
    """Replace the input's `* xyz <charge> <mult> … *` block with `molecule`'s atoms.

    The rendered input embeds real coordinates so the preview is readable, but the JOB's
    geometry is whatever molecule the request carries — that is what keeps one spec
    correct when a batch runs it across many structures, and what keeps a hand-edited
    input usable after the user switches molecule.

    Charge and multiplicity on the `* xyz` line are PRESERVED from the input: they are
    part of the recipe the user composed (and may have hand-edited), not part of the
    geometry. An input using `* xyzfile` or an internal-coordinate `* int` block is left
    untouched — the user reached past the generated form on purpose.
    """
    atoms = molecule.get("atoms") if isinstance(molecule, dict) else None
    if not isinstance(atoms, list) or not atoms:
        return inp

    lines = inp.splitlines()
    start = -1
    for i, line in enumerate(lines):
        token = line.strip().lower()
        # `* xyz 0 1` and the equally legal `*xyz 0 1`.
        if token.startswith("*") and token.lstrip("*").strip().startswith("xyz "):
            start = i
            break
    if start < 0:
        return inp

    end = -1
    for j in range(start + 1, len(lines)):
        if lines[j].strip() == "*":
            end = j
            break
    if end < 0:
        return inp

    body = [
        "%-4s %16.10f %16.10f %16.10f"
        % (
            str(a.get("element", "")),
            float(a.get("x", 0.0)),
            float(a.get("y", 0.0)),
            float(a.get("z", 0.0)),
        )
        for a in atoms
        if isinstance(a, dict)
    ]
    return "\n".join(lines[: start + 1] + body + lines[end:])


def _environment(extra: dict[str, Any] | None) -> dict[str, str]:
    """The child environment: this process's, plus the user's ORCA additions.

    Normally that is the OpenMPI build ORCA was linked against (PATH / LD_LIBRARY_PATH).
    PATH-like variables are PREPENDED to the inherited value rather than replacing it, so
    adding an MPI directory cannot strip the rest of the user's PATH out from under ORCA.
    """
    env = dict(os.environ)
    for key, value in (extra or {}).items():
        key = str(key).strip()
        value = str(value)
        if not key:
            continue
        if key.endswith("PATH") and key in env and env[key]:
            env[key] = value + os.pathsep + env[key]
        else:
            env[key] = value
    return env


def run(
    inp: str,
    *,
    exe: str,
    workdir: str,
    env: dict[str, Any] | None = None,
    on_progress: Callable[[dict[str, Any]], None] | None = None,
) -> str:
    """Write `inp` into `workdir`, run ORCA on it, return the path to its output file.

    Raises [OrcaNotConfigured] when no binary resolves and [OrcaFailed] when the run did
    not complete — never returns a path to a log of a job that died.
    """
    executable = resolve_executable(exe)
    os.makedirs(workdir, exist_ok=True)
    inp_path = os.path.join(workdir, INPUT_NAME)
    out_path = os.path.join(workdir, OUTPUT_NAME)
    with open(inp_path, "w", encoding="utf-8") as fh:
        fh.write(inp if inp.endswith("\n") else inp + "\n")

    # start_new_session puts ORCA (and every MPI rank it forks) into its OWN process
    # group. Cancel kills the SIDECAR, and without this the ranks would be reparented and
    # keep burning cores after the user pressed Stop — so we take the group with us.
    with open(out_path, "w", encoding="utf-8") as log:
        proc = subprocess.Popen(
            [executable, INPUT_NAME],
            cwd=workdir,
            stdout=log,
            stderr=subprocess.STDOUT,
            env=_environment(env),
            start_new_session=True,
        )
        previous = _install_group_terminator(proc)
        try:
            _wait_streaming(proc, out_path, on_progress)
        finally:
            _restore_terminator(previous)

    _require_normal_termination(proc.returncode, out_path)
    return out_path


def _install_group_terminator(proc: subprocess.Popen) -> Any:
    """Route SIGTERM to ORCA's whole process group before we die ourselves.

    The app cancels a job by killing the sidecar's pid. ORCA is a GRANDCHILD of that, so
    without this handler a cancelled job leaves ORCA (and every MPI rank) running to
    completion — the user sees "Cancelled" while the machine stays pinned.
    """
    if not hasattr(signal, "SIGTERM") or not hasattr(os, "killpg"):
        return None

    def _terminate(_signum: int, _frame: Any) -> None:
        _kill_group(proc)
        raise SystemExit(143)  # 128 + SIGTERM, the conventional signal exit code

    try:
        return signal.signal(signal.SIGTERM, _terminate)
    except (ValueError, OSError):
        return None  # not on the main thread — the finally-clause kill still applies


def _restore_terminator(previous: Any) -> None:
    if previous is None:
        return
    try:
        signal.signal(signal.SIGTERM, previous)
    except (ValueError, OSError):
        pass


def _kill_group(proc: subprocess.Popen) -> None:
    """Kill ORCA and every rank it forked. Best-effort — never raises."""
    try:
        os.killpg(os.getpgid(proc.pid), signal.SIGTERM)
    except (ProcessLookupError, PermissionError, OSError):
        try:
            proc.kill()
        except OSError:
            pass


def _wait_streaming(
    proc: subprocess.Popen,
    out_path: str,
    on_progress: Callable[[dict[str, Any]], None] | None,
) -> None:
    """Block until ORCA exits, tailing its output for progress records on the way.

    ORCA writes to a FILE (its stdout is the log), so progress comes from tailing that
    file rather than from a pipe. With no progress callback this degrades to a plain wait.
    """
    if on_progress is None:
        proc.wait()
        return

    offset = 0
    while True:
        try:
            proc.wait(timeout=2.0)
            done = True
        except subprocess.TimeoutExpired:
            done = False
        offset = _drain(out_path, offset, on_progress)
        if done:
            return


def _drain(
    out_path: str, offset: int, on_progress: Callable[[dict[str, Any]], None]
) -> int:
    """Emit a progress record for each interesting new line; return the new file offset.

    Never fatal: telemetry must not be able to kill a running calculation.
    """
    try:
        with open(out_path, "r", encoding="utf-8", errors="replace") as fh:
            fh.seek(offset)
            chunk = fh.read()
            new_offset = fh.tell()
    except OSError:
        return offset
    for line in chunk.splitlines():
        record = _progress_record(line)
        if record is None:
            continue
        try:
            on_progress(record)
        except Exception:  # noqa: BLE001 — a broken callback must not abort the job
            pass
    return new_offset


def _progress_record(line: str) -> dict[str, Any] | None:
    opt = _OPT_CYCLE_RE.search(line)
    if opt:
        return {"t": "opt", "step": int(opt.group(1))}
    scf = _SCF_ITER_RE.match(line)
    if scf:
        return {"t": "scf", "cycle": int(scf.group(1)), "e": float(scf.group(2))}
    return None


def _require_normal_termination(returncode: int, out_path: str) -> None:
    """Raise unless ORCA both exited cleanly AND printed its termination marker.

    Both halves are needed. ORCA exits non-zero on a hard crash, but an SCF that gave up,
    an unreadable basis, or a geometry it rejected can end with exit 0 and no marker —
    treating that as success would hand the UI a result parsed from a half-written log.
    """
    tail = _tail(out_path)
    if returncode != 0:
        raise OrcaFailed(
            "ORCA exited with status %d. Its last output was:\n%s" % (returncode, tail)
        )
    # The marker is followed only by the run-time summary, so the tail we already read
    # covers it — no reason to pull a multi-gigabyte log into memory to find it.
    if TERMINATION_MARKER not in tail:
        raise OrcaFailed(
            "ORCA exited without reaching %r — the calculation did not complete. Its "
            "last output was:\n%s" % (TERMINATION_MARKER, tail)
        )


def _tail(path: str, lines: int = _ERROR_TAIL_LINES) -> str:
    try:
        with open(path, "r", encoding="utf-8", errors="replace") as fh:
            return "\n".join(fh.read().splitlines()[-lines:])
    except OSError:
        return "(no output file was written)"


# ── diagnostics cclib does not parse ──────────────────────────────────────────
#
# cclib maps the SCIENCE out of an ORCA log (energies, geometry, orbitals, vibrations,
# excited states, charges, thermochemistry). It carries no attribute for several things
# the JobResult contract asks for and ORCA does print — the SCF reference actually used,
# the ⟨S²⟩ spin diagnostic, the point group, and the geometry-convergence verdict. Those
# are scraped here, from lines whose format is stable across ORCA 4/5/6.
#
# Every one of these is an HONESTY field: without ⟨S²⟩ a spin-contaminated UHF result
# reads as clean, and without the convergence verdict an abandoned optimization reads as
# a stationary point. Absent values are left absent rather than guessed.

## `Hartree-Fock type      HFTyp           .... UKS` — the reference ORCA actually ran,
## which is not necessarily the one requested (it silently promotes to unrestricted for
## an open shell).
_HFTYP_RE = re.compile(r"HFTyp\s+\.+\s*([A-Za-z]+)")

## The open-shell spin diagnostic block:
##     Expectation value of <S**2>     :     0.753981
##     Ideal value S*(S+1) for S=0.5   :     0.750000
_S2_ACTUAL_RE = re.compile(r"Expectation value of <S\*\*2>\s*:\s*(-?\d+\.\d+)")
_S2_IDEAL_RE = re.compile(r"Ideal value S\*\(S\+1\)[^:]*:\s*(-?\d+\.\d+)")

## `Point Group:  C2v, Order:   4` — printed only when symmetry is enabled (`! UseSym`),
## so its absence is normal, not a degradation.
##
## The COLON is required. ORCA's opening banner is pages of prose that mentions symmetry
## repeatedly, and a colon-optional pattern happily reads "point group symmetry" as a
## point group named "symmetry" — inventing provenance out of a feature list.
_POINT_GROUP_RE = re.compile(r"[Pp]oint\s+[Gg]roup\s*:\s*([A-Za-z][\w*]*)")

## The geometry-convergence table's MAX-gradient row (Eh/bohr), and ORCA's own verdict
## banner. The banner is authoritative: individual rows can read YES while the optimizer
## is still moving on another criterion.
_MAX_GRAD_RE = re.compile(r"MAX gradient\s+(-?\d+\.\d+)")
_OPT_CONVERGED_MARKER = "THE OPTIMIZATION HAS CONVERGED"
## ORCA runs a geometry optimization only when asked; a single point has no verdict.
_OPT_RUN_MARKER = "GEOMETRY OPTIMIZATION CYCLE"

## Basis-function count — provenance for the numerical settings block.
_BASIS_DIM_RE = re.compile(r"Basis Dimension\s+Dim\s+\.+\s*(\d+)")

## How much of a log to scan for the setup block. The SCF settings are printed near the
## top; the rest is read from the tail (see [diagnostics]).
_HEAD_BYTES = 200_000
_TAIL_BYTES = 400_000


def diagnostics(out_path: str) -> dict[str, Any]:
    """Scrape the ORCA-only diagnostics from an output file.

    Returns only the keys actually found — a caller merges them, so a missing value stays
    at the contract's default rather than being invented. Never raises: a diagnostic that
    cannot be read must not fail a calculation that succeeded.

    Reads the head (setup/SCF settings) and the tail (final ⟨S²⟩, convergence verdict)
    rather than the whole file, because a long optimization log is easily gigabytes.
    """
    head, tail = _head_and_tail(out_path)
    if not head and not tail:
        return {}
    out: dict[str, Any] = {}

    hftyp = _HFTYP_RE.search(head)
    if hftyp:
        out["reference"] = hftyp.group(1).upper()

    dim = _BASIS_DIM_RE.search(head)
    if dim:
        out["basis_functions"] = int(dim.group(1))

    # ⟨S²⟩ is printed per SCF; the LAST one is the converged wavefunction's.
    actual = _S2_ACTUAL_RE.findall(tail) or _S2_ACTUAL_RE.findall(head)
    if actual:
        out["s_squared"] = float(actual[-1])
    ideal = _S2_IDEAL_RE.findall(tail) or _S2_IDEAL_RE.findall(head)
    if ideal:
        out["s_squared_exact"] = float(ideal[-1])

    group = _POINT_GROUP_RE.search(head)
    if group:
        out["point_group"] = group.group(1)

    if _OPT_RUN_MARKER in tail or _OPT_RUN_MARKER in head:
        out["geometry_optimized"] = True
        out["geometry_converged"] = _OPT_CONVERGED_MARKER in tail
        grads = _MAX_GRAD_RE.findall(tail)
        if grads:
            out["max_gradient"] = float(grads[-1])
    return out


def _head_and_tail(path: str) -> tuple[str, str]:
    """The first [_HEAD_BYTES] and last [_TAIL_BYTES] of a file, decoded leniently.

    Binary IO deliberately: seeking a TEXT stream to an arbitrary byte offset is only
    defined for cookies `tell()` handed out, so the obvious text-mode version is a latent
    failure on exactly the huge logs this exists to avoid loading whole.
    """
    try:
        size = os.path.getsize(path)
        with open(path, "rb") as fh:
            head = fh.read(_HEAD_BYTES)
            if size <= _HEAD_BYTES:
                text = head.decode("utf-8", errors="replace")
                return text, text
            fh.seek(max(0, size - _TAIL_BYTES))
            tail = fh.read()
        return (head.decode("utf-8", errors="replace"),
                tail.decode("utf-8", errors="replace"))
    except OSError:
        return "", ""


# ── auxiliary files (the reaction-path and Raman data) ────────────────────────
#
# ORCA writes its pathway results to SIDECAR FILES, not into the output log, and cclib
# parses none of them: an IRC, an NEB band and a relaxed scan all come back with empty
# arrays if we read only `job.out`. These readers are what make those tabs work at all.
#
# Every name derives from the input stem, which is why the runner pins it to [BASENAME] —
# the aux filenames are only predictable because we chose the input's name.

## `job_trj.xyz` — every geometry of an optimization, each with its OWN energy in the
## comment. Worth preferring over the log: cclib has to infer the geometry↔energy pairing
## from two separate arrays that routinely differ in length.
OPT_TRAJECTORY_SUFFIX = "_trj.xyz"
## `job_IRC_Full_trj.xyz` — the full reaction path, reactant side through TS to product.
IRC_TRAJECTORY_SUFFIX = "_IRC_Full_trj.xyz"
## `job_MEP_trj.xyz` — the optimized nudged-elastic-band minimum-energy path.
NEB_PATH_SUFFIX = "_MEP_trj.xyz"
## `job.relaxscanact.dat` — two columns: the scanned coordinate's ACTUAL value, and the
## relaxed energy at it. Better than the log, which reports step indices.
RELAXED_SCAN_SUFFIX = ".relaxscanact.dat"
## `job.hess` — the Hessian file, which carries the Raman block the log does not.
HESSIAN_SUFFIX = ".hess"
## The MD trajectory, named by the `%md dump position … filename` line the app renders.
MD_TRAJECTORY_NAME = "trajectory.xyz"
## `<job>-md-ener.csv` — ORCA's per-step MD energetics, including the TEMPERATURE, which
## appears nowhere in the trajectory file. Without it the Trajectory tab's temperature
## plot is a flat line at zero.
MD_ENERGY_CSV_SUFFIX = "-md-ener.csv"
## The NEB product endpoint. ORCA reads the band's far end from a file, so the rendered
## `%neb NEB_End_XYZFile "…"` line names THIS file and the runner must write it — an NEB
## input pointing at a file nobody created dies before the first energy.
NEB_PRODUCT_NAME = "product.xyz"


def write_endpoint_xyz(path: str, symbols: list[str], coords: list[Any]) -> None:
    """Write a single-frame XYZ at `path` (the NEB product endpoint ORCA reads).

    `coords` is `[[x, y, z], …]` in Å, in the SAME atom order as `symbols` — the ordering
    ORCA's band interpolation assumes. Raises ValueError when the two disagree, rather
    than writing a file that would interpolate between mismatched atoms.
    """
    if len(symbols) != len(coords):
        raise ValueError(
            "NEB product geometry has %d atoms but the reactant has %d — the endpoints "
            "must describe the same system in the same order."
            % (len(coords), len(symbols))
        )
    lines = ["%d" % len(symbols), "Qemica NEB product endpoint"]
    for symbol, xyz in zip(symbols, coords):
        lines.append("%-4s %16.10f %16.10f %16.10f"
                     % (symbol, float(xyz[0]), float(xyz[1]), float(xyz[2])))
    os.makedirs(os.path.dirname(path) or ".", exist_ok=True)
    with open(path, "w", encoding="utf-8") as fh:
        fh.write("\n".join(lines) + "\n")

## Wavenumbers within this many cm⁻¹ are the same mode. Used to align the Hessian's Raman
## rows (3N entries, including the ~zero translations/rotations) against the vibrational
## modes cclib parsed (3N−6) — index matching between those two would silently shift every
## activity by six modes.
_RAMAN_MATCH_TOL_CM = 1.0


def aux_file(workdir: str, suffix: str) -> str:
    """Path to an ORCA auxiliary file for the job in `workdir` (may not exist)."""
    return os.path.join(workdir, BASENAME + suffix)


def read_xyz_path(path: str) -> list[dict[str, Any]]:
    """Frames from an ORCA multi-frame XYZ (IRC / NEB / MD trajectory), or [] when the
    file is absent or unreadable.

    Delegates to the shared XYZ-trajectory reader rather than re-parsing: it already
    handles ORCA's `Coordinates from ORCA-job … E <energy>` comment convention, validates
    a consistent atom count, and treats comment energies as Hartree (which is what ORCA
    writes). Returns its `trajectory` frames — `{"time", "coords", "energy",
    "temperature"}`, with `time` the 0-based frame index.
    """
    if not path or not os.path.isfile(path):
        return []
    from ..cheminformatics import parse_xyz_trajectory

    try:
        return list(parse_xyz_trajectory(path).get("trajectory", []))
    except (ValueError, OSError):
        # A truncated or malformed aux file must not sink a calculation that finished;
        # the caller reports the empty path instead.
        return []


def read_relaxed_scan(path: str) -> list[tuple[float, float]]:
    """`(coordinate, energy)` pairs from a `.relaxscanact.dat`, or [] when absent.

    Two whitespace-separated columns: the scanned coordinate's actual value (Å for a bond,
    degrees for an angle/dihedral — whichever was driven) and the relaxed energy in
    Hartree. This is the file worth reading precisely because it carries the REAL
    coordinate; the log reports step indices, which is what makes an imported scan's axis
    meaningless.
    """
    if not path or not os.path.isfile(path):
        return []
    points: list[tuple[float, float]] = []
    try:
        with open(path, "r", encoding="utf-8", errors="replace") as fh:
            for line in fh:
                stripped = line.strip()
                if not stripped or stripped.startswith("#"):
                    continue
                parts = stripped.split()
                if len(parts) < 2:
                    continue
                try:
                    points.append((float(parts[0]), float(parts[1])))
                except ValueError:
                    continue  # a header row, not data
    except OSError:
        return []
    return points


def read_hessian_raman(path: str) -> list[tuple[float, float]]:
    """`(wavenumber, raman_activity)` pairs from a `.hess` `$raman_spectrum` block.

    ORCA only writes this block when the run actually computed Raman activities (a
    numerical-frequency job with the polarizability enabled), so an absent block is
    normal, not a failure. Returns [] when the file or the block is missing.

    The block is a count line followed by one row per mode; the first column is the
    wavenumber and the second the activity. Rows cover ALL 3N modes including the ~zero
    translations and rotations, which is why the caller matches on wavenumber.
    """
    if not path or not os.path.isfile(path):
        return []
    try:
        with open(path, "r", encoding="utf-8", errors="replace") as fh:
            lines = fh.read().splitlines()
    except OSError:
        return []

    try:
        start = next(i for i, line in enumerate(lines)
                     if line.strip().lower() == "$raman_spectrum")
    except StopIteration:
        return []

    rows: list[tuple[float, float]] = []
    for line in lines[start + 1:]:
        stripped = line.strip()
        if not stripped:
            continue
        if stripped.startswith("$"):
            break  # the next block
        parts = stripped.split()
        if len(parts) < 2:
            continue  # the count line
        try:
            rows.append((float(parts[0]), float(parts[1])))
        except ValueError:
            continue
    return rows


def raman_activity_for(rows: list[tuple[float, float]], wavenumber: float) -> float | None:
    """The Raman activity for `wavenumber` from [read_hessian_raman] rows, or None.

    Matched by FREQUENCY, not position: the Hessian lists all 3N modes while a parsed
    vibration list has 3N−6, so aligning by index would shift every activity by six modes
    — a silent, plausible-looking corruption of the whole Raman spectrum.
    """
    best: float | None = None
    best_gap = _RAMAN_MATCH_TOL_CM
    for freq, activity in rows:
        gap = abs(freq - wavenumber)
        if gap <= best_gap:
            best_gap = gap
            best = activity
    return best


# ── scratch hygiene ───────────────────────────────────────────────────────────

## Files worth keeping after a successful run: the input (what was actually submitted),
## the log (the Raw tab), and the structured outputs the result was built from. Everything
## else — .gbw wavefunctions, .densities, per-step .xyz, temporary integrals — is bulk that
## a single opt job produces by the dozen and nothing downstream reads.
_KEEP_SUFFIXES = (".inp", ".out", ".property.txt", ".hess", ".xyz", ".dat", ".cube")


def prune_scratch(workdir: str) -> int:
    """Delete the bulky intermediates ORCA leaves behind, keeping the readable record.

    Returns the number of files removed. Called only after a SUCCESSFUL run whose result
    has already been built — the aux readers need `_trj.xyz`, `.hess` and `.relaxscanact
    .dat`, so cleaning earlier would silently empty the IRC/NEB/scan/Raman tabs.

    A failed run is never pruned: its scratch is the evidence.
    """
    if not workdir or not os.path.isdir(workdir):
        return 0
    removed = 0
    try:
        entries = os.listdir(workdir)
    except OSError:
        return 0
    for name in entries:
        if name.endswith(_KEEP_SUFFIXES):
            continue
        path = os.path.join(workdir, name)
        try:
            if os.path.isfile(path):
                os.remove(path)
                removed += 1
        except OSError:
            continue  # a locked or vanished file is not worth failing a finished job for
    return removed


## Cap on the log carried back in the result. A long optimization or MD log can reach
## hundreds of megabytes, and the whole document rides the IPC and then the result file —
## so a pathological run must not take the app down with it. Generous enough that an
## ordinary job is complete.
_ENGINE_LOG_CAP_BYTES = 2_000_000


def read_engine_log(out_path: str) -> str:
    """ORCA's own output, for the Analyze "Raw" tab.

    The sidecar's usual engine-log capture records the PYTHON process's stdout, which for
    an ORCA job is empty — ORCA writes to its own file. Without this the Raw tab would be
    blank for every ORCA run, which is exactly backwards: the whole reason to look at Raw
    is to read what the engine actually said, and several of our own error messages tell
    the user to go there.

    Truncated from the FRONT when very long: the end of a log carries the result, the
    convergence table and any error, which is what someone opening Raw is looking for.
    """
    if not out_path or not os.path.isfile(out_path):
        return ""
    try:
        size = os.path.getsize(out_path)
        with open(out_path, "rb") as fh:
            if size > _ENGINE_LOG_CAP_BYTES:
                fh.seek(size - _ENGINE_LOG_CAP_BYTES)
                head = ("[Qemica: this log is %.1f MB; showing the last %.1f MB. The full "
                        "file is in the job's scratch directory.]\n\n"
                        % (size / 1e6, _ENGINE_LOG_CAP_BYTES / 1e6))
                return head + fh.read().decode("utf-8", errors="replace")
            return fh.read().decode("utf-8", errors="replace")
    except OSError:
        return ""


def version_from_output(out_path: str) -> str:
    """The ORCA version from its banner, or "" when the banner is absent/unparseable."""
    try:
        with open(out_path, "r", encoding="utf-8", errors="replace") as fh:
            # The banner is in the first page; do not read a multi-GB log to find it.
            head = fh.read(20000)
    except OSError:
        return ""
    match = _VERSION_RE.search(head)
    return match.group(1) if match else ""
