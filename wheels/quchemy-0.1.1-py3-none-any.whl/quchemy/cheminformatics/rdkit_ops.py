"""RDKit cheminformatics operations (overhaul §12.2).

Pure functions translating between the MoleculeGraph JSON contract and RDKit
``Mol`` objects, plus the four derived operations the Godot side needs:
canonical SMILES + InChIKey, 2D depiction, 3D embedding (ETKDG v3 + MMFF), and
SMILES parsing.

All RDKit imports are local to keep import-time cheap and to let the sidecar
probe ``rdkit`` availability without importing this module (overhaul §15.4).
"""

from __future__ import annotations

from typing import Any

# Map the graph's integer bond order to an RDKit BondType.
# order: 1 -> SINGLE, 2 -> DOUBLE, 3 -> TRIPLE, 4 -> AROMATIC.
_ORDER_TO_BONDTYPE: dict[int, str] = {
    1: "SINGLE",
    2: "DOUBLE",
    3: "TRIPLE",
    4: "AROMATIC",
}


def _bondtype_to_order(bond: Any) -> int:
    """Reverse map an RDKit Bond to the graph integer order (4 == aromatic)."""
    from rdkit import Chem

    if bond.GetIsAromatic() or bond.GetBondType() == Chem.BondType.AROMATIC:
        return 4
    bt = bond.GetBondType()
    if bt == Chem.BondType.SINGLE:
        return 1
    if bt == Chem.BondType.DOUBLE:
        return 2
    if bt == Chem.BondType.TRIPLE:
        return 3
    # Anything exotic collapses to a single bond for the graph contract.
    return 1


def graph_to_rdkit(graph: dict[str, Any]) -> Any:
    """Build a sanitized RDKit ``Mol`` from a MoleculeGraph dict.

    Atoms carry element, formal_charge and isotope; bonds map order 1/2/3 to
    SINGLE/DOUBLE/TRIPLE and order 4 to AROMATIC (with the aromatic flag set on
    the participating atoms so sanitization perceives the ring). A double bond's
    ``stereo`` label ("E"/"Z") is stamped onto the Mol so embedding and SMILES
    honor it — a drawn trans isomer must never silently embed as cis.
    """
    from rdkit import Chem

    rw = Chem.RWMol()
    atoms = graph.get("atoms", []) or []
    bonds = graph.get("bonds", []) or []

    for a in atoms:
        atom = Chem.Atom(str(a.get("element", "C")))
        atom.SetFormalCharge(int(a.get("formal_charge", 0)))
        isotope = int(a.get("isotope", 0))
        if isotope:
            atom.SetIsotope(isotope)
        if bool(a.get("aromatic", False)):
            atom.SetIsAromatic(True)
        # Respect an explicit implicit-H count when given (>0); otherwise let
        # sanitization compute implicit Hs from valence.
        rw.AddAtom(atom)

    for b in bonds:
        order = int(b.get("order", 1))
        bt_name = _ORDER_TO_BONDTYPE.get(order, "SINGLE")
        bt = getattr(Chem.BondType, bt_name)
        bi = rw.AddBond(int(b["a"]), int(b["b"]), bt) - 1
        if order == 4:
            bond = rw.GetBondWithIdx(bi)
            bond.SetIsAromatic(True)
            rw.GetAtomWithIdx(int(b["a"])).SetIsAromatic(True)
            rw.GetAtomWithIdx(int(b["b"])).SetIsAromatic(True)

    mol = rw.GetMol()
    Chem.SanitizeMol(mol)
    _apply_bond_stereo(mol, bonds)
    return mol


def _highest_cip_neighbor(mol: Any, atom_idx: int, exclude_idx: int) -> int | None:
    """The CIP-highest-ranked neighbor of ``atom_idx`` other than ``exclude_idx``.

    E/Z labels are defined against CIP priorities, so this is the reference atom a
    stereo double bond's label refers to. ``None`` when the atom has no other
    neighbor (a terminal double bond cannot carry cis/trans). Requires ``_CIPRank``
    props (``Chem.AssignStereochemistry(..., force=True)`` first).
    """
    best: int | None = None
    best_rank = -1
    for nbr in mol.GetAtomWithIdx(atom_idx).GetNeighbors():
        idx = nbr.GetIdx()
        if idx == exclude_idx:
            continue
        rank = int(nbr.GetPropsAsDict().get("_CIPRank", 0))
        if rank > best_rank:
            best_rank = rank
            best = idx
    return best


def _apply_bond_stereo(mol: Any, bonds: list[dict[str, Any]]) -> None:
    """Stamp the graph contract's E/Z double-bond labels onto a sanitized Mol.

    With the stereo atoms chosen as the CIP-highest neighbor on each side,
    STEREOTRANS is exactly E and STEREOCIS exactly Z. Distance-geometry embedding
    (ETKDG) then enforces the corresponding planar arrangement, and MolToSmiles
    writes the directional bonds. Labels on non-double bonds, unknown labels, and
    terminal double bonds are ignored (nothing to enforce).
    """
    from rdkit import Chem

    labeled = [
        (int(b["a"]), int(b["b"]), str(b.get("stereo", "none")).upper())
        for b in bonds
        if str(b.get("stereo", "none")).upper() in ("E", "Z") and int(b.get("order", 1)) == 2
    ]
    if not labeled:
        return
    # CIP ranks decide which neighbor each side's label refers to.
    Chem.AssignStereochemistry(mol, cleanIt=True, force=True)
    for a, b, label in labeled:
        bond = mol.GetBondBetweenAtoms(a, b)
        if bond is None or bond.GetBondType() != Chem.BondType.DOUBLE:
            continue
        na = _highest_cip_neighbor(mol, a, b)
        nb = _highest_cip_neighbor(mol, b, a)
        if na is None or nb is None:
            continue
        bond.SetStereoAtoms(na, nb)
        bond.SetStereo(
            Chem.BondStereo.STEREOTRANS if label == "E" else Chem.BondStereo.STEREOCIS
        )


def _stereo_label(mol: Any, bond: Any) -> str:
    """The graph contract's stereo label ("E" / "Z" / "none") for an RDKit bond.

    SMILES-parsed mols carry CIP-interpreted STEREOE/STEREOZ directly; mols built
    by :func:`_apply_bond_stereo` carry STEREOCIS/STEREOTRANS relative to their
    stereo atoms, which translate to E/Z by checking whether each stereo atom is
    the CIP-highest neighbor on its side (each non-highest reference flips the
    sense once).
    """
    from rdkit import Chem

    st = bond.GetStereo()
    if st == Chem.BondStereo.STEREOE:
        return "E"
    if st == Chem.BondStereo.STEREOZ:
        return "Z"
    if st not in (Chem.BondStereo.STEREOCIS, Chem.BondStereo.STEREOTRANS):
        return "none"
    stereo_atoms = list(bond.GetStereoAtoms())
    if len(stereo_atoms) != 2:
        return "none"
    begin = bond.GetBeginAtomIdx()
    end = bond.GetEndAtomIdx()
    # Sort the stereo atoms to (begin-side, end-side) by adjacency.
    if mol.GetBondBetweenAtoms(stereo_atoms[0], begin) is not None:
        ref_begin, ref_end = stereo_atoms[0], stereo_atoms[1]
    else:
        ref_begin, ref_end = stereo_atoms[1], stereo_atoms[0]
    hi_begin = _highest_cip_neighbor(mol, begin, end)
    hi_end = _highest_cip_neighbor(mol, end, begin)
    if hi_begin is None or hi_end is None:
        return "none"
    flips = int(ref_begin != hi_begin) + int(ref_end != hi_end)
    trans = st == Chem.BondStereo.STEREOTRANS
    if flips % 2 == 1:
        trans = not trans
    return "E" if trans else "Z"


def rdkit_to_graph(mol: Any) -> dict[str, Any]:
    """Convert an RDKit ``Mol`` back to the MoleculeGraph JSON contract.

    implicit_h comes from ``GetTotalNumHs`` (implicit + any explicit H neighbors
    that are not standalone heavy atoms — here we use the total H count RDKit
    tracks for the heavy-atom skeleton). Double-bond E/Z stereo is carried
    through (SMILES-imported isomers must reach the modeler as themselves).
    """
    from rdkit import Chem

    if mol.NeedsUpdatePropertyCache():
        Chem.SanitizeMol(mol)
    # CIP ranks for the CIS/TRANS→E/Z translation; cleanIt=False keeps any stereo
    # flags already on the mol.
    Chem.AssignStereochemistry(mol, cleanIt=False, force=True)

    atoms: list[dict[str, Any]] = []
    for atom in mol.GetAtoms():
        atoms.append(
            {
                "element": atom.GetSymbol(),
                "formal_charge": int(atom.GetFormalCharge()),
                "implicit_h": int(atom.GetTotalNumHs()),
                "aromatic": bool(atom.GetIsAromatic()),
                "isotope": int(atom.GetIsotope()),
            }
        )

    bonds: list[dict[str, Any]] = []
    for bond in mol.GetBonds():
        bonds.append(
            {
                "a": int(bond.GetBeginAtomIdx()),
                "b": int(bond.GetEndAtomIdx()),
                "order": _bondtype_to_order(bond),
                "stereo": _stereo_label(mol, bond),
            }
        )

    return {"atoms": atoms, "bonds": bonds}


def _coerce_mol(graph_or_smiles: Any) -> Any:
    """Accept either a graph dict or a SMILES string, return a sanitized Mol."""
    from rdkit import Chem

    if isinstance(graph_or_smiles, str):
        mol = Chem.MolFromSmiles(graph_or_smiles)
        if mol is None:
            raise ValueError(f"RDKit could not parse SMILES: {graph_or_smiles!r}")
        return mol
    return graph_to_rdkit(graph_or_smiles)


def canonical_smiles(graph_or_smiles: Any) -> tuple[str, str]:
    """Return (canonical SMILES, InChIKey) for a graph dict or SMILES string."""
    from rdkit import Chem

    mol = _coerce_mol(graph_or_smiles)
    smiles = Chem.MolToSmiles(mol)
    inchi = Chem.MolToInchi(mol)
    inchikey = Chem.InchiToInchiKey(inchi) if inchi else ""
    return smiles, inchikey


def depict_2d(graph: dict[str, Any]) -> list[dict[str, float]]:
    """Compute a clean 2D layout for the heavy-atom skeleton.

    Returns one ``{"x", "y"}`` per atom in the graph's atom order.
    """
    from rdkit.Chem import AllChem

    mol = graph_to_rdkit(graph)
    AllChem.Compute2DCoords(mol)
    conf = mol.GetConformer()
    coords: list[dict[str, float]] = []
    for i in range(mol.GetNumAtoms()):
        p = conf.GetAtomPosition(i)
        coords.append({"x": float(p.x), "y": float(p.y)})
    return coords


def _separate_fragments(molh: Any, warnings: list[str]) -> None:
    """Rigidly space out disconnected fragments in the embedded conformer.

    ETKDG embeds a dotted-SMILES / multi-component molecule (e.g. ``[Cl-].CBr``,
    a bimolecular reactant complex) with the fragments placed together and, since
    no bonds join them, MMFF cannot push them apart — RDKit routinely returns
    fragments overlapping (measured: Cl- 0.18 A from a carbon), which is unusable
    as a calculation input yet reports success. This lays the fragments out along
    one axis with a real gap between their van-der-Waals envelopes, moving each
    fragment RIGIDLY so its internal (MMFF-optimized) geometry is preserved, and
    warns that the inter-fragment placement is an arbitrary starting arrangement,
    not a bound complex.
    """
    from rdkit import Chem
    import numpy as np

    frags = Chem.GetMolFrags(molh, asMols=False)
    if len(frags) < 2:
        return

    conf = molh.GetConformer()
    pos = np.array(
        [[conf.GetAtomPosition(i).x, conf.GetAtomPosition(i).y, conf.GetAtomPosition(i).z]
         for i in range(molh.GetNumAtoms())]
    )
    # Per-fragment centroid + bounding radius (max atom distance from centroid).
    info = []
    for atom_ids in frags:
        idx = list(atom_ids)
        centroid = pos[idx].mean(axis=0)
        radius = float(np.max(np.linalg.norm(pos[idx] - centroid, axis=1))) if len(idx) > 1 else 0.0
        info.append((idx, centroid, radius))
    # Largest fragment first for a stable, compact layout.
    info.sort(key=lambda t: len(t[0]), reverse=True)

    gap = 2.5  # A between fragment vdW spheres — a sane non-bonded starting separation
    cursor = 0.0  # running x where the next fragment's LEFT edge goes
    for idx, centroid, radius in info:
        target_center = np.array([cursor + radius, 0.0, 0.0])
        pos[idx] += (target_center - centroid)  # rigid translation of the whole fragment
        cursor += 2.0 * radius + gap

    for i in range(molh.GetNumAtoms()):
        conf.SetAtomPosition(i, tuple(float(v) for v in pos[i]))
    warnings.append(
        "This structure has %d separate fragments; they were placed %.1f A apart in a "
        "line. That is an arbitrary starting arrangement — position them yourself (drag "
        "in the Modeler) or run a geometry optimization to get a bound complex."
        % (len(frags), gap)
    )


def embed_3d(graph: dict[str, Any]) -> dict[str, Any]:
    """Embed a 3D conformer (ETKDG v3) and MMFF-optimize it.

    Adds explicit hydrogens, embeds, optimizes, and returns the conformer
    coordinates (heavy atoms first in original order, then the added Hs) in
    Angstrom. A multi-fragment molecule (dotted SMILES) has its fragments spaced
    apart afterwards (they otherwise embed overlapping — see
    :func:`_separate_fragments`). The return is::

        {"coords_3d": [{"x","y","z"}, ...], "added_hs": bool, "num_heavy": int}
    """
    from rdkit import Chem
    from rdkit.Chem import AllChem

    mol = graph_to_rdkit(graph)
    num_heavy = mol.GetNumAtoms()
    molh = Chem.AddHs(mol)
    added_hs = molh.GetNumAtoms() > num_heavy

    params = AllChem.ETKDGv3()
    params.randomSeed = 0xF00D  # deterministic embed (regression-friendly)
    if AllChem.EmbedMolecule(molh, params) != 0:
        # Fall back to a non-seeded attempt if the seeded embed failed.
        if AllChem.EmbedMolecule(molh, AllChem.ETKDGv3()) != 0:
            raise ValueError("RDKit failed to embed a 3D conformer")
    mmff_warnings: list[str] = []
    try:
        AllChem.MMFFOptimizeMolecule(molh)
    except (ValueError, RuntimeError) as exc:
        # Optimization is best-effort; the embedded geometry is still valid. Surface that it
        # was skipped (don't silently return an unoptimized conformer) — the "degraded
        # capability warns" rule.
        mmff_warnings.append(f"MMFF optimization skipped: {exc}")

    # Space out disconnected fragments AFTER MMFF (which optimizes each fragment's
    # internal geometry but can't separate them — no inter-fragment bonds).
    _separate_fragments(molh, mmff_warnings)

    conf = molh.GetConformer()
    coords: list[dict[str, float]] = []
    for i in range(molh.GetNumAtoms()):
        p = conf.GetAtomPosition(i)
        coords.append({"x": float(p.x), "y": float(p.y), "z": float(p.z)})
    out: dict[str, Any] = {"coords_3d": coords, "added_hs": added_hs, "num_heavy": num_heavy}
    if mmff_warnings:
        out["warnings"] = mmff_warnings
    return out


def generate_conformers(
    graph: dict[str, Any], n_confs: int = 20, seed: int = 42
) -> dict[str, Any]:
    """Generate an ETKDGv3 conformer ensemble, MMFF-rank it, and return it sorted.

    Adds explicit hydrogens, embeds up to ``n_confs`` conformers (deterministic for a
    fixed ``seed``), MMFF-optimizes each (UFF fallback when MMFF lacks parameters),
    deduplicates near-identical rotamers by RMSD, and sorts ascending by energy.

    The coordinate order matches ``atom_symbols`` exactly: the input atoms first (graph
    order, explicit Hs included), then any hydrogens RDKit ``AddHs`` created — the SAME
    layout ``embed_3d`` uses, so the modeler adopts both the heavy atoms and the grown
    Hs through one shared apply path. Returns::

        {
          "conformers": [{"rank", "energy_kcalmol", "delta_e_kcalmol",
                          "coords_3d": [{"x","y","z"}, ...]}, ...],
          "atom_symbols": [str, ...],   # AddHs order; len == len(coords) per conformer
          "num_heavy": int,             # input atom count (Hs added beyond this)
          "n_generated": int,           # conformers embedded before dedup
          "n_unique": int,              # conformers returned after dedup
          "warnings": [str, ...],
        }

    Molecules with no rotatable freedom collapse to one conformer (fine). A failed
    embed (bad valence, RDKit refusal) raises — the sidecar turns it into a structured
    {"ok": false, "error": ...} document.
    """
    from rdkit import Chem
    from rdkit.Chem import AllChem

    warnings: list[str] = []
    # Cap the request so a pathological n keeps generation bounded (~100 is plenty for
    # the energy ladder; the embed cost is linear in conformer count).
    n_req = max(1, min(int(n_confs), 100))

    mol = graph_to_rdkit(graph)
    num_heavy = mol.GetNumAtoms()
    molh = Chem.AddHs(mol)

    params = AllChem.ETKDGv3()
    params.randomSeed = int(seed)
    params.numThreads = 1  # single-threaded → deterministic for a fixed seed
    # Prune near-identical embeds during generation so 20 tries of a near-rigid molecule
    # don't return 20 copies of one rotamer. 0.5 Å is the conventional ensemble threshold.
    params.pruneRmsThresh = 0.5

    conf_ids = list(AllChem.EmbedMultipleConfs(molh, numConfs=n_req, params=params))
    if not conf_ids:
        # ETKDG can refuse a single seed; retry once unseeded before giving up.
        retry = AllChem.ETKDGv3()
        retry.numThreads = 1
        retry.pruneRmsThresh = 0.5
        conf_ids = list(AllChem.EmbedMultipleConfs(molh, numConfs=n_req, params=retry))
        if not conf_ids:
            raise ValueError("RDKit failed to embed any 3D conformer")
        warnings.append("seeded embed produced no conformers; used an unseeded retry")
    n_generated = len(conf_ids)

    # MMFF-optimize every conformer in one shot when MMFF parameters exist for the whole
    # molecule; otherwise fall back to UFF (still gives a usable energy ladder) and say so.
    energies: dict[int, float] = {}
    mmff_ok = AllChem.MMFFHasAllMoleculeParams(molh)
    if mmff_ok:
        results = AllChem.MMFFOptimizeMoleculeConfs(molh, numThreads=1)
    else:
        warnings.append(
            "MMFF has no parameters for this molecule; ranked by UFF energy instead"
        )
        results = AllChem.UFFOptimizeMoleculeConfs(molh, numThreads=1)
    for cid, (converged, energy) in zip(conf_ids, results):
        # converged != 0 means the FF minimization hit its step cap — the geometry/energy
        # are still usable for ranking, but flag it once so the ladder isn't trusted blindly.
        if converged != 0:
            warnings.append("conformer %d force-field minimization did not converge" % cid)
        energies[cid] = float(energy)

    # Deduplicate by best-RMS (symmetry-aware) AFTER optimization — optimization can pull
    # two embeds into the same well that pruneRmsThresh let through pre-optimization.
    kept: list[int] = []
    probe = Chem.RemoveHs(molh)  # RMSD on heavy atoms is enough to tell rotamers apart
    for cid in sorted(conf_ids, key=lambda c: energies[c]):
        duplicate = False
        for ref in kept:
            rms = AllChem.GetBestRMS(probe, probe, prbId=cid, refId=ref)
            if rms < 0.5:
                duplicate = True
                break
        if not duplicate:
            kept.append(cid)

    kept.sort(key=lambda c: energies[c])
    e_min = energies[kept[0]]
    conformers: list[dict[str, Any]] = []
    for rank, cid in enumerate(kept):
        conf = molh.GetConformer(cid)
        coords = [
            {
                "x": float(conf.GetAtomPosition(i).x),
                "y": float(conf.GetAtomPosition(i).y),
                "z": float(conf.GetAtomPosition(i).z),
            }
            for i in range(molh.GetNumAtoms())
        ]
        conformers.append(
            {
                "rank": rank,
                "energy_kcalmol": energies[cid],
                "delta_e_kcalmol": energies[cid] - e_min,
                "coords_3d": coords,
            }
        )

    atom_symbols = [molh.GetAtomWithIdx(i).GetSymbol() for i in range(molh.GetNumAtoms())]
    return {
        "conformers": conformers,
        "atom_symbols": atom_symbols,
        "num_heavy": num_heavy,
        "n_generated": n_generated,
        "n_unique": len(kept),
        "warnings": warnings,
    }


def parse_smiles(smiles: str) -> tuple[dict[str, Any], list[dict[str, float]]]:
    """Parse a SMILES string into a (graph dict, 2D coords) pair."""
    from rdkit import Chem
    from rdkit.Chem import AllChem

    mol = Chem.MolFromSmiles(smiles)
    if mol is None:
        raise ValueError(f"RDKit could not parse SMILES: {smiles!r}")
    graph = rdkit_to_graph(mol)
    AllChem.Compute2DCoords(mol)
    conf = mol.GetConformer()
    coords: list[dict[str, float]] = []
    for i in range(mol.GetNumAtoms()):
        p = conf.GetAtomPosition(i)
        coords.append({"x": float(p.x), "y": float(p.y)})
    return graph, coords
